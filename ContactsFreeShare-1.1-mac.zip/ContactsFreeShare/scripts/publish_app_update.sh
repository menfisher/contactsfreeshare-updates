#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$ROOT_DIR/dist"
UPDATE_REPO="${CONTACTSFREESHARE_UPDATE_REPO:-menfisher/contactsfreeshare-updates}"
UPDATE_REPO_URL="${CONTACTSFREESHARE_UPDATE_REPO_URL:-git@github.com:${UPDATE_REPO}.git}"
UPDATE_BASE_URL="${CONTACTSFREESHARE_UPDATE_BASE_URL:-https://menfisher.github.io/contactsfreeshare-updates}"
UPDATE_MANIFEST_URL="${CONTACTSFREESHARE_UPDATE_MANIFEST_URL:-$UPDATE_BASE_URL/app_update_manifest.json}"
VERSION="${1:-}"
if [[ $# -gt 0 ]]; then
  shift
fi
if [[ $# -gt 0 ]]; then
  RELEASE_NOTES="$*"
else
  RELEASE_NOTES="${CONTACTSFREESHARE_RELEASE_NOTES:-ContactsFreeShare app update.}"
fi
RELEASE_NOTES="${RELEASE_NOTES#“}"
RELEASE_NOTES="${RELEASE_NOTES%”}"

usage() {
  cat <<'TEXT'
Usage:
  scripts/publish_app_update.sh VERSION "Release notes"

Example:
  scripts/publish_app_update.sh 1.1 "Bug fixes and app update publishing improvements."

Optional environment variables:
  CONTACTSFREESHARE_UPDATE_REPO=menfisher/contactsfreeshare-updates
  CONTACTSFREESHARE_UPDATE_REPO_URL=git@github.com:menfisher/contactsfreeshare-updates.git
  CONTACTSFREESHARE_UPDATE_BASE_URL=https://menfisher.github.io/contactsfreeshare-updates
  CONTACTSFREESHARE_UPDATE_MANIFEST_URL=https://menfisher.github.io/contactsfreeshare-updates/app_update_manifest.json
TEXT
}

if [[ "${VERSION:-}" == "-h" || "${VERSION:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ -z "$VERSION" ]]; then
  echo "Error: version is required."
  usage
  exit 1
fi

command -v git >/dev/null 2>&1 || {
  echo "Error: git is required."
  exit 1
}

printf '%s\n' "$VERSION" > "$ROOT_DIR/APP_VERSION"

CONTACTSFREESHARE_REVISION_VERSION="$VERSION" \
CONTACTSFREESHARE_REVISION_NOTES="$RELEASE_NOTES" \
python3 - <<'PY'
import os
from datetime import datetime

from app.services.app_revision_service import record_app_revision

today = datetime.now()
record_app_revision(
    version=os.environ["CONTACTSFREESHARE_REVISION_VERSION"],
    description=os.environ["CONTACTSFREESHARE_REVISION_NOTES"],
    date_display=f"{today.month}/{today.day}/{today.year}",
    export_to_drive=False,
)
PY

CONTACTSFREESHARE_UPDATE_MANIFEST_URL="$UPDATE_MANIFEST_URL" bash "$ROOT_DIR/scripts/build_portable_app.sh"

MANIFEST_TEMPLATE="$BUILD_DIR/app_update_manifest.example.json"
MANIFEST_FILE="$BUILD_DIR/app_update_manifest.json"
MAC_PACKAGE="$BUILD_DIR/ContactsFreeShare-${VERSION}-mac.zip"
WINDOWS_PACKAGE="$BUILD_DIR/ContactsFreeShare-${VERSION}-windows.zip"

if [[ ! -f "$MANIFEST_TEMPLATE" || ! -f "$MAC_PACKAGE" || ! -f "$WINDOWS_PACKAGE" ]]; then
  echo "Error: expected build output was not found in $BUILD_DIR."
  exit 1
fi

python3 - "$MANIFEST_TEMPLATE" "$MANIFEST_FILE" "$RELEASE_NOTES" <<'PY'
import json
import sys
from pathlib import Path

source = Path(sys.argv[1])
target = Path(sys.argv[2])
notes = sys.argv[3]

payload = json.loads(source.read_text(encoding="utf-8"))
payload["notes"] = notes
target.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
PY

WORK_DIR="$(mktemp -d)"
cleanup() {
  rm -rf "$WORK_DIR"
}
trap cleanup EXIT

git clone --quiet "$UPDATE_REPO_URL" "$WORK_DIR/update-repo"

cp "$MANIFEST_FILE" "$WORK_DIR/update-repo/app_update_manifest.json"
cp "$MAC_PACKAGE" "$WORK_DIR/update-repo/"
cp "$WINDOWS_PACKAGE" "$WORK_DIR/update-repo/"

git -C "$WORK_DIR/update-repo" add app_update_manifest.json "ContactsFreeShare-${VERSION}-mac.zip" "ContactsFreeShare-${VERSION}-windows.zip"

if git -C "$WORK_DIR/update-repo" diff --cached --quiet; then
  echo "No update file changes to publish."
  exit 0
fi

git -C "$WORK_DIR/update-repo" commit -m "Publish ContactsFreeShare ${VERSION} update"
git -C "$WORK_DIR/update-repo" push

echo "Published ContactsFreeShare $VERSION update:"
echo "$UPDATE_MANIFEST_URL"
