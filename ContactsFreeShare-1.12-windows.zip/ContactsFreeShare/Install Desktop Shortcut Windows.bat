@echo off
setlocal

cd /d "%~dp0"

set "APP_DIR=%~dp0"
set "TARGET=%APP_DIR%Start ContactsFreeShare Windows.bat"
set "ICON=%APP_DIR%app\static\img\contactsfreeshare-icon.ico"
set "SHORTCUT_NAME=ContactsFS.lnk"

if not exist "%TARGET%" (
  echo Start ContactsFreeShare Windows.bat was not found in:
  echo %APP_DIR%
  echo.
  echo Keep this installer inside the ContactsFreeShare folder and run it again.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$desktop=[Environment]::GetFolderPath('Desktop');" ^
  "$shell=New-Object -ComObject WScript.Shell;" ^
  "$shortcut=$shell.CreateShortcut((Join-Path $desktop '%SHORTCUT_NAME%'));" ^
  "$shortcut.TargetPath=$env:TARGET;" ^
  "$shortcut.WorkingDirectory=$env:APP_DIR;" ^
  "$shortcut.Description='Open ContactsFreeShare';" ^
  "if (Test-Path $env:ICON) { $shortcut.IconLocation=$env:ICON };" ^
  "$shortcut.Save()"

if errorlevel 1 (
  echo.
  echo The desktop shortcut could not be created.
  echo You can still start the app by double-clicking Start ContactsFreeShare Windows.bat.
  echo.
  pause
  exit /b 1
)

echo.
echo ContactsFS desktop shortcut installed.
echo Double-click the ContactsFS icon on your Desktop to open the app.
echo.
pause
