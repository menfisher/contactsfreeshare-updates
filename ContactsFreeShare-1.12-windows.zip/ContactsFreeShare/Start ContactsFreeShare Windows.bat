@echo off
setlocal

cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python 3 was not found.
    echo Attempting to install Python 3 with Windows Package Manager...
    where winget >nul 2>nul
    if errorlevel 1 (
      echo.
      echo Windows Package Manager was not found on this computer.
      echo Install Python 3 from https://www.python.org/downloads/windows/
      echo During install, check "Add python.exe to PATH", then run this file again.
      echo.
      pause
      exit /b 1
    )
    winget install --id Python.Python.3.12 --exact --source winget --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
      echo.
      echo Python installation did not finish successfully.
      echo Install Python 3 from https://www.python.org/downloads/windows/
      echo During install, check "Add python.exe to PATH", then run this file again.
      echo.
      pause
      exit /b 1
    )
    where py >nul 2>nul
    if errorlevel 1 (
      where python >nul 2>nul
      if errorlevel 1 (
        echo.
        echo Python was installed, but Windows has not refreshed the command path yet.
        echo Close this window and run Start ContactsFreeShare Windows.bat again.
        echo.
        pause
        exit /b 1
      )
    )
  )
)

if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 (
    python -m venv .venv
  )
  if errorlevel 1 (
    echo.
    echo Python is installed, but the virtual environment could not be created.
    echo Close this window and run Start ContactsFreeShare Windows.bat again.
    echo.
    pause
    exit /b 1
  )
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python run_contactsfreeshare.py
pause
