#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$ROOT_DIR/dist"
APP_DIR="$BUILD_DIR/ContactsFreeShare"

rm -rf "$APP_DIR"
mkdir -p "$APP_DIR"

rsync -a \
  --exclude '.git' \
  --exclude '.venv' \
  --exclude '__pycache__' \
  --exclude '*.pyc' \
  --exclude '.env' \
  --exclude 'UPDATE_MANIFEST_URL' \
  --exclude 'db/app.sqlite3' \
  --exclude 'db/app.sqlite3-*' \
  --exclude 'db/contacts.db' \
  --exclude 'app/static/uploads' \
  --exclude 'logs' \
  --exclude 'runtime' \
  --exclude 'uploads' \
  --exclude 'dist' \
  "$ROOT_DIR/" "$APP_DIR/"

{
  echo "ContactsFreeShare portable build"
  echo "built_at=$(date '+%Y-%m-%d %H:%M:%S %Z')"
  echo "source_dir=$ROOT_DIR"
} > "$APP_DIR/BUILD_INFO.txt"

cat > "$APP_DIR/Start ContactsFreeShare.command" <<'SCRIPT'
#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi

source ".venv/bin/activate"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python run_contactsfreeshare.py
SCRIPT

chmod +x "$APP_DIR/Start ContactsFreeShare.command"

cat > "$APP_DIR/Install Desktop Shortcut Mac.command" <<'SCRIPT'
#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="$APP_DIR/Start ContactsFreeShare.command"
ICON_SRC="$APP_DIR/app/static/img/contactsfreeshare-icon.icns"
DESKTOP_DIR="$HOME/Desktop"
APP_BUNDLE="$DESKTOP_DIR/ContactsFS.app"

if [ ! -f "$TARGET" ]; then
  echo "Start ContactsFreeShare.command was not found in:"
  echo "$APP_DIR"
  echo
  echo "Keep this installer inside the ContactsFreeShare folder and run it again."
  read -r -p "Press Return to close."
  exit 1
fi

rm -rf "$APP_BUNDLE"
mkdir -p "$APP_BUNDLE/Contents/MacOS" "$APP_BUNDLE/Contents/Resources"

if [ -f "$ICON_SRC" ]; then
  cp "$ICON_SRC" "$APP_BUNDLE/Contents/Resources/ContactsFreeShare.icns"
fi

cat > "$APP_BUNDLE/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleDisplayName</key>
  <string>ContactsFS</string>
  <key>CFBundleExecutable</key>
  <string>ContactsFreeShare</string>
  <key>CFBundleIconFile</key>
  <string>ContactsFreeShare</string>
  <key>CFBundleIdentifier</key>
  <string>local.contactsfreeshare.launcher</string>
  <key>CFBundleName</key>
  <string>ContactsFS</string>
  <key>CFBundlePackageType</key>
  <string>APPL</string>
  <key>LSMinimumSystemVersion</key>
  <string>10.13</string>
</dict>
</plist>
PLIST

{
  echo '#!/usr/bin/env bash'
  printf 'TARGET=%q\n' "$TARGET"
  echo 'if [ ! -f "$TARGET" ]; then'
  echo '  osascript -e "display dialog \"ContactsFreeShare could not find its start file. Re-run Install Desktop Shortcut Mac.command from the ContactsFreeShare folder.\" buttons {\"OK\"} default button \"OK\" with icon caution" >/dev/null 2>&1 || true'
  echo '  exit 1'
  echo 'fi'
  echo 'open "$TARGET"'
} > "$APP_BUNDLE/Contents/MacOS/ContactsFreeShare"
chmod +x "$APP_BUNDLE/Contents/MacOS/ContactsFreeShare"
touch "$APP_BUNDLE"

echo
echo "ContactsFS desktop app installed."
echo "Double-click the ContactsFS icon on your Desktop to open the app."
echo "Keep the unzipped ContactsFreeShare folder in this location:"
echo "$APP_DIR"
echo
read -r -p "Press Return to close."
SCRIPT

chmod +x "$APP_DIR/Install Desktop Shortcut Mac.command"

cat > "$APP_DIR/Start ContactsFreeShare Windows.bat" <<'SCRIPT'
@echo off
setlocal

cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python 3 was not found.
    echo Attempting to install Python 3 with Windows Package Manager...
    where winget >nul 2>nul
    if errorlevel 1 (
      echo.
      echo Windows Package Manager was not found on this computer.
      echo Install Python 3 from https://www.python.org/downloads/windows/
      echo During install, check "Add python.exe to PATH", then run this file again.
      echo.
      pause
      exit /b 1
    )
    winget install --id Python.Python.3.12 --exact --source winget --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
      echo.
      echo Python installation did not finish successfully.
      echo Install Python 3 from https://www.python.org/downloads/windows/
      echo During install, check "Add python.exe to PATH", then run this file again.
      echo.
      pause
      exit /b 1
    )
    where py >nul 2>nul
    if errorlevel 1 (
      where python >nul 2>nul
      if errorlevel 1 (
        echo.
        echo Python was installed, but Windows has not refreshed the command path yet.
        echo Close this window and run Start ContactsFreeShare Windows.bat again.
        echo.
        pause
        exit /b 1
      )
    )
  )
)

if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 (
    python -m venv .venv
  )
  if errorlevel 1 (
    echo.
    echo Python is installed, but the virtual environment could not be created.
    echo Close this window and run Start ContactsFreeShare Windows.bat again.
    echo.
    pause
    exit /b 1
  )
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python run_contactsfreeshare.py
pause
SCRIPT

cat > "$APP_DIR/Install Desktop Shortcut Windows.bat" <<'SCRIPT'
@echo off
setlocal

cd /d "%~dp0"

set "APP_DIR=%~dp0"
set "TARGET=%APP_DIR%Start ContactsFreeShare Windows.bat"
set "ICON=%APP_DIR%app\static\img\contactsfreeshare-icon.ico"
set "SHORTCUT_NAME=ContactsFS.lnk"

if not exist "%TARGET%" (
  echo Start ContactsFreeShare Windows.bat was not found in:
  echo %APP_DIR%
  echo.
  echo Keep this installer inside the ContactsFreeShare folder and run it again.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$desktop=[Environment]::GetFolderPath('Desktop');" ^
  "$shell=New-Object -ComObject WScript.Shell;" ^
  "$shortcut=$shell.CreateShortcut((Join-Path $desktop '%SHORTCUT_NAME%'));" ^
  "$shortcut.TargetPath=$env:TARGET;" ^
  "$shortcut.WorkingDirectory=$env:APP_DIR;" ^
  "$shortcut.Description='Open ContactsFreeShare';" ^
  "if (Test-Path $env:ICON) { $shortcut.IconLocation=$env:ICON };" ^
  "$shortcut.Save()"

if errorlevel 1 (
  echo.
  echo The desktop shortcut could not be created.
  echo You can still start the app by double-clicking Start ContactsFreeShare Windows.bat.
  echo.
  pause
  exit /b 1
)

echo.
echo ContactsFS desktop shortcut installed.
echo Double-click the ContactsFS icon on your Desktop to open the app.
echo.
pause
SCRIPT

APP_VERSION="$(tr -d '[:space:]' < "$ROOT_DIR/APP_VERSION")"
APP_VERSION="${APP_VERSION:-1.0}"
MAC_PACKAGE="ContactsFreeShare-${APP_VERSION}-mac.zip"
WINDOWS_PACKAGE="ContactsFreeShare-${APP_VERSION}-windows.zip"
PUBLIC_MANIFEST_URL="${CONTACTSFREESHARE_UPDATE_MANIFEST_URL:-}"
CLEAN_UPDATE_PACKAGES="${CONTACTSFREESHARE_CLEAN_UPDATE_PACKAGES:-1}"

if [ -n "$PUBLIC_MANIFEST_URL" ]; then
  printf '%s\n' "$PUBLIC_MANIFEST_URL" > "$APP_DIR/UPDATE_MANIFEST_URL"
fi

if [ "$CLEAN_UPDATE_PACKAGES" != "0" ]; then
  find "$BUILD_DIR" -maxdepth 1 -type f \( -name 'ContactsFreeShare-*-mac.zip' -o -name 'ContactsFreeShare-*-windows.zip' -o -name 'app_update_manifest.json' \) -delete
fi
rm -f "$BUILD_DIR/$MAC_PACKAGE" "$BUILD_DIR/$WINDOWS_PACKAGE"
(cd "$BUILD_DIR" && zip -qr "$MAC_PACKAGE" "ContactsFreeShare")
(cd "$BUILD_DIR" && zip -qr "$WINDOWS_PACKAGE" "ContactsFreeShare")

cat > "$BUILD_DIR/app_update_manifest.example.json" <<SCRIPT
{
  "format": "contactsfreeshare.app_update.v1",
  "latest_version": "$APP_VERSION",
  "release_date": "$(date '+%Y-%m-%d')",
  "notes": "Describe what changed in this release.",
  "packages": {
    "mac": {
      "label": "Mac",
      "filename": "$MAC_PACKAGE",
      "download_url": "$MAC_PACKAGE",
      "file_id": "",
      "mime_type": "application/zip"
    },
    "windows": {
      "label": "Windows",
      "filename": "$WINDOWS_PACKAGE",
      "download_url": "$WINDOWS_PACKAGE",
      "file_id": "",
      "mime_type": "application/zip"
    }
  }
}
SCRIPT

echo "Portable app created at:"
echo "$APP_DIR"
echo "Update packages created at:"
echo "$BUILD_DIR/$MAC_PACKAGE"
echo "$BUILD_DIR/$WINDOWS_PACKAGE"
echo "Manifest template created at:"
echo "$BUILD_DIR/app_update_manifest.example.json"
if [ -n "$PUBLIC_MANIFEST_URL" ]; then
  echo "Public update manifest URL embedded at:"
  echo "$APP_DIR/UPDATE_MANIFEST_URL"
fi
