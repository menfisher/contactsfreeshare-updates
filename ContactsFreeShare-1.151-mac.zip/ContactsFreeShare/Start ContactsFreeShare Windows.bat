@echo off
setlocal

pushd "%~dp0"
if errorlevel 1 (
  echo.
  echo ContactsFreeShare could not open its app folder.
  echo Copy the ContactsFreeShare folder to a local Windows folder and run this file again.
  echo.
  pause
  exit /b 1
)

set "PYTHON_CMD="

where py >nul 2>nul
if not errorlevel 1 (
  set "PYTHON_CMD=py -3"
) else (
  where python >nul 2>nul
  if not errorlevel 1 (
    set "PYTHON_CMD=python"
  )
)

if not "%PYTHON_CMD%"=="" (
  %PYTHON_CMD% --version >nul 2>nul
  if errorlevel 1 (
    set "PYTHON_CMD="
  )
)

if "%PYTHON_CMD%"=="" (
  echo Python 3 was not found.
  if exist "vendor\python\windows\python-3.13.13-amd64.exe" (
    echo Installing Python 3.13 from the included offline installer...
    "vendor\python\windows\python-3.13.13-amd64.exe" /quiet InstallAllUsers=0 TargetDir="%LOCALAPPDATA%\Programs\Python\Python313" Include_launcher=1 Include_pip=1 Include_test=0 PrependPath=1
    if errorlevel 1 (
      echo.
      echo Python installation did not finish successfully.
      echo.
      pause
      exit /b 1
    )
    if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" (
      set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    )
  ) else (
    echo.
    echo The included Python installer was not found.
    echo Install Python 3 from https://www.python.org/downloads/windows/ and run this file again.
    echo.
    pause
    exit /b 1
  )
)

if "%PYTHON_CMD%"=="" (
  where py >nul 2>nul
  if not errorlevel 1 (
    set "PYTHON_CMD=py -3"
  ) else (
    where python >nul 2>nul
    if not errorlevel 1 (
      set "PYTHON_CMD=python"
    )
  )
)

if not "%PYTHON_CMD%"=="" (
  %PYTHON_CMD% --version >nul 2>nul
  if errorlevel 1 (
    set "PYTHON_CMD="
  )
)

if "%PYTHON_CMD%"=="" (
  echo.
  echo Python was installed, but it could not be found yet.
  echo Close this window and run Start ContactsFreeShare Windows.bat again.
  echo.
  pause
  exit /b 1
)

%PYTHON_CMD% --version
if errorlevel 1 (
  echo.
  echo Python could not be started.
  echo.
  pause
  exit /b 1
)

for /f "tokens=2 delims= " %%V in ('%PYTHON_CMD% --version 2^>^&1') do set "PYTHON_VERSION=%%V"
echo Using Python %PYTHON_VERSION%

echo %PYTHON_VERSION% | findstr /b "3.12 3.13" >nul
if errorlevel 1 (
  echo.
  echo ContactsFreeShare offline dependencies are bundled for Python 3.12 and 3.13.
  echo Install Python 3.12 or 3.13, or run this launcher while connected to the Internet.
  echo.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 (
    echo.
    echo Python is installed, but the virtual environment could not be created.
    echo Close this window and run Start ContactsFreeShare Windows.bat again.
    echo.
    pause
    exit /b 1
  )
)

".venv\Scripts\python.exe" -c "print('ok')" >nul 2>nul
if errorlevel 1 (
  rmdir /s /q ".venv"
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 (
    echo.
    echo Python is installed, but the virtual environment could not be created.
    echo Close this window and run Start ContactsFreeShare Windows.bat again.
    echo.
    pause
    exit /b 1
  )
)

".venv\Scripts\python.exe" -c "import fastapi, uvicorn, jinja2, multipart" >nul 2>nul
if errorlevel 1 (
  echo Installing ContactsFreeShare Python dependencies...
  if exist "vendor\wheels" (
    ".venv\Scripts\python.exe" -m pip install --no-index --find-links "vendor\wheels" -r requirements.txt
  ) else (
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  )
  if errorlevel 1 (
    echo.
    echo ContactsFreeShare dependencies could not be installed.
    echo Connect to the Internet and run this file again, or use a package that already includes a prepared .venv folder.
    echo.
    pause
    exit /b 1
  )
)
".venv\Scripts\python.exe" run_contactsfreeshare.py
pause
