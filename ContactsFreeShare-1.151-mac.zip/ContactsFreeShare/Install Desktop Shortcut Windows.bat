@echo off
setlocal

set "SOURCE_DIR=%~dp0"
pushd "%~dp0"
if errorlevel 1 (
  echo.
  echo ContactsFreeShare could not open its app folder.
  echo Copy the ContactsFreeShare folder to a local Windows folder and run this file again.
  echo.
  pause
  exit /b 1
)

set "APP_DIR=%SOURCE_DIR%"
set "TARGET=%APP_DIR%Start ContactsFreeShare Windows.bat"
set "ICON=%APP_DIR%app\static\img\contactsfreeshare-icon.ico"
set "LOCAL_ICON_DIR=%LOCALAPPDATA%\ContactsFreeShare"
set "LOCAL_ICON=%LOCAL_ICON_DIR%\contactsfreeshare-icon-transparent.ico"
set "SHORTCUT_NAME=ContactsFS.lnk"

if not exist "%TARGET%" (
  echo Start ContactsFreeShare Windows.bat was not found in:
  echo %APP_DIR%
  echo.
  echo Keep this installer inside the ContactsFreeShare folder and run it again.
  pause
  exit /b 1
)

if exist "%ICON%" (
  if not exist "%LOCAL_ICON_DIR%" mkdir "%LOCAL_ICON_DIR%" >nul 2>nul
  copy /Y "%ICON%" "%LOCAL_ICON%" >nul 2>nul
  if exist "%LOCAL_ICON%" set "ICON=%LOCAL_ICON%"
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$desktop=[Environment]::GetFolderPath('Desktop');" ^
  "$shortcutPath=Join-Path $desktop '%SHORTCUT_NAME%';" ^
  "if (Test-Path $shortcutPath) { Remove-Item $shortcutPath -Force };" ^
  "$shell=New-Object -ComObject WScript.Shell;" ^
  "$shortcut=$shell.CreateShortcut($shortcutPath);" ^
  "$shortcut.TargetPath=$env:TARGET;" ^
  "$shortcut.WorkingDirectory=$desktop;" ^
  "$shortcut.Description='Open ContactsFreeShare';" ^
  "if (Test-Path $env:ICON) { $shortcut.IconLocation=($env:ICON + ',0') };" ^
  "$shortcut.Save()"

if errorlevel 1 (
  echo.
  echo The desktop shortcut could not be created.
  echo You can still start the app by double-clicking Start ContactsFreeShare Windows.bat.
  echo.
  pause
  exit /b 1
)

echo.
echo ContactsFS desktop shortcut installed.
echo Double-click the ContactsFS icon on your Desktop to open the app.
echo.
pause
