from __future__ import annotations

import base64
import hashlib
import hmac
import http.client
import json
import mimetypes
import re
import secrets
import socket
import sqlite3
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, unquote_plus, urlencode
from urllib.request import Request, urlopen

from app.config import (
    GOOGLE_OAUTH_CLIENT_ID,
    GOOGLE_OAUTH_CLIENT_SECRET,
    GOOGLE_OAUTH_REDIRECT_URI,
    GOOGLE_PICKER_API_KEY,
    GOOGLE_PICKER_APP_ID,
    UPLOADS_DIR,
)
from app.database import get_connection


GOOGLE_AUTH_BASE_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://openidconnect.googleapis.com/v1/userinfo"
GOOGLE_PEOPLE_BASE_URL = "https://people.googleapis.com/v1"
GOOGLE_DRIVE_BASE_URL = "https://www.googleapis.com/drive/v3"
GOOGLE_DRIVE_UPLOAD_BASE_URL = "https://www.googleapis.com/upload/drive/v3"
GOOGLE_SCOPES = [
    "openid",
    "email",
    "https://www.googleapis.com/auth/contacts",
    "https://www.googleapis.com/auth/drive.file",
]
GOOGLE_DRIVE_VISIBLE_SCOPES = {
    "https://www.googleapis.com/auth/drive.file",
}
GOOGLE_DRIVE_ROOT_FOLDER_NAME = "ContactsFreeShare"
GOOGLE_DRIVE_BACKUPS_FOLDER_NAME = "Backups"
GOOGLE_DRIVE_ADDRESS_BOOK_PDFS_FOLDER_NAME = "Address Book PDF's"
GOOGLE_DRIVE_ADDRESS_BOOK_PRINTED_FOLDER_NAME = "Address Book Printed"
GOOGLE_DRIVE_ADDRESS_BOOK_PDF_RETENTION_LIMIT = 15
GOOGLE_DRIVE_SHARED_ADDRESS_BOOK_FOLDER_NAME = ""
GOOGLE_DRIVE_SHARED_ADDRESS_BOOK_FOLDER_ID = ""
GOOGLE_DRIVE_SHARED_FOLDER_NAME = "Shared"
GOOGLE_DRIVE_SHARED_CONTACT_RECORDS_FOLDER_NAME = "Contacts"
GOOGLE_DRIVE_SHARED_CONTACT_PHOTOS_FOLDER_NAME = "Contact Photos"
GOOGLE_DRIVE_APP_REVISIONS_FOLDER_NAME = "App Revisions"
GOOGLE_DRIVE_APP_REVISIONS_FILE_NAME = "app_revisions.json"
GOOGLE_DRIVE_APP_UPDATES_FOLDER_NAME = "App Updates"
GOOGLE_DRIVE_APP_UPDATE_MANIFEST_FILE_NAME = "app_update_manifest.json"
GOOGLE_DRIVE_EDITOR_LOCK_FILE_NAME = "editor_lock.json"
GOOGLE_DRIVE_CONTACTS_CURRENT_FILE_NAME = "contacts_current.json"
GOOGLE_DRIVE_CONTACTS_FULL_FILE_NAME = "contacts_current_full.json"
GOOGLE_DRIVE_MEETINGDATA_CURRENT_FILE_NAME = "meetingdata_current.json"
GOOGLE_DRIVE_FIELD_LIST_CURRENT_FILE_NAME = "field_list_current.json"
GOOGLE_DRIVE_SETTINGS_CURRENT_FILE_NAME = "settings_current.json"
GOOGLE_DRIVE_BOOK_LAYOUTS_CURRENT_FILE_NAME = "book_layouts_current.json"
GOOGLE_DRIVE_CHANGES_LIST_CURRENT_FILE_NAME = "changes_list_current.json"
GOOGLE_DRIVE_SHARED_SYNC_STATE_FILE_NAME = "shared_sync_state.json"
EDITOR_LOCK_TIMEOUT_SECONDS = 60 * 60
EDITOR_LOCK_EXTENSION_MINUTES = 15
DEFAULT_EDITOR_SECRET = "test"
EDITOR_SECRET_ITERATIONS = 260_000
DEFAULT_HTTP_TIMEOUT_SECONDS = 30
DRIVE_UPLOAD_TIMEOUT_SECONDS = 180
DRIVE_JSON_UPLOAD_TIMEOUT_SECONDS = 45
DRIVE_READ_RETRY_ATTEMPTS = 4
DRIVE_READ_RETRY_BASE_SECONDS = 1.5
STALE_UPLOAD_PROGRESS_SECONDS = 5 * 60
STALE_SIGNIN_SYNC_SECONDS = 90
DRIVE_BOOTSTRAP_BATCH_SIZE = 25
DRIVE_BOOTSTRAP_VISIBLE_PROGRESS_STEP = 10
ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_INTERVAL_SECONDS = 5
ADDRESS_BOOK_PDF_APP_PROPERTY_KIND = "contactsfreeshare.address_book_pdf"
CONTACT_PHOTO_STATIC_PREFIX = "/static/uploads/contact_photos/"
CONTACT_PHOTO_STORAGE_DIR = UPLOADS_DIR / "contact_photos"
BOOK_LAYOUT_SETTING_COLUMNS = [
    "id",
    "name",
    "book_title",
    "trim_width_in",
    "trim_height_in",
    "margin_left_in",
    "margin_right_in",
    "margin_top_in",
    "margin_bottom_in",
    "font_family",
    "base_font_size_pt",
    "line_height",
    "meeting_table_column_count",
    "meeting_table_column_gap_px",
    "screen_preview_scale",
    "meetingdata_title_bar_color",
    "meetingdata_primary_row_color",
    "meetingdata_secondary_row_color",
    "meetingdata_highlight_row_color",
    "contacts_title_bar_color",
    "contacts_primary_row_color",
    "contacts_secondary_row_color",
    "contacts_highlight_row_color",
    "is_default",
]
BOOK_LAYOUT_COLOR_COLUMNS = [
    "meetingdata_title_bar_color",
    "meetingdata_primary_row_color",
    "meetingdata_secondary_row_color",
    "meetingdata_highlight_row_color",
    "contacts_title_bar_color",
    "contacts_primary_row_color",
    "contacts_secondary_row_color",
    "contacts_highlight_row_color",
]
GOOGLE_IMPORT_PERSON_FIELDS = ",".join(
    [
        "addresses",
        "biographies",
        "birthdays",
        "emailAddresses",
        "memberships",
        "metadata",
        "names",
        "organizations",
        "phoneNumbers",
        "photos",
        "relations",
        "userDefined",
        "urls",
    ]
)

SYNC_NOTICE_MESSAGES = {
    "settings_saved": "Google sync settings were saved locally.",
    "oauth_not_configured": "Google OAuth is not configured yet. Add GOOGLE_OAUTH_CLIENT_ID and GOOGLE_OAUTH_CLIENT_SECRET before connecting.",
    "google_connected": "Google account connected successfully.",
    "google_disconnected": "Google account connection was removed from the app.",
    "import_not_connected": "Connect a Google account before importing contacts.",
    "import_success": "Google contacts were imported into the app and replaced the previous local contact set.",
    "import_failed": "Google import failed. Review Google Connect status and try again.",
    "upload_not_connected": "Reconnect Google before uploading local contact changes.",
    "upload_success": "Queued local contact changes and shared app changes were uploaded successfully.",
    "upload_failed": "Upload failed. Local changes remain queued. Reconnect Google if this keeps happening, then click Upload again.",
    "upload_pending": "Upload is not finished. Click Upload again to continue.",
    "upload_queue_empty": "There are no local contact or shared app changes waiting to upload.",
    "drive_not_connected": "Connect a Google account before creating Google Drive folders, exporting, or backing up to Drive.",
    "drive_scope_missing": "Drive file access has not been granted to the current Google connection yet. Reconnect the Google account to approve Google Drive file access.",
    "drive_storage_ready": "Google Drive storage is ready for App Revisions.",
    "drive_export_success": "App Revisions were exported to Google Drive successfully.",
    "drive_export_failed": "Google Drive export failed. Local App Revisions were still saved in the app.",
    "drive_import_success": "App Revisions were refreshed from Google Drive successfully.",
    "drive_import_failed": "Google Drive refresh failed. Local App Revisions were left unchanged.",
    "app_update_available": "A newer ContactsFreeShare app package is available.",
    "app_update_current": "ContactsFreeShare is already up to date.",
    "app_update_installed_newer": "This installed copy is newer than the latest published update package.",
    "app_update_check_failed": "App update check failed. Confirm the public update manifest URL is set and reachable.",
    "app_update_download_failed": "App update download failed. Try checking for updates again.",
    "app_update_install_failed": "Automatic app update failed. Download the update package and open it manually.",
    "contacts_export_local_failed": "Contacts export to this computer failed or was cancelled before completion.",
    "contacts_export_drive_success": "Contacts were exported to Google Drive successfully.",
    "contacts_export_drive_failed": "Contacts export to Google Drive failed.",
    "contacts_backup_drive_success": "Contacts backup was saved to Google Drive successfully.",
    "contacts_backup_drive_failed": "Contacts backup to Google Drive failed.",
    "meetingdata_backup_drive_success": "MeetingData backup was saved to Google Drive successfully.",
    "meetingdata_backup_drive_failed": "MeetingData backup to Google Drive failed.",
    "backup_local_failed": "Backup to this computer failed or was cancelled before completion.",
    "backup_import_success": "Backup was imported successfully.",
    "backup_import_failed": "Backup import failed. Existing local data was left unchanged.",
    "backup_import_missing_selection": "Choose one backup file to import.",
    "contact_photo_google_success": "Contact photo was uploaded to Google Contacts successfully.",
    "contact_photo_google_failed": "Contact photo upload to Google Contacts failed.",
    "contact_photo_google_missing": "Choose or save an app photo before uploading it to Google Contacts.",
    "contact_photo_google_not_connected": "Connect this contact to Google before uploading its photo.",
    "contact_saved": "Contact was saved.",
    "multi_editor_settings_saved": "ContactsFreeShare settings were saved locally and queued for the next Drive upload.",
    "multi_editor_account_locked": "This Google account is already set for multiple Editors. Single-Editor editing is not allowed.",
    "editor_secret_saved": "Editor secret was saved locally and queued for the next Drive upload.",
    "shared_settings_imported": "Shared app settings and book layouts were imported from Drive.",
    "editor_name_required": "Enter an Editor name before signing in.",
    "editor_secret_required": "Tap the lock and enter the Editor secret before signing in.",
    "editor_secret_invalid": "Editor secret is not correct. The app remains in NO-EDIT mode.",
    "editor_signed_in": "Editor session is active.",
    "editor_signed_out": "Editor session ended.",
    "editor_signout_before_disconnect": "Sign out as Editor before disconnecting or switching the Google account.",
    "field_list_saved": "Field List template was saved locally and queued for the next Drive upload.",
    "address_book_settings_saved": "Field List settings were saved locally and queued for the next Drive upload.",
    "address_book_pdf_uploaded": "Address Book PDF was saved to Google Drive.",
    "address_book_pdf_created": "Address Book PDF was created for preview. Save it to this computer or print it from the preview.",
    "address_book_pdf_failed": "Address Book PDF export failed.",
    "address_book_pdf_preview_drive_failed": "Address Book PDF was created for preview, but Drive upload failed.",
    "address_book_pdf_preview_shared_drive_failed": "Address Book PDF was saved to the app Drive folder, but the shared folder copy failed.",
    "editor_lock_blocked": "This app is in NO-EDIT mode. Sign in as an Editor to make changes.",
    "editor_lock_stale": "The previous Editor session is stale. Confirm takeover to edit.",
    "editor_lock_failed": "Editor sign-in failed. The app is in NO-EDIT mode.",
    "access_name_required": "Enter a name before signing in.",
    "access_signed_in": "Access session is active.",
    "changes_list_connect_google_before_signout": "Connect a Google account before signing out so Changes List edits can be saved to Drive.",
    "signin_sync_blocked": "Editor sign-in is still syncing shared data from Drive. Editing is temporarily unavailable.",
    "signin_sync_failed_blocked": "Editor sign-in sync did not finish. Retry Google Connect sign-in sync before editing.",
    "signin_sync_retry_started": "Shared Drive sync resumed.",
    "bootstrap_editing_blocked": "Drive bootstrap is in progress. Editing is temporarily unavailable.",
    "bootstrap_failed_blocked": "Drive bootstrap did not finish. Resume Upload before editing.",
}

GOOGLE_UPLOAD_PERSON_FIELDS = ",".join(
    [
        "addresses",
        "biographies",
        "birthdays",
        "emailAddresses",
        "memberships",
        "metadata",
        "names",
        "organizations",
        "phoneNumbers",
        "relations",
        "urls",
        "userDefined",
    ]
)
GOOGLE_UPLOAD_UPDATE_FIELDS = ",".join(
    [
        "addresses",
        "biographies",
        "birthdays",
        "emailAddresses",
        "names",
        "organizations",
        "phoneNumbers",
        "relations",
        "urls",
        "userDefined",
    ]
)

_UPLOAD_JOB_LOCK = threading.Lock()
_UPLOAD_JOB_THREAD: threading.Thread | None = None
_SIGNIN_SYNC_LOCK = threading.Lock()
_SIGNIN_SYNC_THREAD: threading.Thread | None = None
_ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_LOCK = threading.Lock()
_ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_THREAD: threading.Thread | None = None
_ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_STOP = threading.Event()


def _now_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _parse_local_timestamp(value: str | None) -> datetime | None:
    text = _clean(str(value or ""))
    if not text:
        return None
    try:
        return datetime.strptime(text, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _json_request(
    url: str,
    *,
    method: str = "GET",
    headers: dict | None = None,
    data: dict | None = None,
    json_data: dict | None = None,
    raw_data: bytes | None = None,
    timeout: int = DEFAULT_HTTP_TIMEOUT_SECONDS,
    retry_attempts: int | None = None,
) -> dict:
    request_headers = {"Accept": "application/json"}
    if headers:
        request_headers.update(headers)
    payload = None
    supplied_body_count = sum(1 for item in (data, json_data, raw_data) if item is not None)
    if supplied_body_count > 1:
        raise ValueError("Only one of data, json_data, or raw_data may be supplied.")
    if data is not None:
        payload = urlencode(data).encode("utf-8")
        request_headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
    elif json_data is not None:
        payload = json.dumps(json_data).encode("utf-8")
        request_headers.setdefault("Content-Type", "application/json")
    elif raw_data is not None:
        payload = raw_data
    request = Request(url, data=payload, headers=request_headers, method=method)
    attempts = max(1, int(retry_attempts or (DRIVE_READ_RETRY_ATTEMPTS if method.upper() == "GET" else 1)))
    for attempt in range(1, attempts + 1):
        try:
            with urlopen(request, timeout=timeout) as response:
                body = response.read().decode("utf-8")
                return json.loads(body) if body else {}
        except HTTPError as exc:
            if attempt >= attempts or exc.code not in {429, 500, 502, 503, 504}:
                raise
            time.sleep(DRIVE_READ_RETRY_BASE_SECONDS * attempt)
        except (
            TimeoutError,
            socket.timeout,
            URLError,
            http.client.RemoteDisconnected,
            http.client.IncompleteRead,
            http.client.BadStatusLine,
        ) as exc:
            if attempt >= attempts:
                raise
            time.sleep(DRIVE_READ_RETRY_BASE_SECONDS * attempt)
    return {}


def _http_error_message(exc: HTTPError) -> str:
    try:
        error_payload = json.loads(exc.read().decode("utf-8"))
    except Exception:
        error_payload = {}
    if isinstance(error_payload, dict):
        nested_error = error_payload.get("error")
        if isinstance(nested_error, dict):
            message = _clean(nested_error.get("message"))
            code = _clean(nested_error.get("status") or nested_error.get("code"))
            if message and code:
                return f"{message} ({code})"
            if message:
                return message
        if isinstance(nested_error, str):
            description = _clean(error_payload.get("error_description"))
            return f"{nested_error}: {description}" if description else nested_error
        message = _clean(error_payload.get("message"))
        if message:
            return message
    return f"HTTP {exc.code}: {exc.reason}"


def describe_google_http_error(exc: HTTPError) -> str:
    return _http_error_message(exc)


def _looks_like_google_quota_error(exc: HTTPError, message: str) -> bool:
    normalized = f"{exc.code} {exc.reason} {message}".lower()
    return (
        exc.code in {403, 429}
        and (
            "resource_exhausted" in normalized
            or "quota exceeded" in normalized
            or "rate limit" in normalized
            or "user rate limit" in normalized
        )
    )


def _google_quota_retry_delay(exc: HTTPError, attempt: int) -> int:
    retry_after = _clean(exc.headers.get("Retry-After") if exc.headers else "")
    if retry_after.isdigit():
        return min(max(int(retry_after), 5), 75)
    return min(20 * attempt, 75)


def _looks_like_reconnect_error(message: str) -> bool:
    normalized = str(message or "").lower()
    return (
        "not connected" in normalized
        or "refresh token" in normalized
        or "reconnect" in normalized
        or "expired" in normalized
        or "revoked" in normalized
        or "invalid_grant" in normalized
    )


def _ensure_google_sync_records_once() -> None:
    with get_connection() as conn:
        account_row = conn.execute("SELECT id FROM google_sync_accounts WHERE id = 1").fetchone()
        state_row = conn.execute("SELECT id FROM google_sync_state WHERE id = 1").fetchone()
        if account_row and state_row:
            _ensure_editor_secret_configured(conn)
            conn.commit()
            return
        conn.execute(
            """
            INSERT INTO google_sync_accounts (id)
            SELECT 1
            WHERE NOT EXISTS (SELECT 1 FROM google_sync_accounts WHERE id = 1)
            """
        )
        conn.execute(
            """
            INSERT INTO google_sync_state (id)
            SELECT 1
            WHERE NOT EXISTS (SELECT 1 FROM google_sync_state WHERE id = 1)
            """
        )
        _ensure_editor_secret_configured(conn)
        conn.commit()


def ensure_google_sync_records() -> None:
    try:
        _ensure_google_sync_records_once()
    except sqlite3.OperationalError as exc:
        if "no such table" not in str(exc).lower():
            raise
        from app.database import initialize_database

        initialize_database()
        _ensure_google_sync_records_once()


def _hash_editor_secret(secret: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac(
        "sha256",
        str(secret or "").encode("utf-8"),
        str(salt or "").encode("utf-8"),
        EDITOR_SECRET_ITERATIONS,
    ).hex()


def _new_editor_secret_salt() -> str:
    return secrets.token_hex(16)


def _ensure_editor_secret_configured(conn) -> None:
    row = conn.execute(
        """
        SELECT editor_secret_hash, editor_secret_salt
        FROM google_sync_state
        WHERE id = 1
        """
    ).fetchone()
    if not row:
        return
    if _clean(row["editor_secret_hash"]) and _clean(row["editor_secret_salt"]):
        return
    salt = _new_editor_secret_salt()
    conn.execute(
        """
        UPDATE google_sync_state
        SET editor_secret_hash = ?, editor_secret_salt = ?, updated_at = ?
        WHERE id = 1
        """,
        (_hash_editor_secret(DEFAULT_EDITOR_SECRET, salt), salt, _now_text()),
    )


def save_editor_secret(secret: str) -> bool:
    normalized_secret = str(secret or "").strip()
    if not normalized_secret:
        return False
    ensure_google_sync_records()
    salt = _new_editor_secret_salt()
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE google_sync_state
            SET editor_secret_hash = ?, editor_secret_salt = ?, updated_at = ?
            WHERE id = 1
            """,
            (_hash_editor_secret(normalized_secret, salt), salt, _now_text()),
        )
        conn.commit()
    return True


def verify_editor_secret(secret: str) -> bool:
    submitted_secret = str(secret or "").strip()
    if not submitted_secret:
        return False
    ensure_google_sync_records()
    with get_connection() as conn:
        _ensure_editor_secret_configured(conn)
        row = conn.execute(
            """
            SELECT editor_secret_hash, editor_secret_salt
            FROM google_sync_state
            WHERE id = 1
            """
        ).fetchone()
        conn.commit()
    if not row:
        return False
    expected_hash = _clean(row["editor_secret_hash"])
    salt = _clean(row["editor_secret_salt"])
    if not expected_hash or not salt:
        return False
    return hmac.compare_digest(_hash_editor_secret(submitted_secret, salt), expected_hash)


def _read_pending_upload_count(conn) -> int:
    count_row = conn.execute(
        """
        SELECT COUNT(*) AS count
        FROM google_sync_queue
        WHERE status = 'pending'
        """
    ).fetchone()
    return int(count_row["count"]) if count_row else 0


def _refresh_pending_upload_count(conn) -> int:
    pending_count = _read_pending_upload_count(conn)
    conn.execute(
        """
        UPDATE google_sync_state
        SET
          pending_upload_count = ?,
          needs_upload_reminder = CASE WHEN ? > 0 THEN 1 ELSE 0 END,
          updated_at = ?
        WHERE id = 1
        """,
        (pending_count, pending_count, _now_text()),
    )
    return pending_count


def _google_sync_is_enabled_for_writes(conn) -> bool:
    row = conn.execute(
        """
        SELECT sync_enabled, multi_editor_enabled
        FROM google_sync_state
        WHERE id = 1
        """
    ).fetchone()
    if not row:
        return False
    return bool(row["multi_editor_enabled"] or row["sync_enabled"])


def _queue_unuploaded_local_contacts(conn) -> int:
    rows = conn.execute(
        """
        SELECT id, family_name, given_name, fields_text, meetings_text, group_membership
        FROM contacts
        WHERE COALESCE(google_contact_id, '') = ''
          AND id NOT IN (
            SELECT contact_id
            FROM google_sync_queue
            WHERE status = 'pending' AND contact_id IS NOT NULL
          )
        ORDER BY id
        """
    ).fetchall()
    queued = 0
    for row in rows:
        item = dict(row)
        payload_json = json.dumps(
            {
                "sync_action": "Create",
                "family_name": _clean(item.get("family_name")),
                "given_name": _clean(item.get("given_name")),
                "fields_text": _clean(item.get("fields_text")),
                "meetings_text": _clean(item.get("meetings_text")),
                "group_membership": _clean(item.get("group_membership")),
            },
            sort_keys=True,
        )
        conn.execute(
            """
            INSERT INTO google_sync_queue (
              contact_id,
              google_contact_id,
              operation,
              payload_json,
              status,
              last_error,
              updated_at
            ) VALUES (?, '', 'update', ?, 'pending', '', ?)
            """,
            (int(item["id"]), payload_json, _now_text()),
        )
        queued += 1
    return queued


def _set_upload_progress(
    conn,
    *,
    in_progress: bool,
    phase: str | None = None,
    total_count: int | None = None,
    processed_count: int | None = None,
    current_contact: str | None = None,
    started_at: str | None = None,
) -> None:
    current_state = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
    if not current_state:
        return
    state = dict(current_state)
    conn.execute(
        """
        UPDATE google_sync_state
        SET
          upload_in_progress = ?,
          upload_phase = ?,
          upload_total_count = ?,
          upload_processed_count = ?,
          upload_current_contact = ?,
          upload_started_at = ?,
          updated_at = ?
        WHERE id = 1
        """,
        (
            1 if in_progress else 0,
            str(phase if phase is not None else state.get("upload_phase") or ""),
            int(total_count if total_count is not None else state.get("upload_total_count") or 0),
            int(processed_count if processed_count is not None else state.get("upload_processed_count") or 0),
            str(current_contact if current_contact is not None else state.get("upload_current_contact") or ""),
            str(started_at if started_at is not None else state.get("upload_started_at") or ""),
            _now_text(),
        ),
    )


def _clear_stale_upload_progress_if_needed(conn) -> bool:
    global _UPLOAD_JOB_THREAD
    current_state = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
    if not current_state:
        return False
    state = dict(current_state)
    if not bool(state.get("upload_in_progress") or 0):
        return False
    started_at = _parse_local_timestamp(state.get("upload_started_at")) or _parse_local_timestamp(state.get("updated_at"))
    if started_at is None:
        return False
    age_seconds = max(0, int((_utc_now() - started_at).total_seconds()))
    if age_seconds < STALE_UPLOAD_PROGRESS_SECONDS:
        return False
    if str(state.get("bootstrap_status") or "") == "running":
        _mark_bootstrap_failed(conn, "Drive bootstrap stopped before it finished. Resume Upload to continue.")
    if _UPLOAD_JOB_THREAD is not None and _UPLOAD_JOB_THREAD.is_alive():
        _set_last_sync_error(conn, "Drive upload is taking too long. Retry Upload to continue.")
    _set_upload_progress(
        conn,
        in_progress=False,
        phase="",
        total_count=int(state.get("upload_total_count") or 0),
        processed_count=int(state.get("upload_processed_count") or 0),
        current_contact="",
        started_at="",
    )
    return True


def _count_pending_shared_contact_exports(conn) -> int:
    row = conn.execute(
        """
        SELECT COUNT(*) AS count
        FROM contacts
        WHERE shared_drive_needs_export = 1
        """
    ).fetchone()
    return int(row["count"] or 0) if row else 0


def _count_unbootstrapped_contacts(conn) -> int:
    row = conn.execute(
        """
        SELECT COUNT(*) AS count
        FROM contacts
        WHERE shared_drive_bootstrapped = 0
        """
    ).fetchone()
    return int(row["count"] or 0) if row else 0


def _count_contacts(conn) -> int:
    row = conn.execute("SELECT COUNT(*) AS count FROM contacts").fetchone()
    return int(row["count"] or 0) if row else 0


def _bootstrap_status_dict(state: dict) -> dict:
    total = int(state.get("bootstrap_total_contacts") or 0)
    processed = int(state.get("bootstrap_processed_contacts") or 0)
    if "bootstrap_remaining_contacts" in state:
        remaining = max(int(state.get("bootstrap_remaining_contacts") or 0), 0)
    else:
        remaining = max(total - processed, 0)
    return {
        "status": str(state.get("bootstrap_status") or "idle"),
        "total": total,
        "processed": processed,
        "remaining": remaining,
        "last_contact_id": int(state.get("bootstrap_last_contact_id") or 0),
        "started_at": str(state.get("bootstrap_started_at") or ""),
        "updated_at": str(state.get("bootstrap_updated_at") or ""),
        "error": str(state.get("bootstrap_error") or ""),
    }


def _is_bootstrap_blocking_state(state: dict) -> bool:
    return str(state.get("bootstrap_status") or "idle") in {"running", "failed"}


def _bootstrap_notice_key(state: dict) -> str:
    return "bootstrap_failed_blocked" if str(state.get("bootstrap_status") or "") == "failed" else "bootstrap_editing_blocked"


def _set_bootstrap_state(
    conn,
    *,
    status: str | None = None,
    total_contacts: int | None = None,
    processed_contacts: int | None = None,
    last_contact_id: int | None = None,
    started_at: str | None = None,
    updated_at: str | None = None,
    error: str | None = None,
) -> None:
    current_state = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
    if not current_state:
        return
    state = dict(current_state)
    conn.execute(
        """
        UPDATE google_sync_state
        SET
          bootstrap_status = ?,
          bootstrap_total_contacts = ?,
          bootstrap_processed_contacts = ?,
          bootstrap_last_contact_id = ?,
          bootstrap_started_at = ?,
          bootstrap_updated_at = ?,
          bootstrap_error = ?,
          updated_at = ?
        WHERE id = 1
        """,
        (
            str(status if status is not None else state.get("bootstrap_status") or "idle"),
            int(total_contacts if total_contacts is not None else state.get("bootstrap_total_contacts") or 0),
            int(processed_contacts if processed_contacts is not None else state.get("bootstrap_processed_contacts") or 0),
            int(last_contact_id if last_contact_id is not None else state.get("bootstrap_last_contact_id") or 0),
            str(started_at if started_at is not None else state.get("bootstrap_started_at") or ""),
            str(updated_at if updated_at is not None else _now_text()),
            str(error if error is not None else state.get("bootstrap_error") or ""),
            _now_text(),
        ),
    )


def _set_signin_sync_state(
    conn,
    *,
    in_progress: bool | None = None,
    phase: str | None = None,
    error: str | None = None,
    total_count: int | None = None,
    processed_count: int | None = None,
    current_item: str | None = None,
) -> None:
    current_state = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
    if not current_state:
        return
    state = dict(current_state)
    next_phase = str(phase if phase is not None else state.get("signin_sync_phase") or "")
    phase_changed = phase is not None and next_phase != str(state.get("signin_sync_phase") or "")
    next_in_progress = bool(in_progress if in_progress is not None else bool(state.get("signin_sync_in_progress") or 0))
    if not next_in_progress:
        total_value = 0
        processed_value = 0
        current_value = ""
    elif total_count is not None or processed_count is not None or current_item is not None:
        total_value = int(total_count if total_count is not None else state.get("signin_sync_total_count") or 0)
        processed_value = int(processed_count if processed_count is not None else state.get("signin_sync_processed_count") or 0)
        current_value = _clean(current_item if current_item is not None else state.get("signin_sync_current_item") or "")
    elif phase_changed:
        total_value = 0
        processed_value = 0
        current_value = ""
    else:
        total_value = int(state.get("signin_sync_total_count") or 0)
        processed_value = int(state.get("signin_sync_processed_count") or 0)
        current_value = _clean(state.get("signin_sync_current_item") or "")
    conn.execute(
        """
        UPDATE google_sync_state
        SET
          signin_sync_in_progress = ?,
          signin_sync_phase = ?,
          signin_sync_error = ?,
          signin_sync_total_count = ?,
          signin_sync_processed_count = ?,
          signin_sync_current_item = ?,
          signin_sync_updated_at = ?,
          updated_at = ?
        WHERE id = 1
        """,
        (
            1 if next_in_progress else 0,
            next_phase,
            str(error if error is not None else state.get("signin_sync_error") or ""),
            total_value,
            processed_value,
            current_value,
            _now_text(),
            _now_text(),
        ),
    )


def _clear_local_contact_data(conn) -> None:
    conn.executescript(
        """
        DELETE FROM relationships;
        DELETE FROM phones;
        DELETE FROM addresses;
        DELETE FROM emails;
        DELETE FROM custom_fields;
        DELETE FROM google_sync_queue;
        DELETE FROM contact_assignment_options;
        DELETE FROM contacts;
        """
    )


def _clear_local_meetingdata_data(conn) -> None:
    conn.executescript(
        """
        DELETE FROM meeting_edit_log_entries;
        DELETE FROM meeting_row_cells_v2;
        DELETE FROM meeting_row_flow_items_v2;
        DELETE FROM meeting_layout_presets_v2;
        DELETE FROM meeting_section_layout_v2;
        DELETE FROM meeting_section_rows_v2;
        DELETE FROM meeting_sections_v2;
        DELETE FROM meeting_section_name_options;
        DELETE FROM meeting_data_rows;
        """
    )


def _clear_transfer_progress_for_account_switch(conn) -> None:
    _clear_local_contact_data(conn)
    _clear_local_meetingdata_data(conn)
    _set_upload_progress(
        conn,
        in_progress=False,
        phase="",
        total_count=0,
        processed_count=0,
        current_contact="",
        started_at="",
    )
    _set_bootstrap_state(
        conn,
        status="idle",
        total_contacts=0,
        processed_contacts=0,
        last_contact_id=0,
        started_at="",
        updated_at=_now_text(),
        error="",
    )
    conn.execute(
        """
        UPDATE google_sync_state
        SET
          pending_upload_count = 0,
          needs_upload_reminder = 0,
          needs_drive_export = 0,
          book_layouts_needs_drive_export = 0,
          contacts_manifest_needs_drive_export = 0,
          meetingdata_needs_drive_export = 0,
          field_list_needs_drive_export = 0,
          changes_list_needs_drive_export = 0,
          contacts_sync_revision = 0,
          meetingdata_sync_revision = 0,
          field_list_sync_revision = 0,
          settings_sync_revision = 0,
          last_import_at = '',
          last_import_account_email = '',
          last_sync_error = '',
          updated_at = ?
        WHERE id = 1
        """,
        (_now_text(),),
    )


def _mark_bootstrap_complete(conn) -> None:
    _set_bootstrap_state(
        conn,
        status="completed",
        error="",
        updated_at=_now_text(),
    )


def _mark_bootstrap_failed(conn, message: str) -> None:
    _set_bootstrap_state(
        conn,
        status="failed",
        error=_clean(message),
        updated_at=_now_text(),
    )


def _visible_bootstrap_processed(processed: int, total: int) -> int:
    if processed <= 0:
        return 0
    if processed >= total:
        return total
    return max((processed // DRIVE_BOOTSTRAP_VISIBLE_PROGRESS_STEP) * DRIVE_BOOTSTRAP_VISIBLE_PROGRESS_STEP, 0)


def _upload_thread_running() -> bool:
    return _UPLOAD_JOB_THREAD is not None and _UPLOAD_JOB_THREAD.is_alive()


def _signin_sync_thread_running() -> bool:
    return _SIGNIN_SYNC_THREAD is not None and _SIGNIN_SYNC_THREAD.is_alive()


def _clear_stale_signin_sync_if_needed(conn) -> bool:
    current_state = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
    if not current_state:
        return False
    state = dict(current_state)
    if not bool(state.get("signin_sync_in_progress") or 0):
        return False
    heartbeat_at = _parse_local_timestamp(state.get("signin_sync_updated_at")) or _parse_local_timestamp(state.get("updated_at"))
    age_seconds = None
    if heartbeat_at is not None:
        age_seconds = max(0, int((_utc_now() - heartbeat_at).total_seconds()))
    if age_seconds is not None and age_seconds < STALE_SIGNIN_SYNC_SECONDS:
        return False
    if _signin_sync_thread_running():
        return False
    _set_signin_sync_state(
        conn,
        in_progress=False,
        phase="",
        error=_clean(state.get("signin_sync_error")) or "Shared sign-in sync stopped before it finished. Retry Drive sync.",
    )
    return True


def _state_has_resumable_upload_work(conn, state: dict) -> bool:
    if str(state.get("bootstrap_status") or "") in {"running", "failed"}:
        return _count_unbootstrapped_contacts(conn) > 0
    pending_count = _read_pending_upload_count(conn)
    if (
        pending_count > 0
        or _count_pending_shared_contact_exports(conn) > 0
        or bool(state.get("needs_drive_export") or 0)
        or bool(state.get("contacts_manifest_needs_drive_export") or 0)
        or bool(state.get("book_layouts_needs_drive_export") or 0)
        or bool(state.get("meetingdata_needs_drive_export") or 0)
        or bool(state.get("field_list_needs_drive_export") or 0)
        or bool(state.get("changes_list_needs_drive_export") or 0)
    ):
        return True
    return False


def _resume_upload_job_if_needed() -> bool:
    global _UPLOAD_JOB_THREAD
    with _UPLOAD_JOB_LOCK:
        if _upload_thread_running():
            return False
        with get_connection() as conn:
            state_row = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
            state = dict(state_row) if state_row else {}
            if not bool(state.get("upload_in_progress") or 0):
                conn.commit()
                return False
            if not _state_has_resumable_upload_work(conn, state):
                _set_upload_progress(
                    conn,
                    in_progress=False,
                    phase="",
                    total_count=0,
                    processed_count=0,
                    current_contact="",
                    started_at="",
                )
                _set_bootstrap_state(
                    conn,
                    status="completed" if _count_unbootstrapped_contacts(conn) <= 0 else "idle",
                    total_contacts=0 if _count_unbootstrapped_contacts(conn) <= 0 else None,
                    processed_contacts=0 if _count_unbootstrapped_contacts(conn) <= 0 else None,
                    last_contact_id=0 if _count_unbootstrapped_contacts(conn) <= 0 else None,
                    started_at="" if _count_unbootstrapped_contacts(conn) <= 0 else None,
                    error="",
                )
                conn.commit()
                return False
            if not str(state.get("upload_started_at") or "").strip():
                _set_upload_progress(conn, in_progress=True, started_at=_now_text())
            _clear_last_sync_error(conn)
            conn.commit()
        _UPLOAD_JOB_THREAD = threading.Thread(target=_run_google_upload_job, daemon=True)
        _UPLOAD_JOB_THREAD.start()
        return True


def _oauth_is_configured() -> bool:
    return bool(GOOGLE_OAUTH_CLIENT_ID and GOOGLE_OAUTH_CLIENT_SECRET and GOOGLE_OAUTH_REDIRECT_URI)


def _google_picker_app_id() -> str:
    configured_app_id = _clean(GOOGLE_PICKER_APP_ID)
    if configured_app_id:
        return configured_app_id
    client_id_prefix = _clean(GOOGLE_OAUTH_CLIENT_ID).split("-", 1)[0]
    return client_id_prefix if client_id_prefix.isdigit() else ""


def _safe_load_json(value: str | None) -> dict:
    text = str(value or "").strip()
    if not text:
        return {}
    try:
        payload = json.loads(text)
    except (TypeError, ValueError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _scope_values(scope_text: str | None) -> set[str]:
    return {chunk.strip() for chunk in str(scope_text or "").split() if chunk.strip()}


def _account_has_drive_scope(account: dict | None = None) -> bool:
    details = account or _load_google_account()
    scopes = _scope_values(details.get("scopes"))
    return any(scope in scopes for scope in GOOGLE_DRIVE_VISIBLE_SCOPES)


def _format_queue_contact_name(contact_row: dict, payload: dict) -> str:
    family_name = _clean((contact_row or {}).get("family_name") or payload.get("family_name"))
    given_name = _clean((contact_row or {}).get("given_name") or payload.get("given_name"))
    if family_name and given_name:
        return f"{family_name}, {given_name}"
    if family_name:
        return family_name
    if given_name:
        return given_name
    google_contact_id = _clean((contact_row or {}).get("google_contact_id") or payload.get("google_contact_id"))
    return google_contact_id or "Local-only contact"


def _list_pending_queue_entries() -> list[dict]:
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT
              q.id,
              q.contact_id,
              q.google_contact_id,
              q.operation,
              q.payload_json,
              q.status,
              q.last_error,
              q.created_at,
              q.updated_at,
              c.family_name,
              c.given_name
            FROM google_sync_queue q
            LEFT JOIN contacts c
              ON c.id = q.contact_id
            WHERE q.status = 'pending'
            ORDER BY q.id
            """
        ).fetchall()

    entries = []
    for row in rows:
        item = dict(row)
        payload = _safe_load_json(item.get("payload_json"))
        operation = _clean(item.get("operation")) or "update"
        action_label = _clean(payload.get("sync_action")) or {
            "create": "Create",
            "update": "Update",
            "delete": "Delete",
        }.get(operation, operation.title())
        entries.append(
            {
                "id": int(item["id"]),
                "contact_name": _format_queue_contact_name(item, payload),
                "operation": operation,
                "action_label": action_label,
                "operation_label": f"{action_label} in Google",
                "google_contact_id": _clean(item.get("google_contact_id") or payload.get("google_contact_id")),
                "queued_at": _clean(item.get("created_at")),
                "updated_at": _clean(item.get("updated_at")),
                "last_error": _clean(item.get("last_error")),
            }
        )
    return entries


def get_google_sync_summary() -> dict:
    ensure_google_sync_records()
    _resume_upload_job_if_needed()
    with get_connection() as conn:
        _clear_stale_signin_sync_if_needed(conn)
        _clear_stale_upload_progress_if_needed(conn)
        account_row = conn.execute("SELECT * FROM google_sync_accounts WHERE id = 1").fetchone()
        state_row = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
        pending_count = _read_pending_upload_count(conn)
        pending_contact_drive_export_count = _count_pending_shared_contact_exports(conn)
        bootstrap_remaining_count = _count_unbootstrapped_contacts(conn)
        current_contact_count = _count_contacts(conn)
        if state_row:
            stored_bootstrap_status = str(state_row["bootstrap_status"] or "idle")
            if bootstrap_remaining_count <= 0 and stored_bootstrap_status in {"running", "failed"}:
                bootstrap_total = int(state_row["bootstrap_total_contacts"] or current_contact_count)
                _set_bootstrap_state(
                    conn,
                    status="completed",
                    total_contacts=bootstrap_total,
                    processed_contacts=bootstrap_total,
                    updated_at=_now_text(),
                    error="",
                )
                conn.commit()
                state_row = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
            if (
                bootstrap_remaining_count <= 0
                and bool(state_row["upload_in_progress"] or 0)
                and str(state_row["upload_phase"] or "") == "drive_bootstrap"
            ):
                _set_upload_progress(
                    conn,
                    in_progress=False,
                    phase="",
                    total_count=int(state_row["upload_total_count"] or 0),
                    processed_count=int(state_row["upload_total_count"] or state_row["upload_processed_count"] or 0),
                    current_contact="",
                    started_at="",
                )
                conn.commit()
                state_row = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()

    account = dict(account_row) if account_row else {}
    state = dict(state_row) if state_row else {}
    state["pending_upload_count"] = pending_count
    stored_bootstrap_status = str(state.get("bootstrap_status") or "idle")
    if bootstrap_remaining_count > 0 and stored_bootstrap_status == "completed":
        state["bootstrap_status"] = "idle"
    state["bootstrap_remaining_contacts"] = bootstrap_remaining_count
    bootstrap_total = int(state.get("bootstrap_total_contacts") or 0)
    if bootstrap_remaining_count > 0 and bootstrap_total != current_contact_count:
        bootstrap_total = current_contact_count
        state["bootstrap_total_contacts"] = bootstrap_total
        state["bootstrap_processed_contacts"] = max(current_contact_count - bootstrap_remaining_count, 0)
    settings_needs_drive_export = bool(state.get("needs_drive_export") or 0)
    contacts_manifest_needs_drive_export = bool(state.get("contacts_manifest_needs_drive_export") or 0)
    book_layouts_needs_drive_export = bool(state.get("book_layouts_needs_drive_export") or 0)
    meetingdata_needs_drive_export = bool(state.get("meetingdata_needs_drive_export") or 0)
    field_list_needs_drive_export = bool(state.get("field_list_needs_drive_export") or 0)
    changes_list_needs_drive_export = bool(state.get("changes_list_needs_drive_export") or 0)
    shared_drive_needs_export = (
        settings_needs_drive_export
        or pending_contact_drive_export_count > 0
        or contacts_manifest_needs_drive_export
        or book_layouts_needs_drive_export
        or meetingdata_needs_drive_export
        or field_list_needs_drive_export
        or changes_list_needs_drive_export
    )
    last_sync_error = str(state.get("last_sync_error") or "")
    if (
        last_sync_error
        and not bool(state.get("upload_in_progress") or 0)
        and pending_count <= 0
        and not shared_drive_needs_export
        and str(state.get("bootstrap_status") or "idle") not in {"running", "failed"}
    ):
        _clear_last_sync_error(conn)
        conn.commit()
        state["last_sync_error"] = ""
    if (
        pending_count > 0
        or shared_drive_needs_export
    ):
        state["needs_upload_reminder"] = 1
    return {
        "account": {
            "email": str(account.get("account_email") or ""),
            "remember_preferred_account": bool(account.get("remember_preferred_account") or 0),
            "status": str(account.get("account_status") or "not_connected"),
            "google_user_id": str(account.get("google_user_id") or ""),
            "display_name": str(account.get("google_display_name") or ""),
            "oauth_configured": _oauth_is_configured(),
            "drive_scope_ready": _account_has_drive_scope(account),
        },
        "state": {
            "source_of_truth": str(state.get("source_of_truth") or "app"),
            "sync_enabled": bool(state.get("sync_enabled") or 0),
            "pending_upload_count": int(state.get("pending_upload_count") or 0),
            "upload_in_progress": bool(state.get("upload_in_progress") or 0),
            "upload_phase": str(state.get("upload_phase") or ""),
            "upload_total_count": int(state.get("upload_total_count") or 0),
            "upload_processed_count": int(state.get("upload_processed_count") or 0),
            "upload_remaining_count": max(
                int(state.get("upload_total_count") or 0) - int(state.get("upload_processed_count") or 0),
                0,
            ),
            "upload_current_contact": str(state.get("upload_current_contact") or ""),
            "upload_started_at": str(state.get("upload_started_at") or ""),
            "bootstrap_status": str(state.get("bootstrap_status") or "idle"),
            "bootstrap_total_contacts": bootstrap_total,
            "bootstrap_processed_contacts": int(state.get("bootstrap_processed_contacts") or 0),
            "bootstrap_remaining_contacts": bootstrap_remaining_count,
            "bootstrap_last_contact_id": int(state.get("bootstrap_last_contact_id") or 0),
            "bootstrap_started_at": str(state.get("bootstrap_started_at") or ""),
            "bootstrap_updated_at": str(state.get("bootstrap_updated_at") or ""),
            "bootstrap_error": str(state.get("bootstrap_error") or ""),
            "last_import_at": str(state.get("last_import_at") or ""),
            "last_import_account_email": str(state.get("last_import_account_email") or ""),
            "last_upload_at": str(state.get("last_upload_at") or ""),
            "last_sync_error": str(state.get("last_sync_error") or ""),
            "last_drive_export_at": str(state.get("last_drive_export_at") or ""),
            "contact_records_needs_drive_export": pending_contact_drive_export_count > 0,
            "pending_contact_drive_export_count": pending_contact_drive_export_count,
            "contacts_manifest_needs_drive_export": contacts_manifest_needs_drive_export,
            "settings_needs_drive_export": settings_needs_drive_export,
            "shared_drive_needs_export": shared_drive_needs_export,
            "needs_drive_export": settings_needs_drive_export,
            "book_layouts_needs_drive_export": book_layouts_needs_drive_export,
            "meetingdata_needs_drive_export": meetingdata_needs_drive_export,
            "field_list_needs_drive_export": field_list_needs_drive_export,
            "changes_list_needs_drive_export": changes_list_needs_drive_export,
            "settings_sync_revision": int(state.get("settings_sync_revision") or 0),
            "book_layouts_sync_revision": int(state.get("book_layouts_sync_revision") or 0),
            "contacts_sync_revision": int(state.get("contacts_sync_revision") or 0),
            "meetingdata_sync_revision": int(state.get("meetingdata_sync_revision") or 0),
            "field_list_sync_revision": int(state.get("field_list_sync_revision") or 0),
            "changes_list_sync_revision": int(state.get("changes_list_sync_revision") or 0),
            "signin_sync_in_progress": bool(state.get("signin_sync_in_progress") or 0),
            "signin_sync_phase": str(state.get("signin_sync_phase") or ""),
            "signin_sync_error": str(state.get("signin_sync_error") or ""),
            "signin_sync_total_count": int(state.get("signin_sync_total_count") or 0),
            "signin_sync_processed_count": int(state.get("signin_sync_processed_count") or 0),
            "signin_sync_current_item": str(state.get("signin_sync_current_item") or ""),
            "signin_sync_updated_at": str(state.get("signin_sync_updated_at") or ""),
            "drive_root_folder_id": str(state.get("drive_root_folder_id") or ""),
            "drive_app_revisions_folder_id": str(state.get("drive_app_revisions_folder_id") or ""),
            "drive_app_revisions_file_id": str(state.get("drive_app_revisions_file_id") or ""),
            "address_book_pdf_share_enabled": bool(state.get("address_book_pdf_share_enabled") or 0),
            "address_book_pdf_share_folder_id": str(state.get("address_book_pdf_share_folder_id") or ""),
            "address_book_pdf_share_folder_name": str(state.get("address_book_pdf_share_folder_name") or ""),
            "import_warning_acknowledged_at": str(state.get("import_warning_acknowledged_at") or ""),
            "needs_upload_reminder": bool(state.get("needs_upload_reminder") or 0),
            "multi_editor_enabled": bool(state.get("multi_editor_enabled") or 0),
            "multi_editor_account_locked": bool(state.get("multi_editor_account_locked") or 0),
            "editor_lock_timeout_minutes": int(state.get("editor_lock_timeout_minutes") or 60),
            "editor_name": str(state.get("editor_name") or ""),
            "editor_session_id": str(state.get("editor_session_id") or ""),
            "editor_mode": str(state.get("editor_mode") or "normal"),
            "editor_lock_owner_name": str(state.get("editor_lock_owner_name") or ""),
            "editor_lock_expires_at": str(state.get("editor_lock_expires_at") or ""),
            "pending_editor_name": str(state.get("pending_editor_name") or ""),
            "access_role": str(state.get("access_role") or "editor"),
            "access_name": str(state.get("access_name") or ""),
            "access_signed_in_at": str(state.get("access_signed_in_at") or ""),
        },
        "pending_queue": _list_pending_queue_entries(),
    }


def get_google_picker_config() -> dict:
    ensure_google_sync_records()
    account = _load_google_account()
    if str(account.get("account_status") or "") != "connected":
        return {"ok": False, "reason": "not_connected"}
    if not _account_has_drive_scope(account):
        return {"ok": False, "reason": "drive_scope_missing"}

    api_key = _clean(GOOGLE_PICKER_API_KEY)
    app_id = _google_picker_app_id()
    if not api_key or not app_id:
        return {
            "ok": False,
            "reason": "picker_not_configured",
            "api_key_configured": bool(api_key),
            "app_id_configured": bool(app_id),
        }

    access_token, account_email = _get_valid_access_token()
    return {
        "ok": True,
        "api_key": api_key,
        "app_id": app_id,
        "access_token": access_token,
        "account_email": account_email,
    }


def is_multi_editor_enabled() -> bool:
    return bool((get_google_sync_summary().get("state") or {}).get("multi_editor_enabled"))


def _has_active_local_editor_session(account: dict, state: dict, *, now: datetime | None = None) -> bool:
    if not bool(state.get("multi_editor_enabled")):
        return False
    if str(account.get("status") or "") != "connected":
        return False
    if str(state.get("editor_mode") or "") != "edit":
        return False
    if not _clean(state.get("editor_session_id")):
        return False
    expires_at = _parse_iso_datetime(_clean(state.get("editor_lock_expires_at")))
    if not expires_at:
        return False
    return expires_at > (now or _utc_now())


def _clear_expired_local_editor_session(state: dict, *, now: datetime | None = None) -> bool:
    if str(state.get("editor_mode") or "") != "edit":
        return False
    if not _clean(state.get("editor_session_id")):
        return False
    expires_at = _parse_iso_datetime(_clean(state.get("editor_lock_expires_at")))
    if not expires_at or expires_at > (now or _utc_now()):
        return False
    previous_editor_name = _clean(state.get("editor_name")) or _clean(state.get("pending_editor_name"))
    _set_editor_session(mode="no_edit", pending_editor_name=previous_editor_name)
    if normalize_access_role(state.get("access_role")) == "editor":
        clear_access_session()
    return True


def is_editing_allowed() -> bool:
    summary = get_google_sync_summary()
    account = summary.get("account") or {}
    state = summary.get("state") or {}
    now = _utc_now()
    if _clear_expired_local_editor_session(state, now=now):
        summary = get_google_sync_summary()
        account = summary.get("account") or {}
        state = summary.get("state") or {}
    access_role = normalize_access_role(state.get("access_role"))
    if _is_bootstrap_blocking_state(state):
        return False
    if bool(state.get("signin_sync_in_progress") or 0) or _clean(state.get("signin_sync_error")):
        return False
    if access_role == "field_list_creation":
        return True
    if not bool(state.get("multi_editor_enabled") or state.get("multi_editor_account_locked")):
        return True
    return _has_active_local_editor_session(account, state, now=now)


def can_retry_signin_sync() -> bool:
    summary = get_google_sync_summary()
    account = summary.get("account") or {}
    state = summary.get("state") or {}
    connected_drive_account = str(account.get("status") or "") == "connected" and bool(account.get("drive_scope_ready"))
    editor_role = normalize_access_role(state.get("access_role")) == "editor"
    if not connected_drive_account or not editor_role:
        return False
    if bool(state.get("upload_in_progress") or 0):
        return False
    if _is_bootstrap_blocking_state(state):
        return False
    return True


def retry_google_signin_sync() -> bool:
    if not can_retry_signin_sync():
        return False
    with get_connection() as conn:
        _clear_stale_signin_sync_if_needed(conn)
        _set_signin_sync_state(conn, in_progress=False, phase="", error="")
        conn.commit()
    _start_signin_sync_job()
    return True


def start_google_signin_sync() -> bool:
    summary = get_google_sync_summary()
    account = summary.get("account") or {}
    state = summary.get("state") or {}
    if str(account.get("status") or "") != "connected" or not bool(account.get("drive_scope_ready")):
        return False
    if bool(state.get("upload_in_progress") or 0):
        return False
    if _is_bootstrap_blocking_state(state):
        return False
    with get_connection() as conn:
        _clear_stale_signin_sync_if_needed(conn)
        _set_signin_sync_state(conn, in_progress=False, phase="", error="")
        conn.commit()
    _start_signin_sync_job()
    return True


def get_edit_block_notice_key() -> str:
    state = (get_google_sync_summary().get("state") or {})
    if _is_bootstrap_blocking_state(state):
        return _bootstrap_notice_key(state)
    if bool(state.get("signin_sync_in_progress") or 0):
        return "signin_sync_blocked"
    if _clean(state.get("signin_sync_error")):
        return "signin_sync_failed_blocked"
    return "editor_lock_blocked"


def _normalize_editor_timeout_minutes(value: int | str | None) -> int:
    try:
        minutes = int(value or 60)
    except (TypeError, ValueError):
        minutes = 60
    if minutes <= 0:
        return 15
    return min(minutes, 105)


def save_multi_editor_setting(
    enabled: bool,
    timeout_minutes: int | str | None = 60,
    *,
    allow_unlock: bool = False,
) -> None:
    normalized_timeout_minutes = _normalize_editor_timeout_minutes(timeout_minutes)
    ensure_google_sync_records()
    with get_connection() as conn:
        state_row = conn.execute(
            "SELECT multi_editor_account_locked FROM google_sync_state WHERE id = 1"
        ).fetchone()
        already_locked = bool(state_row and (state_row["multi_editor_account_locked"] or 0))
        effective_enabled = bool(enabled or (already_locked and not allow_unlock))
        effective_locked = bool(enabled or (already_locked and not allow_unlock))
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              multi_editor_enabled = ?,
              multi_editor_account_locked = ?,
              editor_lock_timeout_minutes = ?,
              editor_mode = CASE WHEN ? = 1 THEN CASE WHEN editor_mode = 'edit' THEN editor_mode ELSE 'no_edit' END ELSE 'normal' END,
              editor_name = CASE WHEN ? = 1 THEN editor_name ELSE '' END,
              editor_session_id = CASE WHEN ? = 1 THEN editor_session_id ELSE '' END,
              editor_lock_owner_name = CASE WHEN ? = 1 THEN editor_lock_owner_name ELSE '' END,
              editor_lock_expires_at = CASE WHEN ? = 1 THEN editor_lock_expires_at ELSE '' END,
              pending_editor_name = CASE WHEN ? = 1 THEN pending_editor_name ELSE '' END,
              access_role = CASE WHEN ? = 1 THEN access_role ELSE 'editor' END,
              access_name = CASE WHEN ? = 1 THEN access_name ELSE '' END,
              access_signed_in_at = CASE WHEN ? = 1 THEN access_signed_in_at ELSE '' END,
              updated_at = ?
            WHERE id = 1
            """,
            (
                1 if effective_enabled else 0,
                1 if effective_locked else 0,
                normalized_timeout_minutes,
                1 if effective_enabled else 0,
                1 if effective_enabled else 0,
                1 if effective_enabled else 0,
                1 if effective_enabled else 0,
                1 if effective_enabled else 0,
                1 if effective_enabled else 0,
                1 if effective_enabled else 0,
                1 if effective_enabled else 0,
                1 if effective_enabled else 0,
                _now_text(),
            ),
        )
        conn.commit()


def save_address_book_pdf_share_setting(
    *,
    enabled: bool,
    folder_id: str | None = None,
    folder_name: str | None = None,
) -> None:
    ensure_google_sync_records()
    normalized_folder_id = _clean(folder_id)
    normalized_folder_name = _clean(folder_name)
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              address_book_pdf_share_enabled = ?,
              address_book_pdf_share_folder_id = ?,
              address_book_pdf_share_folder_name = ?,
              updated_at = ?
            WHERE id = 1
            """,
            (
                1 if enabled else 0,
                normalized_folder_id,
                normalized_folder_name,
                _now_text(),
            ),
        )
        conn.commit()


def set_pending_editor_name(editor_name: str) -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE google_sync_state
            SET pending_editor_name = ?, updated_at = ?
            WHERE id = 1
            """,
            (_clean(editor_name), _now_text()),
        )
        conn.commit()


def get_pending_editor_name() -> str:
    return _clean((get_google_sync_summary().get("state") or {}).get("pending_editor_name"))


def get_current_access_role() -> str:
    return normalize_access_role((get_google_sync_summary().get("state") or {}).get("access_role"))


ACCESS_ROLE_VALUES = {
    "editor",
    "field_list_creation",
    "address_book_creation",
    "changes_contributor",
}


def normalize_access_role(value: str | None) -> str:
    normalized = str(value or "").strip().lower().replace("-", "_").replace(" ", "_")
    return normalized if normalized in ACCESS_ROLE_VALUES else "editor"


def initials_from_name(name: str | None) -> str:
    cleaned_words = [
        "".join(char for char in word if char.isalpha())
        for word in str(name or "").strip().split()
    ]
    words = [word for word in cleaned_words if word]
    if len(words) >= 2:
        return f"{words[0][0]}{words[-1][0]}".upper()
    if len(words) == 1:
        word = words[0]
        if len(word) == 1:
            return word[0].upper()
        return f"{word[0].upper()}{word[1].lower()}"
    return ""


def get_current_editor_initials() -> str:
    state = get_google_sync_summary().get("state") or {}
    access_role = normalize_access_role(state.get("access_role"))
    name = state.get("access_name") or state.get("editor_name") or state.get("pending_editor_name")
    initials = initials_from_name(name)
    if initials:
        return initials
    if not bool(state.get("multi_editor_enabled")):
        return "SE"
    if access_role == "field_list_creation":
        return "FL"
    if access_role == "address_book_creation":
        return "AB"
    if str(state.get("editor_mode") or "") == "edit":
        return "Ed"
    return ""


def get_current_access_initials() -> str:
    state = get_google_sync_summary().get("state") or {}
    return initials_from_name(state.get("access_name") or state.get("editor_name") or state.get("pending_editor_name"))


def can_edit_changes_list() -> bool:
    summary = get_google_sync_summary()
    account = summary.get("account") or {}
    state = summary.get("state") or {}
    if normalize_access_role(state.get("access_role")) == "changes_contributor" and _clean(state.get("access_name")):
        return True
    return (
        bool(state.get("multi_editor_enabled"))
        and str(account.get("status") or "") == "connected"
        and str(state.get("editor_mode") or "") == "edit"
        and bool(_clean(state.get("editor_session_id")))
    )


def get_current_changes_list_initials() -> str:
    if not can_edit_changes_list():
        return ""
    state = get_google_sync_summary().get("state") or {}
    return initials_from_name(state.get("access_name") or state.get("editor_name"))


def save_access_session(access_role: str, access_name: str) -> None:
    normalized_role = normalize_access_role(access_role)
    normalized_name = _clean(access_name)
    ensure_google_sync_records()
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE google_sync_state
            SET access_role = ?, access_name = ?, access_signed_in_at = ?, updated_at = ?
            WHERE id = 1
            """,
            (normalized_role, normalized_name, _now_text(), _now_text()),
        )
        conn.commit()


def clear_access_session() -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE google_sync_state
            SET access_role = 'editor', access_name = '', access_signed_in_at = '', updated_at = ?
            WHERE id = 1
            """,
            (_now_text(),),
        )
        conn.commit()


def _set_editor_session(
    *,
    mode: str,
    editor_name: str = "",
    session_id: str = "",
    owner_name: str = "",
    expires_at: str = "",
    pending_editor_name: str | None = None,
) -> None:
    updates = [
        "editor_mode = ?",
        "editor_name = ?",
        "editor_session_id = ?",
        "editor_lock_owner_name = ?",
        "editor_lock_expires_at = ?",
        "updated_at = ?",
    ]
    params: list[object] = [mode, editor_name, session_id, owner_name, expires_at, _now_text()]
    if pending_editor_name is not None:
        updates.insert(-1, "pending_editor_name = ?")
        params.insert(-1, pending_editor_name)
    params.append(1)
    ensure_google_sync_records()
    with get_connection() as conn:
        conn.execute(
            f"UPDATE google_sync_state SET {', '.join(updates)} WHERE id = ?",
            params,
        )
        conn.commit()


def save_google_sync_settings(account_email: str, remember_preferred_account: bool = True) -> None:
    ensure_google_sync_records()
    normalized_email = str(account_email or "").strip() if remember_preferred_account else ""
    with get_connection() as conn:
        existing_row = conn.execute(
            """
            SELECT account_email, account_status
            FROM google_sync_accounts
            WHERE id = 1
            """
        ).fetchone()
        existing_email = str(existing_row["account_email"] or "") if existing_row else ""
        existing_status = str(existing_row["account_status"] or "") if existing_row else ""
        if (
            normalized_email
            and existing_status == "connected"
            and existing_email.strip().lower() == normalized_email.lower()
        ):
            status = "connected"
        elif normalized_email and not _oauth_is_configured():
            status = "oauth_not_configured"
        elif normalized_email:
            status = "configured"
        else:
            status = "not_connected"
        conn.execute(
            """
            UPDATE google_sync_accounts
            SET
              account_email = ?,
              remember_preferred_account = ?,
              account_status = ?,
              updated_at = ?
            WHERE id = 1
            """,
            (normalized_email, 1 if remember_preferred_account and normalized_email else 0, status, _now_text()),
        )
        conn.commit()


def save_single_editor_sync_setting(enabled: bool) -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        state_row = conn.execute(
            "SELECT multi_editor_account_locked FROM google_sync_state WHERE id = 1"
        ).fetchone()
        if state_row and bool(state_row["multi_editor_account_locked"] or 0):
            conn.execute(
                """
                UPDATE google_sync_state
                SET multi_editor_enabled = 1, editor_mode = 'no_edit', updated_at = ?
                WHERE id = 1
                """,
                (_now_text(),),
            )
            conn.commit()
            return
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              sync_enabled = ?,
              pending_upload_count = CASE WHEN ? = 1 THEN pending_upload_count ELSE 0 END,
              needs_upload_reminder = CASE WHEN ? = 1 THEN needs_upload_reminder ELSE 0 END,
              needs_drive_export = CASE WHEN ? = 1 THEN needs_drive_export ELSE 0 END,
              book_layouts_needs_drive_export = CASE WHEN ? = 1 THEN book_layouts_needs_drive_export ELSE 0 END,
              contacts_manifest_needs_drive_export = CASE WHEN ? = 1 THEN contacts_manifest_needs_drive_export ELSE 0 END,
              meetingdata_needs_drive_export = CASE WHEN ? = 1 THEN meetingdata_needs_drive_export ELSE 0 END,
              field_list_needs_drive_export = CASE WHEN ? = 1 THEN field_list_needs_drive_export ELSE 0 END,
              changes_list_needs_drive_export = CASE WHEN ? = 1 THEN changes_list_needs_drive_export ELSE 0 END,
              updated_at = ?
            WHERE id = 1
            """,
            (
                1 if enabled else 0,
                1 if enabled else 0,
                1 if enabled else 0,
                1 if enabled else 0,
                1 if enabled else 0,
                1 if enabled else 0,
                1 if enabled else 0,
                1 if enabled else 0,
                1 if enabled else 0,
                _now_text(),
            ),
        )
        if not enabled:
            conn.execute("DELETE FROM google_sync_queue WHERE status = 'pending'")
        else:
            _queue_unuploaded_local_contacts(conn)
            _refresh_pending_upload_count(conn)
        conn.commit()


def queue_contact_sync(contact_id: int | None, operation: str, google_contact_id: str = "", payload: dict | None = None) -> None:
    ensure_google_sync_records()
    payload_json = json.dumps(payload or {}, sort_keys=True)
    normalized_google_contact_id = str(google_contact_id or "").strip()
    with get_connection() as conn:
        if not _google_sync_is_enabled_for_writes(conn):
            return
        if contact_id is not None:
            conn.execute(
                """
                DELETE FROM google_sync_queue
                WHERE status = 'pending' AND contact_id = ?
                """,
                (contact_id,),
            )
        elif normalized_google_contact_id:
            conn.execute(
                """
                DELETE FROM google_sync_queue
                WHERE status = 'pending' AND google_contact_id = ?
                """,
                (normalized_google_contact_id,),
            )
        conn.execute(
            """
            INSERT INTO google_sync_queue (
              contact_id,
              google_contact_id,
              operation,
              payload_json,
              status,
              last_error,
              updated_at
            ) VALUES (?, ?, ?, ?, 'pending', '', ?)
            """,
            (contact_id, normalized_google_contact_id, operation, payload_json, _now_text()),
        )
        _refresh_pending_upload_count(conn)
        conn.commit()


def mark_shared_data_for_drive_export() -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        if not _google_sync_is_enabled_for_writes(conn):
            return
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              needs_drive_export = 1,
              updated_at = ?
            WHERE id = 1
            """,
            (_now_text(),),
        )
        conn.commit()


def mark_contacts_manifest_for_drive_export() -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        if not _google_sync_is_enabled_for_writes(conn):
            return
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              contacts_manifest_needs_drive_export = 1,
              updated_at = ?
            WHERE id = 1
            """,
            (_now_text(),),
        )
        conn.commit()


def mark_meetingdata_for_drive_export() -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        if not _google_sync_is_enabled_for_writes(conn):
            return
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              meetingdata_needs_drive_export = 1,
              updated_at = ?
            WHERE id = 1
            """,
            (_now_text(),),
        )
        conn.commit()


def mark_field_list_for_drive_export() -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        if not _google_sync_is_enabled_for_writes(conn):
            return
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              field_list_needs_drive_export = 1,
              updated_at = ?
            WHERE id = 1
            """,
            (_now_text(),),
        )
        conn.commit()


def mark_book_layouts_for_drive_export() -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        if not _google_sync_is_enabled_for_writes(conn):
            return
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              book_layouts_needs_drive_export = 1,
              updated_at = ?
            WHERE id = 1
            """,
            (_now_text(),),
        )
        conn.commit()


def _clear_pending_drive_export(conn) -> None:
    conn.execute(
        """
        UPDATE google_sync_state
        SET
          needs_drive_export = 0,
          updated_at = ?
        WHERE id = 1
        """,
        (_now_text(),),
    )


def _clear_pending_contacts_manifest_drive_export(conn) -> None:
    conn.execute(
        """
        UPDATE google_sync_state
        SET
          contacts_manifest_needs_drive_export = 0,
          updated_at = ?
        WHERE id = 1
        """,
        (_now_text(),),
    )


def _clear_pending_meetingdata_drive_export(conn) -> None:
    conn.execute(
        """
        UPDATE google_sync_state
        SET
          meetingdata_needs_drive_export = 0,
          updated_at = ?
        WHERE id = 1
        """,
        (_now_text(),),
    )


def _clear_pending_field_list_drive_export(conn) -> None:
    conn.execute(
        """
        UPDATE google_sync_state
        SET
          field_list_needs_drive_export = 0,
          updated_at = ?
        WHERE id = 1
        """,
        (_now_text(),),
    )


def _clear_pending_book_layouts_drive_export(conn) -> None:
    conn.execute(
        """
        UPDATE google_sync_state
        SET
          book_layouts_needs_drive_export = 0,
          updated_at = ?
        WHERE id = 1
        """,
        (_now_text(),),
    )


def _clear_pending_changes_list_drive_export(conn) -> None:
    conn.execute(
        """
        UPDATE google_sync_state
        SET
          changes_list_needs_drive_export = 0,
          updated_at = ?
        WHERE id = 1
        """,
        (_now_text(),),
    )


def clear_pending_contact_sync(contact_id: int | None = None, google_contact_id: str = "") -> None:
    normalized_google_contact_id = str(google_contact_id or "").strip()
    if contact_id is None and not normalized_google_contact_id:
        return
    ensure_google_sync_records()
    with get_connection() as conn:
        if contact_id is not None:
            conn.execute(
                """
                DELETE FROM google_sync_queue
                WHERE status = 'pending' AND contact_id = ?
                """,
                (contact_id,),
            )
        if normalized_google_contact_id:
            conn.execute(
                """
                DELETE FROM google_sync_queue
                WHERE status = 'pending' AND google_contact_id = ?
                """,
                (normalized_google_contact_id,),
            )
        _refresh_pending_upload_count(conn)
        conn.commit()


def record_google_import_warning() -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              import_warning_acknowledged_at = ?,
              updated_at = ?
            WHERE id = 1
            """,
            (_now_text(), _now_text()),
        )
        conn.commit()


def record_google_upload_attempt() -> bool:
    ensure_google_sync_records()
    with get_connection() as conn:
        pending_count = _refresh_pending_upload_count(conn)
        if pending_count <= 0:
            conn.execute(
                """
                UPDATE google_sync_state
                SET
                  last_sync_error = ?,
                  updated_at = ?
                WHERE id = 1
                """,
                (SYNC_NOTICE_MESSAGES["upload_queue_empty"], _now_text()),
            )
            conn.commit()
            return False

        conn.execute(
            """
            UPDATE google_sync_state
            SET
              last_sync_error = ?,
              updated_at = ?
            WHERE id = 1
            """,
            (SYNC_NOTICE_MESSAGES["upload_not_ready"], _now_text()),
        )
        conn.commit()
        return True


def _set_last_sync_error(conn, message: str) -> None:
    conn.execute(
        """
        UPDATE google_sync_state
        SET
          last_sync_error = ?,
          updated_at = ?
        WHERE id = 1
        """,
        (str(message or "").strip(), _now_text()),
    )


def _clear_last_sync_error(conn) -> None:
    _set_last_sync_error(conn, "")


def record_google_sync_error(message: str) -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        _set_last_sync_error(conn, message)
        conn.commit()


def store_pending_oauth_state(state: str) -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              pending_oauth_state = ?,
              pending_oauth_state_created_at = ?,
              updated_at = ?
            WHERE id = 1
            """,
            (state, _now_text(), _now_text()),
        )
        conn.commit()


def clear_pending_oauth_state() -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              pending_oauth_state = '',
              pending_oauth_state_created_at = '',
              updated_at = ?
            WHERE id = 1
            """,
            (_now_text(),),
        )
        conn.commit()


def create_google_auth_url() -> str:
    if not _oauth_is_configured():
        raise RuntimeError("Google OAuth is not configured.")
    state = secrets.token_urlsafe(24)
    store_pending_oauth_state(state)
    params = {
        "client_id": GOOGLE_OAUTH_CLIENT_ID,
        "redirect_uri": GOOGLE_OAUTH_REDIRECT_URI,
        "response_type": "code",
        "scope": " ".join(GOOGLE_SCOPES),
        "access_type": "offline",
        "include_granted_scopes": "false",
        "prompt": "select_account consent",
        "state": state,
    }
    return f"{GOOGLE_AUTH_BASE_URL}?{urlencode(params)}"


def _load_pending_oauth_state() -> str:
    ensure_google_sync_records()
    with get_connection() as conn:
        row = conn.execute("SELECT pending_oauth_state FROM google_sync_state WHERE id = 1").fetchone()
    return str(row["pending_oauth_state"] or "") if row else ""


def _exchange_code_for_tokens(code: str) -> dict:
    return _json_request(
        GOOGLE_TOKEN_URL,
        method="POST",
        data={
            "code": code,
            "client_id": GOOGLE_OAUTH_CLIENT_ID,
            "client_secret": GOOGLE_OAUTH_CLIENT_SECRET,
            "redirect_uri": GOOGLE_OAUTH_REDIRECT_URI,
            "grant_type": "authorization_code",
        },
    )


def _refresh_access_token(refresh_token: str) -> dict:
    return _json_request(
        GOOGLE_TOKEN_URL,
        method="POST",
        data={
            "client_id": GOOGLE_OAUTH_CLIENT_ID,
            "client_secret": GOOGLE_OAUTH_CLIENT_SECRET,
            "refresh_token": refresh_token,
            "grant_type": "refresh_token",
        },
    )


def _fetch_userinfo(access_token: str) -> dict:
    return _json_request(
        GOOGLE_USERINFO_URL,
        headers={"Authorization": f"Bearer {access_token}"},
    )


def complete_google_oauth(code: str, state: str) -> None:
    if not _oauth_is_configured():
        raise RuntimeError(SYNC_NOTICE_MESSAGES["oauth_not_configured"])

    pending_state = _load_pending_oauth_state()
    if not pending_state or state != pending_state:
        raise RuntimeError("Google OAuth state did not match the pending request.")

    token_data = _exchange_code_for_tokens(code)
    access_token = str(token_data.get("access_token") or "")
    refresh_token = str(token_data.get("refresh_token") or "")
    expires_in = int(token_data.get("expires_in") or 3600)
    scope_text = str(token_data.get("scope") or "")
    token_expiry = (_utc_now() + timedelta(seconds=max(expires_in - 60, 60))).isoformat()
    userinfo = _fetch_userinfo(access_token)
    account_email = str(userinfo.get("email") or "").strip()
    google_user_id = str(userinfo.get("sub") or "").strip()
    google_display_name = ""

    with get_connection() as conn:
        existing_row = conn.execute(
            "SELECT refresh_token, account_email, google_user_id FROM google_sync_accounts WHERE id = 1"
        ).fetchone()
        previous_email = str(existing_row["account_email"] or "") if existing_row else ""
        previous_user_id = str(existing_row["google_user_id"] or "") if existing_row else ""
        email_changed = bool(previous_email and account_email and previous_email != account_email)
        user_id_changed = bool(previous_user_id and google_user_id and previous_user_id != google_user_id)
        account_changed = email_changed or user_id_changed
        saved_refresh_token = refresh_token or ("" if account_changed else (str(existing_row["refresh_token"] or "") if existing_row else ""))
        conn.execute(
            """
            UPDATE google_sync_accounts
            SET
              account_email = ?,
              remember_preferred_account = 1,
              account_status = 'connected',
              google_user_id = ?,
              google_display_name = ?,
              access_token = ?,
              refresh_token = ?,
              token_expiry = ?,
              scopes = ?,
              updated_at = ?
            WHERE id = 1
            """,
            (
                account_email,
                google_user_id,
                google_display_name,
                access_token,
                saved_refresh_token,
                token_expiry,
                scope_text,
                _now_text(),
            ),
        )
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              last_sync_error = '',
              drive_root_folder_id = '',
              drive_app_revisions_folder_id = '',
              drive_app_revisions_file_id = '',
              pending_oauth_state = '',
              pending_oauth_state_created_at = '',
              signin_sync_in_progress = 0,
              signin_sync_phase = '',
              signin_sync_error = '',
              signin_sync_total_count = 0,
              signin_sync_processed_count = 0,
              signin_sync_current_item = '',
              editor_name = '',
              editor_session_id = '',
              sync_enabled = CASE WHEN multi_editor_enabled = 1 THEN sync_enabled ELSE 1 END,
              editor_mode = CASE WHEN multi_editor_enabled = 1 THEN 'no_edit' ELSE 'normal' END,
              editor_lock_owner_name = '',
              editor_lock_expires_at = '',
              updated_at = ?
            WHERE id = 1
            """,
            (_now_text(),),
        )
        if account_changed:
            _clear_transfer_progress_for_account_switch(conn)
        state_row = conn.execute("SELECT multi_editor_enabled FROM google_sync_state WHERE id = 1").fetchone()
        if state_row and not bool(state_row["multi_editor_enabled"] or 0):
            _queue_unuploaded_local_contacts(conn)
            _refresh_pending_upload_count(conn)
        conn.commit()

    try:
        import_shared_settings_from_google_drive(export_if_missing=False)
    except (RuntimeError, HTTPError, URLError):
        summary = get_google_sync_summary()
        state = summary.get("state") or {}
        if bool(state.get("multi_editor_enabled")):
            raise

def disconnect_google_account(*, preserve_editor_lock_notice: bool = False) -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        account_row = conn.execute("SELECT account_email, remember_preferred_account FROM google_sync_accounts WHERE id = 1").fetchone()
        remembered_email = ""
        if account_row and bool(account_row["remember_preferred_account"] or 0):
            remembered_email = str(account_row["account_email"] or "")
        lock_notice_owner = ""
        lock_notice_expires_at = ""
        if preserve_editor_lock_notice:
            state_row = conn.execute(
                "SELECT editor_lock_owner_name, editor_lock_expires_at FROM google_sync_state WHERE id = 1"
            ).fetchone()
            if state_row:
                lock_notice_owner = str(state_row["editor_lock_owner_name"] or "")
                lock_notice_expires_at = str(state_row["editor_lock_expires_at"] or "")
        conn.execute(
            """
            UPDATE google_sync_accounts
            SET
              account_email = ?,
              account_status = 'not_connected',
              google_user_id = '',
              google_display_name = '',
              access_token = '',
              refresh_token = '',
              token_expiry = '',
              scopes = '',
              updated_at = ?
            WHERE id = 1
            """,
            (remembered_email, _now_text()),
        )
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              sync_enabled = 0,
              last_sync_error = '',
              last_drive_export_at = '',
              signin_sync_in_progress = 0,
              signin_sync_phase = '',
              signin_sync_error = '',
              drive_root_folder_id = '',
              drive_app_revisions_folder_id = '',
              drive_app_revisions_file_id = '',
              upload_in_progress = 0,
              upload_phase = '',
              upload_total_count = 0,
              upload_processed_count = 0,
              upload_current_contact = '',
              upload_started_at = '',
              bootstrap_status = 'idle',
              bootstrap_total_contacts = 0,
              bootstrap_processed_contacts = 0,
              bootstrap_last_contact_id = 0,
              bootstrap_started_at = '',
              bootstrap_updated_at = ?,
              bootstrap_error = '',
              pending_oauth_state = '',
              pending_oauth_state_created_at = '',
              editor_name = '',
              editor_session_id = '',
              editor_mode = CASE WHEN multi_editor_enabled = 1 THEN 'no_edit' ELSE 'normal' END,
              editor_lock_owner_name = ?,
              editor_lock_expires_at = ?,
              pending_editor_name = '',
              access_role = 'editor',
              access_name = '',
              access_signed_in_at = '',
              updated_at = ?
            WHERE id = 1
            """,
            (_now_text(), lock_notice_owner, lock_notice_expires_at, _now_text()),
        )
        conn.commit()


def _load_google_account() -> dict:
    ensure_google_sync_records()
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM google_sync_accounts WHERE id = 1").fetchone()
    return dict(row) if row else {}


def _mark_google_reconnect_required(message: str) -> None:
    error_message = _clean(message) or "Google sign-in expired or was revoked. Reconnect the Google account."
    with get_connection() as conn:
        account_row = conn.execute(
            "SELECT account_email, remember_preferred_account FROM google_sync_accounts WHERE id = 1"
        ).fetchone()
        remembered_email = ""
        if account_row and bool(account_row["remember_preferred_account"] or 0):
            remembered_email = str(account_row["account_email"] or "")
        conn.execute(
            """
            UPDATE google_sync_accounts
            SET
              account_email = ?,
              account_status = 'not_connected',
              google_user_id = '',
              google_display_name = '',
              access_token = '',
              refresh_token = '',
              token_expiry = '',
              scopes = '',
              updated_at = ?
            WHERE id = 1
            """,
            (remembered_email, _now_text()),
        )
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              sync_enabled = 0,
              upload_in_progress = 0,
              upload_phase = '',
              upload_current_contact = '',
              last_sync_error = ?,
              signin_sync_in_progress = 0,
              signin_sync_phase = '',
              signin_sync_error = '',
              updated_at = ?
            WHERE id = 1
            """,
            (error_message, _now_text()),
        )
        conn.commit()


def _get_valid_access_token() -> tuple[str, str]:
    account = _load_google_account()
    access_token = str(account.get("access_token") or "")
    refresh_token = str(account.get("refresh_token") or "")
    token_expiry_raw = str(account.get("token_expiry") or "")
    if not access_token and not refresh_token:
        raise RuntimeError("Google account is not connected.")

    expiry = None
    if token_expiry_raw:
        try:
            expiry = datetime.fromisoformat(token_expiry_raw)
        except ValueError:
            expiry = None

    if access_token and expiry and expiry > _utc_now():
        return access_token, str(account.get("account_email") or "")

    if not refresh_token:
        raise RuntimeError("Google refresh token is missing. Reconnect the Google account.")

    try:
        refreshed = _refresh_access_token(refresh_token)
    except HTTPError as exc:
        message = _http_error_message(exc)
        normalized_message = message.lower()
        if _looks_like_reconnect_error(normalized_message):
            reconnect_message = "Google sign-in expired or was revoked. Reconnect the Google account."
            _mark_google_reconnect_required(reconnect_message)
            raise RuntimeError(reconnect_message) from exc
        raise
    new_access_token = str(refreshed.get("access_token") or "")
    stored_email = str(account.get("account_email") or "")
    stored_user_id = str(account.get("google_user_id") or "")
    if new_access_token and (stored_email or stored_user_id):
        refreshed_userinfo = _fetch_userinfo(new_access_token)
        refreshed_email = str(refreshed_userinfo.get("email") or "").strip()
        refreshed_user_id = str(refreshed_userinfo.get("sub") or "").strip()
        if (stored_email and refreshed_email != stored_email) or (stored_user_id and refreshed_user_id != stored_user_id):
            reconnect_message = "Google sign-in does not match the connected account. Reconnect the Google account."
            _mark_google_reconnect_required(reconnect_message)
            raise RuntimeError(reconnect_message)
    expires_in = int(refreshed.get("expires_in") or 3600)
    token_expiry = (_utc_now() + timedelta(seconds=max(expires_in - 60, 60))).isoformat()
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE google_sync_accounts
            SET
              access_token = ?,
              token_expiry = ?,
              updated_at = ?
            WHERE id = 1
            """,
            (new_access_token, token_expiry, _now_text()),
        )
        conn.commit()
    return new_access_token, str(account.get("account_email") or "")


def _api_get_json(url: str, access_token: str) -> dict:
    return _json_request(
        url,
        headers={"Authorization": f"Bearer {access_token}"},
    )


def _api_json_request(
    url: str,
    access_token: str,
    *,
    method: str = "GET",
    json_data: dict | None = None,
) -> dict:
    return _json_request(
        url,
        method=method,
        headers={"Authorization": f"Bearer {access_token}"},
        json_data=json_data,
    )


def update_google_contact_photo(resource_name: str, photo_bytes: bytes) -> str:
    normalized_resource_name = _clean(resource_name)
    if not normalized_resource_name:
        raise RuntimeError(SYNC_NOTICE_MESSAGES["contact_photo_google_not_connected"])
    if not photo_bytes:
        raise RuntimeError(SYNC_NOTICE_MESSAGES["contact_photo_google_missing"])
    access_token, _account_email = _get_valid_access_token()
    return _update_google_contact_photo(access_token, normalized_resource_name, photo_bytes)


def _update_google_contact_photo(access_token: str, resource_name: str, photo_bytes: bytes) -> str:
    normalized_resource_name = _clean(resource_name)
    if not normalized_resource_name:
        raise RuntimeError(SYNC_NOTICE_MESSAGES["contact_photo_google_not_connected"])
    if not photo_bytes:
        raise RuntimeError(SYNC_NOTICE_MESSAGES["contact_photo_google_missing"])
    payload = {
        "photoBytes": base64.b64encode(photo_bytes).decode("ascii"),
        "personFields": "photos",
        "sources": ["READ_SOURCE_TYPE_CONTACT"],
    }
    response = _api_json_request(
        f"{GOOGLE_PEOPLE_BASE_URL}/{normalized_resource_name}:updateContactPhoto",
        access_token,
        method="PATCH",
        json_data=payload,
    )
    person = response.get("person") or {}
    return _extract_photo_url(person)


def _drive_json_request(
    url: str,
    access_token: str,
    *,
    method: str = "GET",
    json_data: dict | None = None,
    raw_data: bytes | None = None,
    headers: dict | None = None,
    timeout: int = DEFAULT_HTTP_TIMEOUT_SECONDS,
) -> dict:
    request_headers = {"Authorization": f"Bearer {access_token}"}
    if headers:
        request_headers.update(headers)
    return _json_request(
        url,
        method=method,
        headers=request_headers,
        json_data=json_data,
        raw_data=raw_data,
        timeout=timeout,
        retry_attempts=DRIVE_READ_RETRY_ATTEMPTS,
    )


def _drive_query_literal(value: str) -> str:
    return str(value or "").replace("\\", "\\\\").replace("'", "\\'")


def _store_drive_state(
    *,
    root_folder_id: str | None = None,
    app_revisions_folder_id: str | None = None,
    app_revisions_file_id: str | None = None,
    last_drive_export_at: str | None = None,
    last_sync_error: str | None = None,
) -> None:
    ensure_google_sync_records()
    updates: list[str] = []
    params: list[str] = []
    if root_folder_id is not None:
        updates.append("drive_root_folder_id = ?")
        params.append(str(root_folder_id))
    if app_revisions_folder_id is not None:
        updates.append("drive_app_revisions_folder_id = ?")
        params.append(str(app_revisions_folder_id))
    if app_revisions_file_id is not None:
        updates.append("drive_app_revisions_file_id = ?")
        params.append(str(app_revisions_file_id))
    if last_drive_export_at is not None:
        updates.append("last_drive_export_at = ?")
        params.append(str(last_drive_export_at))
    if last_sync_error is not None:
        updates.append("last_sync_error = ?")
        params.append(str(last_sync_error))
    if not updates:
        return
    updates.append("updated_at = ?")
    params.append(_now_text())
    params.append("1")
    with get_connection() as conn:
        conn.execute(
            f"""
            UPDATE google_sync_state
            SET {", ".join(updates)}
            WHERE id = ?
            """,
            params,
        )
        conn.commit()


def _store_local_sync_revisions(
    *,
    conn=None,
    settings_sync_revision: int | None = None,
    book_layouts_sync_revision: int | None = None,
    contacts_sync_revision: int | None = None,
    meetingdata_sync_revision: int | None = None,
    field_list_sync_revision: int | None = None,
    changes_list_sync_revision: int | None = None,
) -> None:
    updates: list[str] = []
    params: list[int | str] = []
    if settings_sync_revision is not None:
        updates.append("settings_sync_revision = ?")
        params.append(int(settings_sync_revision))
    if book_layouts_sync_revision is not None:
        updates.append("book_layouts_sync_revision = ?")
        params.append(int(book_layouts_sync_revision))
    if contacts_sync_revision is not None:
        updates.append("contacts_sync_revision = ?")
        params.append(int(contacts_sync_revision))
    if meetingdata_sync_revision is not None:
        updates.append("meetingdata_sync_revision = ?")
        params.append(int(meetingdata_sync_revision))
    if field_list_sync_revision is not None:
        updates.append("field_list_sync_revision = ?")
        params.append(int(field_list_sync_revision))
    if changes_list_sync_revision is not None:
        updates.append("changes_list_sync_revision = ?")
        params.append(int(changes_list_sync_revision))
    if not updates:
        return
    updates.append("updated_at = ?")
    params.append(_now_text())
    params.append("1")
    if conn is not None:
        conn.execute(
            f"""
            UPDATE google_sync_state
            SET {", ".join(updates)}
            WHERE id = ?
            """,
            params,
        )
        return
    ensure_google_sync_records()
    with get_connection() as managed_conn:
        managed_conn.execute(
            f"""
            UPDATE google_sync_state
            SET {", ".join(updates)}
            WHERE id = ?
            """,
            params,
        )
        managed_conn.commit()


def _normalize_sync_revision(value: object) -> int:
    try:
        return max(int(value or 0), 0)
    except (TypeError, ValueError):
        return 0


def _shared_sync_state_payload(
    *,
    settings_sync_revision: int,
    contacts_sync_revision: int,
    meetingdata_sync_revision: int,
    field_list_sync_revision: int,
    changes_list_sync_revision: int = 0,
    book_layouts_sync_revision: int = 0,
) -> dict:
    return {
        "format": "contactsfreeshare.shared_sync_state.v1",
        "exported_at": _iso_now(),
        "settings_sync_revision": _normalize_sync_revision(settings_sync_revision),
        "book_layouts_sync_revision": _normalize_sync_revision(book_layouts_sync_revision),
        "contacts_sync_revision": _normalize_sync_revision(contacts_sync_revision),
        "meetingdata_sync_revision": _normalize_sync_revision(meetingdata_sync_revision),
        "field_list_sync_revision": _normalize_sync_revision(field_list_sync_revision),
        "changes_list_sync_revision": _normalize_sync_revision(changes_list_sync_revision),
    }


def _normalize_shared_sync_state(payload: object) -> dict:
    if not isinstance(payload, dict):
        return {
            "settings_sync_revision": 0,
            "book_layouts_sync_revision": 0,
            "contacts_sync_revision": 0,
            "meetingdata_sync_revision": 0,
            "field_list_sync_revision": 0,
            "changes_list_sync_revision": 0,
        }
    return {
        "settings_sync_revision": _normalize_sync_revision(payload.get("settings_sync_revision")),
        "book_layouts_sync_revision": _normalize_sync_revision(payload.get("book_layouts_sync_revision")),
        "contacts_sync_revision": _normalize_sync_revision(payload.get("contacts_sync_revision")),
        "meetingdata_sync_revision": _normalize_sync_revision(payload.get("meetingdata_sync_revision")),
        "field_list_sync_revision": _normalize_sync_revision(payload.get("field_list_sync_revision")),
        "changes_list_sync_revision": _normalize_sync_revision(payload.get("changes_list_sync_revision")),
    }


def _drive_get_file(access_token: str, file_id: str, *, fields: str = "id,name,parents,mimeType") -> dict | None:
    normalized_file_id = _clean(file_id)
    if not normalized_file_id:
        return None
    try:
        return _drive_json_request(
            f"{GOOGLE_DRIVE_BASE_URL}/files/{normalized_file_id}?{urlencode({'fields': fields, 'supportsAllDrives': 'true'})}",
            access_token,
        )
    except HTTPError as exc:
        if exc.code == 404:
            return None
        raise


def _drive_find_child(
    access_token: str,
    *,
    parent_id: str,
    name: str,
    mime_type: str,
) -> dict | None:
    query = " and ".join(
        [
            f"'{_drive_query_literal(parent_id)}' in parents",
            f"name = '{_drive_query_literal(name)}'",
            f"mimeType = '{_drive_query_literal(mime_type)}'",
            "trashed = false",
        ]
    )
    payload = _drive_json_request(
        f"{GOOGLE_DRIVE_BASE_URL}/files?{urlencode({'q': query, 'fields': 'files(id,name,parents,mimeType)', 'pageSize': 1, 'supportsAllDrives': 'true', 'includeItemsFromAllDrives': 'true'})}",
        access_token,
    )
    files = payload.get("files") or []
    return dict(files[0]) if files else None


def _drive_find_children(
    access_token: str,
    *,
    parent_id: str,
    name: str,
    mime_type: str,
    fields: str = "files(id,name,parents,mimeType,createdTime,modifiedTime)",
) -> list[dict]:
    query = " and ".join(
        [
            f"'{_drive_query_literal(parent_id)}' in parents",
            f"name = '{_drive_query_literal(name)}'",
            f"mimeType = '{_drive_query_literal(mime_type)}'",
            "trashed = false",
        ]
    )
    payload = _drive_json_request(
        f"{GOOGLE_DRIVE_BASE_URL}/files?{urlencode({'q': query, 'fields': fields, 'pageSize': 1000, 'supportsAllDrives': 'true', 'includeItemsFromAllDrives': 'true'})}",
        access_token,
    )
    return [dict(item) for item in payload.get("files") or []]


def _drive_list_children(access_token: str, *, parent_id: str) -> list[dict]:
    query = " and ".join(
        [
            f"'{_drive_query_literal(parent_id)}' in parents",
            "trashed = false",
        ]
    )
    payload = _drive_json_request(
        f"{GOOGLE_DRIVE_BASE_URL}/files?{urlencode({'q': query, 'fields': 'files(id,name,parents,mimeType)', 'pageSize': 1000, 'supportsAllDrives': 'true', 'includeItemsFromAllDrives': 'true'})}",
        access_token,
    )
    return [dict(item) for item in payload.get("files") or []]


def _drive_children_by_name(access_token: str, *, parent_id: str) -> dict[str, dict]:
    return {
        _clean(item.get("name")): item
        for item in _drive_list_children(access_token, parent_id=parent_id)
        if _clean(item.get("name"))
    }


def _shared_sync_state_score(payload: dict) -> int:
    return (
        _normalize_sync_revision(payload.get("contacts_sync_revision")) * 1000
        + _normalize_sync_revision(payload.get("settings_sync_revision"))
        + _normalize_sync_revision(payload.get("book_layouts_sync_revision"))
        + _normalize_sync_revision(payload.get("meetingdata_sync_revision"))
        + _normalize_sync_revision(payload.get("field_list_sync_revision"))
        + _normalize_sync_revision(payload.get("changes_list_sync_revision"))
    )


def _drive_root_folder_score(access_token: str, folder_item: dict) -> tuple[int, str]:
    folder_id = _clean(folder_item.get("id"))
    if not folder_id:
        return (0, "")
    modified_time = _clean(folder_item.get("modifiedTime") or folder_item.get("createdTime"))
    try:
        shared_folder = _drive_find_child(
            access_token,
            parent_id=folder_id,
            name=GOOGLE_DRIVE_SHARED_FOLDER_NAME,
            mime_type="application/vnd.google-apps.folder",
        )
        if shared_folder is None:
            return (0, modified_time)
        sync_file = _drive_find_child(
            access_token,
            parent_id=_clean(shared_folder.get("id")),
            name=GOOGLE_DRIVE_SHARED_SYNC_STATE_FILE_NAME,
            mime_type="application/json",
        )
        if sync_file is None:
            return (0, modified_time)
        return (_shared_sync_state_score(_drive_load_json_file_content(access_token, _clean(sync_file.get("id")))), modified_time)
    except (RuntimeError, HTTPError, URLError, ValueError):
        return (0, modified_time)


def _drive_find_best_root_folder(access_token: str) -> dict | None:
    candidates = _drive_find_children(
        access_token,
        parent_id="root",
        name=GOOGLE_DRIVE_ROOT_FOLDER_NAME,
        mime_type="application/vnd.google-apps.folder",
    )
    if not candidates:
        return None
    return max(candidates, key=lambda item: _drive_root_folder_score(access_token, item))


def _drive_create_folder(access_token: str, *, name: str, parent_id: str) -> dict:
    payload = {
        "name": name,
        "mimeType": "application/vnd.google-apps.folder",
        "parents": [parent_id],
    }
    return _drive_json_request(
        f"{GOOGLE_DRIVE_BASE_URL}/files?{urlencode({'fields': 'id,name,parents,mimeType', 'supportsAllDrives': 'true'})}",
        access_token,
        method="POST",
        json_data=payload,
    )


def _drive_create_json_file(access_token: str, *, name: str, parent_id: str) -> dict:
    payload = {
        "name": name,
        "mimeType": "application/json",
        "parents": [parent_id],
    }
    return _drive_json_request(
        f"{GOOGLE_DRIVE_BASE_URL}/files?{urlencode({'fields': 'id,name,parents,mimeType', 'supportsAllDrives': 'true'})}",
        access_token,
        method="POST",
        json_data=payload,
    )


def _drive_create_json_file_with_content(
    access_token: str,
    *,
    name: str,
    parent_id: str,
    payload: dict,
) -> dict:
    boundary = f"contactsfreeshare_{secrets.token_hex(12)}"
    metadata = {
        "name": name,
        "mimeType": "application/json",
        "parents": [parent_id],
    }
    body = "\r\n".join(
        [
            f"--{boundary}",
            "Content-Type: application/json; charset=UTF-8",
            "",
            json.dumps(metadata, separators=(",", ":")),
            f"--{boundary}",
            "Content-Type: application/json; charset=UTF-8",
            "",
            json.dumps(payload, indent=2),
            f"--{boundary}--",
            "",
        ]
    ).encode("utf-8")
    return _drive_json_request(
        f"{GOOGLE_DRIVE_UPLOAD_BASE_URL}/files?{urlencode({'uploadType': 'multipart', 'fields': 'id,name,parents,mimeType', 'supportsAllDrives': 'true'})}",
        access_token,
        method="POST",
        raw_data=body,
        headers={"Content-Type": f"multipart/related; boundary={boundary}"},
        timeout=DRIVE_UPLOAD_TIMEOUT_SECONDS,
    )


def _drive_create_file(
    access_token: str,
    *,
    name: str,
    parent_id: str,
    mime_type: str,
    app_properties: dict[str, str] | None = None,
) -> dict:
    payload = {
        "name": name,
        "mimeType": mime_type,
        "parents": [parent_id],
    }
    cleaned_app_properties = {
        _clean(key): _clean(value)
        for key, value in (app_properties or {}).items()
        if _clean(key) and _clean(value)
    }
    if cleaned_app_properties:
        payload["appProperties"] = cleaned_app_properties
    return _drive_json_request(
        f"{GOOGLE_DRIVE_BASE_URL}/files?{urlencode({'fields': 'id,name,parents,mimeType,appProperties', 'supportsAllDrives': 'true'})}",
        access_token,
        method="POST",
        json_data=payload,
    )


def _drive_update_json_file_content(access_token: str, file_id: str, payload: dict) -> dict:
    return _drive_json_request(
        f"{GOOGLE_DRIVE_UPLOAD_BASE_URL}/files/{file_id}?{urlencode({'uploadType': 'media', 'supportsAllDrives': 'true'})}",
        access_token,
        method="PATCH",
        raw_data=json.dumps(payload, indent=2).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        timeout=DRIVE_JSON_UPLOAD_TIMEOUT_SECONDS,
    )


def _drive_update_file_content(access_token: str, file_id: str, *, content: bytes, mime_type: str) -> dict:
    return _drive_json_request(
        f"{GOOGLE_DRIVE_UPLOAD_BASE_URL}/files/{file_id}?{urlencode({'uploadType': 'media', 'supportsAllDrives': 'true'})}",
        access_token,
        method="PATCH",
        raw_data=content,
        headers={"Content-Type": mime_type},
        timeout=DRIVE_UPLOAD_TIMEOUT_SECONDS,
    )


def _drive_ensure_file_parent(access_token: str, file_id: str, parent_id: str) -> dict | None:
    normalized_file_id = _clean(file_id)
    normalized_parent_id = _clean(parent_id)
    if not normalized_file_id or not normalized_parent_id:
        return None
    file_item = _drive_get_file(
        access_token,
        normalized_file_id,
        fields="id,name,parents,mimeType",
    )
    if not file_item:
        return None
    parents = [_clean(parent) for parent in (file_item.get("parents") or []) if _clean(parent)]
    if parents == [normalized_parent_id]:
        return file_item
    query_params = {
        "fields": "id,name,parents,mimeType",
        "supportsAllDrives": "true",
        "addParents": normalized_parent_id,
    }
    parents_to_remove = [parent for parent in parents if parent != normalized_parent_id]
    if parents_to_remove:
        query_params["removeParents"] = ",".join(parents_to_remove)
    return _drive_json_request(
        f"{GOOGLE_DRIVE_BASE_URL}/files/{normalized_file_id}?{urlencode(query_params)}",
        access_token,
        method="PATCH",
        json_data={},
    )


def _drive_load_json_file_content(access_token: str, file_id: str) -> dict:
    return _drive_json_request(
        f"{GOOGLE_DRIVE_BASE_URL}/files/{file_id}?{urlencode({'alt': 'media', 'supportsAllDrives': 'true'})}",
        access_token,
    )


def _drive_load_file_content(
    access_token: str,
    file_id: str,
    *,
    timeout: int = DRIVE_UPLOAD_TIMEOUT_SECONDS,
) -> bytes:
    request = Request(
        f"{GOOGLE_DRIVE_BASE_URL}/files/{file_id}?{urlencode({'alt': 'media', 'supportsAllDrives': 'true'})}",
        headers={"Authorization": f"Bearer {access_token}"},
        method="GET",
    )
    for attempt in range(1, DRIVE_READ_RETRY_ATTEMPTS + 1):
        try:
            with urlopen(request, timeout=timeout) as response:
                return response.read()
        except HTTPError as exc:
            if attempt >= DRIVE_READ_RETRY_ATTEMPTS or exc.code not in {429, 500, 502, 503, 504}:
                raise
            time.sleep(DRIVE_READ_RETRY_BASE_SECONDS * attempt)
        except (
            TimeoutError,
            socket.timeout,
            URLError,
            http.client.RemoteDisconnected,
            http.client.IncompleteRead,
            http.client.BadStatusLine,
        ):
            if attempt >= DRIVE_READ_RETRY_ATTEMPTS:
                raise
            time.sleep(DRIVE_READ_RETRY_BASE_SECONDS * attempt)
    return b""


def _drive_delete_file_if_exists(access_token: str, file_id: str) -> None:
    normalized_file_id = _clean(file_id)
    if not normalized_file_id:
        return
    try:
        _drive_json_request(
            f"{GOOGLE_DRIVE_BASE_URL}/files/{normalized_file_id}?{urlencode({'supportsAllDrives': 'true'})}",
            access_token,
            method="DELETE",
        )
    except HTTPError as exc:
        if exc.code != 404:
            raise


def ensure_google_drive_app_revisions_storage() -> dict:
    ensure_google_sync_records()
    account = _load_google_account()
    if str(account.get("account_status") or "") != "connected":
        raise RuntimeError(SYNC_NOTICE_MESSAGES["drive_not_connected"])
    if not _account_has_drive_scope(account):
        raise RuntimeError(SYNC_NOTICE_MESSAGES["drive_scope_missing"])

    access_token, account_email = _get_valid_access_token()
    summary = get_google_sync_summary()
    state = summary.get("state") or {}

    root_folder = _drive_get_file(access_token, state.get("drive_root_folder_id") or "")
    if root_folder is None:
        root_folder = _drive_find_best_root_folder(access_token)
    if root_folder is None:
        root_folder = _drive_create_folder(
            access_token,
            name=GOOGLE_DRIVE_ROOT_FOLDER_NAME,
            parent_id="root",
        )

    root_folder_id = _clean(root_folder.get("id"))
    app_revisions_folder = _drive_get_file(access_token, state.get("drive_app_revisions_folder_id") or "")
    if app_revisions_folder is None:
        app_revisions_folder = _drive_find_child(
            access_token,
            parent_id=root_folder_id,
            name=GOOGLE_DRIVE_APP_REVISIONS_FOLDER_NAME,
            mime_type="application/vnd.google-apps.folder",
        )
    if app_revisions_folder is None:
        app_revisions_folder = _drive_create_folder(
            access_token,
            name=GOOGLE_DRIVE_APP_REVISIONS_FOLDER_NAME,
            parent_id=root_folder_id,
        )

    app_revisions_folder_id = _clean(app_revisions_folder.get("id"))
    app_revisions_file = _drive_get_file(access_token, state.get("drive_app_revisions_file_id") or "")
    if app_revisions_file is None:
        app_revisions_file = _drive_find_child(
            access_token,
            parent_id=app_revisions_folder_id,
            name=GOOGLE_DRIVE_APP_REVISIONS_FILE_NAME,
            mime_type="application/json",
        )
    if app_revisions_file is None:
        app_revisions_file = _drive_create_json_file(
            access_token,
            name=GOOGLE_DRIVE_APP_REVISIONS_FILE_NAME,
            parent_id=app_revisions_folder_id,
        )

    app_revisions_file_id = _clean(app_revisions_file.get("id"))
    _store_drive_state(
        root_folder_id=root_folder_id,
        app_revisions_folder_id=app_revisions_folder_id,
        app_revisions_file_id=app_revisions_file_id,
        last_sync_error="",
    )
    return {
        "account_email": account_email,
        "root_folder_id": root_folder_id,
        "app_revisions_folder_id": app_revisions_folder_id,
        "app_revisions_file_id": app_revisions_file_id,
    }


def ensure_google_drive_root_storage() -> dict:
    ensure_google_sync_records()
    account = _load_google_account()
    if str(account.get("account_status") or "") != "connected":
        raise RuntimeError(SYNC_NOTICE_MESSAGES["drive_not_connected"])
    if not _account_has_drive_scope(account):
        raise RuntimeError(SYNC_NOTICE_MESSAGES["drive_scope_missing"])

    access_token, account_email = _get_valid_access_token()
    summary = get_google_sync_summary()
    state = summary.get("state") or {}

    root_folder = _drive_get_file(access_token, state.get("drive_root_folder_id") or "")
    if root_folder is None:
        root_folder = _drive_find_best_root_folder(access_token)
    if root_folder is None:
        root_folder = _drive_create_folder(
            access_token,
            name=GOOGLE_DRIVE_ROOT_FOLDER_NAME,
            parent_id="root",
        )
    root_folder_id = _clean(root_folder.get("id"))
    _store_drive_state(root_folder_id=root_folder_id, last_sync_error="")
    return {
        "account_email": account_email,
        "root_folder_id": root_folder_id,
    }


def _ensure_shared_drive_storage(access_token: str | None = None) -> dict:
    storage = ensure_google_drive_root_storage()
    token = access_token or _get_valid_access_token()[0]
    shared_folder = _drive_find_child(
        token,
        parent_id=storage["root_folder_id"],
        name=GOOGLE_DRIVE_SHARED_FOLDER_NAME,
        mime_type="application/vnd.google-apps.folder",
    )
    if shared_folder is None:
        shared_folder = _drive_create_folder(
            token,
            name=GOOGLE_DRIVE_SHARED_FOLDER_NAME,
            parent_id=storage["root_folder_id"],
        )
    shared_folder_id = _clean(shared_folder.get("id"))
    shared_children = _drive_children_by_name(token, parent_id=shared_folder_id)

    def ensure_folder(name: str) -> str:
        folder_item = shared_children.get(name)
        if folder_item is None or _clean(folder_item.get("mimeType")) != "application/vnd.google-apps.folder":
            folder_item = _drive_create_folder(token, name=name, parent_id=shared_folder_id)
            shared_children[name] = folder_item
        return _clean(folder_item.get("id"))

    def ensure_file(name: str) -> str:
        file_item = shared_children.get(name)
        if file_item is None or _clean(file_item.get("mimeType")) != "application/json":
            file_item = _drive_create_json_file(token, name=name, parent_id=shared_folder_id)
            _drive_update_json_file_content(token, _clean(file_item.get("id")), {})
            shared_children[name] = file_item
        return _clean(file_item.get("id"))

    contact_records_folder_id = ensure_folder(GOOGLE_DRIVE_SHARED_CONTACT_RECORDS_FOLDER_NAME)
    contact_photos_folder_id = ensure_folder(GOOGLE_DRIVE_SHARED_CONTACT_PHOTOS_FOLDER_NAME)

    return {
        **storage,
        "shared_folder_id": shared_folder_id,
        "contact_records_folder_id": contact_records_folder_id,
        "contact_photos_folder_id": contact_photos_folder_id,
        "editor_lock_file_id": ensure_file(GOOGLE_DRIVE_EDITOR_LOCK_FILE_NAME),
        "contacts_current_file_id": ensure_file(GOOGLE_DRIVE_CONTACTS_CURRENT_FILE_NAME),
        "contacts_full_file_id": ensure_file(GOOGLE_DRIVE_CONTACTS_FULL_FILE_NAME),
        "meetingdata_current_file_id": ensure_file(GOOGLE_DRIVE_MEETINGDATA_CURRENT_FILE_NAME),
        "field_list_current_file_id": ensure_file(GOOGLE_DRIVE_FIELD_LIST_CURRENT_FILE_NAME),
        "settings_current_file_id": ensure_file(GOOGLE_DRIVE_SETTINGS_CURRENT_FILE_NAME),
        "book_layouts_current_file_id": ensure_file(GOOGLE_DRIVE_BOOK_LAYOUTS_CURRENT_FILE_NAME),
        "changes_list_current_file_id": ensure_file(GOOGLE_DRIVE_CHANGES_LIST_CURRENT_FILE_NAME),
        "shared_sync_state_file_id": ensure_file(GOOGLE_DRIVE_SHARED_SYNC_STATE_FILE_NAME),
    }


def _ensure_shared_settings_drive_storage(access_token: str | None = None) -> dict:
    storage = ensure_google_drive_root_storage()
    token = access_token or _get_valid_access_token()[0]
    shared_folder = _drive_find_child(
        token,
        parent_id=storage["root_folder_id"],
        name=GOOGLE_DRIVE_SHARED_FOLDER_NAME,
        mime_type="application/vnd.google-apps.folder",
    )
    if shared_folder is None:
        shared_folder = _drive_create_folder(
            token,
            name=GOOGLE_DRIVE_SHARED_FOLDER_NAME,
            parent_id=storage["root_folder_id"],
        )
    shared_folder_id = _clean(shared_folder.get("id"))
    shared_children = _drive_children_by_name(token, parent_id=shared_folder_id)

    def ensure_file(name: str) -> str:
        file_item = shared_children.get(name)
        if file_item is None or _clean(file_item.get("mimeType")) != "application/json":
            file_item = _drive_create_json_file(token, name=name, parent_id=shared_folder_id)
            _drive_update_json_file_content(token, _clean(file_item.get("id")), {})
            shared_children[name] = file_item
        return _clean(file_item.get("id"))

    return {
        **storage,
        "shared_folder_id": shared_folder_id,
        "settings_current_file_id": ensure_file(GOOGLE_DRIVE_SETTINGS_CURRENT_FILE_NAME),
        "shared_sync_state_file_id": ensure_file(GOOGLE_DRIVE_SHARED_SYNC_STATE_FILE_NAME),
    }


def _ensure_shared_book_layouts_drive_storage(access_token: str | None = None) -> dict:
    storage = ensure_google_drive_root_storage()
    token = access_token or _get_valid_access_token()[0]
    shared_folder = _drive_find_child(
        token,
        parent_id=storage["root_folder_id"],
        name=GOOGLE_DRIVE_SHARED_FOLDER_NAME,
        mime_type="application/vnd.google-apps.folder",
    )
    if shared_folder is None:
        shared_folder = _drive_create_folder(
            token,
            name=GOOGLE_DRIVE_SHARED_FOLDER_NAME,
            parent_id=storage["root_folder_id"],
        )
    shared_folder_id = _clean(shared_folder.get("id"))
    shared_children = _drive_children_by_name(token, parent_id=shared_folder_id)

    def ensure_file(name: str) -> str:
        file_item = shared_children.get(name)
        if file_item is None or _clean(file_item.get("mimeType")) != "application/json":
            file_item = _drive_create_json_file(token, name=name, parent_id=shared_folder_id)
            _drive_update_json_file_content(token, _clean(file_item.get("id")), {})
            shared_children[name] = file_item
        return _clean(file_item.get("id"))

    return {
        **storage,
        "shared_folder_id": shared_folder_id,
        "book_layouts_current_file_id": ensure_file(GOOGLE_DRIVE_BOOK_LAYOUTS_CURRENT_FILE_NAME),
        "shared_sync_state_file_id": ensure_file(GOOGLE_DRIVE_SHARED_SYNC_STATE_FILE_NAME),
    }


def _iso_now() -> str:
    return _utc_now().isoformat()


def _parse_iso_datetime(value: str) -> datetime | None:
    try:
        parsed = datetime.fromisoformat(str(value or "").replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _load_editor_lock(access_token: str, file_id: str) -> dict:
    try:
        payload = _drive_load_json_file_content(access_token, file_id)
    except HTTPError as exc:
        if exc.code == 404:
            return {}
        raise
    return payload if isinstance(payload, dict) else {}


def _load_shared_sync_state(access_token: str, storage: dict) -> dict:
    try:
        payload = _drive_load_json_file_content(access_token, storage["shared_sync_state_file_id"])
    except HTTPError as exc:
        if exc.code == 404:
            return _normalize_shared_sync_state({})
        raise
    return _normalize_shared_sync_state(payload)


def _write_shared_sync_state(access_token: str, storage: dict, sync_state: dict) -> dict:
    payload = _shared_sync_state_payload(
        settings_sync_revision=sync_state.get("settings_sync_revision"),
        contacts_sync_revision=sync_state.get("contacts_sync_revision"),
        meetingdata_sync_revision=sync_state.get("meetingdata_sync_revision"),
        field_list_sync_revision=sync_state.get("field_list_sync_revision"),
        changes_list_sync_revision=sync_state.get("changes_list_sync_revision"),
        book_layouts_sync_revision=sync_state.get("book_layouts_sync_revision"),
    )
    _drive_update_json_file_content(access_token, storage["shared_sync_state_file_id"], payload)
    return payload


def _next_dataset_sync_revision(
    access_token: str,
    storage: dict,
    *,
    revision_key: str,
    local_revision: int,
    remote_sync_state: dict | None = None,
) -> tuple[int, dict]:
    sync_state = remote_sync_state or _load_shared_sync_state(access_token, storage)
    remote_revision = _normalize_sync_revision(sync_state.get(revision_key))
    return max(_normalize_sync_revision(local_revision), remote_revision) + 1, sync_state


def _clean_contact_photo_path(photo_url: str | None) -> str:
    photo_path = _clean(str(photo_url or ""))
    return photo_path if photo_path.startswith(CONTACT_PHOTO_STATIC_PREFIX) else ""


def _contact_photo_local_path(photo_url: str | None) -> Path | None:
    normalized_photo = _clean_contact_photo_path(photo_url)
    if not normalized_photo:
        return None
    filename = Path(normalized_photo).name
    if not filename:
        return None
    return CONTACT_PHOTO_STORAGE_DIR / filename


def _local_contact_photo_bytes(photo_url: str | None) -> bytes:
    local_path = _contact_photo_local_path(photo_url)
    if local_path is None or not local_path.is_file():
        return b""
    return local_path.read_bytes()


def _contact_photo_drive_filename(contact_id: int, photo_path: str) -> str:
    suffix = Path(photo_path).suffix.lower() or ".jpg"
    return f"contact_{contact_id}_photo{suffix}"


def _contact_record_drive_filename(contact_id: int) -> str:
    return f"contact_{contact_id}.json"


def mark_contact_for_drive_export(contact_id: int) -> None:
    ensure_google_sync_records()
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE contacts
            SET
              shared_drive_needs_export = 1
            WHERE id = ?
            """,
            (int(contact_id),),
        )
        conn.commit()


def _normalize_exported_contact_row(contact_row: dict) -> dict:
    payload = {
        key: value
        for key, value in dict(contact_row).items()
        if key not in {"relationships", "phones", "emails", "addresses", "custom_fields"}
    }
    payload["photo_needs_export"] = 0
    payload["shared_drive_needs_export"] = 0
    payload["shared_drive_bootstrapped"] = 1
    return payload


def _load_contact_edit_log_rows(conn, contact_id: int) -> list[dict]:
    rows = conn.execute(
        """
        SELECT *
        FROM contact_edit_log_entries
        WHERE contact_id = ?
        ORDER BY batch_created_at DESC, batch_row_index ASC, id ASC
        """,
        (contact_id,),
    ).fetchall()
    return [dict(row) for row in rows]


def _build_shared_contact_record_payload(conn, contact_id: int) -> dict | None:
    contact = _load_contact_for_sync(conn, contact_id)
    if not contact:
        return None
    edit_logs = _load_contact_edit_log_rows(conn, contact_id)
    return {
        "format": "contactsfreeshare.shared_contact.v1",
        "exported_at": _iso_now(),
        "contact": _normalize_exported_contact_row(contact),
        "relationships": [dict(item) for item in contact.get("relationships") or []],
        "phones": [dict(item) for item in contact.get("phones") or []],
        "emails": [dict(item) for item in contact.get("emails") or []],
        "addresses": [dict(item) for item in contact.get("addresses") or []],
        "custom_fields": [dict(item) for item in contact.get("custom_fields") or []],
        "contact_edit_log_entries": edit_logs,
    }


def _shared_contact_payload_matches(local_payload: dict, remote_payload: dict) -> bool:
    if not isinstance(local_payload, dict) or not isinstance(remote_payload, dict):
        return False
    comparable_keys = (
        "format",
        "contact",
        "relationships",
        "phones",
        "emails",
        "addresses",
        "custom_fields",
        "contact_edit_log_entries",
    )
    local_comparable = {key: local_payload.get(key) for key in comparable_keys}
    remote_comparable = {key: remote_payload.get(key) for key in comparable_keys}
    return json.dumps(local_comparable, sort_keys=True, default=str) == json.dumps(
        remote_comparable,
        sort_keys=True,
        default=str,
    )


def _manifest_contact_row_matches(contact_row: dict, manifest_row: dict | None) -> bool:
    if not isinstance(manifest_row, dict):
        return False
    contact_id = int(contact_row.get("id") or 0)
    if contact_id <= 0:
        return False
    return (
        int(manifest_row.get("id") or 0) == contact_id
        and int(manifest_row.get("shared_drive_revision") or 0) == int(contact_row.get("shared_drive_revision") or 0)
        and _clean(manifest_row.get("status")) == _clean(contact_row.get("status"))
        and _clean(manifest_row.get("family_name")) == _clean(contact_row.get("family_name"))
        and _clean(manifest_row.get("given_name")) == _clean(contact_row.get("given_name"))
        and _clean(manifest_row.get("file_name")) == _contact_record_drive_filename(contact_id)
    )


def _shared_assignment_options_payload(conn) -> list[dict]:
    rows = conn.execute(
        """
        SELECT *
        FROM contact_assignment_options
        ORDER BY kind, value, id
        """
    ).fetchall()
    return [dict(row) for row in rows]


def _shared_contacts_manifest_payload(conn) -> dict:
    rows = conn.execute(
        """
        SELECT id, shared_drive_revision, status, family_name, given_name
        FROM contacts
        ORDER BY id
        """
    ).fetchall()
    return {
        "format": "contactsfreeshare.shared_contacts.v2",
        "exported_at": _iso_now(),
        "assignment_options": _shared_assignment_options_payload(conn),
        "contacts": [
            {
                "id": int(row["id"]),
                "shared_drive_revision": int(row["shared_drive_revision"] or 0),
                "status": _clean(row["status"]),
                "family_name": _clean(row["family_name"]),
                "given_name": _clean(row["given_name"]),
                "file_name": _contact_record_drive_filename(int(row["id"])),
            }
            for row in rows
        ],
    }


def _write_contacts_full_snapshot_to_google_drive(access_token: str, storage: dict) -> None:
    from app.services.backup_service import build_contacts_shared_payload

    _drive_update_json_file_content(
        access_token,
        storage["contacts_full_file_id"],
        build_contacts_shared_payload(),
    )


def _insert_row_dict(conn, table_name: str, row: dict) -> None:
    if not isinstance(row, dict) or not row:
        return
    columns = list(row.keys())
    placeholders = ", ".join("?" for _ in columns)
    conn.execute(
        f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({placeholders})",
        tuple(row[column] for column in columns),
    )


def _replace_contact_assignment_options(conn, rows: list[dict]) -> None:
    conn.execute("DELETE FROM contact_assignment_options")
    for row in rows:
        _insert_row_dict(conn, "contact_assignment_options", dict(row))


def _delete_local_contact_record(conn, contact_id: int) -> None:
    conn.execute("DELETE FROM contact_edit_log_entries WHERE contact_id = ?", (contact_id,))
    conn.execute("DELETE FROM relationships WHERE contact_id = ?", (contact_id,))
    conn.execute("DELETE FROM phones WHERE contact_id = ?", (contact_id,))
    conn.execute("DELETE FROM addresses WHERE contact_id = ?", (contact_id,))
    conn.execute("DELETE FROM emails WHERE contact_id = ?", (contact_id,))
    conn.execute("DELETE FROM custom_fields WHERE contact_id = ?", (contact_id,))
    conn.execute("DELETE FROM contacts WHERE id = ?", (contact_id,))


def _upsert_shared_contact_record(conn, payload: dict) -> int:
    contact_row = payload.get("contact")
    if not isinstance(contact_row, dict) or not contact_row:
        raise ValueError("Shared contact payload is missing the contact row.")
    contact_id = int(contact_row.get("id") or 0)
    if contact_id <= 0:
        raise ValueError("Shared contact payload is missing a valid contact id.")

    normalized_contact_row = dict(contact_row)
    normalized_contact_row["photo_needs_export"] = 0
    normalized_contact_row["shared_drive_needs_export"] = 0
    normalized_contact_row["shared_drive_bootstrapped"] = 1

    _delete_local_contact_record(conn, contact_id)
    _insert_row_dict(conn, "contacts", normalized_contact_row)
    for table_name in ("relationships", "phones", "emails", "addresses", "custom_fields", "contact_edit_log_entries"):
        for row in payload.get(table_name) or []:
            _insert_row_dict(conn, table_name, dict(row))
    return contact_id


def _sync_pending_contact_photos_to_google_drive(access_token: str, contact_photos_folder_id: str) -> None:
    CONTACT_PHOTO_STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT id, photo, photo_drive_file_id, photo_needs_export
            FROM contacts
            WHERE photo_needs_export = 1
            ORDER BY id
            """
        ).fetchall()
        for row in rows:
            contact = dict(row)
            contact_id = int(contact.get("id") or 0)
            photo_path = _clean_contact_photo_path(contact.get("photo"))
            drive_file_id = _clean(contact.get("photo_drive_file_id"))
            local_path = _contact_photo_local_path(photo_path)

            if not photo_path or local_path is None or not local_path.is_file():
                if drive_file_id:
                    _drive_delete_file_if_exists(access_token, drive_file_id)
                conn.execute(
                    """
                    UPDATE contacts
                    SET
                      photo_drive_file_id = '',
                      photo_needs_export = 0
                    WHERE id = ?
                    """,
                    (contact_id,),
                )
                continue

            filename = _contact_photo_drive_filename(contact_id, photo_path)
            if not drive_file_id:
                existing_file = _drive_find_child(
                    access_token,
                    parent_id=contact_photos_folder_id,
                    name=filename,
                    mime_type=mimetypes.guess_type(filename)[0] or "image/jpeg",
                )
                if existing_file is None:
                    existing_file = _drive_create_file(
                        access_token,
                        name=filename,
                        parent_id=contact_photos_folder_id,
                        mime_type=mimetypes.guess_type(filename)[0] or "image/jpeg",
                    )
                drive_file_id = _clean(existing_file.get("id"))

            _drive_update_file_content(
                access_token,
                drive_file_id,
                content=local_path.read_bytes(),
                mime_type=mimetypes.guess_type(local_path.name)[0] or "application/octet-stream",
            )
            conn.execute(
                """
                UPDATE contacts
                SET
                  photo_drive_file_id = ?,
                  photo_needs_export = 0
                WHERE id = ?
                """,
                (drive_file_id, contact_id),
            )
        conn.commit()


def _cleanup_remote_contact_photos(access_token: str, contact_photos_folder_id: str) -> None:
    with get_connection() as conn:
        referenced_ids = {
            _clean(row["photo_drive_file_id"])
            for row in conn.execute(
                """
                SELECT photo_drive_file_id
                FROM contacts
                WHERE TRIM(COALESCE(photo_drive_file_id, '')) != ''
                """
            ).fetchall()
            if _clean(row["photo_drive_file_id"])
        }
    for file_item in _drive_list_children(access_token, parent_id=contact_photos_folder_id):
        file_id = _clean(file_item.get("id"))
        if file_id and file_id not in referenced_ids:
            _drive_delete_file_if_exists(access_token, file_id)


def _cleanup_local_contact_photos(referenced_photo_paths: set[str]) -> None:
    if not CONTACT_PHOTO_STORAGE_DIR.exists():
        return
    referenced_filenames = {Path(item).name for item in referenced_photo_paths if item}
    for existing_file in CONTACT_PHOTO_STORAGE_DIR.iterdir():
        if existing_file.is_file() and existing_file.name not in referenced_filenames:
            existing_file.unlink()


def _import_changed_contact_photos_from_google_drive(
    access_token: str,
    previous_photo_state: dict[int, tuple[str, int, str]],
) -> None:
    CONTACT_PHOTO_STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    with get_connection() as conn:
        rows = [
            dict(row)
            for row in conn.execute(
                """
                SELECT id, photo, photo_drive_file_id, photo_sync_revision
                FROM contacts
                ORDER BY id
                """
            ).fetchall()
        ]

    referenced_photo_paths = {
        _clean_contact_photo_path(row.get("photo"))
        for row in rows
        if _clean_contact_photo_path(row.get("photo"))
    }
    for row in rows:
        contact_id = int(row.get("id") or 0)
        photo_path = _clean_contact_photo_path(row.get("photo"))
        drive_file_id = _clean(row.get("photo_drive_file_id"))
        local_path = _contact_photo_local_path(photo_path)
        if not photo_path or not drive_file_id or local_path is None:
            continue
        previous_file_id, previous_revision, previous_photo_path = previous_photo_state.get(contact_id, ("", 0, ""))
        current_revision = int(row.get("photo_sync_revision") or 0)
        if (
            local_path.is_file()
            and drive_file_id == previous_file_id
            and current_revision == previous_revision
            and photo_path == previous_photo_path
        ):
            continue
        local_path.write_bytes(_drive_load_file_content(access_token, drive_file_id))

    _cleanup_local_contact_photos(referenced_photo_paths)


def _export_contacts_manifest_only_to_google_drive(
    conn,
    access_token: str,
    storage: dict,
    remote_sync_state: dict,
    existing_manifest: dict,
    local_contacts_revision: int,
) -> bool:
    if str(existing_manifest.get("format") or "").strip() != "contactsfreeshare.shared_contacts.v2":
        return False

    manifest_payload = _shared_contacts_manifest_payload(conn)
    existing_referenced_files = {
        _clean(item.get("file_name")) or _contact_record_drive_filename(int(item.get("id") or 0))
        for item in existing_manifest.get("contacts") or []
        if isinstance(item, dict) and int(item.get("id") or 0) > 0
    }
    referenced_files = {
        _clean(item.get("file_name"))
        for item in manifest_payload.get("contacts") or []
        if isinstance(item, dict) and _clean(item.get("file_name"))
    }
    removed_files = sorted(existing_referenced_files - referenced_files)

    _set_upload_progress(
        conn,
        in_progress=True,
        phase="drive_shared_data",
        total_count=1,
        processed_count=0,
        current_contact="Shared contact list",
    )
    conn.commit()

    _drive_update_json_file_content(access_token, storage["contacts_current_file_id"], manifest_payload)
    for file_name in removed_files:
        file_item = _drive_find_child(
            access_token,
            parent_id=storage["contact_records_folder_id"],
            name=file_name,
            mime_type="application/json",
        )
        if file_item is not None:
            _drive_delete_file_if_exists(access_token, _clean(file_item.get("id")))

    if existing_referenced_files != referenced_files:
        next_contacts_revision, remote_sync_state = _next_dataset_sync_revision(
            access_token,
            storage,
            revision_key="contacts_sync_revision",
            local_revision=local_contacts_revision,
            remote_sync_state=remote_sync_state,
        )
        remote_sync_state["contacts_sync_revision"] = next_contacts_revision
        _write_shared_sync_state(access_token, storage, remote_sync_state)
        _store_local_sync_revisions(conn=conn, contacts_sync_revision=next_contacts_revision)

    _clear_pending_contacts_manifest_drive_export(conn)
    _set_upload_progress(
        conn,
        in_progress=False,
        phase="",
        total_count=1,
        processed_count=1,
        current_contact="",
        started_at="",
    )
    conn.commit()
    _store_drive_state(last_drive_export_at=_now_text(), last_sync_error="")
    return True


def export_shared_contacts_to_google_drive() -> bool:
    access_token, _account_email = _get_valid_access_token()
    storage = _ensure_shared_drive_storage(access_token)
    remote_sync_state = _load_shared_sync_state(access_token, storage)

    with get_connection() as conn:
        existing_manifest = _drive_load_json_file_content(access_token, storage["contacts_current_file_id"])
        manifest_is_v2 = (
            isinstance(existing_manifest, dict)
            and str(existing_manifest.get("format") or "").strip() == "contactsfreeshare.shared_contacts.v2"
        )
        total_contacts = _count_contacts(conn)
        state_row = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
        state = dict(state_row) if state_row else {}
        local_contacts_revision = _normalize_sync_revision(state.get("contacts_sync_revision"))
        pending_contact_export_count = _count_pending_shared_contact_exports(conn)
        pending_photo_export_count = int(
            (conn.execute("SELECT COUNT(*) AS count FROM contacts WHERE photo_needs_export = 1").fetchone() or {"count": 0})["count"]
            or 0
        )
        bootstrap_remaining_count = _count_unbootstrapped_contacts(conn)
        if (
            manifest_is_v2
            and bool(state.get("contacts_manifest_needs_drive_export") or 0)
            and pending_contact_export_count <= 0
            and pending_photo_export_count <= 0
            and bootstrap_remaining_count <= 0
        ):
            return _export_contacts_manifest_only_to_google_drive(
                conn,
                access_token,
                storage,
                remote_sync_state,
                existing_manifest,
                local_contacts_revision,
            )
        bootstrap_needed = (not manifest_is_v2) or bootstrap_remaining_count > 0

    _sync_pending_contact_photos_to_google_drive(access_token, storage["contact_photos_folder_id"])
    _cleanup_remote_contact_photos(access_token, storage["contact_photos_folder_id"])
    contact_record_files = _drive_children_by_name(access_token, parent_id=storage["contact_records_folder_id"])

    with get_connection() as conn:
        existing_manifest = _drive_load_json_file_content(access_token, storage["contacts_current_file_id"])
        manifest_is_v2 = (
            isinstance(existing_manifest, dict)
            and str(existing_manifest.get("format") or "").strip() == "contactsfreeshare.shared_contacts.v2"
        )
        total_contacts = _count_contacts(conn)
        state_row = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
        state = dict(state_row) if state_row else {}
        local_contacts_revision = _normalize_sync_revision(state.get("contacts_sync_revision"))
        bootstrap_needed = (not manifest_is_v2) or _count_unbootstrapped_contacts(conn) > 0

        if bootstrap_needed:
            bootstrap_status = str(state.get("bootstrap_status") or "idle")
            bootstrap_total = int(state.get("bootstrap_total_contacts") or 0)
            if bootstrap_status not in {"running", "failed"} or bootstrap_total <= 0 or bootstrap_total != total_contacts:
                conn.execute("UPDATE contacts SET shared_drive_bootstrapped = 0")
                _set_bootstrap_state(
                    conn,
                    status="running",
                    total_contacts=total_contacts,
                    processed_contacts=0,
                    last_contact_id=0,
                    started_at=_now_text(),
                    updated_at=_now_text(),
                    error="",
                )
            else:
                _set_bootstrap_state(conn, status="running", updated_at=_now_text(), error="")
            _set_upload_progress(
                conn,
                in_progress=True,
                phase="drive_bootstrap",
                total_count=int((conn.execute("SELECT bootstrap_total_contacts FROM google_sync_state WHERE id = 1").fetchone() or {"bootstrap_total_contacts": total_contacts})["bootstrap_total_contacts"] or total_contacts),
                processed_count=_visible_bootstrap_processed(int((conn.execute("SELECT bootstrap_processed_contacts FROM google_sync_state WHERE id = 1").fetchone() or {"bootstrap_processed_contacts": 0})["bootstrap_processed_contacts"] or 0), total_contacts),
                current_contact="",
                started_at=_now_text(),
            )
            conn.commit()

            while True:
                state = dict(conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone() or {})
                bootstrap_total = int(state.get("bootstrap_total_contacts") or total_contacts)
                bootstrap_processed = int(state.get("bootstrap_processed_contacts") or 0)
                remaining_contacts = _count_unbootstrapped_contacts(conn)
                if remaining_contacts <= 0:
                    break
                batch_rows = conn.execute(
                    """
                    SELECT id
                    FROM contacts
                    WHERE shared_drive_bootstrapped = 0
                    ORDER BY id
                    LIMIT ?
                    """,
                    (DRIVE_BOOTSTRAP_BATCH_SIZE,),
                ).fetchall()
                if not batch_rows:
                    break

                current_contact_name = ""
                for row in batch_rows:
                    contact_id = int(row["id"])
                    payload = _build_shared_contact_record_payload(conn, contact_id)
                    if payload is not None:
                        current_contact_name = _format_queue_contact_name(payload.get("contact") or {}, {})
                        filename = _contact_record_drive_filename(contact_id)
                        file_item = contact_record_files.get(filename)
                        if file_item is None:
                            file_item = _drive_create_json_file_with_content(
                                access_token,
                                name=filename,
                                parent_id=storage["contact_records_folder_id"],
                                payload=payload,
                            )
                            contact_record_files[filename] = file_item
                        else:
                            _drive_update_json_file_content(access_token, _clean(file_item.get("id")), payload)
                    bootstrap_processed += 1
                    conn.execute(
                        """
                        UPDATE contacts
                        SET
                          shared_drive_bootstrapped = 1,
                          shared_drive_needs_export = 0,
                          shared_drive_revision = CASE WHEN shared_drive_revision > 0 THEN shared_drive_revision ELSE 1 END
                        WHERE id = ?
                        """,
                        (contact_id,),
                    )
                    _set_bootstrap_state(
                        conn,
                        status="running",
                        total_contacts=bootstrap_total,
                        processed_contacts=bootstrap_processed,
                        last_contact_id=contact_id,
                        updated_at=_now_text(),
                        error="",
                    )
                    if bootstrap_processed % DRIVE_BOOTSTRAP_VISIBLE_PROGRESS_STEP == 0 or bootstrap_processed >= bootstrap_total:
                        _set_upload_progress(
                            conn,
                            in_progress=True,
                            phase="drive_bootstrap",
                            total_count=bootstrap_total,
                            processed_count=_visible_bootstrap_processed(bootstrap_processed, bootstrap_total),
                            current_contact=current_contact_name,
                            started_at=str(state.get("bootstrap_started_at") or _now_text()),
                        )
                    conn.commit()

                _set_upload_progress(
                    conn,
                    in_progress=True,
                    phase="drive_bootstrap",
                    total_count=bootstrap_total,
                    processed_count=_visible_bootstrap_processed(bootstrap_processed, bootstrap_total),
                    current_contact=current_contact_name,
                    started_at=str(state.get("bootstrap_started_at") or _now_text()),
                )
                conn.commit()

            remaining_dirty_count = _count_unbootstrapped_contacts(conn)
            if remaining_dirty_count <= 0:
                manifest_payload = _shared_contacts_manifest_payload(conn)
                _drive_update_json_file_content(access_token, storage["contacts_current_file_id"], manifest_payload)

                referenced_files = {
                    item["file_name"]
                    for item in manifest_payload.get("contacts") or []
                    if isinstance(item, dict) and _clean(item.get("file_name"))
                }
                for file_item in contact_record_files.values():
                    file_name = _clean(file_item.get("name"))
                    file_id = _clean(file_item.get("id"))
                    if file_name and file_name not in referenced_files:
                        _drive_delete_file_if_exists(access_token, file_id)
                next_contacts_revision, remote_sync_state = _next_dataset_sync_revision(
                    access_token,
                    storage,
                    revision_key="contacts_sync_revision",
                    local_revision=local_contacts_revision,
                    remote_sync_state=remote_sync_state,
                )
                remote_sync_state["contacts_sync_revision"] = next_contacts_revision
                _write_shared_sync_state(access_token, storage, remote_sync_state)
                _store_local_sync_revisions(conn=conn, contacts_sync_revision=next_contacts_revision)
                _mark_bootstrap_complete(conn)
                _clear_pending_drive_export(conn)
                _set_upload_progress(
                    conn,
                    in_progress=False,
                    phase="",
                    total_count=bootstrap_total,
                    processed_count=bootstrap_total,
                    current_contact="",
                    started_at="",
                )
            conn.commit()
            if remaining_dirty_count <= 0:
                _write_contacts_full_snapshot_to_google_drive(access_token, storage)
            _store_drive_state(last_drive_export_at=_now_text(), last_sync_error="")
            return remaining_dirty_count <= 0

        else:
            changed_rows = conn.execute(
                """
                SELECT id
                FROM contacts
                WHERE shared_drive_needs_export = 1
                ORDER BY id
                """
            ).fetchall()
            changed_contact_ids = [int(row["id"]) for row in changed_rows]
            exported_contact_ids: list[int] = []
            uploaded_contact_ids: list[int] = []
            manifest_by_contact_id = {
                int(item.get("id") or 0): item
                for item in (existing_manifest.get("contacts") if isinstance(existing_manifest, dict) else []) or []
                if isinstance(item, dict) and int(item.get("id") or 0) > 0
            }
            for contact_id in changed_contact_ids:
                payload = _build_shared_contact_record_payload(conn, contact_id)
                if payload is None:
                    continue
                current_contact_name = _format_queue_contact_name(payload.get("contact") or {}, {})
                filename = _contact_record_drive_filename(contact_id)
                file_item = contact_record_files.get(filename)
                if file_item is not None and _manifest_contact_row_matches(
                    payload.get("contact") or {},
                    manifest_by_contact_id.get(contact_id),
                ):
                    try:
                        remote_payload = _drive_load_json_file_content(access_token, _clean(file_item.get("id")))
                    except HTTPError as exc:
                        if exc.code != 404:
                            raise
                        remote_payload = {}
                    if _shared_contact_payload_matches(payload, remote_payload):
                        exported_contact_ids.append(contact_id)
                        continue
                _set_upload_progress(
                    conn,
                    in_progress=True,
                    phase="drive_shared_data",
                    total_count=1,
                    processed_count=0,
                    current_contact=current_contact_name or "Shared app data",
                    started_at=str(state.get("upload_started_at") or _now_text()),
                )
                conn.commit()
                if file_item is None:
                    file_item = _drive_create_json_file(
                        access_token,
                        name=filename,
                        parent_id=storage["contact_records_folder_id"],
                    )
                    contact_record_files[filename] = file_item
                _drive_update_json_file_content(access_token, _clean(file_item.get("id")), payload)
                exported_contact_ids.append(contact_id)
                uploaded_contact_ids.append(contact_id)
            if changed_contact_ids and exported_contact_ids and not uploaded_contact_ids:
                placeholders = ",".join("?" for _ in exported_contact_ids)
                conn.execute(
                    f"""
                    UPDATE contacts
                    SET shared_drive_needs_export = 0
                    WHERE id IN ({placeholders})
                    """,
                    tuple(exported_contact_ids),
                )
                conn.commit()
                _store_drive_state(last_drive_export_at=_now_text(), last_sync_error="")
                return True
        remaining_dirty_count = 0 if changed_contact_ids and len(exported_contact_ids) == len(changed_contact_ids) else _count_pending_shared_contact_exports(conn)

        if remaining_dirty_count <= 0:
            manifest_payload = _shared_contacts_manifest_payload(conn)
            existing_referenced_files = {
                _clean(item.get("file_name")) or _contact_record_drive_filename(int(item.get("id") or 0))
                for item in (existing_manifest.get("contacts") if isinstance(existing_manifest, dict) else []) or []
                if isinstance(item, dict) and int(item.get("id") or 0) > 0
            }
            _drive_update_json_file_content(access_token, storage["contacts_current_file_id"], manifest_payload)

            referenced_files = {
                item["file_name"]
                for item in manifest_payload.get("contacts") or []
                if isinstance(item, dict) and _clean(item.get("file_name"))
            }
            for item in manifest_payload.get("contacts") or []:
                if not isinstance(item, dict):
                    continue
                contact_id = int(item.get("id") or 0)
                file_name = _clean(item.get("file_name"))
                if contact_id <= 0 or not file_name or file_name in contact_record_files:
                    continue
                payload = _build_shared_contact_record_payload(conn, contact_id)
                if payload is None:
                    continue
                contact_record_files[file_name] = _drive_create_json_file_with_content(
                    access_token,
                    name=file_name,
                    parent_id=storage["contact_records_folder_id"],
                    payload=payload,
                )
            removed_drive_record_count = 0
            for file_item in contact_record_files.values():
                file_name = _clean(file_item.get("name"))
                file_id = _clean(file_item.get("id"))
                if file_name and file_name not in referenced_files:
                    _drive_delete_file_if_exists(access_token, file_id)
                    removed_drive_record_count += 1
            manifest_contacts_changed = existing_referenced_files != referenced_files
            if uploaded_contact_ids or removed_drive_record_count > 0 or manifest_contacts_changed:
                next_contacts_revision, remote_sync_state = _next_dataset_sync_revision(
                    access_token,
                    storage,
                    revision_key="contacts_sync_revision",
                    local_revision=local_contacts_revision,
                    remote_sync_state=remote_sync_state,
                )
                remote_sync_state["contacts_sync_revision"] = next_contacts_revision
                _write_shared_sync_state(access_token, storage, remote_sync_state)
                _store_local_sync_revisions(conn=conn, contacts_sync_revision=next_contacts_revision)
            if exported_contact_ids:
                placeholders = ",".join("?" for _ in exported_contact_ids)
                conn.execute(
                    f"""
                    UPDATE contacts
                    SET shared_drive_needs_export = 0
                    WHERE id IN ({placeholders})
                    """,
                    tuple(exported_contact_ids),
                )

        conn.commit()
    if remaining_dirty_count <= 0:
        _write_contacts_full_snapshot_to_google_drive(access_token, storage)
    _store_drive_state(last_drive_export_at=_now_text(), last_sync_error="")
    return remaining_dirty_count <= 0


def export_shared_meetingdata_to_google_drive() -> None:
    from app.services.backup_service import build_meetingdata_backup_bytes

    _filename, content = build_meetingdata_backup_bytes()
    summary = get_google_sync_summary()
    state = summary.get("state") or {}
    access_token, _account_email = _get_valid_access_token()
    storage = _ensure_shared_drive_storage(access_token)
    remote_sync_state = _load_shared_sync_state(access_token, storage)
    next_meetingdata_revision, remote_sync_state = _next_dataset_sync_revision(
        access_token,
        storage,
        revision_key="meetingdata_sync_revision",
        local_revision=_normalize_sync_revision(state.get("meetingdata_sync_revision")),
        remote_sync_state=remote_sync_state,
    )
    payload = json.loads(content.decode("utf-8"))
    _drive_update_json_file_content(access_token, storage["meetingdata_current_file_id"], payload)
    remote_sync_state["meetingdata_sync_revision"] = next_meetingdata_revision
    _write_shared_sync_state(access_token, storage, remote_sync_state)
    _store_local_sync_revisions(meetingdata_sync_revision=next_meetingdata_revision)
    _store_drive_state(last_drive_export_at=_now_text(), last_sync_error="")


def import_shared_contacts_from_google_drive(
    *,
    access_token: str | None = None,
    storage: dict | None = None,
    remote_sync_state: dict | None = None,
    progress_callback=None,
) -> bool:
    from app.services.backup_service import restore_contacts_backup_payload

    token = access_token or _get_valid_access_token()[0]
    resolved_storage = storage or _ensure_shared_drive_storage(token)
    sync_state = remote_sync_state or _load_shared_sync_state(token, resolved_storage)
    summary = get_google_sync_summary()
    local_contacts_revision = _normalize_sync_revision((summary.get("state") or {}).get("contacts_sync_revision"))
    remote_contacts_revision = _normalize_sync_revision(sync_state.get("contacts_sync_revision"))
    if remote_contacts_revision > 0 and remote_contacts_revision == local_contacts_revision:
        return True
    with get_connection() as conn:
        local_contact_count = _count_contacts(conn)
        previous_photo_state = {
            int(row["id"]): (
                _clean(row["photo_drive_file_id"]),
                int(row["photo_sync_revision"] or 0),
                _clean_contact_photo_path(row["photo"]),
            )
            for row in conn.execute(
                """
                SELECT id, photo, photo_drive_file_id, photo_sync_revision
                FROM contacts
                """
            ).fetchall()
        }
    if local_contact_count <= 0 and _clean(resolved_storage.get("contacts_full_file_id")):
        full_payload = _drive_load_json_file_content(token, resolved_storage["contacts_full_file_id"])
        if isinstance(full_payload, dict) and full_payload.get("tables"):
            restore_contacts_backup_payload(full_payload, restore_files=False)
            if remote_contacts_revision > 0:
                _store_local_sync_revisions(contacts_sync_revision=remote_contacts_revision)
            _import_changed_contact_photos_from_google_drive(token, previous_photo_state)
            return True
    payload = _drive_load_json_file_content(token, resolved_storage["contacts_current_file_id"])
    if isinstance(payload, dict) and payload.get("tables"):
        restore_contacts_backup_payload(payload, restore_files=False)
        if remote_contacts_revision > 0:
            _store_local_sync_revisions(contacts_sync_revision=remote_contacts_revision)
        _write_contacts_full_snapshot_to_google_drive(token, resolved_storage)
        _import_changed_contact_photos_from_google_drive(token, previous_photo_state)
        return True

    if not isinstance(payload, dict) or str(payload.get("format") or "").strip() != "contactsfreeshare.shared_contacts.v2":
        export_shared_contacts_to_google_drive()
        return False

    with get_connection() as conn:
        local_revision_by_id = {
            int(row["id"]): int(row["shared_drive_revision"] or 0)
            for row in conn.execute(
                """
                SELECT id, shared_drive_revision
                FROM contacts
                """
            ).fetchall()
        }

    remote_contacts = [
        item
        for item in (payload.get("contacts") or [])
        if isinstance(item, dict) and int(item.get("id") or 0) > 0
    ]
    remote_ids = {int(item["id"]) for item in remote_contacts}
    changed_contacts = [
        item
        for item in remote_contacts
        if local_revision_by_id.get(int(item["id"])) != int(item.get("shared_drive_revision") or 0)
    ]
    removed_contact_ids = set(local_revision_by_id) - remote_ids

    changed_contact_count = len(changed_contacts)
    if changed_contacts and progress_callback is not None:
        progress_callback("contacts", 0, changed_contact_count, "Preparing contact records")

    for index, contact_item in enumerate(changed_contacts, start=1):
        contact_name = ", ".join(
            item
            for item in (
                _clean(contact_item.get("family_name")),
                _clean(contact_item.get("given_name")),
            )
            if item
        ) or f"Contact {int(contact_item['id'])}"
        if progress_callback is not None and (index == 1 or index % 10 == 0 or index == changed_contact_count):
            progress_callback("contacts", index, changed_contact_count, contact_name)
        filename = _clean(contact_item.get("file_name")) or _contact_record_drive_filename(int(contact_item["id"]))
        file_item = _drive_find_child(
            token,
            parent_id=resolved_storage["contact_records_folder_id"],
            name=filename,
            mime_type="application/json",
        )
        if file_item is None:
            raise RuntimeError(f"Shared contact file is missing for contact {contact_item['id']}.")
        contact_payload = _drive_load_json_file_content(token, _clean(file_item.get("id")))
        with get_connection() as conn:
            _upsert_shared_contact_record(conn, contact_payload)
            conn.commit()

    with get_connection() as conn:
        if not remote_contacts:
            _clear_local_contact_data(conn)
            if remote_contacts_revision > 0:
                _store_local_sync_revisions(conn=conn, contacts_sync_revision=remote_contacts_revision)
            conn.execute(
                """
                UPDATE google_sync_state
                SET
                  pending_upload_count = 0,
                  needs_upload_reminder = 0,
                  needs_drive_export = 0,
                  last_sync_error = '',
                  updated_at = ?
                WHERE id = 1
                """,
                (_now_text(),),
            )
            conn.commit()
            return True

        for contact_id in sorted(removed_contact_ids):
            _delete_local_contact_record(conn, contact_id)

        _replace_contact_assignment_options(conn, payload.get("assignment_options") or [])
        conn.execute("DELETE FROM google_sync_queue")
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              pending_upload_count = 0,
              needs_upload_reminder = 0,
              needs_drive_export = 0,
              last_sync_error = '',
              updated_at = ?
            WHERE id = 1
            """,
            (_now_text(),),
        )
        conn.commit()

    if remote_contacts_revision > 0:
        _store_local_sync_revisions(contacts_sync_revision=remote_contacts_revision)
    _write_contacts_full_snapshot_to_google_drive(token, resolved_storage)
    _import_changed_contact_photos_from_google_drive(token, previous_photo_state)
    return True


def import_shared_meetingdata_from_google_drive(
    *,
    access_token: str | None = None,
    storage: dict | None = None,
    remote_sync_state: dict | None = None,
) -> bool:
    from app.services.backup_service import restore_meetingdata_backup_payload

    token = access_token or _get_valid_access_token()[0]
    resolved_storage = storage or _ensure_shared_drive_storage(token)
    sync_state = remote_sync_state or _load_shared_sync_state(token, resolved_storage)
    summary = get_google_sync_summary()
    local_meetingdata_revision = _normalize_sync_revision((summary.get("state") or {}).get("meetingdata_sync_revision"))
    remote_meetingdata_revision = _normalize_sync_revision(sync_state.get("meetingdata_sync_revision"))
    if remote_meetingdata_revision > 0 and remote_meetingdata_revision == local_meetingdata_revision:
        return True
    payload = _drive_load_json_file_content(token, resolved_storage["meetingdata_current_file_id"])
    if not isinstance(payload, dict) or not payload.get("tables"):
        if local_meetingdata_revision <= 0:
            with get_connection() as conn:
                _clear_local_meetingdata_data(conn)
                conn.execute(
                    """
                    UPDATE google_sync_state
                    SET meetingdata_needs_drive_export = 0, updated_at = ?
                    WHERE id = 1
                    """,
                    (_now_text(),),
                )
                conn.commit()
        export_shared_meetingdata_to_google_drive()
        return False
    if remote_meetingdata_revision <= 0 and local_meetingdata_revision <= 0:
        with get_connection() as conn:
            _clear_local_meetingdata_data(conn)
            conn.execute(
                """
                UPDATE google_sync_state
                SET meetingdata_needs_drive_export = 0, updated_at = ?
                WHERE id = 1
                """,
                (_now_text(),),
            )
            conn.commit()
        export_shared_meetingdata_to_google_drive()
        return False
    restore_meetingdata_backup_payload(payload)
    if remote_meetingdata_revision > 0:
        _store_local_sync_revisions(meetingdata_sync_revision=remote_meetingdata_revision)
    return True


def export_shared_settings_to_google_drive() -> None:
    summary = get_google_sync_summary()
    state = summary.get("state") or {}
    account_locked = bool(state.get("multi_editor_account_locked") or state.get("multi_editor_enabled"))
    with get_connection() as conn:
        _ensure_editor_secret_configured(conn)
        secret_row = conn.execute(
            """
            SELECT editor_secret_hash, editor_secret_salt
            FROM google_sync_state
            WHERE id = 1
            """
        ).fetchone()
        conn.commit()
    secret_settings = dict(secret_row) if secret_row else {}
    access_token, _account_email = _get_valid_access_token()
    storage = _ensure_shared_settings_drive_storage(access_token)
    remote_sync_state = _load_shared_sync_state(access_token, storage)
    next_settings_revision, remote_sync_state = _next_dataset_sync_revision(
        access_token,
        storage,
        revision_key="settings_sync_revision",
        local_revision=_normalize_sync_revision(state.get("settings_sync_revision")),
        remote_sync_state=remote_sync_state,
    )
    payload = {
        "format": "contactsfreeshare.settings.v1",
        "exported_at": _iso_now(),
        "settings": {
            "multi_editor_enabled": bool(state.get("multi_editor_enabled")),
            "multi_editor_account_locked": account_locked,
            "editor_lock_timeout_minutes": _normalize_editor_timeout_minutes(
                state.get("editor_lock_timeout_minutes")
            ),
            "editor_secret_hash": _clean(secret_settings.get("editor_secret_hash")),
            "editor_secret_salt": _clean(secret_settings.get("editor_secret_salt")),
        },
    }
    _drive_update_json_file_content(access_token, storage["settings_current_file_id"], payload)
    remote_sync_state["settings_sync_revision"] = next_settings_revision
    _write_shared_sync_state(access_token, storage, remote_sync_state)
    _store_local_sync_revisions(settings_sync_revision=next_settings_revision)
    _store_drive_state(last_drive_export_at=_now_text(), last_sync_error="")
    with get_connection() as conn:
        _clear_pending_drive_export(conn)
        conn.commit()


def export_book_layouts_to_google_drive(
    *,
    access_token: str | None = None,
    storage: dict | None = None,
    remote_sync_state: dict | None = None,
) -> None:
    token = access_token or _get_valid_access_token()[0]
    resolved_storage = storage or _ensure_shared_book_layouts_drive_storage(token)
    state = get_google_sync_summary().get("state") or {}
    next_revision, sync_state = _next_dataset_sync_revision(
        token,
        resolved_storage,
        revision_key="book_layouts_sync_revision",
        local_revision=_normalize_sync_revision(state.get("book_layouts_sync_revision")),
        remote_sync_state=remote_sync_state,
    )
    payload = {
        "format": "contactsfreeshare.book_layouts.v1",
        "exported_at": _iso_now(),
        "book_layout_presets": _export_book_layout_presets_payload(),
    }
    _drive_update_json_file_content(token, resolved_storage["book_layouts_current_file_id"], payload)
    sync_state["book_layouts_sync_revision"] = next_revision
    _write_shared_sync_state(token, resolved_storage, sync_state)
    _store_local_sync_revisions(book_layouts_sync_revision=next_revision)
    _store_drive_state(last_drive_export_at=_now_text(), last_sync_error="")
    with get_connection() as conn:
        _clear_pending_book_layouts_drive_export(conn)
        conn.commit()


def _export_book_layout_presets_payload() -> list[dict]:
    ensure_google_sync_records()
    from app.services.meeting_v2_service import ensure_default_book_layout_preset

    ensure_default_book_layout_preset()
    columns_sql = ", ".join(BOOK_LAYOUT_SETTING_COLUMNS)
    with get_connection() as conn:
        rows = conn.execute(
            f"""
            SELECT {columns_sql}
            FROM book_layout_presets
            ORDER BY id
            """
        ).fetchall()
    return [dict(row) for row in rows]


def _coerce_book_layout_preset_payload(raw_preset: object) -> dict | None:
    if not isinstance(raw_preset, dict):
        return None
    cleaned = {column: raw_preset.get(column) for column in BOOK_LAYOUT_SETTING_COLUMNS}
    try:
        cleaned["id"] = int(cleaned.get("id") or 0)
    except (TypeError, ValueError):
        cleaned["id"] = 0
    cleaned["name"] = _clean(cleaned.get("name")) or "Pocket Address Book"
    cleaned["book_title"] = _clean(cleaned.get("book_title")) or "Address Book"
    cleaned["font_family"] = _clean(cleaned.get("font_family")) or "Arial"
    for column in (
        "trim_width_in",
        "trim_height_in",
        "margin_left_in",
        "margin_right_in",
        "margin_top_in",
        "margin_bottom_in",
        "base_font_size_pt",
        "line_height",
        "screen_preview_scale",
    ):
        try:
            cleaned[column] = float(cleaned.get(column))
        except (TypeError, ValueError):
            cleaned[column] = 0.0
    for column in ("meeting_table_column_count", "meeting_table_column_gap_px", "is_default"):
        try:
            cleaned[column] = int(cleaned.get(column) or 0)
        except (TypeError, ValueError):
            cleaned[column] = 0
    for column, fallback in (
        ("meetingdata_title_bar_color", "#e3eff3"),
        ("meetingdata_primary_row_color", "#f8f3e3"),
        ("meetingdata_secondary_row_color", "#edf5f7"),
        ("meetingdata_highlight_row_color", "#ffe3a1"),
        ("contacts_title_bar_color", "#e3eff3"),
        ("contacts_primary_row_color", "#f8f3e3"),
        ("contacts_secondary_row_color", "#edf5f7"),
        ("contacts_highlight_row_color", "#ffe3a1"),
    ):
        cleaned[column] = _clean(cleaned.get(column)) or fallback
    return cleaned if cleaned["id"] > 0 else None


def _import_book_layout_presets_payload(raw_presets: object) -> bool:
    if not isinstance(raw_presets, list):
        return False
    presets = [
        preset
        for preset in (_coerce_book_layout_preset_payload(item) for item in raw_presets)
        if preset is not None
    ]
    if not presets:
        return False

    update_columns = [column for column in BOOK_LAYOUT_SETTING_COLUMNS if column != "id"]
    insert_placeholders = ", ".join("?" for _ in BOOK_LAYOUT_SETTING_COLUMNS)
    update_assignments = ", ".join(f"{column} = ?" for column in update_columns)
    default_preset = next((preset for preset in presets if int(preset.get("is_default") or 0)), None)

    with get_connection() as conn:
        for preset in presets:
            existing_by_id = conn.execute(
                f"""
                SELECT id, {", ".join(BOOK_LAYOUT_COLOR_COLUMNS)}
                FROM book_layout_presets
                WHERE id = ?
                """,
                (preset["id"],),
            ).fetchone()
            if existing_by_id:
                merged_preset = dict(preset)
                for column in BOOK_LAYOUT_COLOR_COLUMNS:
                    merged_preset[column] = existing_by_id[column]
                conn.execute(
                    f"""
                    UPDATE book_layout_presets
                    SET {update_assignments}
                    WHERE id = ?
                    """,
                    tuple(merged_preset[column] for column in update_columns) + (preset["id"],),
                )
                continue

            existing_by_name = conn.execute(
                f"""
                SELECT id, {", ".join(BOOK_LAYOUT_COLOR_COLUMNS)}
                FROM book_layout_presets
                WHERE name = ?
                """,
                (preset["name"],),
            ).fetchone()
            if existing_by_name:
                merged_preset = dict(preset)
                for column in BOOK_LAYOUT_COLOR_COLUMNS:
                    merged_preset[column] = existing_by_name[column]
                conn.execute(
                    f"""
                    UPDATE book_layout_presets
                    SET {update_assignments}
                    WHERE id = ?
                    """,
                    tuple(merged_preset[column] for column in update_columns) + (int(existing_by_name["id"]),),
                )
                continue

            conn.execute(
                f"""
                INSERT INTO book_layout_presets ({", ".join(BOOK_LAYOUT_SETTING_COLUMNS)})
                VALUES ({insert_placeholders})
                """,
                tuple(preset[column] for column in BOOK_LAYOUT_SETTING_COLUMNS),
            )
        if default_preset:
            conn.execute("UPDATE book_layout_presets SET is_default = 0")
            updated_default = conn.execute(
                """
                UPDATE book_layout_presets
                SET is_default = 1
                WHERE id = ?
                """,
                (default_preset["id"],),
            ).rowcount
            if not updated_default:
                conn.execute(
                    """
                    UPDATE book_layout_presets
                    SET is_default = 1
                    WHERE name = ?
                    """,
                    (default_preset["name"],),
                )
        else:
            conn.execute(
                """
                UPDATE book_layout_presets
                SET is_default = CASE
                  WHEN id = (SELECT id FROM book_layout_presets ORDER BY id LIMIT 1) THEN 1
                  ELSE 0
                END
                """
            )
        conn.commit()
    return True


def import_shared_settings_from_google_drive(
    *,
    access_token: str | None = None,
    storage: dict | None = None,
    remote_sync_state: dict | None = None,
    export_if_missing: bool = True,
) -> bool:
    token = access_token or _get_valid_access_token()[0]
    resolved_storage = storage or _ensure_shared_settings_drive_storage(token)
    sync_state = remote_sync_state or _load_shared_sync_state(token, resolved_storage)
    summary = get_google_sync_summary()
    local_state = summary.get("state") or {}
    local_settings_revision = _normalize_sync_revision(local_state.get("settings_sync_revision"))
    remote_settings_revision = _normalize_sync_revision(sync_state.get("settings_sync_revision"))
    if (
        remote_settings_revision > 0
        and remote_settings_revision == local_settings_revision
        and bool(local_state.get("multi_editor_enabled") or local_state.get("multi_editor_account_locked"))
    ):
        return True
    payload = _drive_load_json_file_content(token, resolved_storage["settings_current_file_id"])
    settings = payload.get("settings") if isinstance(payload, dict) else None
    if not isinstance(settings, dict):
        if export_if_missing:
            export_shared_settings_to_google_drive()
        return False
    locked = bool(settings.get("multi_editor_account_locked") or settings.get("multi_editor_enabled"))
    enabled = bool(settings.get("multi_editor_enabled") or locked)
    timeout_minutes = _normalize_editor_timeout_minutes(settings.get("editor_lock_timeout_minutes"))
    remote_secret_hash = _clean(settings.get("editor_secret_hash"))
    remote_secret_salt = _clean(settings.get("editor_secret_salt"))
    ensure_google_sync_records()
    with get_connection() as conn:
        if remote_secret_hash and remote_secret_salt:
            conn.execute(
                """
                UPDATE google_sync_state
                SET
                  multi_editor_enabled = ?,
                  multi_editor_account_locked = ?,
                  editor_lock_timeout_minutes = ?,
                  editor_mode = CASE WHEN ? = 1 AND editor_mode != 'edit' THEN 'no_edit' ELSE editor_mode END,
                  editor_secret_hash = ?,
                  editor_secret_salt = ?,
                  settings_sync_revision = ?,
                  updated_at = ?
                WHERE id = 1
                """,
                (
                    1 if enabled else 0,
                    1 if locked else 0,
                    timeout_minutes,
                    1 if enabled else 0,
                    remote_secret_hash,
                    remote_secret_salt,
                    remote_settings_revision,
                    _now_text(),
                ),
            )
        else:
            conn.execute(
                """
                UPDATE google_sync_state
                SET
                  multi_editor_enabled = ?,
                  multi_editor_account_locked = ?,
                  editor_lock_timeout_minutes = ?,
                  editor_mode = CASE WHEN ? = 1 AND editor_mode != 'edit' THEN 'no_edit' ELSE editor_mode END,
                  settings_sync_revision = ?,
                  updated_at = ?
                WHERE id = 1
                """,
                (
                    1 if enabled else 0,
                    1 if locked else 0,
                    timeout_minutes,
                    1 if enabled else 0,
                    remote_settings_revision,
                    _now_text(),
                ),
            )
            _ensure_editor_secret_configured(conn)
        conn.commit()
    _import_book_layout_presets_payload(payload.get("book_layout_presets"))
    return True


def import_book_layouts_from_google_drive(
    *,
    access_token: str | None = None,
    storage: dict | None = None,
    remote_sync_state: dict | None = None,
) -> bool:
    token = access_token or _get_valid_access_token()[0]
    resolved_storage = storage or _ensure_shared_book_layouts_drive_storage(token)
    sync_state = remote_sync_state or _load_shared_sync_state(token, resolved_storage)
    summary = get_google_sync_summary()
    local_revision = _normalize_sync_revision((summary.get("state") or {}).get("book_layouts_sync_revision"))
    remote_revision = _normalize_sync_revision(sync_state.get("book_layouts_sync_revision"))
    if remote_revision > 0 and remote_revision == local_revision:
        return True
    if remote_revision <= 0:
        export_book_layouts_to_google_drive(
            access_token=token,
            storage=resolved_storage,
            remote_sync_state=sync_state,
        )
        return False
    payload = _drive_load_json_file_content(token, resolved_storage["book_layouts_current_file_id"])
    presets = payload.get("book_layout_presets") if isinstance(payload, dict) else None
    if not _import_book_layout_presets_payload(presets):
        return False
    _store_local_sync_revisions(book_layouts_sync_revision=remote_revision)
    with get_connection() as conn:
        _clear_pending_book_layouts_drive_export(conn)
        conn.commit()
    return True


def export_field_list_to_google_drive(
    *,
    access_token: str | None = None,
    storage: dict | None = None,
    remote_sync_state: dict | None = None,
) -> None:
    from app.services.field_list_service import export_field_list_payload

    token = access_token or _get_valid_access_token()[0]
    resolved_storage = storage or _ensure_shared_drive_storage(token)
    state = get_google_sync_summary().get("state") or {}
    next_revision, sync_state = _next_dataset_sync_revision(
        token,
        resolved_storage,
        revision_key="field_list_sync_revision",
        local_revision=_normalize_sync_revision(state.get("field_list_sync_revision")),
        remote_sync_state=remote_sync_state,
    )
    payload = {
        **export_field_list_payload(),
        "exported_at": _iso_now(),
    }
    _drive_update_json_file_content(token, resolved_storage["field_list_current_file_id"], payload)
    sync_state["field_list_sync_revision"] = next_revision
    _write_shared_sync_state(token, resolved_storage, sync_state)
    _store_local_sync_revisions(field_list_sync_revision=next_revision)
    _store_drive_state(last_drive_export_at=_now_text(), last_sync_error="")


def import_field_list_from_google_drive(
    *,
    access_token: str | None = None,
    storage: dict | None = None,
    remote_sync_state: dict | None = None,
) -> bool:
    from app.services.field_list_service import import_field_list_payload

    token = access_token or _get_valid_access_token()[0]
    resolved_storage = storage or _ensure_shared_drive_storage(token)
    sync_state = remote_sync_state or _load_shared_sync_state(token, resolved_storage)
    summary = get_google_sync_summary()
    local_revision = _normalize_sync_revision((summary.get("state") or {}).get("field_list_sync_revision"))
    remote_revision = _normalize_sync_revision(sync_state.get("field_list_sync_revision"))
    if remote_revision > 0 and remote_revision == local_revision:
        return True
    if remote_revision <= 0:
        export_field_list_to_google_drive(
            access_token=token,
            storage=resolved_storage,
            remote_sync_state=sync_state,
        )
        return False
    payload = _drive_load_json_file_content(token, resolved_storage["field_list_current_file_id"])
    if not import_field_list_payload(payload):
        return False
    _store_local_sync_revisions(field_list_sync_revision=remote_revision)
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE google_sync_state
            SET field_list_needs_drive_export = 0, updated_at = ?
            WHERE id = 1
            """,
            (_now_text(),),
        )
        conn.commit()
    return True


def export_changes_list_to_google_drive(
    *,
    access_token: str | None = None,
    storage: dict | None = None,
    remote_sync_state: dict | None = None,
) -> None:
    from app.services.changes_list_service import export_changes_list_payload

    token = access_token or _get_valid_access_token()[0]
    resolved_storage = storage or _ensure_shared_drive_storage(token)
    state = get_google_sync_summary().get("state") or {}
    next_revision, sync_state = _next_dataset_sync_revision(
        token,
        resolved_storage,
        revision_key="changes_list_sync_revision",
        local_revision=_normalize_sync_revision(state.get("changes_list_sync_revision")),
        remote_sync_state=remote_sync_state,
    )
    payload = {
        "format": "contactsfreeshare.changes_list.v1",
        "exported_at": _iso_now(),
        "entries": export_changes_list_payload(),
    }
    _drive_update_json_file_content(token, resolved_storage["changes_list_current_file_id"], payload)
    sync_state["changes_list_sync_revision"] = next_revision
    _write_shared_sync_state(token, resolved_storage, sync_state)
    _store_local_sync_revisions(changes_list_sync_revision=next_revision)
    _store_drive_state(last_drive_export_at=_now_text(), last_sync_error="")


def import_changes_list_from_google_drive(
    *,
    access_token: str | None = None,
    storage: dict | None = None,
    remote_sync_state: dict | None = None,
) -> bool:
    from app.services.changes_list_service import replace_changes_list_from_payload

    token = access_token or _get_valid_access_token()[0]
    resolved_storage = storage or _ensure_shared_drive_storage(token)
    sync_state = remote_sync_state or _load_shared_sync_state(token, resolved_storage)
    summary = get_google_sync_summary()
    local_revision = _normalize_sync_revision((summary.get("state") or {}).get("changes_list_sync_revision"))
    remote_revision = _normalize_sync_revision(sync_state.get("changes_list_sync_revision"))
    if remote_revision > 0 and remote_revision == local_revision:
        return True
    if remote_revision <= 0:
        export_changes_list_to_google_drive(
            access_token=token,
            storage=resolved_storage,
            remote_sync_state=sync_state,
        )
        return False
    payload = _drive_load_json_file_content(token, resolved_storage["changes_list_current_file_id"])
    entries = payload.get("entries") if isinstance(payload, dict) else None
    if not replace_changes_list_from_payload(entries):
        return False
    _store_local_sync_revisions(changes_list_sync_revision=remote_revision)
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE google_sync_state
            SET changes_list_needs_drive_export = 0, updated_at = ?
            WHERE id = 1
            """,
            (_now_text(),),
        )
        conn.commit()
    return True


def sync_shared_data_from_google_drive() -> None:
    access_token, _account_email = _get_valid_access_token()
    storage = _ensure_shared_drive_storage(access_token)
    remote_sync_state = _load_shared_sync_state(access_token, storage)
    import_shared_settings_from_google_drive(access_token=access_token, storage=storage, remote_sync_state=remote_sync_state)
    import_book_layouts_from_google_drive(access_token=access_token, storage=storage, remote_sync_state=remote_sync_state)
    import_shared_contacts_from_google_drive(access_token=access_token, storage=storage, remote_sync_state=remote_sync_state)
    import_shared_meetingdata_from_google_drive(access_token=access_token, storage=storage, remote_sync_state=remote_sync_state)
    import_field_list_from_google_drive(access_token=access_token, storage=storage, remote_sync_state=remote_sync_state)
    import_changes_list_from_google_drive(access_token=access_token, storage=storage, remote_sync_state=remote_sync_state)


def _run_signin_sync_job(*, skip_settings: bool = False) -> None:
    global _SIGNIN_SYNC_THREAD
    try:
        access_token, account_email = _get_valid_access_token()
        storage = _ensure_shared_drive_storage(access_token)
        remote_sync_state = _load_shared_sync_state(access_token, storage)
        with get_connection() as conn:
            row = conn.execute(
                """
                SELECT
                  settings_sync_revision,
                  book_layouts_sync_revision,
                  contacts_sync_revision,
                  meetingdata_sync_revision,
                  field_list_sync_revision,
                  changes_list_sync_revision,
                  (SELECT COUNT(*) FROM contacts) AS local_contact_count
                FROM google_sync_state
                WHERE id = 1
                """
            ).fetchone()
        local_revisions = dict(row) if row else {}

        def needs_import(revision_key: str) -> bool:
            if revision_key == "contacts_sync_revision" and int(local_revisions.get("local_contact_count") or 0) <= 0:
                return True
            remote_revision = _normalize_sync_revision(remote_sync_state.get(revision_key))
            local_revision = _normalize_sync_revision(local_revisions.get(revision_key))
            return remote_revision <= 0 or remote_revision != local_revision

        if not skip_settings:
            if needs_import("settings_sync_revision"):
                with get_connection() as conn:
                    _set_signin_sync_state(conn, in_progress=True, phase="shared_settings", error="")
                    conn.commit()
            import_shared_settings_from_google_drive(access_token=access_token, storage=storage, remote_sync_state=remote_sync_state)
        if needs_import("book_layouts_sync_revision"):
            with get_connection() as conn:
                _set_signin_sync_state(conn, in_progress=True, phase="book_layouts", error="")
                conn.commit()
        import_book_layouts_from_google_drive(access_token=access_token, storage=storage, remote_sync_state=remote_sync_state)
        if needs_import("contacts_sync_revision"):
            with get_connection() as conn:
                _set_signin_sync_state(conn, in_progress=True, phase="contacts", error="")
                conn.commit()
        import_shared_contacts_from_google_drive(
            access_token=access_token,
            storage=storage,
            remote_sync_state=remote_sync_state,
            progress_callback=_touch_signin_sync,
        )
        if needs_import("meetingdata_sync_revision"):
            with get_connection() as conn:
                _set_signin_sync_state(conn, in_progress=True, phase="meetingdata", error="")
                conn.commit()
        import_shared_meetingdata_from_google_drive(access_token=access_token, storage=storage, remote_sync_state=remote_sync_state)
        if needs_import("field_list_sync_revision"):
            with get_connection() as conn:
                _set_signin_sync_state(conn, in_progress=True, phase="field_list", error="")
                conn.commit()
        import_field_list_from_google_drive(access_token=access_token, storage=storage, remote_sync_state=remote_sync_state)
        if needs_import("changes_list_sync_revision"):
            with get_connection() as conn:
                _set_signin_sync_state(conn, in_progress=True, phase="changes_list", error="")
                conn.commit()
        import_changes_list_from_google_drive(access_token=access_token, storage=storage, remote_sync_state=remote_sync_state)
        with get_connection() as conn:
            _set_signin_sync_state(conn, in_progress=False, phase="", error="")
            conn.execute(
                """
                UPDATE google_sync_state
                SET last_import_at = ?, last_import_account_email = ?, updated_at = ?
                WHERE id = 1
                """,
                (_now_text(), account_email, _now_text()),
            )
            conn.commit()
    except Exception as exc:
        message = _clean(str(exc)) or SYNC_NOTICE_MESSAGES["import_failed"]
        with get_connection() as conn:
            _set_signin_sync_state(conn, in_progress=False, phase="", error=message)
            conn.commit()
    finally:
        with _SIGNIN_SYNC_LOCK:
            _SIGNIN_SYNC_THREAD = None


def _touch_signin_sync(
    phase: str,
    processed_count: int | None = None,
    total_count: int | None = None,
    current_item: str | None = None,
) -> None:
    with get_connection() as conn:
        _set_signin_sync_state(
            conn,
            in_progress=True,
            phase=phase,
            error="",
            total_count=total_count,
            processed_count=processed_count,
            current_item=current_item,
        )
        conn.commit()


def _start_signin_sync_job(*, skip_settings: bool = False) -> None:
    global _SIGNIN_SYNC_THREAD
    with _SIGNIN_SYNC_LOCK:
        if _signin_sync_thread_running():
            return
        with get_connection() as conn:
            _set_signin_sync_state(conn, in_progress=True, phase="starting", error="")
            conn.commit()
        _SIGNIN_SYNC_THREAD = threading.Thread(
            target=_run_signin_sync_job,
            kwargs={"skip_settings": skip_settings},
            daemon=True,
        )
        _SIGNIN_SYNC_THREAD.start()


def get_google_signin_sync_progress() -> dict:
    with get_connection() as conn:
        _clear_stale_signin_sync_if_needed(conn)
        conn.commit()
    summary = get_google_sync_summary()
    state = summary.get("state") or {}
    return {
        "in_progress": bool(state.get("signin_sync_in_progress") or 0),
        "phase": str(state.get("signin_sync_phase") or ""),
        "error": str(state.get("signin_sync_error") or ""),
        "total_count": int(state.get("signin_sync_total_count") or 0),
        "processed_count": int(state.get("signin_sync_processed_count") or 0),
        "current_item": str(state.get("signin_sync_current_item") or ""),
    }


def export_shared_data_to_google_drive() -> None:
    with get_connection() as conn:
        state = dict(conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone() or {})
        settings_needed = bool(state.get("needs_drive_export") or 0)
        book_layouts_needed = bool(state.get("book_layouts_needs_drive_export") or 0)
        contacts_manifest_needed = bool(state.get("contacts_manifest_needs_drive_export") or 0)
        meetingdata_needed = bool(state.get("meetingdata_needs_drive_export") or 0)
        field_list_needed = bool(state.get("field_list_needs_drive_export") or 0)
        changes_list_needed = bool(state.get("changes_list_needs_drive_export") or 0)
        contact_export_needed = _count_pending_shared_contact_exports(conn) > 0
        conn.commit()

    contacts_complete = True
    if settings_needed:
        export_shared_settings_to_google_drive()
    if book_layouts_needed:
        export_book_layouts_to_google_drive()
    if contacts_manifest_needed or contact_export_needed:
        contacts_complete = export_shared_contacts_to_google_drive()
    if meetingdata_needed:
        export_shared_meetingdata_to_google_drive()
    if field_list_needed:
        export_field_list_to_google_drive()
    if changes_list_needed:
        export_changes_list_to_google_drive()

    with get_connection() as conn:
        if settings_needed and contacts_complete:
            _clear_pending_drive_export(conn)
        if book_layouts_needed:
            _clear_pending_book_layouts_drive_export(conn)
        if contacts_manifest_needed and contacts_complete:
            _clear_pending_contacts_manifest_drive_export(conn)
        if meetingdata_needed:
            _clear_pending_meetingdata_drive_export(conn)
        if field_list_needed:
            _clear_pending_field_list_drive_export(conn)
        if changes_list_needed:
            _clear_pending_changes_list_drive_export(conn)
        conn.commit()


def _current_sync_work() -> dict:
    summary = get_google_sync_summary()
    state = summary.get("state") or {}
    bootstrap_status = str(state.get("bootstrap_status") or "idle")
    bootstrap_remaining = int(state.get("bootstrap_remaining_contacts") or 0)
    pending_contact_count = int(state.get("pending_upload_count") or 0)
    drive_export_needed = bool(state.get("needs_drive_export") or 0)
    book_layouts_drive_export_needed = bool(state.get("book_layouts_needs_drive_export") or 0)
    contacts_manifest_drive_export_needed = bool(state.get("contacts_manifest_needs_drive_export") or 0)
    contact_records_drive_export_needed = bool(state.get("contact_records_needs_drive_export") or 0)
    meetingdata_drive_export_needed = bool(state.get("meetingdata_needs_drive_export") or 0)
    field_list_drive_export_needed = bool(state.get("field_list_needs_drive_export") or 0)
    changes_list_drive_export_needed = bool(state.get("changes_list_needs_drive_export") or 0)
    shared_drive_needed = (
        drive_export_needed
        or book_layouts_drive_export_needed
        or contacts_manifest_drive_export_needed
        or contact_records_drive_export_needed
        or meetingdata_drive_export_needed
        or field_list_drive_export_needed
        or changes_list_drive_export_needed
    )
    return {
        "bootstrap_incomplete": bootstrap_status in {"running", "failed"} or bootstrap_remaining > 0,
        "pending_contact_count": pending_contact_count,
        "drive_export_needed": shared_drive_needed,
        "book_layouts_drive_export_needed": book_layouts_drive_export_needed,
        "meetingdata_drive_export_needed": meetingdata_drive_export_needed,
        "field_list_drive_export_needed": field_list_drive_export_needed,
        "changes_list_drive_export_needed": changes_list_drive_export_needed,
        "total_count": pending_contact_count + (1 if shared_drive_needed else 0),
    }


def acquire_editor_lock(editor_name: str, *, force: bool = False, settings_loaded: bool = False) -> dict:
    normalized_name = _clean(editor_name)
    if not normalized_name:
        return {"status": "name_required"}
    access_token, account_email = _get_valid_access_token()
    storage = _ensure_shared_drive_storage(access_token)
    if not settings_loaded:
        import_shared_settings_from_google_drive(access_token=access_token, storage=storage)
        settings_loaded = True
    lock = _load_editor_lock(access_token, storage["editor_lock_file_id"])
    now = _utc_now()
    local_state = get_google_sync_summary().get("state") or {}
    timeout_minutes = _normalize_editor_timeout_minutes(local_state.get("editor_lock_timeout_minutes"))
    expires_at = now + timedelta(minutes=timeout_minutes)
    existing_owner = _clean(lock.get("editor_name"))
    existing_session_id = _clean(lock.get("session_id"))
    existing_expiry = _parse_iso_datetime(_clean(lock.get("expires_at")))
    existing_active = bool(existing_owner and existing_expiry and existing_expiry > now)
    local_session_id = _clean(local_state.get("editor_session_id"))

    if existing_active and existing_session_id and existing_session_id == local_session_id:
        session_id = existing_session_id
    elif existing_active:
        _set_editor_session(
            mode="no_edit",
            owner_name=existing_owner,
            expires_at=existing_expiry.isoformat(),
            pending_editor_name=normalized_name,
        )
        return {"status": "blocked", "owner_name": existing_owner, "expires_at": existing_expiry.isoformat()}
    else:
        session_id = secrets.token_urlsafe(18)

    payload = {
        "format": "contactsfreeshare.editor_lock.v1",
        "editor_name": normalized_name,
        "account_email": account_email,
        "session_id": session_id,
        "locked_at": _iso_now(),
        "heartbeat_at": _iso_now(),
        "timeout_minutes": timeout_minutes,
        "expires_at": expires_at.isoformat(),
    }
    _drive_update_json_file_content(access_token, storage["editor_lock_file_id"], payload)
    _set_editor_session(
        mode="edit",
        editor_name=normalized_name,
        session_id=session_id,
        owner_name=normalized_name,
        expires_at=expires_at.isoformat(),
        pending_editor_name="",
    )
    with get_connection() as conn:
        _set_signin_sync_state(conn, in_progress=False, phase="", error="")
        conn.commit()
    _start_signin_sync_job(skip_settings=settings_loaded)
    return {"status": "acquired", "editor_name": normalized_name, "expires_at": expires_at.isoformat()}


def release_editor_lock() -> None:
    state = get_google_sync_summary().get("state") or {}
    if not bool(state.get("multi_editor_enabled")):
        return
    previous_editor_name = _clean(state.get("editor_name")) or _clean(state.get("pending_editor_name"))
    session_id = _clean(state.get("editor_session_id"))
    if session_id:
        try:
            export_shared_data_to_google_drive()
            access_token, _account_email = _get_valid_access_token()
            storage = _ensure_shared_drive_storage(access_token)
            lock = _load_editor_lock(access_token, storage["editor_lock_file_id"])
            if _clean(lock.get("session_id")) == session_id:
                _drive_update_json_file_content(access_token, storage["editor_lock_file_id"], {})
        finally:
            _set_editor_session(mode="no_edit", pending_editor_name=previous_editor_name)
    else:
        _set_editor_session(mode="no_edit", pending_editor_name=previous_editor_name)


def get_editor_lock_status() -> dict:
    summary = get_google_sync_summary()
    account = summary.get("account") or {}
    state = summary.get("state") or {}
    expires_at = _parse_iso_datetime(_clean(state.get("editor_lock_expires_at")))
    now = _utc_now()
    if _clear_expired_local_editor_session(state, now=now):
        summary = get_google_sync_summary()
        account = summary.get("account") or {}
        state = summary.get("state") or {}
        expires_at = _parse_iso_datetime(_clean(state.get("editor_lock_expires_at")))
    remaining_seconds = 0
    if expires_at:
        remaining_seconds = max(0, int((expires_at - now).total_seconds()))
    active = (
        remaining_seconds > 0
        and _has_active_local_editor_session(account, state, now=now)
    )
    return {
        "active": active,
        "multi_editor_enabled": bool(state.get("multi_editor_enabled")),
        "editor_name": _clean(state.get("editor_name")),
        "owner_name": _clean(state.get("editor_lock_owner_name")) or _clean(state.get("editor_name")),
        "expires_at": expires_at.isoformat() if expires_at else "",
        "remaining_seconds": remaining_seconds,
    }


def extend_editor_lock(minutes: int = EDITOR_LOCK_EXTENSION_MINUTES) -> dict:
    state = get_google_sync_summary().get("state") or {}
    if not bool(state.get("multi_editor_enabled")) or str(state.get("editor_mode") or "") != "edit":
        return {"status": "not_active", **get_editor_lock_status()}
    session_id = _clean(state.get("editor_session_id"))
    if not session_id:
        return {"status": "not_active", **get_editor_lock_status()}
    access_token, _account_email = _get_valid_access_token()
    storage = _ensure_shared_drive_storage(access_token)
    lock = _load_editor_lock(access_token, storage["editor_lock_file_id"])
    if _clean(lock.get("session_id")) != session_id:
        _set_editor_session(mode="no_edit", pending_editor_name=_clean(state.get("editor_name")))
        return {"status": "lost_lock", **get_editor_lock_status()}
    current_expiry = _parse_iso_datetime(_clean(lock.get("expires_at"))) or _utc_now()
    base_expiry = max(current_expiry, _utc_now())
    expires_at = base_expiry + timedelta(minutes=max(1, int(minutes or EDITOR_LOCK_EXTENSION_MINUTES)))
    lock["heartbeat_at"] = _iso_now()
    lock["expires_at"] = expires_at.isoformat()
    _drive_update_json_file_content(access_token, storage["editor_lock_file_id"], lock)
    _set_editor_session(
        mode="edit",
        editor_name=_clean(state.get("editor_name")),
        session_id=session_id,
        owner_name=_clean(state.get("editor_lock_owner_name")) or _clean(state.get("editor_name")),
        expires_at=expires_at.isoformat(),
        pending_editor_name="",
    )
    return {"status": "extended", **get_editor_lock_status()}


def export_shared_data_after_edit() -> None:
    mark_shared_data_for_drive_export()


def export_app_revisions_to_google_drive(revisions: list[dict] | None = None) -> dict:
    storage = ensure_google_drive_app_revisions_storage()
    access_token, account_email = _get_valid_access_token()
    if revisions is None:
        from app.services.app_revision_service import list_app_revisions

        revisions = list_app_revisions(limit=5)
    payload = {
        "format": "contactsfreeshare.app_revisions.v1",
        "account_email": account_email,
        "exported_at": _now_text(),
        "revisions": [
            {
                "date_display": str(item.get("date_display") or ""),
                "version": str(item.get("version") or ""),
                "description": str(item.get("description") or ""),
            }
            for item in revisions
        ],
    }
    _drive_update_json_file_content(access_token, storage["app_revisions_file_id"], payload)
    _store_drive_state(last_drive_export_at=_now_text(), last_sync_error="")
    return {**storage, "account_email": account_email}


def import_app_update_manifest_from_google_drive() -> dict:
    storage = ensure_google_drive_root_storage()
    access_token, account_email = _get_valid_access_token()
    updates_folder = _drive_find_child(
        access_token,
        parent_id=storage["root_folder_id"],
        name=GOOGLE_DRIVE_APP_UPDATES_FOLDER_NAME,
        mime_type="application/vnd.google-apps.folder",
    )
    if updates_folder is None:
        raise RuntimeError("App Updates folder was not found in Google Drive.")
    manifest_file = _drive_find_child(
        access_token,
        parent_id=_clean(updates_folder.get("id")),
        name=GOOGLE_DRIVE_APP_UPDATE_MANIFEST_FILE_NAME,
        mime_type="application/json",
    )
    if manifest_file is None:
        raise RuntimeError("App update manifest was not found in Google Drive.")
    payload = _drive_load_json_file_content(access_token, _clean(manifest_file.get("id")))
    return {
        "account_email": account_email,
        "updates_folder_id": _clean(updates_folder.get("id")),
        "manifest_file_id": _clean(manifest_file.get("id")),
        "manifest": payload if isinstance(payload, dict) else {},
    }


def download_app_update_package_from_google_drive(*, file_id: str) -> dict:
    access_token, account_email = _get_valid_access_token()
    file_item = _drive_get_file(
        access_token,
        file_id,
        fields="id,name,mimeType,size",
    )
    if file_item is None:
        raise RuntimeError("The requested app update package was not found in Google Drive.")
    content = _drive_load_file_content(access_token, _clean(file_item.get("id")), timeout=DRIVE_UPLOAD_TIMEOUT_SECONDS)
    return {
        "account_email": account_email,
        "file_id": _clean(file_item.get("id")),
        "filename": _clean(file_item.get("name")) or "ContactsFreeShare-update.zip",
        "mime_type": _clean(file_item.get("mimeType")) or "application/octet-stream",
        "content": content,
    }


def export_contacts_file_to_google_drive(filename: str, content: bytes, mime_type: str) -> dict:
    storage = ensure_google_drive_root_storage()
    access_token, account_email = _get_valid_access_token()
    existing_file = _drive_find_child(
        access_token,
        parent_id=storage["root_folder_id"],
        name=filename,
        mime_type=mime_type,
    )
    if existing_file is None:
        existing_file = _drive_create_file(
            access_token,
            name=filename,
            parent_id=storage["root_folder_id"],
            mime_type=mime_type,
        )
    file_id = _clean(existing_file.get("id"))
    _drive_update_file_content(access_token, file_id, content=content, mime_type=mime_type)
    _store_drive_state(last_drive_export_at=_now_text(), last_sync_error="")
    return {
        **storage,
        "account_email": account_email,
        "file_id": file_id,
        "filename": filename,
    }


def export_backup_file_to_google_drive(filename: str, content: bytes, mime_type: str) -> dict:
    storage = ensure_google_drive_root_storage()
    access_token, account_email = _get_valid_access_token()
    backups_folder = _drive_find_child(
        access_token,
        parent_id=storage["root_folder_id"],
        name=GOOGLE_DRIVE_BACKUPS_FOLDER_NAME,
        mime_type="application/vnd.google-apps.folder",
    )
    if backups_folder is None:
        backups_folder = _drive_create_folder(
            access_token,
            name=GOOGLE_DRIVE_BACKUPS_FOLDER_NAME,
            parent_id=storage["root_folder_id"],
        )
    backups_folder_id = _clean(backups_folder.get("id"))
    existing_file = _drive_find_child(
        access_token,
        parent_id=backups_folder_id,
        name=filename,
        mime_type=mime_type,
    )
    if existing_file is None:
        existing_file = _drive_create_file(
            access_token,
            name=filename,
            parent_id=backups_folder_id,
            mime_type=mime_type,
        )
    file_id = _clean(existing_file.get("id"))
    _drive_update_file_content(access_token, file_id, content=content, mime_type=mime_type)
    _store_drive_state(last_drive_export_at=_now_text(), last_sync_error="")
    return {
        **storage,
        "account_email": account_email,
        "backups_folder_id": backups_folder_id,
        "file_id": file_id,
        "filename": filename,
    }


def _ensure_google_drive_backups_folder(access_token: str, root_folder_id: str) -> dict:
    backups_folder = _drive_find_child(
        access_token,
        parent_id=root_folder_id,
        name=GOOGLE_DRIVE_BACKUPS_FOLDER_NAME,
        mime_type="application/vnd.google-apps.folder",
    )
    if backups_folder is None:
        backups_folder = _drive_create_folder(
            access_token,
            name=GOOGLE_DRIVE_BACKUPS_FOLDER_NAME,
            parent_id=root_folder_id,
        )
    return backups_folder


def upload_address_book_pdf_to_google_drive(filename: str, content: bytes) -> dict:
    return _upload_address_book_pdf_to_folder(
        filename,
        content,
        folder_name=GOOGLE_DRIVE_ADDRESS_BOOK_PDFS_FOLDER_NAME,
    )


def upload_address_book_printed_pdf_to_google_drive(filename: str, content: bytes) -> dict:
    return _upload_address_book_pdf_to_folder(
        filename,
        content,
        folder_name=GOOGLE_DRIVE_ADDRESS_BOOK_PRINTED_FOLDER_NAME,
    )


def _prune_address_book_pdf_folder(access_token: str, folder_id: str, *, keep_count: int = GOOGLE_DRIVE_ADDRESS_BOOK_PDF_RETENTION_LIMIT) -> None:
    query = " and ".join(
        [
            f"'{_drive_query_literal(folder_id)}' in parents",
            "mimeType = 'application/pdf'",
            "trashed = false",
        ]
    )
    payload = _drive_json_request(
        f"{GOOGLE_DRIVE_BASE_URL}/files?{urlencode({'q': query, 'fields': 'files(id,name,createdTime,modifiedTime)', 'pageSize': 1000, 'orderBy': 'createdTime desc', 'supportsAllDrives': 'true', 'includeItemsFromAllDrives': 'true'})}",
        access_token,
    )
    files = [dict(item) for item in payload.get("files") or []]
    files.sort(
        key=lambda item: (
            _clean(item.get("createdTime")) or _clean(item.get("modifiedTime")),
            _clean(item.get("id")),
        ),
        reverse=True,
    )
    for file_item in files[max(0, keep_count):]:
        _drive_delete_file_if_exists(access_token, _clean(file_item.get("id")))


def _strip_address_book_pdf_date_suffix(filename: str) -> str:
    base = re.sub(r"\.[^.]+$", "", _clean(filename))
    base = re.sub(r"[\s_-]*\d{4}-\d{2}-\d{2}$", "", base)
    base = re.sub(r"[\s_-]*\d{2}-\d{2}-\d{4}$", "", base)
    base = re.sub(r"[\s_-]*\d{1,2}/\d{1,2}/\d{2,4}$", "", base)
    return base.strip()


def _drive_find_folder_by_id_or_name(access_token: str, *, folder_id: str, folder_name: str) -> dict | None:
    normalized_folder_id = _clean(folder_id)
    if normalized_folder_id:
        try:
            folder = _drive_get_file(access_token, normalized_folder_id, fields="id,name,parents,mimeType")
            if folder and _clean(folder.get("mimeType")) == "application/vnd.google-apps.folder":
                return folder
        except HTTPError:
            pass

    # With drive.file, broad name searches across My Drive are intentionally avoided.
    # Shared folders must be app-created or explicitly granted to the app by ID.
    return None


def _address_book_pdf_share_settings() -> dict:
    ensure_google_sync_records()
    with get_connection() as conn:
        row = conn.execute(
            """
            SELECT
              multi_editor_enabled,
              sync_enabled,
              address_book_pdf_share_enabled,
              address_book_pdf_share_folder_id,
              address_book_pdf_share_folder_name
            FROM google_sync_state
            WHERE id = 1
            """
        ).fetchone()
    state = dict(row) if row else {}
    return {
        "enabled": bool((state.get("multi_editor_enabled") or 0) or (state.get("sync_enabled") or 0)) and bool(state.get("address_book_pdf_share_enabled") or 0),
        "folder_id": _clean(state.get("address_book_pdf_share_folder_id")),
        "folder_name": _clean(state.get("address_book_pdf_share_folder_name")),
    }


def _is_address_book_pdf_replacement(file_item: dict, target_base: str) -> bool:
    app_properties = file_item.get("appProperties") if isinstance(file_item.get("appProperties"), dict) else {}
    if _clean(app_properties.get("contactsfreeshare_kind")) == ADDRESS_BOOK_PDF_APP_PROPERTY_KIND:
        return True
    if not target_base:
        return False
    return _strip_address_book_pdf_date_suffix(_clean(file_item.get("name"))) == target_base


def _delete_existing_address_book_pdfs(access_token: str, folder_id: str, filename: str) -> int:
    target_base = _strip_address_book_pdf_date_suffix(filename)
    query = " and ".join(
        [
            f"'{_drive_query_literal(folder_id)}' in parents",
            "mimeType = 'application/pdf'",
            "trashed = false",
        ]
    )
    payload = _drive_json_request(
        f"{GOOGLE_DRIVE_BASE_URL}/files?{urlencode({'q': query, 'fields': 'files(id,name,mimeType,appProperties)', 'pageSize': 1000, 'supportsAllDrives': 'true', 'includeItemsFromAllDrives': 'true'})}",
        access_token,
    )
    deleted_count = 0
    for file_item in payload.get("files") or []:
        if not _is_address_book_pdf_replacement(dict(file_item), target_base):
            continue
        file_id = _clean(file_item.get("id"))
        if not file_id:
            continue
        _drive_delete_file_if_exists(access_token, file_id)
        deleted_count += 1
    return deleted_count


def _mirror_address_book_pdf_to_shared_folder(access_token: str, filename: str, content: bytes) -> dict | None:
    settings = _address_book_pdf_share_settings()
    if not settings["enabled"]:
        return None
    folder = _drive_find_folder_by_id_or_name(
        access_token,
        folder_id=settings["folder_id"],
        folder_name=settings["folder_name"],
    )
    if folder is None:
        return None
    folder_id = _clean(folder.get("id"))
    if not folder_id:
        return None
    deleted_count = _delete_existing_address_book_pdfs(access_token, folder_id, filename)
    file_item = _drive_create_file(
        access_token,
        name=_clean(filename) or "Address_Book.pdf",
        parent_id=folder_id,
        mime_type="application/pdf",
        app_properties={
            "contactsfreeshare_kind": ADDRESS_BOOK_PDF_APP_PROPERTY_KIND,
            "contactsfreeshare_folder": "shared_address_book_pdf",
        },
    )
    file_id = _clean(file_item.get("id"))
    _drive_ensure_file_parent(access_token, file_id, folder_id)
    _drive_update_file_content(
        access_token,
        file_id,
        content=content,
        mime_type="application/pdf",
    )
    _drive_ensure_file_parent(access_token, file_id, folder_id)
    return {
        "folder_id": folder_id,
        "file_id": file_id,
        "folder_name": _clean(folder.get("name")),
        "deleted_count": deleted_count,
    }


def cleanup_orphaned_address_book_pdf_root_files() -> int:
    ensure_google_sync_records()
    account = _load_google_account()
    if str(account.get("account_status") or "") != "connected" or not _account_has_drive_scope(account):
        return 0
    access_token, _account_email = _get_valid_access_token()
    storage = ensure_google_drive_root_storage()
    pdf_folder = _drive_find_child(
        access_token,
        parent_id=storage["root_folder_id"],
        name=GOOGLE_DRIVE_ADDRESS_BOOK_PDFS_FOLDER_NAME,
        mime_type="application/vnd.google-apps.folder",
    )
    in_folder_names: set[str] = set()
    if pdf_folder is not None:
        folder_id = _clean(pdf_folder.get("id"))
        if folder_id:
            folder_query = " and ".join(
                [
                    f"'{_drive_query_literal(folder_id)}' in parents",
                    "mimeType = 'application/pdf'",
                    "trashed = false",
                ]
            )
            folder_payload = _drive_json_request(
                f"{GOOGLE_DRIVE_BASE_URL}/files?{urlencode({'q': folder_query, 'fields': 'files(name)', 'pageSize': 1000, 'supportsAllDrives': 'true', 'includeItemsFromAllDrives': 'true'})}",
                access_token,
            )
            in_folder_names = {
                _clean(item.get("name"))
                for item in folder_payload.get("files") or []
                if _clean(item.get("name"))
            }
    query = " and ".join(
        [
            "'root' in parents",
            "mimeType = 'application/pdf'",
            "trashed = false",
            "'me' in owners",
        ]
    )
    payload = _drive_json_request(
        f"{GOOGLE_DRIVE_BASE_URL}/files?{urlencode({'q': query, 'fields': 'files(id,name,parents,mimeType,appProperties)', 'pageSize': 1000, 'supportsAllDrives': 'true', 'includeItemsFromAllDrives': 'true'})}",
        access_token,
    )
    deleted_count = 0
    for file_item in payload.get("files") or []:
        app_properties = file_item.get("appProperties") if isinstance(file_item.get("appProperties"), dict) else {}
        is_tagged_address_book_pdf = _clean(app_properties.get("contactsfreeshare_kind")) == ADDRESS_BOOK_PDF_APP_PROPERTY_KIND
        is_duplicate_address_book_pdf = _clean(file_item.get("name")) in in_folder_names
        if not is_tagged_address_book_pdf and not is_duplicate_address_book_pdf:
            continue
        file_id = _clean(file_item.get("id"))
        if not file_id:
            continue
        _drive_delete_file_if_exists(access_token, file_id)
        deleted_count += 1
    return deleted_count


def _run_orphaned_address_book_pdf_cleanup_loop() -> None:
    while not _ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_STOP.wait(ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_INTERVAL_SECONDS):
        try:
            cleanup_orphaned_address_book_pdf_root_files()
        except (RuntimeError, HTTPError, URLError) as exc:
            record_google_sync_error(f"Address Book PDF root cleanup failed: {exc}")


def start_orphaned_address_book_pdf_cleanup_job() -> None:
    if not _account_has_drive_scope():
        return
    global _ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_THREAD
    with _ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_LOCK:
        if _ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_THREAD and _ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_THREAD.is_alive():
            return
        _ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_STOP.clear()
        _ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_THREAD = threading.Thread(
            target=_run_orphaned_address_book_pdf_cleanup_loop,
            daemon=True,
        )
        _ORPHANED_ADDRESS_BOOK_PDF_CLEANUP_THREAD.start()


def _upload_address_book_pdf_to_folder(filename: str, content: bytes, *, folder_name: str) -> dict:
    access_token, _account_email = _get_valid_access_token()
    storage = ensure_google_drive_root_storage()
    folder = _drive_find_child(
        access_token,
        parent_id=storage["root_folder_id"],
        name=folder_name,
        mime_type="application/vnd.google-apps.folder",
    )
    if folder is None:
        folder = _drive_create_folder(
            access_token,
            name=folder_name,
            parent_id=storage["root_folder_id"],
        )
    folder_id = _clean(folder.get("id"))
    if not folder_id:
        raise RuntimeError(f"Google Drive folder for {folder_name} did not return an ID.")
    deleted_count = 0
    file_item = _drive_create_file(
        access_token,
        name=_clean(filename) or "Address_Book.pdf",
        parent_id=folder_id,
        mime_type="application/pdf",
        app_properties={
            "contactsfreeshare_kind": ADDRESS_BOOK_PDF_APP_PROPERTY_KIND,
            "contactsfreeshare_folder": folder_name,
        },
    )
    file_id = _clean(file_item.get("id"))
    _drive_ensure_file_parent(access_token, file_id, folder_id)
    _drive_update_file_content(
        access_token,
        file_id,
        content=content,
        mime_type="application/pdf",
    )
    _drive_ensure_file_parent(access_token, file_id, folder_id)
    _prune_address_book_pdf_folder(access_token, folder_id)
    shared_file = None
    if folder_name == GOOGLE_DRIVE_ADDRESS_BOOK_PDFS_FOLDER_NAME:
        try:
            shared_file = _mirror_address_book_pdf_to_shared_folder(access_token, filename, content)
        except (RuntimeError, HTTPError, URLError) as exc:
            shared_file = {"error": str(exc)}
    if _account_has_drive_scope():
        cleanup_orphaned_address_book_pdf_root_files()
    return {
        "folder_id": folder_id,
        "file_id": file_id,
        "filename": _clean(filename),
        "folder_name": folder_name,
        "deleted_count": deleted_count,
        "shared_file": shared_file,
    }


def list_google_drive_backup_files() -> dict[str, list[dict]]:
    storage = ensure_google_drive_root_storage()
    access_token, _account_email = _get_valid_access_token()
    backups_folder = _ensure_google_drive_backups_folder(access_token, storage["root_folder_id"])
    backups_folder_id = _clean(backups_folder.get("id"))

    def list_kind(kind: str) -> list[dict]:
        label = "MeetingData" if kind == "meetingdata" else "Contacts"
        name_prefix = f"ContactsFreeShare_{label}_"
        query = " and ".join(
            [
                f"'{_drive_query_literal(backups_folder_id)}' in parents",
                f"name contains '{_drive_query_literal(name_prefix)}'",
                "mimeType = 'application/json'",
                "trashed = false",
            ]
        )
        payload = _drive_json_request(
            f"{GOOGLE_DRIVE_BASE_URL}/files?{urlencode({'q': query, 'fields': 'files(id,name,createdTime,modifiedTime,size,mimeType)', 'pageSize': 5, 'orderBy': 'createdTime desc', 'supportsAllDrives': 'true', 'includeItemsFromAllDrives': 'true'})}",
            access_token,
        )
        return [
            {
                "id": _clean(item.get("id")),
                "name": _clean(item.get("name")),
                "created_time": _clean(item.get("createdTime")),
                "modified_time": _clean(item.get("modifiedTime")),
                "size": _clean(item.get("size")),
            }
            for item in payload.get("files") or []
            if _clean(item.get("id"))
            and _clean(item.get("name")).startswith(name_prefix)
        ]

    return {
        "contacts": list_kind("contacts"),
        "meetingdata": list_kind("meetingdata"),
    }


def load_google_drive_backup_json(file_id: str) -> dict:
    ensure_google_drive_root_storage()
    access_token, _account_email = _get_valid_access_token()
    payload = _drive_load_json_file_content(access_token, file_id)
    return payload if isinstance(payload, dict) else {}


def import_app_revisions_from_google_drive() -> list[dict]:
    storage = ensure_google_drive_app_revisions_storage()
    access_token, _account_email = _get_valid_access_token()
    payload = _drive_load_json_file_content(access_token, storage["app_revisions_file_id"])
    revisions = payload.get("revisions") or []
    normalized_revisions: list[dict] = []
    for revision in revisions:
        if not isinstance(revision, dict):
            continue
        normalized_revisions.append(
            {
                "date_display": str(revision.get("date_display") or "").strip(),
                "version": str(revision.get("version") or "").strip(),
                "description": str(revision.get("description") or "").strip(),
            }
        )
    return normalized_revisions


def _contact_groups_map(access_token: str) -> dict[str, str]:
    groups: dict[str, str] = {}
    page_token = ""
    while True:
        params = {"pageSize": 1000}
        if page_token:
            params["pageToken"] = page_token
        url = f"{GOOGLE_PEOPLE_BASE_URL}/contactGroups?{urlencode(params)}"
        payload = _api_get_json(url, access_token)
        for item in payload.get("contactGroups", []):
          resource_name = str(item.get("resourceName") or "")
          name = str(item.get("formattedName") or item.get("name") or resource_name)
          if resource_name:
              groups[resource_name] = name
        page_token = str(payload.get("nextPageToken") or "")
        if not page_token:
            break
    return groups


def _contact_groups_lookup(access_token: str) -> tuple[dict[str, str], dict[str, str]]:
    resource_to_name = _contact_groups_map(access_token)
    name_to_resource = {name: resource for resource, name in resource_to_name.items() if name}
    resource_to_name.setdefault("contactGroups/myContacts", "myContacts")
    name_to_resource.setdefault("myContacts", "contactGroups/myContacts")
    return resource_to_name, name_to_resource


def _clean(value) -> str:
    return str(value or "").strip()


def _strip_trailing_parenthetical(value: str) -> str:
    return re.sub(r"\s*\([^)]*\)\s*$", "", str(value or "")).strip()


def _split_group_membership_text(value: str | None) -> list[str]:
    text = str(value or "").replace(":::", "\n").replace(";", "\n")
    values: list[str] = []
    seen: set[str] = set()
    for chunk in text.splitlines():
        cleaned = chunk.strip()
        if not cleaned or cleaned.lower() == "no entry" or cleaned in seen:
            continue
        seen.add(cleaned)
        values.append(cleaned)
    return values


def _group_membership_text(group_names: list[str]) -> str:
    return ":::".join(name for name in group_names if name)


def _shared_group_membership_names(field_name: str, meeting_name: str) -> list[str]:
    cleaned_field_name = _clean(field_name)
    cleaned_meeting_name = _clean(meeting_name)
    if not cleaned_field_name or not cleaned_meeting_name:
        return []
    return [
        f"{cleaned_field_name} - {cleaned_meeting_name} (Shared)",
        "TriState Separates (Shared)",
        "myContacts",
    ]


def _parse_field_meeting(group_names: list[str]) -> tuple[str, str]:
    for name in group_names:
        text = str(name or "").strip()
        if " - " not in text:
            continue
        base = text[:-8].strip() if text.endswith("(Shared)") else text
        field_name, meeting_name = base.split(" - ", 1)
        if field_name and meeting_name:
            return field_name.strip(), meeting_name.strip()
    return "", ""


def _parse_field_meeting_from_organizations(organizations: list[dict]) -> tuple[str, str]:
    for item in organizations:
        field_name = _clean(item.get("title"))
        meeting_name = _clean(item.get("name"))
        if field_name or meeting_name:
            return field_name, meeting_name
    return "", ""


def _primary_text(items: list[dict], value_key: str) -> str:
    for item in items:
        metadata = item.get("metadata") or {}
        if metadata.get("primary"):
            return _clean(item.get(value_key))
    for item in items:
        value = _clean(item.get(value_key))
        if value:
            return value
    return ""


_COORDINATES_RE = re.compile(r"(-?\d{1,3}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)")


def _normalize_coordinates(value: object) -> str:
    text = _clean(value)
    if not text:
        return ""
    text = unquote_plus(text)
    match = _COORDINATES_RE.search(text)
    if not match:
        return ""
    latitude = match.group(1)
    longitude = match.group(2)
    try:
        lat_value = float(latitude)
        lng_value = float(longitude)
    except ValueError:
        return ""
    if not (-90 <= lat_value <= 90 and -180 <= lng_value <= 180):
        return ""
    return f"{latitude}, {longitude}"


def _coordinate_map_url(base_url: str, coordinates: str) -> str:
    return f"{base_url}?q={quote(_clean(coordinates), safe=',')}"


def _coordinates_from_mapping(value: object) -> str:
    if not isinstance(value, dict):
        return _normalize_coordinates(value)
    direct = _normalize_coordinates(
        value.get("coordinates")
        or value.get("coordinate")
        or value.get("gps")
        or value.get("gpsCoordinates")
        or value.get("latLng")
        or value.get("latlng")
    )
    if direct:
        return direct
    latitude = value.get("latitude") or value.get("lat")
    longitude = value.get("longitude") or value.get("lng") or value.get("lon")
    if latitude is not None and longitude is not None:
        return _normalize_coordinates(f"{latitude}, {longitude}")
    for item in value.values():
        nested = _coordinates_from_mapping(item)
        if nested:
            return nested
    return ""


def _normalize_coordinate_label(value: object) -> str:
    label = _clean(value).lower()
    label = re.sub(r"\bcoordinates?\b", "", label)
    label = re.sub(r"\bgps\b", "", label)
    label = re.sub(r"\blat(?:itude)?\b", "", label)
    label = re.sub(r"\b(?:lng|longitude)\b", "", label)
    label = re.sub(r"[^a-z0-9]+", " ", label)
    return label.strip()


def _google_user_defined_coordinates(user_defined: list[dict]) -> dict[object, str]:
    coordinates_by_key: dict[object, str] = {}
    unassigned = ""
    for item in user_defined or []:
        key = _clean(item.get("key")).lower()
        value = _clean(item.get("value"))
        if not key or not value:
            continue
        if not any(token in key for token in ("coordinate", "coordinates", "coord", "gps", "lat", "lng", "longitude", "latitude")):
            continue
        coordinates = _normalize_coordinates(value)
        if not coordinates:
            continue
        index_match = re.search(r"\b(?:address|addr)\s*(\d+)\b", key)
        if index_match:
            coordinates_by_key[int(index_match.group(1))] = coordinates
        elif not unassigned:
            label_key = _normalize_coordinate_label(key)
            if label_key:
                coordinates_by_key[label_key] = coordinates
            else:
                unassigned = coordinates
    if unassigned:
        coordinates_by_key.setdefault(0, unassigned)
    return coordinates_by_key


def _is_coordinate_custom_field_key(value: object) -> bool:
    key = _clean(value).lower()
    if not key:
        return False
    return any(token in key for token in ("coordinate", "coordinates", "coord", "gps", "lat", "lng", "longitude", "latitude"))


def _google_url_coordinate_candidates(urls: list[dict]) -> list[dict[str, str]]:
    candidates = []
    for item in urls or []:
        value = _clean(item.get("value"))
        if not value:
            continue
        normalized_value = value.lower()
        if not (
            "maps.google." in normalized_value
            or "google.com/maps" in normalized_value
            or "maps.apple." in normalized_value
        ):
            continue
        coordinates = _normalize_coordinates(value)
        if not coordinates:
            continue
        candidates.append(
            {
                "label": _clean(item.get("formattedType") or item.get("type")),
                "value": value,
                "coordinates": coordinates,
            }
        )
    return candidates


def _google_url_coordinates(
    url_coordinate_candidates: list[dict[str, str]],
    address_type: object,
    position: int,
    address_count: int,
) -> str:
    if not url_coordinate_candidates:
        return ""
    normalized_address_type = _clean(address_type).lower()
    if normalized_address_type:
        for item in url_coordinate_candidates:
            if _clean(item.get("label")).lower() == normalized_address_type:
                return _clean(item.get("coordinates"))
    if address_count == 1 and len(url_coordinate_candidates) == 1:
        return _clean(url_coordinate_candidates[0].get("coordinates"))
    if position <= len(url_coordinate_candidates):
        item = url_coordinate_candidates[position - 1]
        if not _clean(item.get("label")):
            return _clean(item.get("coordinates"))
    return ""


def _google_address_coordinates(
    address: dict,
    user_defined_coordinates: dict[object, str],
    url_coordinate_candidates: list[dict[str, str]],
    position: int,
    address_count: int,
) -> str:
    for key in ("coordinates", "location", "metadata"):
        coordinates = _coordinates_from_mapping(address.get(key))
        if coordinates:
            return coordinates
    address_label_key = _normalize_coordinate_label(address.get("formattedType") or address.get("type"))
    return (
        user_defined_coordinates.get(address_label_key)
        or user_defined_coordinates.get(position)
        or user_defined_coordinates.get(0)
        or _google_url_coordinates(url_coordinate_candidates, address.get("formattedType") or address.get("type"), position, address_count)
        or ""
    )


def _extract_photo_url(person: dict) -> str:
    photos = person.get("photos") or []
    for item in photos:
        if (item.get("metadata") or {}).get("primary") and _clean(item.get("url")):
            return _clean(item.get("url"))
    for item in photos:
        if _clean(item.get("url")):
            return _clean(item.get("url"))
    return ""


def _load_contact_children(conn, table_name: str, contact_id: int) -> list[dict]:
    rows = conn.execute(
        f"""
        SELECT *
        FROM {table_name}
        WHERE contact_id = ?
        ORDER BY position, id
        """,
        (contact_id,),
    ).fetchall()
    return [dict(row) for row in rows]


def _load_contact_for_sync(conn, contact_id: int) -> dict | None:
    row = conn.execute("SELECT * FROM contacts WHERE id = ?", (contact_id,)).fetchone()
    if not row:
        return None
    contact = dict(row)
    contact["relationships"] = _load_contact_children(conn, "relationships", contact_id)
    contact["phones"] = _load_contact_children(conn, "phones", contact_id)
    contact["emails"] = _load_contact_children(conn, "emails", contact_id)
    contact["addresses"] = _load_contact_children(conn, "addresses", contact_id)
    contact["custom_fields"] = _load_contact_children(conn, "custom_fields", contact_id)
    return contact


def _parse_birthday(value: str | None) -> dict | None:
    text = _clean(value)
    if not text or text.lower() == "no entry":
        return None
    normalized = text.replace("/", "-").replace(".", "-")
    parts = [part.strip() for part in normalized.split("-") if part.strip()]
    try:
        if len(parts) == 3:
            first, second, third = (int(part) for part in parts)
            if len(parts[0]) == 4:
                year, month, day = first, second, third
            else:
                month, day, year = first, second, third
            if month and day:
                return {"year": year, "month": month, "day": day}
        if len(parts) == 2:
            month, day = (int(part) for part in parts)
            if month and day:
                return {"month": month, "day": day}
    except ValueError:
        return None
    return None


def _normalize_google_type(value: str | None) -> str:
    cleaned = _clean(value)
    normalized = cleaned.lower().replace(" ", "_")
    predefined = {
        "home",
        "work",
        "mobile",
        "cell",
        "main",
        "home_fax",
        "work_fax",
        "pager",
        "other",
        "school",
    }
    if normalized in predefined:
        return normalized
    return cleaned


GOOGLE_PREDEFINED_RELATION_TYPES = {
    "assistant",
    "brother",
    "child",
    "domesticpartner",
    "father",
    "friend",
    "manager",
    "mother",
    "parent",
    "partner",
    "referredby",
    "relative",
    "sister",
    "spouse",
}

GOOGLE_RELATION_TYPE_ALIASES = {
    "domestic_partner": "domesticPartner",
    "domesticpartner": "domesticPartner",
    "referred_by": "referredBy",
    "referredby": "referredBy",
}


def _google_relation_type(value: str | None) -> str:
    cleaned = _clean(value)
    if not cleaned:
        return ""
    normalized = cleaned.lower().replace(" ", "_")
    if normalized in GOOGLE_RELATION_TYPE_ALIASES:
        return GOOGLE_RELATION_TYPE_ALIASES[normalized]
    lookup_key = normalized.replace("_", "")
    if lookup_key in GOOGLE_PREDEFINED_RELATION_TYPES:
        return normalized
    return cleaned


def _contact_names_payload(contact: dict) -> list[dict]:
    family_name = _clean(contact.get("family_name"))
    given_name = _clean(contact.get("given_name"))
    if not family_name and not given_name:
        return []
    payload = {"displayName": ", ".join(part for part in [family_name, given_name] if part)}
    if family_name:
        payload["familyName"] = family_name
    if given_name:
        payload["givenName"] = given_name
    return [payload]


def _contact_person_payload(contact: dict) -> dict:
    payload: dict[str, list[dict]] = {}

    names = _contact_names_payload(contact)
    if names:
        payload["names"] = names

    field_name = _clean(contact.get("fields_text"))
    meeting_name = _clean(contact.get("meetings_text"))
    if field_name or meeting_name:
        organization_payload = {"current": True}
        if meeting_name:
            organization_payload["name"] = meeting_name
        if field_name:
            organization_payload["title"] = field_name
        payload["organizations"] = [organization_payload]

    phones = []
    for item in contact.get("phones", []):
        phone_value = _clean(item.get("phone_value"))
        if not phone_value:
            continue
        phone_payload = {"value": phone_value}
        phone_type = _normalize_google_type(item.get("phone_type"))
        if phone_type:
            phone_payload["type"] = phone_type
        phones.append(phone_payload)
    if phones:
        payload["phoneNumbers"] = phones

    emails = []
    for item in contact.get("emails", []):
        email_value = _clean(item.get("email_value"))
        if not email_value:
            continue
        email_payload = {"value": email_value}
        email_type = _normalize_google_type(item.get("email_type"))
        if email_type:
            email_payload["type"] = email_type
        emails.append(email_payload)
    if emails:
        payload["emailAddresses"] = emails

    addresses = []
    for item in contact.get("addresses", []):
        formatted_address = _clean(item.get("formatted_address"))
        if not formatted_address:
            continue
        address_payload = {"formattedValue": formatted_address}
        address_type = _normalize_google_type(item.get("address_type"))
        if address_type:
            address_payload["type"] = address_type
        addresses.append(address_payload)
    if addresses:
        payload["addresses"] = addresses

    urls = []
    for index, item in enumerate(contact.get("addresses", []), start=1):
        coordinates = _clean(item.get("coordinates"))
        if not coordinates:
            continue
        address_label = _clean(item.get("address_type")) or f"Address {index}"
        url_type = _normalize_google_type(address_label)
        for map_url in (
            _coordinate_map_url("http://maps.apple.com/", coordinates),
            _coordinate_map_url("http://maps.google.com/", coordinates),
        ):
            url_payload = {"value": map_url}
            if url_type:
                url_payload["type"] = url_type
            urls.append(url_payload)
    if urls:
        payload["urls"] = urls

    relations = []
    for item in contact.get("relationships", []):
        relation_value = _clean(item.get("relation_value"))
        relation_type = _google_relation_type(item.get("relation_type"))
        if not relation_value and not relation_type:
            continue
        relation_payload = {}
        if relation_value:
            relation_payload["person"] = relation_value
        if relation_type:
            relation_payload["type"] = relation_type
        relations.append(relation_payload)
    if relations:
        payload["relations"] = relations

    custom_fields = []
    for index, item in enumerate(contact.get("addresses", []), start=1):
        coordinates = _clean(item.get("coordinates"))
        if coordinates:
            address_label = _clean(item.get("address_type")) or f"Address {index}"
            custom_fields.append(
                {
                    "key": f"{address_label} - Coordinates",
                    "value": coordinates,
                }
            )
    for item in contact.get("custom_fields", []):
        field_key = _clean(item.get("field_type"))
        field_value = _clean(item.get("field_value"))
        if _is_coordinate_custom_field_key(field_key) and _normalize_coordinates(field_value):
            continue
        if not field_key and not field_value:
            continue
        custom_payload = {}
        if field_key:
            custom_payload["key"] = field_key
        if field_value:
            custom_payload["value"] = field_value
        custom_fields.append(custom_payload)
    if custom_fields:
        payload["userDefined"] = custom_fields

    note_text = _clean(contact.get("notes"))
    if note_text and note_text.lower() != "no entry":
        payload["biographies"] = [{"value": note_text}]

    birthday = _parse_birthday(contact.get("birthday"))
    if birthday:
        payload["birthdays"] = [{"date": birthday}]

    return payload


def _desired_group_names(contact: dict) -> list[str]:
    values = _split_group_membership_text(contact.get("group_membership"))
    field_name = _clean(contact.get("fields_text"))
    meeting_name = _clean(contact.get("meetings_text"))
    if field_name and meeting_name:
        shared_group_names = _shared_group_membership_names(field_name, meeting_name)
        canonical_names = {value.lower() for value in shared_group_names}
        values = [value for value in values if " - " not in value and _clean(value).lower() not in canonical_names]
        values.extend(shared_group_names)
    elif "myContacts" not in values:
        values.append("myContacts")

    deduped: list[str] = []
    seen: set[str] = set()
    for item in values:
        cleaned = _clean(item)
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        deduped.append(cleaned)
    return deduped


def _extract_contact_group_memberships(person: dict) -> set[str]:
    groups: set[str] = set()
    for membership in person.get("memberships") or []:
        group_membership = membership.get("contactGroupMembership") or {}
        resource_name = _clean(group_membership.get("contactGroupResourceName"))
        if resource_name:
            groups.add(resource_name)
    return groups


def _fetch_google_person(access_token: str, resource_name: str) -> dict:
    url = (
        f"{GOOGLE_PEOPLE_BASE_URL}/{resource_name}"
        f"?personFields={GOOGLE_UPLOAD_PERSON_FIELDS}"
    )
    return _api_get_json(url, access_token)


def _ensure_contact_group_resource(
    access_token: str,
    group_name: str,
    name_to_resource: dict[str, str],
    resource_to_name: dict[str, str],
) -> str:
    normalized_name = _clean(group_name)
    if not normalized_name:
        return ""
    existing = name_to_resource.get(normalized_name)
    if existing:
        return existing
    if normalized_name in {"myContacts", "starred"}:
        resource_name = f"contactGroups/{normalized_name}"
        name_to_resource[normalized_name] = resource_name
        resource_to_name[resource_name] = normalized_name
        return resource_name

    payload = _api_json_request(
        f"{GOOGLE_PEOPLE_BASE_URL}/contactGroups",
        access_token,
        method="POST",
        json_data={"contactGroup": {"name": normalized_name}},
    )
    resource_name = _clean(payload.get("resourceName"))
    formatted_name = _clean(payload.get("formattedName") or payload.get("name")) or normalized_name
    if resource_name:
        name_to_resource[formatted_name] = resource_name
        name_to_resource[normalized_name] = resource_name
        resource_to_name[resource_name] = formatted_name
    return resource_name


def _sync_google_contact_groups(
    access_token: str,
    resource_name: str,
    current_person: dict,
    desired_group_names: list[str],
    resource_to_name: dict[str, str],
    name_to_resource: dict[str, str],
) -> None:
    desired_resources = {
        _ensure_contact_group_resource(access_token, group_name, name_to_resource, resource_to_name)
        for group_name in desired_group_names
    }
    desired_resources.discard("")
    current_resources = _extract_contact_group_memberships(current_person)
    removed_resources = sorted(current_resources - desired_resources)

    for group_resource in removed_resources:
        _api_json_request(
            f"{GOOGLE_PEOPLE_BASE_URL}/{group_resource}/members:modify",
            access_token,
            method="POST",
            json_data={"resourceNamesToRemove": [resource_name]},
        )

    for group_resource in sorted(desired_resources - current_resources):
        _api_json_request(
            f"{GOOGLE_PEOPLE_BASE_URL}/{group_resource}/members:modify",
            access_token,
            method="POST",
            json_data={"resourceNamesToAdd": [resource_name]},
        )

    _cleanup_empty_contact_group_resources(
        access_token,
        removed_resources,
        resource_to_name,
        name_to_resource,
        removed_contact_resources=[resource_name],
    )


def _chunked(values: list[str], size: int = 1000) -> list[list[str]]:
    return [values[index : index + size] for index in range(0, len(values), size)]


def _queue_google_contact_group_sync(
    batch: dict[str, dict[str, set[str]]],
    access_token: str,
    resource_name: str,
    current_person: dict,
    desired_group_names: list[str],
    resource_to_name: dict[str, str],
    name_to_resource: dict[str, str],
) -> None:
    desired_resources = {
        _ensure_contact_group_resource(access_token, group_name, name_to_resource, resource_to_name)
        for group_name in desired_group_names
    }
    desired_resources.discard("")
    current_resources = _extract_contact_group_memberships(current_person)
    for group_resource in current_resources - desired_resources:
        batch.setdefault(group_resource, {"add": set(), "remove": set()})["remove"].add(resource_name)
    for group_resource in desired_resources - current_resources:
        batch.setdefault(group_resource, {"add": set(), "remove": set()})["add"].add(resource_name)


def _flush_google_contact_group_batch(
    access_token: str,
    batch: dict[str, dict[str, set[str]]],
    resource_to_name: dict[str, str],
    name_to_resource: dict[str, str],
) -> None:
    removed_by_group: dict[str, set[str]] = {}
    for group_resource in sorted(batch):
        changes = batch[group_resource]
        remove_names = sorted(changes.get("remove") or set())
        add_names = sorted(changes.get("add") or set())
        if remove_names:
            for chunk in _chunked(remove_names):
                _api_json_request(
                    f"{GOOGLE_PEOPLE_BASE_URL}/{group_resource}/members:modify",
                    access_token,
                    method="POST",
                    json_data={"resourceNamesToRemove": chunk},
                )
            removed_by_group.setdefault(group_resource, set()).update(remove_names)
        if add_names:
            for chunk in _chunked(add_names):
                _api_json_request(
                    f"{GOOGLE_PEOPLE_BASE_URL}/{group_resource}/members:modify",
                    access_token,
                    method="POST",
                    json_data={"resourceNamesToAdd": chunk},
                )

    cleanup_group_resources = [
        group_resource
        for group_resource, changes in batch.items()
        if changes.get("remove") and not _is_system_contact_group_resource(group_resource, resource_to_name)
    ]
    removed_contact_resources = sorted(
        {
            resource_name
            for group_resource in cleanup_group_resources
            for resource_name in removed_by_group.get(group_resource, set())
        }
    )
    _cleanup_empty_contact_group_resources(
        access_token,
        cleanup_group_resources,
        resource_to_name,
        name_to_resource,
        removed_contact_resources=removed_contact_resources,
    )


def _is_system_contact_group_resource(group_resource: str, resource_to_name: dict[str, str]) -> bool:
    system_group_names = {"myContacts", "starred"}
    system_group_resources = {"contactGroups/myContacts", "contactGroups/starred"}
    group_name = _clean(resource_to_name.get(group_resource))
    return group_resource in system_group_resources or group_name in system_group_names


def _remove_contact_from_group_resources(
    access_token: str,
    resource_name: str,
    group_resources: list[str],
    resource_to_name: dict[str, str],
) -> list[str]:
    removed_resources: list[str] = []
    seen_resources: set[str] = set()
    for group_resource_value in group_resources:
        group_resource = _clean(group_resource_value)
        if (
            not group_resource
            or group_resource in seen_resources
            or _is_system_contact_group_resource(group_resource, resource_to_name)
        ):
            continue
        seen_resources.add(group_resource)
        try:
            _api_json_request(
                f"{GOOGLE_PEOPLE_BASE_URL}/{group_resource}/members:modify",
                access_token,
                method="POST",
                json_data={"resourceNamesToRemove": [resource_name]},
            )
        except HTTPError as exc:
            if exc.code not in {400, 404}:
                raise
            continue
        removed_resources.append(group_resource)
    return removed_resources


def _contact_group_member_state(access_token: str, group_resource: str) -> tuple[int | None, list[str]]:
    detail = _api_get_json(
        f"{GOOGLE_PEOPLE_BASE_URL}/{group_resource}?{urlencode({'maxMembers': 1000})}",
        access_token,
    )
    visible_members = [
        _clean(item)
        for item in (detail.get("memberResourceNames") or [])
        if _clean(item)
    ]
    try:
        member_count = int(detail.get("memberCount"))
    except (TypeError, ValueError):
        member_count = len(visible_members) if "memberResourceNames" in detail else None
    return member_count, visible_members


def _cleanup_empty_contact_group_resources(
    access_token: str,
    group_resources: list[str],
    resource_to_name: dict[str, str],
    name_to_resource: dict[str, str],
    removed_contact_resources: list[str] | None = None,
) -> None:
    removed_contacts = {_clean(item) for item in (removed_contact_resources or []) if _clean(item)}
    seen_resources: set[str] = set()
    for group_resource_value in group_resources:
        group_resource = _clean(group_resource_value)
        if (
            not group_resource
            or group_resource in seen_resources
            or _is_system_contact_group_resource(group_resource, resource_to_name)
        ):
            continue
        seen_resources.add(group_resource)
        member_count: int | None = None
        visible_members: list[str] = []
        group_missing = False
        for attempt in range(3):
            try:
                member_count, visible_members = _contact_group_member_state(access_token, group_resource)
            except HTTPError as exc:
                if exc.code == 404:
                    member_count = None
                    visible_members = []
                    group_missing = True
                    break
                raise

            if visible_members and removed_contacts and set(visible_members).issubset(removed_contacts):
                for visible_member in visible_members:
                    _remove_contact_from_group_resources(access_token, visible_member, [group_resource], resource_to_name)
                time.sleep(0.5 * (attempt + 1))
                continue
            if member_count == 0 or not visible_members or attempt >= 2:
                break
            time.sleep(0.5 * (attempt + 1))
        if group_missing:
            continue
        if member_count not in {0, None} and visible_members:
            continue
        try:
            _api_json_request(
                f"{GOOGLE_PEOPLE_BASE_URL}/{group_resource}?{urlencode({'deleteContacts': 'false'})}",
                access_token,
                method="DELETE",
            )
        except HTTPError as exc:
            if exc.code not in {400, 404}:
                raise
            continue
        deleted_name = resource_to_name.pop(group_resource, "")
        if deleted_name:
            name_to_resource.pop(deleted_name, None)


def _cleanup_empty_contact_groups(
    access_token: str,
    group_names: list[str],
    resource_to_name: dict[str, str],
    name_to_resource: dict[str, str],
    removed_contact_resources: list[str] | None = None,
) -> None:
    group_resources = [
        _clean(name_to_resource.get(_clean(group_name)))
        for group_name in group_names
        if _clean(group_name)
    ]
    _cleanup_empty_contact_group_resources(
        access_token,
        group_resources,
        resource_to_name,
        name_to_resource,
        removed_contact_resources=removed_contact_resources,
    )


def _cleanup_empty_app_contact_groups(
    access_token: str,
    resource_to_name: dict[str, str],
    name_to_resource: dict[str, str],
) -> None:
    group_resources = [
        resource_name
        for resource_name, group_name in resource_to_name.items()
        if _clean(group_name).endswith("(Shared)")
    ]
    _cleanup_empty_contact_group_resources(access_token, group_resources, resource_to_name, name_to_resource)


def _previous_group_names_from_payload(payload: dict) -> list[str]:
    values = _split_group_membership_text(payload.get("previous_group_membership"))
    field_name = _clean(payload.get("previous_fields_text"))
    meeting_name = _clean(payload.get("previous_meetings_text"))
    if field_name and meeting_name:
        modern_group_name = f"{field_name} - {meeting_name}"
        legacy_group_name = f"{field_name} - {_strip_trailing_parenthetical(meeting_name)} (Shared)"
        shared_group_names = _shared_group_membership_names(field_name, meeting_name)
        existing_names = {value.lower() for value in values}
        if modern_group_name.lower() not in existing_names and legacy_group_name.lower() not in existing_names:
            values.append(modern_group_name)
        values.extend(shared_group_names)

    deduped: list[str] = []
    seen: set[str] = set()
    for item in values:
        cleaned = _clean(item)
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        deduped.append(cleaned)
    return deduped


def _update_local_contact_google_state(
    conn,
    contact_id: int,
    google_contact_id: str,
    etag: str,
    status: str,
) -> None:
    conn.execute(
        """
        UPDATE contacts
        SET
          google_contact_id = ?,
          etag = ?,
          last_updated = ?,
          status = ?
        WHERE id = ?
        """,
        (google_contact_id, etag, _now_text(), status, contact_id),
    )


def _delete_queue_entry(conn, queue_id: int) -> None:
    conn.execute("DELETE FROM google_sync_queue WHERE id = ?", (queue_id,))


def _update_queue_error(conn, queue_id: int, message: str) -> None:
    conn.execute(
        """
        UPDATE google_sync_queue
        SET
          last_error = ?,
          updated_at = ?
        WHERE id = ?
        """,
        (str(message or "").strip(), _now_text(), queue_id),
    )


def _process_delete_queue_entry(
    access_token: str,
    queue_entry: dict,
    resource_to_name: dict[str, str],
    name_to_resource: dict[str, str],
) -> None:
    google_contact_id = _clean(queue_entry.get("google_contact_id"))
    if not google_contact_id:
        return
    payload = _safe_load_json(queue_entry.get("payload_json"))
    current_group_resources: list[str] = []
    try:
        current_person = _fetch_google_person(access_token, google_contact_id)
        current_group_resources = sorted(_extract_contact_group_memberships(current_person))
    except HTTPError as exc:
        if exc.code != 404:
            raise

    removed_group_resources = _remove_contact_from_group_resources(
        access_token,
        google_contact_id,
        current_group_resources,
        resource_to_name,
    )
    try:
        _api_json_request(
            f"{GOOGLE_PEOPLE_BASE_URL}/{google_contact_id}:deleteContact",
            access_token,
            method="DELETE",
        )
    except HTTPError as exc:
        if exc.code != 404:
            raise
    _cleanup_empty_contact_group_resources(
        access_token,
        removed_group_resources,
        resource_to_name,
        name_to_resource,
        removed_contact_resources=[google_contact_id],
    )
    group_names = payload.get("group_names")
    if isinstance(group_names, list):
        _cleanup_empty_contact_groups(
            access_token,
            [str(item or "") for item in group_names],
            resource_to_name,
            name_to_resource,
            removed_contact_resources=[google_contact_id],
        )


def _process_upsert_queue_entry(
    conn,
    access_token: str,
    queue_entry: dict,
    resource_to_name: dict[str, str],
    name_to_resource: dict[str, str],
    group_sync_batch: dict[str, dict[str, set[str]]] | None = None,
) -> None:
    contact_id = int(queue_entry["contact_id"])
    contact = _load_contact_for_sync(conn, contact_id)
    if not contact:
        return

    queue_payload = _safe_load_json(queue_entry.get("payload_json"))
    person_payload = _contact_person_payload(contact)
    desired_group_names = _desired_group_names(contact)
    google_contact_id = _clean(contact.get("google_contact_id"))

    if google_contact_id:
        try:
            current_person = _fetch_google_person(access_token, google_contact_id)
        except HTTPError as exc:
            if exc.code == 404:
                google_contact_id = ""
                current_person = {}
            else:
                raise
    else:
        current_person = {}

    if not google_contact_id:
        created = _api_json_request(
            f"{GOOGLE_PEOPLE_BASE_URL}/people:createContact?personFields={urlencode({'fields': GOOGLE_UPLOAD_PERSON_FIELDS})[7:]}",
            access_token,
            method="POST",
            json_data=person_payload,
        )
        resource_name = _clean(created.get("resourceName"))
        etag = _clean(created.get("etag"))
        if not etag:
            for source in (created.get("metadata") or {}).get("sources") or []:
                etag = _clean(source.get("etag"))
                if etag:
                    break
        _update_local_contact_google_state(conn, contact_id, resource_name, etag, "synced")
        current_person = created
        _sync_google_contact_groups(access_token, resource_name, current_person, desired_group_names, resource_to_name, name_to_resource)
        photo_bytes = _local_contact_photo_bytes(contact.get("photo"))
        if photo_bytes:
            _update_google_contact_photo(access_token, resource_name, photo_bytes)
        return

    source_payload = {}
    for source in (current_person.get("metadata") or {}).get("sources") or []:
        if str(source.get("type") or "").upper() == "CONTACT":
            source_payload = dict(source)
            break
    if not source_payload:
        raise RuntimeError("Google contact metadata is missing the CONTACT source required for update.")

    update_payload = dict(person_payload)
    update_payload["resourceName"] = google_contact_id
    update_payload["etag"] = _clean(current_person.get("etag"))
    update_payload["metadata"] = {"sources": [source_payload]}
    updated = _api_json_request(
        (
            f"{GOOGLE_PEOPLE_BASE_URL}/{google_contact_id}:updateContact"
            f"?updatePersonFields={GOOGLE_UPLOAD_UPDATE_FIELDS}"
            f"&personFields={GOOGLE_UPLOAD_PERSON_FIELDS}"
        ),
        access_token,
        method="PATCH",
        json_data=update_payload,
    )
    if group_sync_batch is not None:
        _queue_google_contact_group_sync(
            group_sync_batch,
            access_token,
            google_contact_id,
            current_person,
            desired_group_names,
            resource_to_name,
            name_to_resource,
        )
    else:
        _sync_google_contact_groups(access_token, google_contact_id, current_person, desired_group_names, resource_to_name, name_to_resource)
    photo_bytes = _local_contact_photo_bytes(contact.get("photo"))
    if photo_bytes:
        _update_google_contact_photo(access_token, google_contact_id, photo_bytes)
    previous_group_names = _previous_group_names_from_payload(queue_payload)
    if previous_group_names and group_sync_batch is None:
        _cleanup_empty_contact_groups(
            access_token,
            previous_group_names,
            resource_to_name,
            name_to_resource,
            removed_contact_resources=[google_contact_id],
        )
    etag = _clean(updated.get("etag"))
    if not etag:
        for source in (updated.get("metadata") or {}).get("sources") or []:
            etag = _clean(source.get("etag"))
            if etag:
                break
    _update_local_contact_google_state(conn, contact_id, google_contact_id, etag, "synced")


def import_google_contacts() -> int:
    ensure_google_sync_records()
    access_token, account_email = _get_valid_access_token()
    groups_map = _contact_groups_map(access_token)
    people: list[dict] = []
    page_token = ""
    while True:
        params = {
            "personFields": GOOGLE_IMPORT_PERSON_FIELDS,
            "pageSize": 500,
            "sources": "READ_SOURCE_TYPE_CONTACT",
        }
        if page_token:
            params["pageToken"] = page_token
        url = f"{GOOGLE_PEOPLE_BASE_URL}/people/me/connections?{urlencode(params)}"
        payload = _api_get_json(url, access_token)
        for person in payload.get("connections", []):
            if (person.get("metadata") or {}).get("deleted"):
                continue
            people.append(person)
        page_token = str(payload.get("nextPageToken") or "")
        if not page_token:
            break

    with get_connection() as conn:
        _clear_local_contact_data(conn)

        imported = 0
        for person in people:
            names = person.get("names") or []
            display_name = _primary_text(names, "displayName")
            family_name = _primary_text(names, "familyName")
            given_name = _primary_text(names, "givenName")
            group_names = []
            for membership in person.get("memberships") or []:
                group_membership = membership.get("contactGroupMembership") or {}
                resource_name = _clean(group_membership.get("contactGroupResourceName"))
                if resource_name and resource_name in groups_map:
                    group_names.append(groups_map[resource_name])
            fields_text, meetings_text = _parse_field_meeting(group_names)
            if not fields_text and not meetings_text:
                fields_text, meetings_text = _parse_field_meeting_from_organizations(person.get("organizations") or [])
            birthdays = person.get("birthdays") or []
            birthday_text = ""
            for birthday in birthdays:
                date = birthday.get("date") or {}
                year = date.get("year")
                month = date.get("month")
                day = date.get("day")
                if month and day:
                    if year:
                        birthday_text = f"{year:04d}-{month:02d}-{day:02d}"
                    else:
                        birthday_text = f"{month:02d}-{day:02d}"
                    break
            biographies = person.get("biographies") or []
            notes = _primary_text(biographies, "value")
            user_defined = person.get("userDefined") or []
            user_defined_coordinates = _google_user_defined_coordinates(user_defined)
            addresses = person.get("addresses") or []
            url_coordinate_candidates = _google_url_coordinate_candidates(person.get("urls") or [])
            metadata = person.get("metadata") or {}
            sources = metadata.get("sources") or []
            etag = _clean(person.get("etag"))
            if not etag:
                for source in sources:
                    etag = _clean(source.get("etag"))
                    if etag:
                        break
            resource_name = _clean(person.get("resourceName"))
            if not resource_name:
                continue

            cursor = conn.execute(
                """
                INSERT INTO contacts (
                  selected,
                  google_contact_id,
                  etag,
                  last_updated,
                  status,
                  fields_text,
                  meetings_text,
                  group_membership,
                  family_name,
                  given_name,
                  photo,
                  birthday,
                  notes,
                  mtg_home_elder_flag
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "",
                    resource_name,
                    etag,
                    _now_text(),
                    "imported",
                    fields_text,
                    meetings_text,
                    _group_membership_text(_shared_group_membership_names(fields_text, meetings_text) or group_names),
                    family_name or display_name,
                    given_name,
                    _extract_photo_url(person),
                    birthday_text,
                    notes,
                    "",
                ),
            )
            contact_id = int(cursor.lastrowid)

            for index, relation in enumerate(person.get("relations") or [], start=1):
                relation_type = _clean(relation.get("type") or relation.get("formattedType"))
                relation_value = _clean(relation.get("person"))
                if relation_type or relation_value:
                    conn.execute(
                        """
                        INSERT INTO relationships (contact_id, position, relation_type, relation_value)
                        VALUES (?, ?, ?, ?)
                        """,
                        (contact_id, index, relation_type, relation_value),
                    )

            for index, phone in enumerate(person.get("phoneNumbers") or [], start=1):
                phone_type = _clean(phone.get("formattedType") or phone.get("type"))
                phone_value = _clean(phone.get("value"))
                if phone_type or phone_value:
                    conn.execute(
                        """
                        INSERT INTO phones (contact_id, position, phone_type, phone_value)
                        VALUES (?, ?, ?, ?)
                        """,
                        (contact_id, index, phone_type, phone_value),
                    )

            for index, email in enumerate(person.get("emailAddresses") or [], start=1):
                email_type = _clean(email.get("formattedType") or email.get("type"))
                email_value = _clean(email.get("value"))
                if email_type or email_value:
                    conn.execute(
                        """
                        INSERT INTO emails (contact_id, position, email_type, email_value)
                        VALUES (?, ?, ?, ?)
                        """,
                        (contact_id, index, email_type, email_value),
                    )

            for index, address in enumerate(addresses, start=1):
                address_type = _clean(address.get("formattedType") or address.get("type"))
                formatted_address = _clean(address.get("formattedValue"))
                coordinates = _google_address_coordinates(
                    address,
                    user_defined_coordinates,
                    url_coordinate_candidates,
                    index,
                    len(addresses),
                )
                if address_type or formatted_address or coordinates:
                    conn.execute(
                        """
                        INSERT INTO addresses (contact_id, position, address_type, formatted_address, coordinates)
                        VALUES (?, ?, ?, ?, ?)
                        """,
                        (contact_id, index, address_type, formatted_address, coordinates),
                    )

            for index, item in enumerate(user_defined, start=1):
                field_type = _clean(item.get("key"))
                field_value = _clean(item.get("value"))
                if _is_coordinate_custom_field_key(field_type) and _normalize_coordinates(field_value):
                    continue
                if field_type or field_value:
                    conn.execute(
                        """
                        INSERT INTO custom_fields (contact_id, position, field_type, field_value)
                        VALUES (?, ?, ?, ?)
                        """,
                        (contact_id, index, field_type, field_value),
                    )

            imported += 1

        conn.execute(
            """
            UPDATE google_sync_state
            SET
              pending_upload_count = 0,
              needs_upload_reminder = 0,
              needs_drive_export = 0,
              upload_in_progress = 0,
              upload_phase = '',
              upload_total_count = 0,
              upload_processed_count = 0,
              upload_current_contact = '',
              upload_started_at = '',
              bootstrap_status = 'idle',
              bootstrap_total_contacts = ?,
              bootstrap_processed_contacts = 0,
              bootstrap_last_contact_id = 0,
              bootstrap_started_at = '',
              bootstrap_updated_at = ?,
              bootstrap_error = '',
              last_import_at = ?,
              last_import_account_email = ?,
              last_sync_error = '',
              updated_at = ?
            WHERE id = 1
            """,
            (imported, _now_text(), _now_text(), account_email, _now_text()),
        )
        conn.commit()

    return imported


def upload_google_contacts() -> int:
    ensure_google_sync_records()
    access_token, account_email = _get_valid_access_token()

    with get_connection() as conn:
        pending_rows = [
            dict(row)
            for row in conn.execute(
                """
                SELECT *
                FROM google_sync_queue
                WHERE status = 'pending'
                ORDER BY id
                """
            ).fetchall()
        ]

    if not pending_rows:
        with get_connection() as conn:
            _refresh_pending_upload_count(conn)
            _set_upload_progress(
                conn,
                in_progress=False,
                phase="",
                total_count=0,
                processed_count=0,
                current_contact="",
                started_at="",
            )
            _clear_last_sync_error(conn)
            conn.commit()
        return 0

    resource_to_name, name_to_resource = _contact_groups_lookup(access_token)
    processed = 0
    total_count = len(pending_rows)

    with get_connection() as conn:
        _set_upload_progress(
            conn,
            in_progress=True,
            phase="google_contacts",
            total_count=total_count,
            processed_count=0,
            current_contact="",
            started_at=_now_text(),
        )
        conn.commit()

    max_quota_attempts = 4
    group_sync_batch: dict[str, dict[str, set[str]]] = {}
    processed_upsert_queue_ids: list[int] = []
    for queue_entry in pending_rows:
        payload = _safe_load_json(queue_entry.get("payload_json"))
        current_contact_name = _format_queue_contact_name(queue_entry, payload)
        quota_attempt = 1
        while True:
            try:
                with get_connection() as conn:
                    _set_upload_progress(
                        conn,
                        in_progress=True,
                        phase="google_contacts",
                        total_count=total_count,
                        processed_count=processed,
                        current_contact=current_contact_name,
                    )
                    conn.commit()

                operation = _clean(queue_entry.get("operation")) or "update"
                if operation == "delete":
                    _process_delete_queue_entry(access_token, queue_entry, resource_to_name, name_to_resource)
                    with get_connection() as conn:
                        _delete_queue_entry(conn, int(queue_entry["id"]))
                        _refresh_pending_upload_count(conn)
                        _set_upload_progress(
                            conn,
                            in_progress=True,
                            phase="google_contacts",
                            total_count=total_count,
                            processed_count=processed + 1,
                            current_contact=current_contact_name,
                        )
                        _clear_last_sync_error(conn)
                        conn.commit()
                else:
                    with get_connection() as conn:
                        _process_upsert_queue_entry(
                            conn,
                            access_token,
                            queue_entry,
                            resource_to_name,
                            name_to_resource,
                            group_sync_batch=group_sync_batch,
                        )
                        processed_upsert_queue_ids.append(int(queue_entry["id"]))
                        _set_upload_progress(
                            conn,
                            in_progress=True,
                            phase="google_contacts",
                            total_count=total_count,
                            processed_count=processed + 1,
                            current_contact=current_contact_name,
                        )
                        _clear_last_sync_error(conn)
                        conn.commit()
                processed += 1
                break
            except HTTPError as exc:
                message = _http_error_message(exc) or f"Google upload failed with HTTP {exc.code}."
                if _looks_like_google_quota_error(exc, message) and quota_attempt < max_quota_attempts:
                    delay_seconds = _google_quota_retry_delay(exc, quota_attempt)
                    with get_connection() as conn:
                        _update_queue_error(conn, int(queue_entry["id"]), message)
                        _refresh_pending_upload_count(conn)
                        _set_upload_progress(
                            conn,
                            in_progress=True,
                            phase="google_contacts",
                            total_count=total_count,
                            processed_count=processed,
                            current_contact=f"{current_contact_name} - waiting for Google quota",
                        )
                        _set_last_sync_error(conn, f"Google asked us to slow down. Retrying in {delay_seconds} seconds.")
                        conn.commit()
                    time.sleep(delay_seconds)
                    quota_attempt += 1
                    continue
                with get_connection() as conn:
                    _update_queue_error(conn, int(queue_entry["id"]), message)
                    _refresh_pending_upload_count(conn)
                    _set_upload_progress(
                        conn,
                        in_progress=False,
                        phase="google_contacts",
                        total_count=total_count,
                        processed_count=processed,
                        current_contact=current_contact_name,
                    )
                    _set_last_sync_error(conn, message)
                    conn.commit()
                raise RuntimeError(message) from exc
            except Exception as exc:
                message = _clean(str(exc)) or SYNC_NOTICE_MESSAGES["upload_failed"]
                with get_connection() as conn:
                    _update_queue_error(conn, int(queue_entry["id"]), message)
                    _refresh_pending_upload_count(conn)
                    _set_upload_progress(
                        conn,
                        in_progress=False,
                        phase="google_contacts",
                        total_count=total_count,
                        processed_count=processed,
                        current_contact=current_contact_name,
                    )
                    _set_last_sync_error(conn, message)
                    conn.commit()
                raise RuntimeError(message) from exc

    if group_sync_batch:
        with get_connection() as conn:
            _set_upload_progress(
                conn,
                in_progress=True,
                phase="google_contacts",
                total_count=total_count,
                processed_count=processed,
                current_contact="Updating Google contact groups",
            )
            conn.commit()
        _flush_google_contact_group_batch(access_token, group_sync_batch, resource_to_name, name_to_resource)

    with get_connection() as conn:
        for queue_id in processed_upsert_queue_ids:
            _delete_queue_entry(conn, queue_id)
        _refresh_pending_upload_count(conn)
        _set_upload_progress(
            conn,
            in_progress=False,
            phase="",
            total_count=total_count,
            processed_count=processed,
            current_contact="",
        )
        conn.execute(
            """
            UPDATE google_sync_state
            SET
              last_upload_at = ?,
              needs_upload_reminder = 0,
              last_sync_error = '',
              updated_at = ?
            WHERE id = 1
            """,
            (_now_text(), _now_text()),
        )
        conn.commit()

    try:
        _cleanup_empty_app_contact_groups(access_token, resource_to_name, name_to_resource)
    except Exception:
        pass
    return processed


def upload_pending_changes(*, allow_bootstrap: bool = True) -> dict:
    sync_work = _current_sync_work()
    bootstrap_incomplete = bool(sync_work["bootstrap_incomplete"])
    pending_contact_count = int(sync_work["pending_contact_count"])
    drive_export_needed = bool(sync_work["drive_export_needed"])
    meetingdata_drive_export_needed = bool(sync_work["meetingdata_drive_export_needed"])
    total_count = int(sync_work["total_count"])
    processed_count = 0

    if bootstrap_incomplete and allow_bootstrap:
        with get_connection() as conn:
            state = dict(conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone() or {})
            contact_count = _count_contacts(conn)
            bootstrap_total = int(state.get("bootstrap_total_contacts") or 0)
            if bootstrap_total != contact_count:
                bootstrap_total = contact_count
            bootstrap_remaining = _count_unbootstrapped_contacts(conn)
            bootstrap_processed = max(bootstrap_total - bootstrap_remaining, 0)
            _set_bootstrap_state(
                conn,
                status="running",
                total_contacts=bootstrap_total,
                processed_contacts=bootstrap_processed,
                updated_at=_now_text(),
                error="",
            )
            _set_upload_progress(
                conn,
                in_progress=True,
                phase="drive_bootstrap",
                total_count=bootstrap_total,
                processed_count=_visible_bootstrap_processed(bootstrap_processed, bootstrap_total),
                current_contact="",
                started_at=str(state.get("bootstrap_started_at") or _now_text()),
            )
            _clear_last_sync_error(conn)
            conn.commit()
        contacts_complete = export_shared_contacts_to_google_drive()
        if not contacts_complete or not drive_export_needed:
            return {
                "contact_upload_count": 0,
                "drive_exported": contacts_complete,
                "processed_count": int(contacts_complete),
                "total_count": 1 if contacts_complete else 0,
            }
        export_shared_data_to_google_drive()
        with get_connection() as conn:
            _set_upload_progress(
                conn,
                in_progress=False,
                phase="",
                total_count=total_count,
                processed_count=total_count,
                current_contact="",
                started_at="",
            )
            conn.execute(
                """
                UPDATE google_sync_state
                SET
                  last_upload_at = ?,
                  needs_upload_reminder = 0,
                  last_sync_error = '',
                  updated_at = ?
                WHERE id = 1
                """,
                (_now_text(), _now_text()),
            )
            conn.commit()
        return {
            "contact_upload_count": 0,
            "drive_exported": True,
            "processed_count": total_count,
            "total_count": total_count,
        }

    if pending_contact_count <= 0 and not drive_export_needed:
        with get_connection() as conn:
            _refresh_pending_upload_count(conn)
            _set_upload_progress(
                conn,
                in_progress=False,
                total_count=0,
                processed_count=0,
                current_contact="",
                started_at="",
            )
            _clear_last_sync_error(conn)
            conn.commit()
        return {
            "contact_upload_count": 0,
            "drive_exported": False,
            "processed_count": 0,
            "total_count": 0,
        }

    contact_upload_count = 0
    if pending_contact_count > 0:
        contact_upload_count = upload_google_contacts()
        processed_count += contact_upload_count
        refreshed_sync_work = _current_sync_work()
        drive_export_needed = drive_export_needed or bool(refreshed_sync_work["drive_export_needed"])
        if drive_export_needed:
            total_count = max(total_count, processed_count + 1)
        if drive_export_needed:
            with get_connection() as conn:
                _set_upload_progress(
                    conn,
                    in_progress=True,
                    phase="drive_shared_data",
                    total_count=total_count,
                    processed_count=processed_count,
                    current_contact="Shared app data",
                )
                conn.commit()

    drive_exported = False
    if drive_export_needed:
        export_shared_data_to_google_drive()
        drive_exported = True
        processed_count += 1
        with get_connection() as conn:
            _set_upload_progress(
                conn,
                in_progress=False,
                phase="",
                total_count=total_count,
                processed_count=processed_count,
                current_contact="",
            )
            conn.execute(
                """
                UPDATE google_sync_state
                SET
                  last_upload_at = ?,
                  needs_upload_reminder = 0,
                  last_sync_error = '',
                  updated_at = ?
                WHERE id = 1
                """,
                (_now_text(), _now_text()),
            )
            conn.commit()
    elif pending_contact_count > 0:
        with get_connection() as conn:
            _set_upload_progress(
                conn,
                in_progress=False,
                phase="",
                total_count=total_count,
                processed_count=processed_count,
                current_contact="",
            )
            conn.execute(
                """
                UPDATE google_sync_state
                SET
                  last_upload_at = ?,
                  needs_upload_reminder = 0,
                  last_sync_error = '',
                  updated_at = ?
                WHERE id = 1
                """,
                (_now_text(), _now_text()),
            )
            conn.commit()
    return {
        "contact_upload_count": contact_upload_count,
        "drive_exported": drive_exported,
        "processed_count": processed_count,
        "total_count": total_count,
    }


def _run_google_upload_job() -> None:
    global _UPLOAD_JOB_THREAD
    try:
        upload_pending_changes()
    except Exception as exc:
        message = _clean(str(exc)) or SYNC_NOTICE_MESSAGES["upload_failed"]
        with get_connection() as conn:
            state = dict(conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone() or {})
            if str(state.get("bootstrap_status") or "") == "running":
                _mark_bootstrap_failed(conn, message)
            _refresh_pending_upload_count(conn)
            _set_upload_progress(conn, in_progress=False)
            _set_last_sync_error(conn, message)
            conn.commit()
    finally:
        with _UPLOAD_JOB_LOCK:
            _UPLOAD_JOB_THREAD = None


def get_google_upload_progress() -> dict:
    summary = get_google_sync_summary()
    state = summary["state"]
    last_error = str(state.get("last_sync_error") or "")
    in_progress = bool(state.get("upload_in_progress") or 0)
    processed_count = int(state.get("upload_processed_count") or 0)
    total_count = int(state.get("upload_total_count") or 0)
    phase = str(state.get("upload_phase") or "")
    pending_count = int(state.get("pending_upload_count") or 0)
    settings_needs_drive_export = bool(state.get("settings_needs_drive_export") or state.get("needs_drive_export") or 0)
    book_layouts_needs_drive_export = bool(state.get("book_layouts_needs_drive_export") or 0)
    contacts_manifest_needs_drive_export = bool(state.get("contacts_manifest_needs_drive_export") or 0)
    contact_records_needs_drive_export = bool(state.get("contact_records_needs_drive_export") or 0)
    meetingdata_needs_drive_export = bool(state.get("meetingdata_needs_drive_export") or 0)
    field_list_needs_drive_export = bool(state.get("field_list_needs_drive_export") or 0)
    changes_list_needs_drive_export = bool(state.get("changes_list_needs_drive_export") or 0)
    any_drive_export_needed = (
        settings_needs_drive_export
        or book_layouts_needs_drive_export
        or contacts_manifest_needs_drive_export
        or contact_records_needs_drive_export
        or meetingdata_needs_drive_export
        or field_list_needs_drive_export
        or changes_list_needs_drive_export
    )
    bootstrap = _bootstrap_status_dict(state)
    if bootstrap["status"] in {"running", "failed"} or bootstrap["remaining"] > 0:
        if bootstrap["status"] == "running":
            notice = "upload_in_progress"
        elif bootstrap["status"] == "failed":
            notice = "upload_failed"
        else:
            notice = "upload_pending"
        return {
            "in_progress": bootstrap["status"] == "running",
            "total_count": bootstrap["total"],
            "processed_count": _visible_bootstrap_processed(bootstrap["processed"], bootstrap["total"]),
            "remaining_count": bootstrap["remaining"],
            "phase": "drive_bootstrap",
            "current_contact": str(state.get("upload_current_contact") or ""),
            "started_at": bootstrap["started_at"],
            "pending_count": pending_count,
            "settings_needs_drive_export": settings_needs_drive_export,
            "shared_drive_needs_export": True,
            "needs_drive_export": True,
            "contact_records_needs_drive_export": contact_records_needs_drive_export,
            "contacts_manifest_needs_drive_export": contacts_manifest_needs_drive_export,
            "book_layouts_needs_drive_export": book_layouts_needs_drive_export,
            "meetingdata_needs_drive_export": meetingdata_needs_drive_export,
            "field_list_needs_drive_export": field_list_needs_drive_export,
            "changes_list_needs_drive_export": changes_list_needs_drive_export,
            "last_error": bootstrap["error"] or last_error,
            "notice": notice,
            "bootstrap_status": bootstrap["status"],
            "bootstrap_total": bootstrap["total"],
            "bootstrap_processed": bootstrap["processed"],
            "bootstrap_remaining": bootstrap["remaining"],
            "bootstrap_error": bootstrap["error"],
        }
    if in_progress:
        notice = "upload_in_progress"
    elif last_error and _looks_like_reconnect_error(last_error):
        notice = "upload_not_connected"
    elif last_error and (pending_count > 0 or any_drive_export_needed):
        notice = "upload_failed"
    elif processed_count > 0 and pending_count == 0 and not any_drive_export_needed:
        notice = "upload_success"
    elif pending_count > 0 or any_drive_export_needed:
        notice = "upload_pending"
    else:
        notice = "upload_queue_empty"
    return {
        "in_progress": in_progress,
        "total_count": total_count,
        "processed_count": processed_count,
        "remaining_count": max(total_count - processed_count, 0),
        "phase": phase,
        "current_contact": str(state.get("upload_current_contact") or ""),
        "started_at": str(state.get("upload_started_at") or ""),
        "pending_count": pending_count,
        "settings_needs_drive_export": settings_needs_drive_export,
        "shared_drive_needs_export": any_drive_export_needed,
        "needs_drive_export": any_drive_export_needed,
        "contact_records_needs_drive_export": contact_records_needs_drive_export,
        "contacts_manifest_needs_drive_export": contacts_manifest_needs_drive_export,
        "book_layouts_needs_drive_export": book_layouts_needs_drive_export,
        "meetingdata_needs_drive_export": meetingdata_needs_drive_export,
        "field_list_needs_drive_export": field_list_needs_drive_export,
        "changes_list_needs_drive_export": changes_list_needs_drive_export,
        "last_error": last_error,
        "notice": notice,
        "bootstrap_status": bootstrap["status"],
        "bootstrap_total": bootstrap["total"],
        "bootstrap_processed": bootstrap["processed"],
        "bootstrap_remaining": bootstrap["remaining"],
        "bootstrap_error": bootstrap["error"],
    }


def start_google_upload_job() -> dict:
    global _UPLOAD_JOB_THREAD
    ensure_google_sync_records()
    with _UPLOAD_JOB_LOCK:
        if _upload_thread_running():
            with get_connection() as conn:
                _refresh_pending_upload_count(conn)
                state_row = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
                state = dict(state_row) if state_row else {}
                contact_records_drive_export_needed = _count_pending_shared_contact_exports(conn) > 0
                conn.commit()
            if not bool(state.get("upload_in_progress") or 0):
                _UPLOAD_JOB_THREAD = None
            else:
                return {
                    "started": False,
                    "in_progress": True,
                    "pending_count": int(state.get("pending_upload_count") or 0),
                    "needs_drive_export": contact_records_drive_export_needed or bool(state.get("needs_drive_export") or 0) or bool(state.get("book_layouts_needs_drive_export") or 0) or bool(state.get("contacts_manifest_needs_drive_export") or 0) or bool(state.get("meetingdata_needs_drive_export") or 0) or bool(state.get("field_list_needs_drive_export") or 0) or bool(state.get("changes_list_needs_drive_export") or 0),
                    "contact_records_needs_drive_export": contact_records_drive_export_needed,
                    "meetingdata_needs_drive_export": bool(state.get("meetingdata_needs_drive_export") or 0),
                    "field_list_needs_drive_export": bool(state.get("field_list_needs_drive_export") or 0),
                    "changes_list_needs_drive_export": bool(state.get("changes_list_needs_drive_export") or 0),
                    "total_count": int(state.get("upload_total_count") or 0),
                    "processed_count": int(state.get("upload_processed_count") or 0),
                    "bootstrap_status": str(state.get("bootstrap_status") or "idle"),
                    "bootstrap_total": int(state.get("bootstrap_total_contacts") or 0),
                    "bootstrap_processed": int(state.get("bootstrap_processed_contacts") or 0),
                }
        with get_connection() as conn:
            state_row = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
            state = dict(state_row) if state_row else {}
            pending_count = _refresh_pending_upload_count(conn)
            needs_drive_export = bool(state.get("needs_drive_export") or 0)
            contacts_manifest_needs_drive_export = bool(state.get("contacts_manifest_needs_drive_export") or 0)
            book_layouts_needs_drive_export = bool(state.get("book_layouts_needs_drive_export") or 0)
            contact_records_drive_export_needed = _count_pending_shared_contact_exports(conn) > 0
            meetingdata_needs_drive_export = bool(state.get("meetingdata_needs_drive_export") or 0)
            field_list_needs_drive_export = bool(state.get("field_list_needs_drive_export") or 0)
            changes_list_needs_drive_export = bool(state.get("changes_list_needs_drive_export") or 0)
            bootstrap_remaining = _count_unbootstrapped_contacts(conn)
            if bootstrap_remaining > 0 or str(state.get("bootstrap_status") or "") in {"running", "failed"}:
                contact_count = _count_contacts(conn)
                bootstrap_total = int(state.get("bootstrap_total_contacts") or 0)
                if bootstrap_total != contact_count:
                    bootstrap_total = contact_count
                bootstrap_processed = max(bootstrap_total - bootstrap_remaining, 0)
                _set_bootstrap_state(
                    conn,
                    status="running",
                    total_contacts=bootstrap_total,
                    processed_contacts=bootstrap_processed,
                    started_at=str(state.get("bootstrap_started_at") or _now_text()),
                    updated_at=_now_text(),
                    error="",
                )
                _set_upload_progress(
                    conn,
                    in_progress=True,
                    phase="drive_bootstrap",
                    total_count=bootstrap_total,
                    processed_count=_visible_bootstrap_processed(bootstrap_processed, bootstrap_total),
                    current_contact="",
                    started_at=str(state.get("bootstrap_started_at") or _now_text()),
                )
                _clear_last_sync_error(conn)
                conn.commit()
                _UPLOAD_JOB_THREAD = threading.Thread(target=_run_google_upload_job, daemon=True)
                _UPLOAD_JOB_THREAD.start()
                return {
                    "started": True,
                    "in_progress": True,
                    "pending_count": pending_count,
                    "needs_drive_export": True,
                    "meetingdata_needs_drive_export": meetingdata_needs_drive_export,
                    "field_list_needs_drive_export": field_list_needs_drive_export,
                    "changes_list_needs_drive_export": changes_list_needs_drive_export,
                    "total_count": bootstrap_total,
                    "processed_count": _visible_bootstrap_processed(bootstrap_processed, bootstrap_total),
                    "bootstrap_status": "running",
                    "bootstrap_total": bootstrap_total,
                    "bootstrap_processed": bootstrap_processed,
                }
            if bool(state.get("upload_in_progress") or 0) and _state_has_resumable_upload_work(conn, state):
                if not str(state.get("upload_started_at") or "").strip():
                    _set_upload_progress(conn, in_progress=True, started_at=_now_text())
                    state = dict(conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone() or {})
                _clear_last_sync_error(conn)
                conn.commit()
                _UPLOAD_JOB_THREAD = threading.Thread(target=_run_google_upload_job, daemon=True)
                _UPLOAD_JOB_THREAD.start()
                return {
                    "started": True,
                    "in_progress": True,
                    "pending_count": pending_count,
                    "needs_drive_export": contact_records_drive_export_needed or bool(state.get("needs_drive_export") or 0) or bool(state.get("book_layouts_needs_drive_export") or 0) or bool(state.get("contacts_manifest_needs_drive_export") or 0) or bool(state.get("meetingdata_needs_drive_export") or 0) or bool(state.get("field_list_needs_drive_export") or 0) or bool(state.get("changes_list_needs_drive_export") or 0),
                    "contact_records_needs_drive_export": contact_records_drive_export_needed,
                    "meetingdata_needs_drive_export": bool(state.get("meetingdata_needs_drive_export") or 0),
                    "field_list_needs_drive_export": bool(state.get("field_list_needs_drive_export") or 0),
                    "changes_list_needs_drive_export": bool(state.get("changes_list_needs_drive_export") or 0),
                    "total_count": int(state.get("upload_total_count") or 0),
                    "processed_count": int(state.get("upload_processed_count") or 0),
                    "bootstrap_status": str(state.get("bootstrap_status") or "idle"),
                    "bootstrap_total": int(state.get("bootstrap_total_contacts") or 0),
                    "bootstrap_processed": int(state.get("bootstrap_processed_contacts") or 0),
                }
            _clear_stale_upload_progress_if_needed(conn)
            state_row = conn.execute("SELECT * FROM google_sync_state WHERE id = 1").fetchone()
            state = dict(state_row) if state_row else {}
            pending_count = _refresh_pending_upload_count(conn)
            needs_drive_export = bool(state.get("needs_drive_export") or 0)
            contacts_manifest_needs_drive_export = bool(state.get("contacts_manifest_needs_drive_export") or 0)
            book_layouts_needs_drive_export = bool(state.get("book_layouts_needs_drive_export") or 0)
            contact_records_drive_export_needed = _count_pending_shared_contact_exports(conn) > 0
            meetingdata_needs_drive_export = bool(state.get("meetingdata_needs_drive_export") or 0)
            field_list_needs_drive_export = bool(state.get("field_list_needs_drive_export") or 0)
            changes_list_needs_drive_export = bool(state.get("changes_list_needs_drive_export") or 0)
            any_drive_export_needed = (
                needs_drive_export
                or contacts_manifest_needs_drive_export
                or book_layouts_needs_drive_export
                or contact_records_drive_export_needed
                or meetingdata_needs_drive_export
                or field_list_needs_drive_export
                or changes_list_needs_drive_export
            )
            total_count = pending_count + (1 if any_drive_export_needed else 0)
            if bool(state.get("upload_in_progress") or 0):
                conn.commit()
                return {
                    "started": False,
                    "in_progress": True,
                    "pending_count": pending_count,
                    "needs_drive_export": any_drive_export_needed,
                    "contact_records_needs_drive_export": contact_records_drive_export_needed,
                    "meetingdata_needs_drive_export": meetingdata_needs_drive_export,
                    "field_list_needs_drive_export": field_list_needs_drive_export,
                    "changes_list_needs_drive_export": changes_list_needs_drive_export,
                    "total_count": int(state.get("upload_total_count") or total_count),
                    "processed_count": int(state.get("upload_processed_count") or 0),
                    "bootstrap_status": str(state.get("bootstrap_status") or "idle"),
                    "bootstrap_total": int(state.get("bootstrap_total_contacts") or 0),
                    "bootstrap_processed": int(state.get("bootstrap_processed_contacts") or 0),
                }
            if total_count <= 0:
                _set_upload_progress(
                    conn,
                    in_progress=False,
                    phase="",
                    total_count=0,
                    processed_count=0,
                    current_contact="",
                    started_at="",
                )
                _clear_last_sync_error(conn)
                conn.commit()
                return {
                    "started": False,
                    "in_progress": False,
                    "pending_count": 0,
                    "needs_drive_export": False,
                    "contact_records_needs_drive_export": False,
                    "meetingdata_needs_drive_export": False,
                    "field_list_needs_drive_export": False,
                    "changes_list_needs_drive_export": False,
                    "total_count": 0,
                    "processed_count": 0,
                    "bootstrap_status": str(state.get("bootstrap_status") or "idle"),
                    "bootstrap_total": int(state.get("bootstrap_total_contacts") or 0),
                    "bootstrap_processed": int(state.get("bootstrap_processed_contacts") or 0),
                }
            account_row = conn.execute("SELECT account_status FROM google_sync_accounts WHERE id = 1").fetchone()
            if str(account_row["account_status"] if account_row else "") != "connected":
                message = SYNC_NOTICE_MESSAGES["upload_not_connected"]
                _set_upload_progress(
                    conn,
                    in_progress=False,
                    phase="",
                    total_count=total_count,
                    processed_count=0,
                    current_contact="",
                    started_at="",
                )
                _set_last_sync_error(conn, message)
                conn.commit()
                raise RuntimeError(message)
            _set_upload_progress(
                conn,
                in_progress=True,
                phase="google_contacts" if pending_count > 0 else "drive_shared_data",
                total_count=total_count,
                processed_count=0,
                current_contact="",
                started_at=_now_text(),
            )
            _clear_last_sync_error(conn)
            conn.commit()

        _UPLOAD_JOB_THREAD = threading.Thread(target=_run_google_upload_job, daemon=True)
        _UPLOAD_JOB_THREAD.start()
        return {
            "started": True,
            "in_progress": True,
            "pending_count": pending_count,
            "needs_drive_export": any_drive_export_needed,
            "contact_records_needs_drive_export": contact_records_drive_export_needed,
            "meetingdata_needs_drive_export": meetingdata_needs_drive_export,
            "field_list_needs_drive_export": field_list_needs_drive_export,
            "changes_list_needs_drive_export": changes_list_needs_drive_export,
            "total_count": total_count,
            "processed_count": 0,
            "bootstrap_status": str(state.get("bootstrap_status") or "idle"),
            "bootstrap_total": int(state.get("bootstrap_total_contacts") or 0),
            "bootstrap_processed": int(state.get("bootstrap_processed_contacts") or 0),
        }


def get_notice_message(notice_key: str) -> str:
    return SYNC_NOTICE_MESSAGES.get(str(notice_key or "").strip(), "")
