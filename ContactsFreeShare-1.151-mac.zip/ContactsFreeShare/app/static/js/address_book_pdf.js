function addressBookPdfNumber(form, name, fallback) {
  const value = parseFloat(form.querySelector(`[name="${name}"]`)?.value || "");
  return Number.isFinite(value) ? value : fallback;
}

function addressBookPdfText(form, name, fallback) {
  const value = form.querySelector(`[name="${name}"]`)?.value || "";
  return value.trim() || fallback;
}

function addressBookPdfChoice(form, name, fallback) {
  return form.querySelector(`[name="${name}"]:checked`)?.value || fallback;
}

function addressBookPdfMapProvider() {
  const form = document.querySelector("[data-address-book-pdf-form]");
  return addressBookPdfChoice(form, "address_map_provider", "google") === "apple" ? "apple" : "google";
}

function escapeAddressBookPdfHtml(value) {
  return String(value || "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  }[char]));
}

function normalizeAddressBookPdfKey(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\bsouth\b/g, "s")
    .replace(/\bnorth\b/g, "n")
    .trim();
}

function sanitizeAddressBookPdfMeetingHtml(value) {
  const template = document.createElement("template");
  template.innerHTML = String(value || "");
  const allowedTags = new Set(["B", "STRONG", "I", "EM", "U", "BR"]);
  const appendTextWithBreaks = (fragment, text) => {
    String(text || "").split(/\r?\n/).forEach((part, index) => {
      if (index > 0) fragment.appendChild(document.createElement("br"));
      if (part) fragment.appendChild(document.createTextNode(part));
    });
  };
  const sanitizeNode = (node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      const fragment = document.createDocumentFragment();
      appendTextWithBreaks(fragment, node.textContent || "");
      return fragment;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return document.createTextNode("");
    const tagName = node.tagName.toUpperCase();
    if (!allowedTags.has(tagName)) {
      const fragment = document.createDocumentFragment();
      Array.from(node.childNodes).forEach((child) => fragment.appendChild(sanitizeNode(child)));
      return fragment;
    }
    const clone = document.createElement(tagName.toLowerCase());
    if (tagName === "BR") return clone;
    Array.from(node.childNodes).forEach((child) => clone.appendChild(sanitizeNode(child)));
    return clone;
  };
  const fragment = document.createDocumentFragment();
  Array.from(template.content.childNodes).forEach((node) => fragment.appendChild(sanitizeNode(node)));
  const output = document.createElement("div");
  output.appendChild(fragment);
  return output.innerHTML.replace(/<br\s*\/?>/gi, "<br>");
}

function contactNameHtmlForAddressBookPdf(value) {
  const text = String(value || "CONTACT, Name").trim() || "CONTACT, Name";
  const commaIndex = text.indexOf(",");
  if (commaIndex < 0) return escapeAddressBookPdfHtml(text);
  const lastName = text.slice(0, commaIndex);
  const rest = text.slice(commaIndex);
  return `<strong>${escapeAddressBookPdfHtml(lastName)}</strong>${escapeAddressBookPdfHtml(rest)}`;
}

function addressBookPdfAddressDisplayLines(address) {
  const lines = String(address || "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  return lines.flatMap((line) => {
    if (line.length <= 42) return [line];
    const cityStateZipMatch = line.match(/^(.+?),\s*([^,]+,\s*[A-Z]{2}\s+\d{5}(?:-\d{4})?)$/);
    if (!cityStateZipMatch) return [line];
    const streetPart = cityStateZipMatch[1].trim();
    const cityStateZipPart = cityStateZipMatch[2].trim();
    if (!streetPart || !cityStateZipPart) return [line];
    return [streetPart, cityStateZipPart];
  });
}

function addressBookPdfAddressEntry(address) {
  if (address && typeof address === "object") {
    const coordinates = String(address.coordinates || "").trim();
    return {
      text: String(address.text || "").trim(),
      coordinates,
      hasCoordinates: Boolean(address.has_coordinates || coordinates),
    };
  }
  return {
    text: String(address || "").trim(),
    coordinates: "",
    hasCoordinates: false,
  };
}

function addressBookPdfMapUrl(coordinates) {
  const value = String(coordinates || "").trim().replace(/\s*,\s*/g, ",");
  if (!value) return "";
  const provider = addressBookPdfMapProvider();
  const host = provider === "apple" ? "maps.apple.com" : "maps.google.com";
  return `http://${host}/?q=${value}`;
}

function getAddressBookPdfPrintOrder() {
  const input = document.querySelector("[data-address-book-pdf-print-order-json]");
  try {
    const payload = JSON.parse(input?.value || "{}");
    return payload && typeof payload === "object" ? payload : { fields: [] };
  } catch {
    return { fields: [] };
  }
}

function setAddressBookPdfPrintOrder(payload) {
  const input = document.querySelector("[data-address-book-pdf-print-order-json]");
  if (!input) return;
  input.value = JSON.stringify(payload || { fields: [] });
}

function persistAddressBookPdfPrintOrder() {
  const input = document.querySelector("[data-address-book-pdf-print-order-json]");
  const customMode = document.querySelector('[name="print_order_mode"][value="custom"]');
  if (customMode) customMode.checked = true;
  if (!input) return Promise.resolve();
  const body = new FormData();
  body.set("print_order_json", input.value || '{"fields":[]}');
  body.set("print_order_mode", "custom");
  return fetch("/address-book/pdf/print-order", {
    method: "POST",
    body,
    credentials: "same-origin",
  }).catch(() => {});
}

function addressBookPdfPrintOrderLookup() {
  const payload = getAddressBookPdfPrintOrder();
  const fields = new Map();
  const meetings = new Map();
  (payload.fields || []).forEach((field, fieldIndex) => {
    const fieldName = String(field.name || "");
    fields.set(fieldName, Number(field.order || fieldIndex + 1));
    (field.meetings || []).forEach((meeting, meetingIndex) => {
      meetings.set(`${fieldName}\n${String(meeting.name || "")}`, Number(meeting.order || meetingIndex + 1));
    });
  });
  return { fields, meetings };
}

function getAddressBookPdfOrderedFields(fields = getAddressBookPdfPickerFields()) {
  const lookup = addressBookPdfPrintOrderLookup();
  return (fields || [])
    .map((field, fieldIndex) => {
      const fieldName = String(field.name || "");
      const meetings = (field.meetings || [])
        .map((meeting, meetingIndex) => ({
          ...meeting,
          name: String(meeting.name || ""),
          order: lookup.meetings.get(`${fieldName}\n${String(meeting.name || "")}`) || meetingIndex + 1_000_000,
        }))
        .sort((left, right) => left.order - right.order || left.name.localeCompare(right.name));
      return {
        ...field,
        name: fieldName,
        order: lookup.fields.get(fieldName) || fieldIndex + 1_000_000,
        meetings,
      };
    })
    .sort((left, right) => left.order - right.order || left.name.localeCompare(right.name));
}

function phoneNumberHtmlForAddressBookPdf(value) {
  const text = String(value || "").trim();
  const digits = text.replace(/\D/g, "");
  if (digits.length !== 10) return escapeAddressBookPdfHtml(text);
  const callPart = `${digits.slice(0, 3)}-${digits.slice(3, 6)}`;
  const messagePart = digits.slice(6);
  return `
    <a class="address-book-pdf-phone-call-link" href="tel:${digits}">${escapeAddressBookPdfHtml(callPart)}</a><span class="address-book-pdf-phone-separator">-</span><a class="address-book-pdf-phone-message-link" href="sms:${digits}">${escapeAddressBookPdfHtml(messagePart)}</a>
  `;
}

function getAddressBookPdfPickerFields() {
  const palette = document.querySelector("[data-address-book-pdf-picker]");
  if (!palette) return [];
  if (Array.isArray(window.addressBookPdfPickerFields)) return window.addressBookPdfPickerFields;
  try {
    const payload = JSON.parse(palette.dataset.addressBookPdfPicker || "{}");
    window.addressBookPdfPickerFields = Array.isArray(payload.fields) ? payload.fields : [];
  } catch {
    window.addressBookPdfPickerFields = [];
  }
  return window.addressBookPdfPickerFields;
}

function getAddressBookPdfMeetingPreviewSections() {
  const palette = document.querySelector("[data-address-book-pdf-picker]");
  if (!palette) return [];
  if (Array.isArray(window.addressBookPdfMeetingPreviewSections)) return window.addressBookPdfMeetingPreviewSections;
  try {
    const payload = JSON.parse(palette.dataset.addressBookPdfMeetingPreview || "{}");
    window.addressBookPdfMeetingPreviewSections = Array.isArray(payload.sections) ? payload.sections : [];
  } catch {
    window.addressBookPdfMeetingPreviewSections = [];
  }
  return window.addressBookPdfMeetingPreviewSections;
}

function addressBookPdfMeetingPreviewRows() {
  const fieldSelect = document.querySelector("[data-address-book-pdf-field-picker]");
  const meetingSelect = document.querySelector("[data-address-book-pdf-meeting-picker]");
  const selectedMeetingKey = normalizeAddressBookPdfKey(meetingSelect?.value || "");
  const selectedFieldKey = normalizeAddressBookPdfKey(fieldSelect?.value || "");
  if (!selectedMeetingKey) return [];
  const scored = getAddressBookPdfMeetingPreviewSections()
    .map((section) => {
      const meetingKey = normalizeAddressBookPdfKey(section.meeting || section.meeting_key);
      const fieldKey = normalizeAddressBookPdfKey(section.field || section.field_key);
      const meetingMatches =
        meetingKey === selectedMeetingKey ||
        meetingKey.startsWith(selectedMeetingKey) ||
        selectedMeetingKey.startsWith(meetingKey);
      if (!meetingMatches) return null;
      const fieldMatches =
        fieldKey === selectedFieldKey ||
        (selectedFieldKey && fieldKey.includes(selectedFieldKey)) ||
        (fieldKey && selectedFieldKey.includes(fieldKey));
      return { score: fieldMatches ? 2 : 1, rows: section.rows || [] };
    })
    .filter(Boolean)
    .sort((left, right) => right.score - left.score);
  return scored[0]?.rows || [];
}

function getAddressBookPdfPreviewContacts() {
  const fieldSelect = document.querySelector("[data-address-book-pdf-field-picker]");
  const meetingSelect = document.querySelector("[data-address-book-pdf-meeting-picker]");
  const fields = getAddressBookPdfOrderedFields();
  const selectedFieldName = fieldSelect?.value || "";
  const selectedMeetingName = meetingSelect?.value || "";
  const scopedFields = selectedFieldName ? fields.filter((field) => field.name === selectedFieldName) : fields;
  const contacts = [];

  scopedFields.forEach((field) => {
    const meetings = selectedMeetingName
      ? (field.meetings || []).filter((meeting) => meeting.name === selectedMeetingName)
      : (field.meetings || []);
    meetings.forEach((meeting) => {
      (meeting.contacts || []).forEach((contact) => contacts.push(contact));
    });
  });
  return contacts.slice(0, 10);
}

function renderAddressBookPdfMeetingPreviewRow(row) {
  const rowStyle = [
    Number(row.font_size_pt || 0) ? `--meeting-row-font-size: ${Number(row.font_size_pt).toFixed(2)}pt` : "",
    `--meeting-grid-column-gap: ${Math.max(0, Math.min(48, Number(row.column_gap_px || 6)))}px`,
  ].filter(Boolean).join("; ");
  const styleAttr = rowStyle ? ` style="${rowStyle}"` : "";
  const rowClass = row.is_underlined_row ? " is-underlined-row" : "";
  if (row.kind === "blank") return `<div class="field-list-meeting-preview-blank${rowClass}"${styleAttr}></div>`;
  if (row.kind === "divider") return `<div class="field-list-meeting-preview-divider${rowClass}"${styleAttr}></div>`;
  if (row.kind === "flow") {
    return `
      <div class="field-list-meeting-preview-flow${rowClass}"${styleAttr}>
        ${(row.columns || []).map((column) => {
          const colStart = Math.max(1, Math.min(28, Number(column.col_start || 1)));
          const colSpan = Math.max(1, Math.min(28, Number(column.col_span || 1)));
          return `
            <div class="field-list-meeting-preview-cell field-list-meeting-preview-flow-column align-left" style="grid-column: ${colStart} / span ${colSpan};">
              <div class="field-list-meeting-preview-flow-text">${sanitizeAddressBookPdfMeetingHtml(column.html)}</div>
            </div>
          `;
        }).join("")}
      </div>
    `;
  }
  return `
    <div class="field-list-meeting-preview-row${rowClass}"${styleAttr}>
      ${(row.cells || []).map((cell) => {
        const classes = [
          "field-list-meeting-preview-cell",
          cell.align === "right" ? "align-right" : cell.align === "center" || cell.align === "auto" ? "align-center" : "align-left",
          cell.is_bold ? "is-bold" : "",
          cell.is_italic ? "is-italic" : "",
          cell.is_title ? "is-title" : "",
          cell.is_underlined ? "is-underlined" : "",
        ].filter(Boolean).join(" ");
        const colStart = Math.max(1, Math.min(28, Number(cell.col_start || 1)));
        const colSpan = Math.max(1, Math.min(28, Number(cell.col_span || 28)));
        return `<div class="${classes}" style="grid-column: ${colStart} / span ${colSpan};">${sanitizeAddressBookPdfMeetingHtml(cell.html)}</div>`;
      }).join("")}
    </div>
  `;
}

function renderAddressBookPdfMeetingPreviewRows(rows) {
  const chunks = [];
  let currentGroup = "";
  let groupedRows = [];

  const flushGroup = () => {
    if (!groupedRows.length) return;
    chunks.push(`
      <div class="address-book-pdf-keep-together-block">
        ${groupedRows.map(renderAddressBookPdfMeetingPreviewRow).join("")}
      </div>
    `);
    groupedRows = [];
    currentGroup = "";
  };

  rows.forEach((row) => {
    const group = String(row.keep_together_group || "").trim();
    if (!group) {
      flushGroup();
      chunks.push(renderAddressBookPdfMeetingPreviewRow(row));
      return;
    }
    if (currentGroup && group !== currentGroup) {
      flushGroup();
    }
    currentGroup = group;
    groupedRows.push(row);
  });
  flushGroup();
  return chunks.join("");
}

function renderAddressBookPdfBiblePreview() {
  const biblePreview = document.querySelector("[data-address-book-pdf-bible-preview]");
  if (!biblePreview) return;
  const rows = addressBookPdfMeetingPreviewRows();
  biblePreview.innerHTML = rows.length
    ? `<div class="field-list-bible-cluster align-center address-book-pdf-keep-together-block">${renderAddressBookPdfMeetingPreviewRows(rows)}</div>`
    : "";
}

function updateAddressBookPdfPageLabels() {
  const fieldSelect = document.querySelector("[data-address-book-pdf-field-picker]");
  const meetingSelect = document.querySelector("[data-address-book-pdf-meeting-picker]");
  const meetingTitle = document.querySelector("[data-address-book-pdf-meeting-title]");
  const pageFooter = document.querySelector("[data-address-book-pdf-page-footer]");
  const fieldName = fieldSelect?.value || "All Fields";
  const meetingName = meetingSelect?.value || "All Meetings";
  if (meetingTitle) meetingTitle.textContent = meetingName;
  if (pageFooter) pageFooter.textContent = `${fieldName} - Page 1`;
}

function updateAddressBookPdfCoverCanvas() {
  const page = document.querySelector("[data-address-book-pdf-page]");
  const canvasPreview = document.querySelector("[data-address-book-pdf-cover-canvas-preview]");
  const imageEl = document.querySelector("[data-address-book-pdf-cover-canvas-image]");
  const titleEl = document.querySelector("[data-address-book-pdf-cover-canvas-title]");
  const dateEl = document.querySelector("[data-address-book-pdf-cover-canvas-date]");
  const includeValue = document.querySelector("[data-address-book-pdf-include-cover-value]");
  const imageData = document.querySelector("[data-address-book-pdf-cover-image-data]")?.value || "";
  const showCover = includeValue?.value === "1" && Boolean(imageData);

  if (!page || !canvasPreview || !imageEl || !titleEl || !dateEl) return;
  page.classList.toggle("has-cover-preview", showCover);
  canvasPreview.hidden = !showCover;
  if (!showCover) {
    imageEl.removeAttribute("src");
    titleEl.hidden = true;
    dateEl.hidden = true;
    return;
  }

  const titleEnabled = document.querySelector("[data-address-book-pdf-include-cover-title-value]")?.value === "1";
  const dateEnabled = document.querySelector("[data-address-book-pdf-include-cover-date-value]")?.value === "1";
  const titleText = document.querySelector("[data-address-book-pdf-cover-title-text]")?.value || "";
  const dateText = document.querySelector("[data-address-book-pdf-cover-date-text]")?.value || "";
  const titleEffect = document.querySelector("[data-address-book-pdf-cover-title-effect]")?.value || "shadow";

  imageEl.src = imageData;
  titleEl.textContent = titleText;
  titleEl.hidden = !titleEnabled || !titleText.trim();
  titleEl.style.left = `${(parseFloat(document.querySelector("[data-address-book-pdf-cover-title-x]")?.value || "0.5") || 0.5) * 100}%`;
  titleEl.style.top = `${(parseFloat(document.querySelector("[data-address-book-pdf-cover-title-y]")?.value || "0.24") || 0.24) * 100}%`;
  titleEl.style.fontSize = `${Math.max(8, Math.min(72, parseFloat(document.querySelector("[data-address-book-pdf-cover-title-font-size]")?.value || "30") || 30))}px`;
  titleEl.style.color = document.querySelector("[data-address-book-pdf-cover-title-color]")?.value || "#ffffff";
  titleEl.dataset.effect = titleEffect;

  dateEl.textContent = dateText;
  dateEl.hidden = !dateEnabled || !dateText.trim();
  dateEl.style.left = `${(parseFloat(document.querySelector("[data-address-book-pdf-cover-date-x]")?.value || "0.5") || 0.5) * 100}%`;
  dateEl.style.top = `${(parseFloat(document.querySelector("[data-address-book-pdf-cover-date-y]")?.value || "0.82") || 0.82) * 100}%`;
  dateEl.style.fontSize = `${Math.max(8, Math.min(72, parseFloat(document.querySelector("[data-address-book-pdf-cover-date-font-size]")?.value || "18") || 18))}px`;
  dateEl.style.color = document.querySelector("[data-address-book-pdf-cover-date-color]")?.value || "#ffffff";
}

function renderAddressBookPdfContactPreview() {
  const list = document.querySelector("[data-address-book-pdf-contact-list]");
  if (!list) return;
  updateAddressBookPdfPageLabels();
  const contacts = getAddressBookPdfPreviewContacts();
  if (!contacts.length) {
    list.innerHTML = '<div class="address-book-pdf-empty-preview">No contacts found for this selection.</div>';
    return;
  }
  list.innerHTML = contacts.map((contact) => {
    const phoneLines = (contact.phones || [])
      .filter((item) => item.value)
      .map((phone, index) => {
        const useFullPhoneLabel = index > 0 && phone.custom_label;
        const phoneCode = useFullPhoneLabel ? phone.custom_label : (phone.code || "");
        return `
        <div class="address-book-pdf-phone-line ${index === 0 ? "is-primary-phone" : "is-secondary-phone"}">
          <span class="address-book-pdf-phone-value">${phoneNumberHtmlForAddressBookPdf(phone.value || "")}</span>
          <span class="address-book-pdf-phone-code ${useFullPhoneLabel ? "is-full-phone-label" : ""}">${escapeAddressBookPdfHtml(phoneCode)}</span>
        </div>
      `;
      }).join("");
    const addressLines = (contact.addresses || [])
      .map(addressBookPdfAddressEntry)
      .filter((address) => address.text)
      .flatMap((address) => (
        addressBookPdfAddressDisplayLines(address.text).map((line) => ({
          line,
          coordinates: address.coordinates,
          hasCoordinates: address.hasCoordinates,
        }))
      ))
      .map((address) => {
        const lineHtml = escapeAddressBookPdfHtml(address.line);
        const mapUrl = address.hasCoordinates ? addressBookPdfMapUrl(address.coordinates) : "";
        return `
          <div class="address-book-pdf-address-line ${address.hasCoordinates ? "has-gps" : "no-gps"}">
            ${mapUrl ? `<a href="${escapeAddressBookPdfHtml(mapUrl)}" target="_blank" rel="noopener">${lineHtml}</a>` : lineHtml}
          </div>
        `;
      })
      .join("");
    return `
      <div class="address-book-pdf-contact-row">
        <div class="address-book-pdf-phone-stack">${phoneLines}</div>
        <div class="address-book-pdf-contact-main">
          <div class="address-book-pdf-contact-name">${contactNameHtmlForAddressBookPdf(contact.name)}</div>
          <div class="address-book-pdf-contact-address">${addressLines}</div>
        </div>
      </div>
    `;
  }).join("");
  renderAddressBookPdfBiblePreview();
}

function updateAddressBookPdfPreview() {
  const form = document.querySelector("[data-address-book-pdf-form]");
  if (!form) return;

  const trimWidth = Math.max(0.1, addressBookPdfNumber(form, "trim_width_in", 3.5));
  const trimHeight = Math.max(0.1, addressBookPdfNumber(form, "trim_height_in", 5));
  const marginLeft = Math.max(0, addressBookPdfNumber(form, "margin_left_in", 0.14));
  const marginRight = Math.max(0, addressBookPdfNumber(form, "margin_right_in", 0.14));
  const marginTop = Math.max(0, addressBookPdfNumber(form, "margin_top_in", 0.14));
  const marginBottom = Math.max(0, addressBookPdfNumber(form, "margin_bottom_in", 0.14));
  const fontFamily = addressBookPdfText(form, "font_family", "Arial");
  const fontSize = Math.max(1, addressBookPdfNumber(form, "base_font_size_pt", 7));
  const lineHeight = Math.max(0.5, addressBookPdfNumber(form, "line_height", 1.2));
  const columnCount = Math.max(1, parseInt(form.querySelector('[name="meeting_table_column_count"]')?.value || "28", 10) || 28);
  const columnGap = Math.max(0, parseInt(form.querySelector('[name="meeting_table_column_gap_px"]')?.value || "6", 10) || 6);
  const previewScale = Math.max(40, addressBookPdfNumber(form, "screen_preview_scale", 220));
  const bookTitle = addressBookPdfText(form, "book_title", "Address Book");
  const addressAlign = addressBookPdfChoice(form, "address_align", "right") === "left" ? "left" : "right";
  const addressItalic = Boolean(form.querySelector('[name="address_italic"]')?.checked);

  const printableWidth = Math.max(0.1, trimWidth - marginLeft - marginRight);
  const printableHeight = Math.max(0.1, trimHeight - marginTop - marginBottom);
  const previewWidth = printableWidth * previewScale;
  const columnWidth = printableWidth / columnCount;

  const fitScale = Math.min(430 / trimWidth, 650 / trimHeight, 150);
  const page = document.querySelector("[data-address-book-pdf-page]");
  const printable = document.querySelector("[data-address-book-pdf-printable]");
  const bookSize = document.querySelector("[data-address-book-pdf-book-size]");
  const printableSize = document.querySelector("[data-address-book-pdf-printable-size]");

  if (page) {
    page.style.width = `${trimWidth * fitScale}px`;
    page.style.height = `${trimHeight * fitScale}px`;
  }
  if (printable) {
    printable.style.left = `${marginLeft * fitScale}px`;
    printable.style.right = `${marginRight * fitScale}px`;
    printable.style.top = `${marginTop * fitScale}px`;
    printable.style.bottom = `${marginBottom * fitScale}px`;
    printable.style.width = "";
    printable.style.height = "";
    printable.style.fontFamily = fontFamily;
    printable.style.fontSize = `${fontSize * (fitScale / 72)}px`;
    printable.style.lineHeight = String(lineHeight);
    printable.dataset.addressAlign = addressAlign;
    printable.classList.toggle("address-book-pdf-address-italic", addressItalic);
  }
  if (bookSize) {
    bookSize.textContent = `${trimWidth.toFixed(2)}" x ${trimHeight.toFixed(2)}"`;
  }
  if (printableSize) {
    printableSize.textContent = `${printableWidth.toFixed(2)}" x ${printableHeight.toFixed(2)}" printable`;
  }

  const setText = (selector, value) => {
    const element = document.querySelector(selector);
    if (element) element.textContent = value;
  };
  setText('[data-metric="printable-width"]', `${printableWidth.toFixed(2)} in`);
  setText('[data-metric="printable-height"]', `${printableHeight.toFixed(2)} in`);
  setText('[data-metric="column-width"]', `${columnWidth.toFixed(3)} in`);
  setText('[data-metric="preview-width"]', `${previewWidth.toFixed(0)} px`);
  setText('[data-metric="font-family"]', fontFamily);

  form.style.setProperty("--address-book-pdf-column-count", String(columnCount));
  form.style.setProperty("--address-book-pdf-column-gap", `${columnGap}px`);
  updateAddressBookPdfPageLabels();
  updateAddressBookPdfCoverCanvas();
}

function installAddressBookPdfTemporaryNotice() {
  const notice = document.querySelector("[data-address-book-pdf-temporary-notice], #contacts-temporary-notice[data-auto-hide-ms]");
  if (!notice) return;
  const delay = Number.parseInt(notice.dataset.autoHideMs || "3600", 10) || 3600;
  window.setTimeout(() => {
    notice.style.transition = "opacity 220ms ease";
    notice.style.opacity = "0";
    window.setTimeout(() => notice.remove(), 240);
  }, delay);
}

function decimalPlaces(value) {
  const text = String(value || "");
  if (!text.includes(".")) return 0;
  return text.split(".")[1].length;
}

function normalizeSteppedValue(value, step) {
  const places = Math.max(decimalPlaces(step), 0);
  return places ? value.toFixed(places) : String(Math.round(value));
}

function stepAddressBookPdfNumber(input, direction) {
  if (!input) return;
  const step = Number.parseFloat(input.getAttribute("step") || "1") || 1;
  const min = Number.parseFloat(input.getAttribute("min") || "");
  const max = Number.parseFloat(input.getAttribute("max") || "");
  const fallback = Number.parseFloat(input.getAttribute("value") || "0") || 0;
  let nextValue = (Number.parseFloat(input.value || "") || fallback) + (step * direction);
  if (Number.isFinite(min)) nextValue = Math.max(min, nextValue);
  if (Number.isFinite(max)) nextValue = Math.min(max, nextValue);
  input.value = normalizeSteppedValue(nextValue, step);
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
}

function bindRepeatingAddressBookPdfStep(button, input, direction) {
  let delayTimer = null;
  let repeatTimer = null;

  const stopRepeating = () => {
    if (delayTimer) {
      window.clearTimeout(delayTimer);
      delayTimer = null;
    }
    if (repeatTimer) {
      window.clearInterval(repeatTimer);
      repeatTimer = null;
    }
    if (button.hasPointerCapture) {
      try {
        button.releasePointerCapture(Number(button.dataset.activePointerId || -1));
      } catch {
        // Pointer capture may already be released by the browser.
      }
    }
    delete button.dataset.activePointerId;
  };

  const startRepeating = (event) => {
    event.preventDefault();
    stopRepeating();
    if (event.pointerId !== undefined && button.setPointerCapture) {
      button.dataset.activePointerId = String(event.pointerId);
      button.setPointerCapture(event.pointerId);
    }
    stepAddressBookPdfNumber(input, direction);
    delayTimer = window.setTimeout(() => {
      repeatTimer = window.setInterval(() => stepAddressBookPdfNumber(input, direction), 90);
    }, 320);
  };

  button.addEventListener("pointerdown", startRepeating);
  button.addEventListener("pointerup", stopRepeating);
  button.addEventListener("pointercancel", stopRepeating);
  button.addEventListener("lostpointercapture", stopRepeating);
  button.addEventListener("blur", stopRepeating);
}

function enhanceAddressBookPdfNumberInputs(form) {
  form.querySelectorAll('input[type="number"]').forEach((input) => {
    if (input.closest(".address-book-pdf-number-control")) return;
    const wrapper = document.createElement("span");
    wrapper.className = "address-book-pdf-number-control";
    input.parentNode.insertBefore(wrapper, input);
    wrapper.appendChild(input);

    const buttons = document.createElement("span");
    buttons.className = "address-book-pdf-number-buttons";

    const upButton = document.createElement("button");
    upButton.type = "button";
    upButton.className = "address-book-pdf-number-step";
    upButton.setAttribute("aria-label", `Increase ${input.id || input.name || "value"}`);
    upButton.textContent = "▲";

    const downButton = document.createElement("button");
    downButton.type = "button";
    downButton.className = "address-book-pdf-number-step";
    downButton.setAttribute("aria-label", `Decrease ${input.id || input.name || "value"}`);
    downButton.textContent = "▼";

    bindRepeatingAddressBookPdfStep(upButton, input, 1);
    bindRepeatingAddressBookPdfStep(downButton, input, -1);
    buttons.append(upButton, downButton);
    wrapper.appendChild(buttons);
  });
}

function installAddressBookPdfMapProviderControls(form) {
  form.querySelectorAll('[name="address_map_provider"]').forEach((input) => {
    input.addEventListener("change", renderAddressBookPdfContactPreview);
  });
}

function installAddressBookPdfPrintOrderModal(form) {
  const modal = document.querySelector("[data-address-book-pdf-order-modal]");
  const openButton = document.querySelector("[data-address-book-pdf-order-open]");
  const applyButton = document.querySelector("[data-address-book-pdf-order-apply]");
  const cancelButtons = Array.from(document.querySelectorAll("[data-address-book-pdf-order-cancel]"));
  const fieldsList = document.querySelector("[data-address-book-pdf-order-fields]");
  const meetingsList = document.querySelector("[data-address-book-pdf-order-meetings]");
  const meetingTitle = document.querySelector("[data-address-book-pdf-order-meeting-title]");
  if (!modal || !openButton || !applyButton || !fieldsList || !meetingsList || !meetingTitle) return;

  let selectedFieldName = "";
  let orderState = [];

  const syncOpenButtonVisibility = () => {
    const customMode = form.querySelector('[name="print_order_mode"][value="custom"]');
    openButton.hidden = !customMode?.checked;
  };

  const orderedFields = () => getAddressBookPdfOrderedFields()
    .map((field) => ({
      name: field.name,
      order: field.order,
      meetings: (field.meetings || []).map((meeting) => ({
        name: meeting.name,
        order: meeting.order,
      })),
    }));

  const dragHandle = '<span class="address-book-pdf-drag-handle" aria-hidden="true">☰</span>';
  const selectedField = () => orderState.find((field) => field.name === selectedFieldName) || orderState[0] || null;

  const renderFields = () => {
    fieldsList.innerHTML = orderState.map((field) => `
      <button type="button" class="address-book-pdf-sortable-item ${field.name === selectedFieldName ? "is-selected" : ""}" draggable="true" data-order-field-name="${escapeAddressBookPdfHtml(field.name)}">
        ${dragHandle}<span>${escapeAddressBookPdfHtml(field.name || "Field")}</span>
      </button>
    `).join("");
  };

  const renderMeetings = () => {
    const field = selectedField();
    selectedFieldName = field?.name || "";
    meetingTitle.textContent = selectedFieldName ? `Meetings in ${selectedFieldName}` : "Meetings";
    meetingsList.innerHTML = (field?.meetings || []).map((meeting) => `
      <button type="button" class="address-book-pdf-sortable-item" draggable="true" data-order-meeting-name="${escapeAddressBookPdfHtml(meeting.name)}">
        ${dragHandle}<span>${escapeAddressBookPdfHtml(meeting.name || "Meeting")}</span>
      </button>
    `).join("");
  };

  const render = () => {
    orderState = orderedFields();
    if (!orderState.some((field) => field.name === selectedFieldName)) {
      selectedFieldName = orderState[0]?.name || "";
    }
    renderFields();
    renderMeetings();
  };

  const moveItem = (items, fromIndex, toIndex) => {
    if (fromIndex < 0 || toIndex < 0 || fromIndex === toIndex) return false;
    const [item] = items.splice(fromIndex, 1);
    items.splice(toIndex, 0, item);
    return true;
  };

  const bindSortableList = (container, selector, getItems, afterMove) => {
    let draggedKey = "";
    container.addEventListener("dragstart", (event) => {
      const item = event.target.closest(selector);
      if (!item) return;
      draggedKey = item.dataset.orderFieldName || item.dataset.orderMeetingName || "";
      item.classList.add("is-dragging");
      event.dataTransfer.effectAllowed = "move";
    });
    container.addEventListener("dragend", () => {
      container.querySelectorAll(".is-dragging").forEach((item) => item.classList.remove("is-dragging"));
      draggedKey = "";
    });
    container.addEventListener("dragover", (event) => {
      event.preventDefault();
      const overItem = event.target.closest(selector);
      if (!overItem || !draggedKey) return;
      const items = getItems();
      const overKey = overItem.dataset.orderFieldName || overItem.dataset.orderMeetingName || "";
      const fromIndex = items.findIndex((item) => item.name === draggedKey);
      const toIndex = items.findIndex((item) => item.name === overKey);
      if (moveItem(items, fromIndex, toIndex)) {
        collect();
        afterMove();
      }
    });
  };

  const collect = () => {
    setAddressBookPdfPrintOrder({
      fields: orderState.map((field, fieldIndex) => ({
        name: field.name,
        order: fieldIndex + 1,
        meetings: (field.meetings || []).map((meeting, meetingIndex) => ({
          name: meeting.name,
          order: meetingIndex + 1,
        })),
      })),
    });
    document.dispatchEvent(new CustomEvent("address-book-pdf-print-order-changed"));
    return persistAddressBookPdfPrintOrder();
  };

  fieldsList.addEventListener("click", (event) => {
    const item = event.target.closest("[data-order-field-name]");
    if (!item) return;
    collect();
    selectedFieldName = item.dataset.orderFieldName || "";
    renderFields();
    renderMeetings();
  });

  bindSortableList(fieldsList, "[data-order-field-name]", () => orderState, () => {
    renderFields();
    renderMeetings();
  });
  bindSortableList(meetingsList, "[data-order-meeting-name]", () => selectedField()?.meetings || [], renderMeetings);

  openButton.addEventListener("click", () => {
    render();
    modal.showModal();
  });
  applyButton.addEventListener("click", async () => {
    await collect();
    modal.close();
  });
  cancelButtons.forEach((button) => button.addEventListener("click", () => modal.close()));
  modal.addEventListener("cancel", () => modal.close());
  form.addEventListener("submit", () => {
    if (modal.open) collect();
  });
  form.querySelectorAll('[name="print_order_mode"]').forEach((input) => {
    input.addEventListener("change", syncOpenButtonVisibility);
  });
  syncOpenButtonVisibility();
}

function installAddressBookPdfPrintFieldsModal(form) {
  const modal = document.querySelector("[data-address-book-pdf-field-print-modal]");
  const openButtons = Array.from(document.querySelectorAll("[data-address-book-pdf-print-button], [data-address-book-pdf-print-paper-button]"));
  const list = document.querySelector("[data-address-book-pdf-field-print-list]");
  const confirmButton = document.querySelector("[data-address-book-pdf-field-print-confirm]");
  const cancelButton = document.querySelector("[data-address-book-pdf-field-print-cancel]");
  const selectedInput = document.querySelector("[data-address-book-pdf-print-field-names]");
  if (!modal || !openButtons.length || !list || !confirmButton || !cancelButton || !selectedInput) return;

  let submittingPrint = false;
  let activeSubmitButton = openButtons[0];

  const syncAllCheckbox = () => {
    const allCheckbox = list.querySelector("[data-print-field-all]");
    const fieldCheckboxes = Array.from(list.querySelectorAll("[data-print-field-name]"));
    if (!allCheckbox || !fieldCheckboxes.length) return;
    const checkedCount = fieldCheckboxes.filter((checkbox) => checkbox.checked).length;
    allCheckbox.checked = checkedCount === fieldCheckboxes.length;
    allCheckbox.indeterminate = checkedCount > 0 && checkedCount < fieldCheckboxes.length;
  };

  const render = () => {
    const fields = getAddressBookPdfOrderedFields();
    list.innerHTML = `
      <label class="address-book-pdf-print-field-row address-book-pdf-print-field-row-all">
        <input type="checkbox" data-print-field-all checked>
        <span>All Fields</span>
      </label>
      ${fields.map((field) => `
        <label class="address-book-pdf-print-field-row">
          <input type="checkbox" value="${escapeAddressBookPdfHtml(String(field.name || ""))}" data-print-field-name checked>
          <span>${escapeAddressBookPdfHtml(String(field.name || "Field"))}</span>
        </label>
      `).join("")}
    `;
    syncAllCheckbox();
  };

  list.addEventListener("change", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLInputElement)) return;
    if (target.matches("[data-print-field-all]")) {
      list.querySelectorAll("[data-print-field-name]").forEach((checkbox) => {
        checkbox.checked = target.checked;
      });
      syncAllCheckbox();
      return;
    }
    if (target.matches("[data-print-field-name]")) {
      syncAllCheckbox();
    }
  });

  openButtons.forEach((openButton) => {
    openButton.addEventListener("click", (event) => {
      activeSubmitButton = openButton;
      if (submittingPrint) {
        submittingPrint = false;
        return;
      }
      event.preventDefault();
      render();
      modal.showModal();
    });
  });

  confirmButton.addEventListener("click", () => {
    const selectedFields = Array.from(list.querySelectorAll("[data-print-field-name]:checked"))
      .map((checkbox) => checkbox.value)
      .filter(Boolean);
    selectedInput.value = JSON.stringify(selectedFields);
    submittingPrint = true;
    modal.close();
    activeSubmitButton.click();
  });

  cancelButton.addEventListener("click", () => modal.close());
  modal.addEventListener("cancel", () => modal.close());
}

function installAddressBookPdfCoverModal(form) {
  const modal = document.querySelector("[data-address-book-pdf-cover-modal]");
  const openButton = document.querySelector("[data-address-book-pdf-cover-open]");
  const fileInput = document.querySelector("[data-address-book-pdf-cover-file]");
  const zoomInput = document.querySelector("[data-address-book-pdf-cover-zoom]");
  const preview = document.querySelector("[data-address-book-pdf-cover-preview]");
  const applyButton = document.querySelector("[data-address-book-pdf-cover-apply]");
  const clearButton = document.querySelector("[data-address-book-pdf-cover-clear]");
  const cancelButton = document.querySelector("[data-address-book-pdf-cover-cancel]");
  const includeCheckbox = document.querySelector("[data-address-book-pdf-cover-include]");
  const includeValue = document.querySelector("[data-address-book-pdf-include-cover-value]");
  const includeTitleCheckbox = document.querySelector("[data-address-book-pdf-cover-title-include]");
  const includeTitleValue = document.querySelector("[data-address-book-pdf-include-cover-title-value]");
  const includeDateCheckbox = document.querySelector("[data-address-book-pdf-cover-date-include]");
  const dateRow = includeDateCheckbox?.closest(".address-book-pdf-cover-date-row");
  const includeDateValue = document.querySelector("[data-address-book-pdf-include-cover-date-value]");
  const titleInput = document.querySelector("[data-address-book-pdf-cover-title-input]");
  const titleSizeInput = document.querySelector("[data-address-book-pdf-cover-title-size]");
  const titleColorInput = document.querySelector("[data-address-book-pdf-cover-title-color-input]");
  const titleTextInput = document.querySelector("[data-address-book-pdf-cover-title-text]");
  const titleFontSizeInput = document.querySelector("[data-address-book-pdf-cover-title-font-size]");
  const titleColorHiddenInput = document.querySelector("[data-address-book-pdf-cover-title-color]");
  const titleEffectHiddenInput = document.querySelector("[data-address-book-pdf-cover-title-effect]");
  const titleEffectInputs = Array.from(document.querySelectorAll("[data-address-book-pdf-cover-title-effect-choice]"));
  const titleXInput = document.querySelector("[data-address-book-pdf-cover-title-x]");
  const titleYInput = document.querySelector("[data-address-book-pdf-cover-title-y]");
  const titlePreviewWidthInput = document.querySelector("[data-address-book-pdf-cover-title-preview-width]");
  const dateInput = document.querySelector("[data-address-book-pdf-cover-date-input]");
  const dateSizeInput = document.querySelector("[data-address-book-pdf-cover-date-size]");
  const dateColorInput = document.querySelector("[data-address-book-pdf-cover-date-color-input]");
  const dateTextInput = document.querySelector("[data-address-book-pdf-cover-date-text]");
  const dateFontSizeInput = document.querySelector("[data-address-book-pdf-cover-date-font-size]");
  const dateColorHiddenInput = document.querySelector("[data-address-book-pdf-cover-date-color]");
  const dateXInput = document.querySelector("[data-address-book-pdf-cover-date-x]");
  const dateYInput = document.querySelector("[data-address-book-pdf-cover-date-y]");
  const titleControls = document.querySelector(".address-book-pdf-cover-title-controls");
  const dateFields = document.querySelector(".address-book-pdf-cover-date-fields");
  const savedSelect = document.querySelector("[data-address-book-pdf-cover-saved-select]");
  const saveCoverButton = document.querySelector("[data-address-book-pdf-cover-save]");
  const deleteCoverButton = document.querySelector("[data-address-book-pdf-cover-delete]");
  const dataInput = document.querySelector("[data-address-book-pdf-cover-image-data]");
  const widthInput = document.querySelector("[data-address-book-pdf-cover-image-width]");
  const heightInput = document.querySelector("[data-address-book-pdf-cover-image-height]");
  if (!modal || !openButton || !fileInput || !zoomInput || !preview || !applyButton || !clearButton || !cancelButton || !includeCheckbox || !includeValue || !includeTitleCheckbox || !includeTitleValue || !includeDateCheckbox || !includeDateValue || !titleInput || !titleSizeInput || !titleColorInput || !titleTextInput || !titleFontSizeInput || !titleColorHiddenInput || !titleEffectHiddenInput || !titleXInput || !titleYInput || !titlePreviewWidthInput || !dateInput || !dateSizeInput || !dateColorInput || !dateTextInput || !dateFontSizeInput || !dateColorHiddenInput || !dateXInput || !dateYInput || !titleControls || !dateFields || !savedSelect || !saveCoverButton || !deleteCoverButton || !dataInput || !widthInput || !heightInput) return;

  const savedCoverStorageKey = "addressBookPdfSavedCovers";
  let pendingCover = null;
  let sourceCover = null;
  let cropState = { x: 0.5, y: 0.5, zoom: 1 };
  let titlePosition = {
    x: parseFloat(titleXInput.value || "0.5") || 0.5,
    y: parseFloat(titleYInput.value || "0.24") || 0.24,
  };
  let datePosition = {
    x: parseFloat(dateXInput.value || "0.5") || 0.5,
    y: parseFloat(dateYInput.value || "0.82") || 0.82,
  };

  const todayDateText = () => {
    const now = new Date();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    return `${month}/${day}/${now.getFullYear()}`;
  };

  const syncCoverChoiceVisibility = () => {
    const wantsCover = includeCheckbox.checked;
    openButton.hidden = !wantsCover;
    if (dateRow) dateRow.hidden = !wantsCover;
    if (!wantsCover) {
      includeDateCheckbox.checked = false;
      includeDateValue.value = "0";
    }
  };

  const syncCoverTextAccess = () => {
    const titleEnabled = includeTitleCheckbox.checked;
    const dateEnabled = includeDateCheckbox.checked;
    titleControls.classList.toggle("is-disabled", !titleEnabled);
    dateFields.classList.toggle("is-disabled", !dateEnabled);
    [titleInput, titleSizeInput, titleColorInput, ...titleEffectInputs].forEach((input) => {
      input.disabled = !titleEnabled;
    });
    [dateInput, dateSizeInput, dateColorInput].forEach((input) => {
      input.disabled = !dateEnabled;
    });
  };

  const readSavedCovers = () => {
    try {
      const parsed = JSON.parse(window.localStorage.getItem(savedCoverStorageKey) || "{}");
      return parsed && typeof parsed === "object" && parsed.items && typeof parsed.items === "object"
        ? parsed.items
        : {};
    } catch {
      return {};
    }
  };

  const writeSavedCovers = (items) => {
    window.localStorage.setItem(savedCoverStorageKey, JSON.stringify({ items: items || {} }));
  };

  const renderSavedCovers = (selectedName = "") => {
    const items = readSavedCovers();
    const names = Object.keys(items).sort((left, right) => left.localeCompare(right));
    savedSelect.replaceChildren();
    const emptyOption = document.createElement("option");
    emptyOption.value = "";
    emptyOption.textContent = "Choose saved cover";
    savedSelect.appendChild(emptyOption);
    names.forEach((name) => {
      const option = document.createElement("option");
      option.value = name;
      option.textContent = name;
      if (name === selectedName) option.selected = true;
      savedSelect.appendChild(option);
    });
    deleteCoverButton.disabled = !savedSelect.value;
  };

  const coverDimensions = () => {
    const widthIn = Math.max(0.1, addressBookPdfNumber(form, "trim_width_in", 3.5));
    const heightIn = Math.max(0.1, addressBookPdfNumber(form, "trim_height_in", 5.5));
    const scale = Math.min(360, Math.max(180, 300));
    return {
      width: Math.max(1, Math.round(widthIn * scale)),
      height: Math.max(1, Math.round(heightIn * scale)),
    };
  };

  const clampTitlePosition = () => {
    const titleEl = preview.querySelector("[data-address-book-pdf-cover-title-preview]");
    const stage = preview.querySelector(".address-book-pdf-cover-preview-stage");
    if (titleEl && stage) {
      const stageWidth = stage.clientWidth || 1;
      const stageHeight = stage.clientHeight || 1;
      const titleWidthRatio = Math.min(0.98, (titleEl.offsetWidth || 0) / stageWidth);
      const titleHeightRatio = Math.min(0.98, (titleEl.offsetHeight || 0) / stageHeight);
      const minX = titleWidthRatio / 2;
      const maxX = 1 - (titleWidthRatio / 2);
      const minY = titleHeightRatio / 2;
      const maxY = 1 - (titleHeightRatio / 2);
      titlePosition = {
        x: Math.min(maxX, Math.max(minX, titlePosition.x)),
        y: Math.min(maxY, Math.max(minY, titlePosition.y)),
      };
      return;
    }
    titlePosition = {
      x: Math.min(0.95, Math.max(0.05, titlePosition.x)),
      y: Math.min(0.95, Math.max(0.05, titlePosition.y)),
    };
  };

  const clampDatePosition = () => {
    const dateEl = preview.querySelector("[data-address-book-pdf-cover-date-preview]");
    const stage = preview.querySelector(".address-book-pdf-cover-preview-stage");
    if (dateEl && stage) {
      const stageWidth = stage.clientWidth || 1;
      const stageHeight = stage.clientHeight || 1;
      const dateWidthRatio = Math.min(0.98, (dateEl.offsetWidth || 0) / stageWidth);
      const dateHeightRatio = Math.min(0.98, (dateEl.offsetHeight || 0) / stageHeight);
      const minX = dateWidthRatio / 2;
      const maxX = 1 - (dateWidthRatio / 2);
      const minY = dateHeightRatio / 2;
      const maxY = 1 - (dateHeightRatio / 2);
      datePosition = {
        x: Math.min(maxX, Math.max(minX, datePosition.x)),
        y: Math.min(maxY, Math.max(minY, datePosition.y)),
      };
      return;
    }
    datePosition = {
      x: Math.min(0.95, Math.max(0.05, datePosition.x)),
      y: Math.min(0.95, Math.max(0.05, datePosition.y)),
    };
  };

  const updateTitlePreview = () => {
    const titleEl = preview.querySelector("[data-address-book-pdf-cover-title-preview]");
    if (!titleEl) return;
    const selectedEffect = titleEffectInputs.find((input) => input.checked)?.value || "shadow";
    clampTitlePosition();
    titleEl.textContent = titleInput.value || "";
    titleEl.style.left = `${titlePosition.x * 100}%`;
    titleEl.style.top = `${titlePosition.y * 100}%`;
    titleEl.style.fontSize = `${Math.max(8, Math.min(72, parseFloat(titleSizeInput.value || "30") || 30))}px`;
    titleEl.style.color = titleColorInput.value || "#ffffff";
    titleEl.dataset.effect = selectedEffect;
    titleEl.hidden = !includeTitleCheckbox.checked || !titleEl.textContent.trim();
    clampTitlePosition();
    titleEl.style.left = `${titlePosition.x * 100}%`;
    titleEl.style.top = `${titlePosition.y * 100}%`;
  };

  const updateDatePreview = () => {
    const dateEl = preview.querySelector("[data-address-book-pdf-cover-date-preview]");
    if (!dateEl) return;
    clampDatePosition();
    dateEl.textContent = dateInput.value || "";
    dateEl.style.left = `${datePosition.x * 100}%`;
    dateEl.style.top = `${datePosition.y * 100}%`;
    dateEl.style.fontSize = `${Math.max(8, Math.min(72, parseFloat(dateSizeInput.value || "18") || 18))}px`;
    dateEl.style.color = dateColorInput.value || "#ffffff";
    dateEl.hidden = !includeDateCheckbox.checked || !dateEl.textContent.trim();
    clampDatePosition();
    dateEl.style.left = `${datePosition.x * 100}%`;
    dateEl.style.top = `${datePosition.y * 100}%`;
  };

  const clampCropState = () => {
    cropState.zoom = Math.min(3, Math.max(1, parseFloat(cropState.zoom || 1) || 1));
    cropState.x = Math.min(1, Math.max(0, parseFloat(cropState.x || 0.5) || 0.5));
    cropState.y = Math.min(1, Math.max(0, parseFloat(cropState.y || 0.5) || 0.5));
  };

  const updateCropPreview = () => {
    const imageEl = preview.querySelector("[data-address-book-pdf-cover-crop-image]");
    const stage = preview.querySelector(".address-book-pdf-cover-preview-stage");
    if (!imageEl || !stage || !sourceCover?.image) return;
    clampCropState();
    const stageWidth = stage.clientWidth || 1;
    const stageHeight = stage.clientHeight || 1;
    const sourceRatio = sourceCover.image.naturalWidth / sourceCover.image.naturalHeight;
    const stageRatio = stageWidth / stageHeight;
    let baseWidth = stageWidth;
    let baseHeight = stageHeight;
    if (sourceRatio > stageRatio) {
      baseHeight = stageHeight;
      baseWidth = stageHeight * sourceRatio;
    } else {
      baseWidth = stageWidth;
      baseHeight = stageWidth / sourceRatio;
    }
    const drawWidth = baseWidth * cropState.zoom;
    const drawHeight = baseHeight * cropState.zoom;
    const minX = Math.min(0, stageWidth - drawWidth);
    const minY = Math.min(0, stageHeight - drawHeight);
    const x = minX * cropState.x;
    const y = minY * cropState.y;
    imageEl.style.width = `${drawWidth}px`;
    imageEl.style.height = `${drawHeight}px`;
    imageEl.style.transform = `translate(${x}px, ${y}px)`;
    zoomInput.value = String(cropState.zoom);
  };

  const drawPreview = (src) => {
    preview.innerHTML = src
      ? `<div class="address-book-pdf-cover-preview-stage">
          <img src="${src}" alt="Selected cover picture" data-address-book-pdf-cover-crop-image>
          <div class="address-book-pdf-cover-title-preview" data-address-book-pdf-cover-title-preview></div>
          <div class="address-book-pdf-cover-date-preview" data-address-book-pdf-cover-date-preview></div>
        </div>`
      : '<div class="address-book-pdf-cover-empty">No cover picture selected.</div>';
    updateCropPreview();
    updateTitlePreview();
    updateDatePreview();
  };

  const syncTitleHiddenInputs = () => {
    titleTextInput.value = titleInput.value || "";
    titleFontSizeInput.value = titleSizeInput.value || "30";
    titleColorHiddenInput.value = titleColorInput.value || "#ffffff";
    titleEffectHiddenInput.value = titleEffectInputs.find((input) => input.checked)?.value || "shadow";
    titleXInput.value = String(titlePosition.x);
    titleYInput.value = String(titlePosition.y);
    titlePreviewWidthInput.value = String(preview.querySelector(".address-book-pdf-cover-preview-stage")?.clientWidth || preview.clientWidth || "");
    includeTitleValue.value = includeTitleCheckbox.checked ? "1" : "0";
    updateTitlePreview();
    updateAddressBookPdfCoverCanvas();
  };

  const syncDateHiddenInputs = () => {
    dateTextInput.value = dateInput.value || "";
    dateFontSizeInput.value = dateSizeInput.value || "18";
    dateColorHiddenInput.value = dateColorInput.value || "#ffffff";
    dateXInput.value = String(datePosition.x);
    dateYInput.value = String(datePosition.y);
    includeDateValue.value = includeDateCheckbox.checked ? "1" : "0";
    updateDatePreview();
    updateAddressBookPdfCoverCanvas();
  };

  const fileToSourceCover = (file) => new Promise((resolve, reject) => {
    if (!file) {
      resolve(null);
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read cover picture."));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error("Could not load cover picture."));
      image.onload = () => {
        resolve({
          src: String(reader.result || ""),
          image,
        });
      };
      image.src = String(reader.result || "");
    };
    reader.readAsDataURL(file);
  });

  const sourceToCover = () => {
    if (!sourceCover?.image) return pendingCover;
    const { width, height } = coverDimensions();
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    const sourceRatio = sourceCover.image.naturalWidth / sourceCover.image.naturalHeight;
    const targetRatio = width / height;
    let sw = sourceCover.image.naturalWidth;
    let sh = sourceCover.image.naturalHeight;
    if (sourceRatio > targetRatio) {
      sh = sourceCover.image.naturalHeight / cropState.zoom;
      sw = sh * targetRatio;
    } else {
      sw = sourceCover.image.naturalWidth / cropState.zoom;
      sh = sw / targetRatio;
    }
    const maxSx = Math.max(0, sourceCover.image.naturalWidth - sw);
    const maxSy = Math.max(0, sourceCover.image.naturalHeight - sh);
    const sx = maxSx * cropState.x;
    const sy = maxSy * cropState.y;
    ctx.drawImage(sourceCover.image, sx, sy, sw, sh, 0, 0, width, height);
    return {
      data: canvas.toDataURL("image/jpeg", 0.9),
      width,
      height,
    };
  };

  const setStoredCover = (cover) => {
    dataInput.value = cover?.data || "";
    widthInput.value = cover?.width ? String(cover.width) : "";
    heightInput.value = cover?.height ? String(cover.height) : "";
    includeCheckbox.checked = Boolean(cover?.data);
    includeValue.value = cover?.data ? "1" : "0";
    syncCoverChoiceVisibility();
    drawPreview(cover?.data || "");
    syncTitleHiddenInputs();
    syncDateHiddenInputs();
    updateAddressBookPdfCoverCanvas();
  };

  const currentSavedCoverPayload = () => {
    const cover = sourceToCover();
    if (!cover?.data) return null;
    return {
      cover,
      title: {
        enabled: includeTitleCheckbox.checked,
        text: titleInput.value || "",
        size: titleSizeInput.value || "30",
        color: titleColorInput.value || "#ffffff",
        effect: titleEffectInputs.find((input) => input.checked)?.value || "shadow",
        x: titlePosition.x,
        y: titlePosition.y,
      },
      date: {
        enabled: includeDateCheckbox.checked,
        text: dateInput.value || todayDateText(),
        size: dateSizeInput.value || "18",
        color: dateColorInput.value || "#ffffff",
        x: datePosition.x,
        y: datePosition.y,
      },
    };
  };

  const applySavedCoverPayload = (payload) => {
    if (!payload?.cover?.data) return;
    pendingCover = {
      data: payload.cover.data,
      width: payload.cover.width,
      height: payload.cover.height,
    };
    dataInput.value = pendingCover.data;
    widthInput.value = pendingCover.width ? String(pendingCover.width) : "";
    heightInput.value = pendingCover.height ? String(pendingCover.height) : "";
    includeCheckbox.checked = true;
    includeValue.value = "1";
    includeTitleCheckbox.checked = Boolean(payload.title?.enabled);
    includeDateCheckbox.checked = Boolean(payload.date?.enabled);
    titleInput.value = payload.title?.text || addressBookPdfText(form, "book_title", "");
    titleSizeInput.value = payload.title?.size || "30";
    titleColorInput.value = payload.title?.color || "#ffffff";
    const effect = payload.title?.effect || "shadow";
    titleEffectInputs.forEach((input) => {
      input.checked = input.value === effect;
    });
    if (!titleEffectInputs.some((input) => input.checked) && titleEffectInputs[0]) {
      titleEffectInputs[0].checked = true;
    }
    dateInput.value = payload.date?.text || todayDateText();
    dateSizeInput.value = payload.date?.size || "18";
    dateColorInput.value = payload.date?.color || "#ffffff";
    titlePosition = {
      x: parseFloat(payload.title?.x || "0.5") || 0.5,
      y: parseFloat(payload.title?.y || "0.24") || 0.24,
    };
    datePosition = {
      x: parseFloat(payload.date?.x || "0.5") || 0.5,
      y: parseFloat(payload.date?.y || "0.82") || 0.82,
    };
    sourceCover = { src: pendingCover.data, image: null };
    cropState = { x: 0.5, y: 0.5, zoom: 1 };
    syncCoverChoiceVisibility();
    syncCoverTextAccess();
    syncTitleHiddenInputs();
    syncDateHiddenInputs();
    updateAddressBookPdfCoverCanvas();
    const image = new Image();
    image.onload = () => {
      sourceCover.image = image;
      drawPreview(sourceCover.src);
      syncTitleHiddenInputs();
      syncDateHiddenInputs();
      syncCoverChoiceVisibility();
      syncCoverTextAccess();
      updateAddressBookPdfCoverCanvas();
    };
    image.src = sourceCover.src;
  };

  openButton.addEventListener("click", () => {
    pendingCover = dataInput.value ? { data: dataInput.value, width: widthInput.value, height: heightInput.value } : null;
    sourceCover = pendingCover?.data ? { src: pendingCover.data, image: null } : null;
    cropState = { x: 0.5, y: 0.5, zoom: 1 };
    includeCheckbox.checked = includeValue.value === "1" && Boolean(dataInput.value);
    includeTitleCheckbox.checked = includeTitleValue.value === "1";
    includeDateCheckbox.checked = includeDateValue.value === "1";
    titleInput.value = titleTextInput.value || addressBookPdfText(form, "book_title", "");
    titleSizeInput.value = titleFontSizeInput.value || "30";
    titleColorInput.value = titleColorHiddenInput.value || "#ffffff";
    dateInput.value = dateTextInput.value || todayDateText();
    dateSizeInput.value = dateFontSizeInput.value || "18";
    dateColorInput.value = dateColorHiddenInput.value || "#ffffff";
    const storedEffect = titleEffectHiddenInput.value || "shadow";
    titleEffectInputs.forEach((input) => {
      input.checked = input.value === storedEffect;
    });
    if (!titleEffectInputs.some((input) => input.checked) && titleEffectInputs[0]) {
      titleEffectInputs[0].checked = true;
    }
    titlePosition = {
      x: parseFloat(titleXInput.value || "0.5") || 0.5,
      y: parseFloat(titleYInput.value || "0.24") || 0.24,
    };
    datePosition = {
      x: parseFloat(dateXInput.value || "0.5") || 0.5,
      y: parseFloat(dateYInput.value || "0.82") || 0.82,
    };
    fileInput.value = "";
    if (sourceCover?.src) {
      const image = new Image();
      image.onload = () => {
        sourceCover.image = image;
        drawPreview(sourceCover.src);
        syncCoverTextAccess();
      };
      image.src = sourceCover.src;
    } else {
      drawPreview("");
    }
    renderSavedCovers(savedSelect.value);
    syncCoverTextAccess();
    modal.showModal();
  });

  fileInput.addEventListener("change", async () => {
    try {
      sourceCover = await fileToSourceCover(fileInput.files?.[0]);
      cropState = { x: 0.5, y: 0.5, zoom: 1 };
      pendingCover = sourceToCover();
      if (pendingCover?.data) includeCheckbox.checked = true;
      drawPreview(sourceCover?.src || "");
    } catch {
      pendingCover = null;
      sourceCover = null;
      drawPreview("");
    }
  });

  applyButton.addEventListener("click", () => {
    const shouldInclude = includeCheckbox.checked;
    pendingCover = sourceToCover();
    setStoredCover(pendingCover);
    includeCheckbox.checked = shouldInclude && Boolean(dataInput.value);
    includeValue.value = includeCheckbox.checked ? "1" : "0";
    syncTitleHiddenInputs();
    syncDateHiddenInputs();
    modal.close();
  });
  includeCheckbox.addEventListener("change", () => {
    includeValue.value = includeCheckbox.checked && (pendingCover?.data || dataInput.value) ? "1" : "0";
    syncCoverChoiceVisibility();
    updateAddressBookPdfCoverCanvas();
  });
  includeTitleCheckbox.addEventListener("change", () => {
    syncTitleHiddenInputs();
    syncCoverTextAccess();
  });
  includeDateCheckbox.addEventListener("change", () => {
    syncDateHiddenInputs();
    syncCoverTextAccess();
  });
  titleInput.addEventListener("input", syncTitleHiddenInputs);
  titleSizeInput.addEventListener("input", syncTitleHiddenInputs);
  titleColorInput.addEventListener("input", syncTitleHiddenInputs);
  titleEffectInputs.forEach((input) => input.addEventListener("change", syncTitleHiddenInputs));
  dateInput.addEventListener("input", syncDateHiddenInputs);
  dateSizeInput.addEventListener("input", syncDateHiddenInputs);
  dateColorInput.addEventListener("input", syncDateHiddenInputs);
  zoomInput.addEventListener("input", () => {
    cropState.zoom = parseFloat(zoomInput.value || "1") || 1;
    pendingCover = sourceToCover();
    updateCropPreview();
  });
  preview.addEventListener("pointerdown", (event) => {
    const cropImage = event.target.closest?.("[data-address-book-pdf-cover-crop-image]");
    if (!cropImage) return;
    event.preventDefault();
    const startX = event.clientX;
    const startY = event.clientY;
    const startCrop = { ...cropState };
    const stage = preview.querySelector(".address-book-pdf-cover-preview-stage");
    const moveCrop = (moveEvent) => {
      const rect = stage?.getBoundingClientRect();
      if (!rect?.width || !rect?.height) return;
      const imageEl = preview.querySelector("[data-address-book-pdf-cover-crop-image]");
      const overflowX = Math.max(1, (imageEl?.offsetWidth || rect.width) - rect.width);
      const overflowY = Math.max(1, (imageEl?.offsetHeight || rect.height) - rect.height);
      cropState.x = startCrop.x - ((moveEvent.clientX - startX) / overflowX);
      cropState.y = startCrop.y - ((moveEvent.clientY - startY) / overflowY);
      pendingCover = sourceToCover();
      updateCropPreview();
    };
    const stopCrop = () => {
      window.removeEventListener("pointermove", moveCrop);
      window.removeEventListener("pointerup", stopCrop);
      window.removeEventListener("pointercancel", stopCrop);
    };
    window.addEventListener("pointermove", moveCrop);
    window.addEventListener("pointerup", stopCrop);
    window.addEventListener("pointercancel", stopCrop);
  });
  preview.addEventListener("pointerdown", (event) => {
    const dateEl = event.target.closest?.("[data-address-book-pdf-cover-date-preview]");
    if (!dateEl) return;
    event.preventDefault();
    dateEl.setPointerCapture?.(event.pointerId);
    const moveDate = (moveEvent) => {
      const rect = preview.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      datePosition = {
        x: (moveEvent.clientX - rect.left) / rect.width,
        y: (moveEvent.clientY - rect.top) / rect.height,
      };
      syncDateHiddenInputs();
    };
    const stopMove = () => {
      window.removeEventListener("pointermove", moveDate);
      window.removeEventListener("pointerup", stopMove);
      window.removeEventListener("pointercancel", stopMove);
    };
    window.addEventListener("pointermove", moveDate);
    window.addEventListener("pointerup", stopMove);
    window.addEventListener("pointercancel", stopMove);
  });
  preview.addEventListener("pointerdown", (event) => {
    const titleEl = event.target.closest?.("[data-address-book-pdf-cover-title-preview]");
    if (!titleEl) return;
    event.preventDefault();
    titleEl.setPointerCapture?.(event.pointerId);
    const moveTitle = (moveEvent) => {
      const rect = preview.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      titlePosition = {
        x: (moveEvent.clientX - rect.left) / rect.width,
        y: (moveEvent.clientY - rect.top) / rect.height,
      };
      syncTitleHiddenInputs();
    };
    const stopMove = () => {
      window.removeEventListener("pointermove", moveTitle);
      window.removeEventListener("pointerup", stopMove);
      window.removeEventListener("pointercancel", stopMove);
    };
    window.addEventListener("pointermove", moveTitle);
    window.addEventListener("pointerup", stopMove);
    window.addEventListener("pointercancel", stopMove);
  });
  savedSelect.addEventListener("change", () => {
    const items = readSavedCovers();
    const selected = savedSelect.value || "";
    deleteCoverButton.disabled = !selected;
    if (selected && items[selected]) {
      applySavedCoverPayload(items[selected]);
    }
  });
  saveCoverButton.addEventListener("click", () => {
    const payload = currentSavedCoverPayload();
    if (!payload) {
      window.alert("Choose a cover picture before saving this cover page.");
      return;
    }
    const existingName = savedSelect.value || "";
    const defaultName = existingName || addressBookPdfText(form, "book_title", "Cover Page");
    const name = window.prompt("Save cover page as:", defaultName);
    if (!name) return;
    const cleanName = name.trim();
    if (!cleanName) return;
    const items = readSavedCovers();
    items[cleanName] = payload;
    try {
      writeSavedCovers(items);
      renderSavedCovers(cleanName);
    } catch {
      window.alert("This cover page is too large to save in browser storage.");
    }
  });
  deleteCoverButton.addEventListener("click", () => {
    const selected = savedSelect.value || "";
    if (!selected) return;
    const items = readSavedCovers();
    delete items[selected];
    writeSavedCovers(items);
    renderSavedCovers("");
  });
  if (!dateInput.value) dateInput.value = todayDateText();
  syncDateHiddenInputs();
  renderSavedCovers();
  syncCoverChoiceVisibility();
  syncCoverTextAccess();
  clearButton.addEventListener("click", () => {
    pendingCover = null;
    fileInput.value = "";
    setStoredCover(null);
    modal.close();
  });
  cancelButton.addEventListener("click", () => modal.close());
  modal.addEventListener("cancel", () => modal.close());
}

function installAddressBookPdfPickers() {
  const palette = document.querySelector("[data-address-book-pdf-picker]");
  const fieldSelect = document.querySelector("[data-address-book-pdf-field-picker]");
  const meetingSelect = document.querySelector("[data-address-book-pdf-meeting-picker]");
  if (!palette || !fieldSelect || !meetingSelect) return;

  const orderedFields = () => getAddressBookPdfOrderedFields();

  const renderFields = () => {
    const previousFieldName = fieldSelect.value || fieldSelect.dataset.selectedFieldName || "";
    const fields = orderedFields();
    fieldSelect.replaceChildren();
    const allOption = document.createElement("option");
    allOption.value = "";
    allOption.textContent = "All Fields";
    fieldSelect.appendChild(allOption);
    fields.forEach((field) => {
      const option = document.createElement("option");
      option.value = field.name || "";
      option.textContent = field.name || "";
      if (option.value === previousFieldName) option.selected = true;
      fieldSelect.appendChild(option);
    });
    if (!fields.some((field) => field.name === previousFieldName)) {
      fieldSelect.value = "";
    }
    fieldSelect.dataset.selectedFieldName = fieldSelect.value;
  };

  const refreshMeetings = () => {
    const selectedFieldName = fieldSelect.value || "";
    const previousMeetingName = meetingSelect.value || meetingSelect.dataset.selectedMeetingName || "";
    const fields = orderedFields();
    const field = fields.find((item) => item.name === selectedFieldName);
    const meetings = field?.meetings || [];

    meetingSelect.replaceChildren();
    const allOption = document.createElement("option");
    allOption.value = "";
    allOption.textContent = "All Meetings";
    meetingSelect.appendChild(allOption);

    meetings.forEach((meeting) => {
      const option = document.createElement("option");
      option.value = meeting.name || "";
      option.textContent = meeting.name || "";
      if (option.value === previousMeetingName) option.selected = true;
      meetingSelect.appendChild(option);
    });
    if (!meetings.some((meeting) => meeting.name === previousMeetingName)) {
      meetingSelect.value = "";
    }
    meetingSelect.dataset.selectedMeetingName = meetingSelect.value;
    renderAddressBookPdfContactPreview();
  };

  fieldSelect.addEventListener("change", () => {
    fieldSelect.dataset.selectedFieldName = fieldSelect.value;
    meetingSelect.dataset.selectedMeetingName = "";
    refreshMeetings();
    updateAddressBookPdfPreview();
  });
  meetingSelect.addEventListener("change", () => {
    meetingSelect.dataset.selectedMeetingName = meetingSelect.value;
    renderAddressBookPdfContactPreview();
    updateAddressBookPdfPreview();
  });
  document.addEventListener("address-book-pdf-print-order-changed", () => {
    renderFields();
    refreshMeetings();
    updateAddressBookPdfPreview();
  });
  renderFields();
  refreshMeetings();
}

function installAddressBookPdfDeleteLayoutModal(form) {
  const deleteButton = document.querySelector("[data-address-book-delete-layout]");
  if (!deleteButton) return;
  const deleteModal = window.AppModal?.create({
    dialog: document.getElementById("address-book-delete-layout-modal"),
    form: document.getElementById("address-book-delete-layout-modal-form"),
    titleEl: document.getElementById("address-book-delete-layout-modal-title"),
    copyEl: document.getElementById("address-book-delete-layout-modal-copy"),
    labelEl: document.getElementById("address-book-delete-layout-modal-label"),
    inputEl: document.getElementById("address-book-delete-layout-modal-input"),
    errorEl: document.getElementById("address-book-delete-layout-modal-error"),
    cancelEl: document.getElementById("address-book-delete-layout-modal-cancel"),
    saveEl: document.getElementById("address-book-delete-layout-modal-confirm"),
  });

  deleteButton.addEventListener("click", async (event) => {
    event.preventDefault();
    const confirmed = await deleteModal.prompt({
      title: "Delete Layout?",
      copy: "Meetings using this layout will be reassigned to another layout.",
      label: "Layout",
      requireInput: false,
      submitLabel: "Delete",
    });
    if (!confirmed) return;
    form.action = deleteButton.getAttribute("formaction") || form.action;
    form.method = deleteButton.getAttribute("formmethod") || "post";
    form.submit();
  });
}

window.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("[data-address-book-pdf-form]");
  const presetPicker = document.querySelector("[data-address-book-pdf-preset-picker]");
  if (!form) return;
  installAddressBookPdfTemporaryNotice();
  installAddressBookPdfPickers();
  enhanceAddressBookPdfNumberInputs(form);
  installAddressBookPdfMapProviderControls(form);
  installAddressBookPdfPrintOrderModal(form);
  installAddressBookPdfPrintFieldsModal(form);
  installAddressBookPdfCoverModal(form);
  installAddressBookPdfDeleteLayoutModal(form);
  updateAddressBookPdfPreview();

  form.addEventListener("input", updateAddressBookPdfPreview);
  form.addEventListener("change", updateAddressBookPdfPreview);

  presetPicker?.addEventListener("change", () => {
    if (!presetPicker.value) return;
    if (presetPicker.value === "__default__") {
      form.action = "/address-book/pdf/set-default";
      form.method = "post";
      form.submit();
      return;
    }
    window.location.href = `/address-book/pdf?preset_id=${encodeURIComponent(presetPicker.value)}`;
  });
});
