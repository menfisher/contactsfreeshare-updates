(function () {
  const PICKER_CONFIG_URL = "/google/picker/config";
  const COOKIE_PICKER_HELP = "If Google says it cannot access your account, close the Google window, allow third-party cookies for ContactsFreeShare, then choose the folder again.";

  let pickerApiPromise = null;

  const byId = (id) => document.getElementById(id);

  const setStatus = (statusElement, message) => {
    if (!statusElement) return;
    statusElement.textContent = message || "";
  };

  const loadPickerApi = () => {
    if (window.google?.picker) return Promise.resolve();
    if (pickerApiPromise) return pickerApiPromise;
    pickerApiPromise = new Promise((resolve, reject) => {
      const startedAt = Date.now();
      const waitForGapi = () => {
        if (window.google?.picker) {
          resolve();
          return;
        }
        if (!window.gapi?.load) {
          if (Date.now() - startedAt > 10000) {
            reject(new Error("Google Picker library could not be loaded."));
            return;
          }
          window.setTimeout(waitForGapi, 100);
          return;
        }
        window.gapi.load("picker", {
          callback: resolve,
          onerror: () => reject(new Error("Google Picker library could not be loaded.")),
          timeout: 10000,
          ontimeout: () => reject(new Error("Google Picker library timed out.")),
        });
      };
      waitForGapi();
    });
    return pickerApiPromise;
  };

  const fetchPickerConfig = async () => {
    const response = await fetch(PICKER_CONFIG_URL, {
      method: "GET",
      headers: { "Accept": "application/json" },
      cache: "no-store",
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || !payload.ok) {
      const reason = payload.reason || "unknown";
      if (reason === "not_connected") {
        throw new Error("Connect Google before choosing a Drive folder.");
      }
      if (reason === "drive_scope_missing") {
        throw new Error("Reconnect Google to grant Drive file access first.");
      }
      if (reason === "picker_not_configured") {
        throw new Error("Google Picker is not configured for this app package.");
      }
      throw new Error(payload.message || "Google Picker could not be opened.");
    }
    return payload;
  };

  const applyFolderSelection = (doc, idInput, nameInput, statusElement) => {
    const folderId = doc[google.picker.Document.ID] || doc.id || "";
    const folderName = doc[google.picker.Document.NAME] || doc.name || "";
    if (!folderId) {
      throw new Error("Google did not return a folder ID.");
    }
    idInput.value = folderId;
    idInput.dispatchEvent(new Event("input", { bubbles: true }));
    idInput.dispatchEvent(new Event("change", { bubbles: true }));
    if (nameInput && folderName) {
      nameInput.value = folderName;
      nameInput.dispatchEvent(new Event("input", { bubbles: true }));
      nameInput.dispatchEvent(new Event("change", { bubbles: true }));
    }
    setStatus(statusElement, folderName ? `Selected ${folderName}.` : "Folder selected.");
  };

  const openFolderPicker = async (button, idInput, nameInput, statusElement) => {
    const originalText = button.textContent;
    button.disabled = true;
    button.textContent = "Opening...";
    setStatus(statusElement, "");
    try {
      const config = await fetchPickerConfig();
      await loadPickerApi();
      const myDriveFoldersView = new google.picker.DocsView(google.picker.ViewId.DOCS)
        .setSelectFolderEnabled(true)
        .setIncludeFolders(true)
        .setMimeTypes("application/vnd.google-apps.folder")
        .setOwnedByMe(true)
        .setMode(google.picker.DocsViewMode.LIST);
      const sharedFoldersView = new google.picker.DocsView(google.picker.ViewId.DOCS)
        .setSelectFolderEnabled(true)
        .setIncludeFolders(true)
        .setMimeTypes("application/vnd.google-apps.folder")
        .setOwnedByMe(false)
        .setMode(google.picker.DocsViewMode.LIST)
        .setQuery("type:folder");
      const allFoldersView = new google.picker.DocsView(google.picker.ViewId.FOLDERS)
        .setSelectFolderEnabled(true)
        .setIncludeFolders(true)
        .setMode(google.picker.DocsViewMode.LIST);
      const picker = new google.picker.PickerBuilder()
        .addView(myDriveFoldersView)
        .addView(sharedFoldersView)
        .addView(allFoldersView)
        .setOAuthToken(config.access_token)
        .setDeveloperKey(config.api_key)
        .setAppId(config.app_id)
        .setOrigin(window.location.protocol + "//" + window.location.host)
        .setTitle("Choose shared PDF folder")
        .setCallback((data) => {
          if (data[google.picker.Response.ACTION] === google.picker.Action.CANCEL) {
            setStatus(statusElement, "");
            return;
          }
          if (data[google.picker.Response.ACTION] !== google.picker.Action.PICKED) {
            return;
          }
          const docs = data[google.picker.Response.DOCUMENTS] || [];
          if (!docs.length) {
            setStatus(statusElement, "No folder was selected.");
            return;
          }
          try {
            applyFolderSelection(docs[0], idInput, nameInput, statusElement);
          } catch (error) {
            setStatus(statusElement, error.message || "Folder selection failed.");
          }
        })
        .build();
      picker.setVisible(true);
      setStatus(statusElement, COOKIE_PICKER_HELP);
    } catch (error) {
      const message = error.message || "Google Picker could not be opened.";
      setStatus(statusElement, `${message} ${COOKIE_PICKER_HELP}`);
    } finally {
      button.disabled = false;
      button.textContent = originalText;
    }
  };

  window.addEventListener("DOMContentLoaded", () => {
    const button = byId("address-book-pdf-share-folder-picker");
    const idInput = byId("address-book-pdf-share-folder-id");
    const nameInput = byId("address-book-pdf-share-folder-name");
    const statusElement = byId("address-book-pdf-share-folder-picker-status");
    if (!button || !idInput) return;
    button.addEventListener("click", () => {
      openFolderPicker(button, idInput, nameInput, statusElement);
    });
  });
})();
