#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

if [ -f ".venv/pyvenv.cfg" ]; then
  VENV_HOME="$(awk -F= '/^home = / { gsub(/^ /, "", $2); print $2; exit }' ".venv/pyvenv.cfg")"
  if [ -n "$VENV_HOME" ] && [ ! -d "$VENV_HOME" ]; then
    rm -rf ".venv"
  fi
fi

if [ ! -x ".venv/bin/python" ]; then
  python3 -m venv .venv
fi

PYTHON=".venv/bin/python"
if ! "$PYTHON" -c "import fastapi, uvicorn, jinja2, multipart" >/dev/null 2>&1; then
  echo "Installing ContactsFreeShare Python dependencies..."
  if [ -d "vendor/wheels" ]; then
    "$PYTHON" -m pip install --no-index --find-links "vendor/wheels" -r requirements.txt
  else
    "$PYTHON" -m pip install -r requirements.txt
  fi
fi
"$PYTHON" run_contactsfreeshare.py
