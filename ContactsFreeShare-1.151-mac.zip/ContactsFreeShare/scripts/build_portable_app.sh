#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$ROOT_DIR/dist"
APP_DIR="$BUILD_DIR/ContactsFreeShare"

rm -rf "$APP_DIR"
mkdir -p "$APP_DIR"

rsync -a \
  --exclude '.git' \
  --exclude '.venv' \
  --exclude '/contactsfreeshare-site/' \
  --exclude '/dist/' \
  --exclude '/imports/' \
  --exclude '/logs/' \
  --exclude '/runtime/' \
  --exclude '/uploads/' \
  --exclude '/*.gs' \
  --exclude '/appsscript.json' \
  --exclude '/9.sidebar.html' \
  --exclude '/10.sidebar_addContact.html' \
  --exclude '/11.CreateAddressBooksDialog.html' \
  --exclude '/12.fieldList.html' \
  --exclude '__pycache__' \
  --exclude '*.pyc' \
  --exclude '.env' \
  --exclude 'UPDATE_MANIFEST_URL' \
  --exclude 'app.db' \
  --exclude 'db/app.sqlite3' \
  --exclude 'db/app.sqlite3-*' \
  --exclude 'db/contacts.db' \
  --exclude 'app/static/uploads' \
  "$ROOT_DIR/" "$APP_DIR/"

{
  echo "ContactsFreeShare portable build"
  echo "built_at=$(date '+%Y-%m-%d %H:%M:%S %Z')"
  echo "source_dir=$ROOT_DIR"
} > "$APP_DIR/BUILD_INFO.txt"

if [ -f "$ROOT_DIR/.env" ]; then
  awk -F= '
    BEGIN {
      keys["GOOGLE_OAUTH_CLIENT_ID"] = 1
      keys["GOOGLE_OAUTH_CLIENT_SECRET"] = 1
      keys["GOOGLE_OAUTH_REDIRECT_URI"] = 1
      keys["GOOGLE_PICKER_API_KEY"] = 1
      keys["GOOGLE_PICKER_APP_ID"] = 1
      keys["CONTACTSFREESHARE_UPDATE_MANIFEST_URL"] = 1
    }
    $1 in keys { print }
  ' "$ROOT_DIR/.env" > "$APP_DIR/.env"
fi

if [ -f "$ROOT_DIR/.env" ]; then
  for required_key in GOOGLE_PICKER_API_KEY GOOGLE_PICKER_APP_ID; do
    if grep -q "^${required_key}=" "$ROOT_DIR/.env" && ! grep -q "^${required_key}=" "$APP_DIR/.env"; then
      echo "Error: $required_key was not copied into the portable package .env."
      exit 1
    fi
  done
fi

cat > "$APP_DIR/Start ContactsFreeShare.command" <<'SCRIPT'
#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

if [ -f ".venv/pyvenv.cfg" ]; then
  VENV_HOME="$(awk -F= '/^home = / { gsub(/^ /, "", $2); print $2; exit }' ".venv/pyvenv.cfg")"
  if [ -n "$VENV_HOME" ] && [ ! -d "$VENV_HOME" ]; then
    rm -rf ".venv"
  fi
fi

if [ ! -x ".venv/bin/python" ]; then
  python3 -m venv .venv
fi

PYTHON=".venv/bin/python"
if ! "$PYTHON" -c "import fastapi, uvicorn, jinja2, multipart" >/dev/null 2>&1; then
  echo "Installing ContactsFreeShare Python dependencies..."
  if [ -d "vendor/wheels" ]; then
    "$PYTHON" -m pip install --no-index --find-links "vendor/wheels" -r requirements.txt
  else
    "$PYTHON" -m pip install -r requirements.txt
  fi
fi
"$PYTHON" run_contactsfreeshare.py
SCRIPT

chmod +x "$APP_DIR/Start ContactsFreeShare.command"

cat > "$APP_DIR/Install Desktop Shortcut Mac.command" <<'SCRIPT'
#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="$APP_DIR/Start ContactsFreeShare.command"
ICON_SRC="$APP_DIR/app/static/img/contactsfreeshare-icon.icns"
DESKTOP_DIR="$HOME/Desktop"
APP_BUNDLE="$DESKTOP_DIR/ContactsFS.app"

if [ ! -f "$TARGET" ]; then
  echo "Start ContactsFreeShare.command was not found in:"
  echo "$APP_DIR"
  echo
  echo "Keep this installer inside the ContactsFreeShare folder and run it again."
  read -r -p "Press Return to close."
  exit 1
fi

rm -rf "$APP_BUNDLE"
mkdir -p "$APP_BUNDLE/Contents/MacOS" "$APP_BUNDLE/Contents/Resources"

if [ -f "$ICON_SRC" ]; then
  cp "$ICON_SRC" "$APP_BUNDLE/Contents/Resources/ContactsFreeShare.icns"
fi

cat > "$APP_BUNDLE/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleDisplayName</key>
  <string>ContactsFS</string>
  <key>CFBundleExecutable</key>
  <string>ContactsFreeShare</string>
  <key>CFBundleIconFile</key>
  <string>ContactsFreeShare</string>
  <key>CFBundleIdentifier</key>
  <string>local.contactsfreeshare.launcher</string>
  <key>CFBundleName</key>
  <string>ContactsFS</string>
  <key>CFBundlePackageType</key>
  <string>APPL</string>
  <key>LSMinimumSystemVersion</key>
  <string>10.13</string>
</dict>
</plist>
PLIST

{
  echo '#!/usr/bin/env bash'
  printf 'TARGET=%q\n' "$TARGET"
  echo 'if [ ! -f "$TARGET" ]; then'
  echo '  osascript -e "display dialog \"ContactsFreeShare could not find its start file. Re-run Install Desktop Shortcut Mac.command from the ContactsFreeShare folder.\" buttons {\"OK\"} default button \"OK\" with icon caution" >/dev/null 2>&1 || true'
  echo '  exit 1'
  echo 'fi'
  echo 'open "$TARGET"'
} > "$APP_BUNDLE/Contents/MacOS/ContactsFreeShare"
chmod +x "$APP_BUNDLE/Contents/MacOS/ContactsFreeShare"
touch "$APP_BUNDLE"

echo
echo "ContactsFS desktop app installed."
echo "Double-click the ContactsFS icon on your Desktop to open the app."
echo "Keep the unzipped ContactsFreeShare folder in this location:"
echo "$APP_DIR"
echo
read -r -p "Press Return to close."
SCRIPT

chmod +x "$APP_DIR/Install Desktop Shortcut Mac.command"

cat > "$APP_DIR/Start ContactsFreeShare Windows.bat" <<'SCRIPT'
@echo off
setlocal

pushd "%~dp0"
if errorlevel 1 (
  echo.
  echo ContactsFreeShare could not open its app folder.
  echo Copy the ContactsFreeShare folder to a local Windows folder and run this file again.
  echo.
  pause
  exit /b 1
)

set "PYTHON_CMD="

where py >nul 2>nul
if not errorlevel 1 (
  set "PYTHON_CMD=py -3"
) else (
  where python >nul 2>nul
  if not errorlevel 1 (
    set "PYTHON_CMD=python"
  )
)

if not "%PYTHON_CMD%"=="" (
  %PYTHON_CMD% --version >nul 2>nul
  if errorlevel 1 (
    set "PYTHON_CMD="
  )
)

if "%PYTHON_CMD%"=="" (
  echo Python 3 was not found.
  if exist "vendor\python\windows\python-3.13.13-amd64.exe" (
    echo Installing Python 3.13 from the included offline installer...
    "vendor\python\windows\python-3.13.13-amd64.exe" /quiet InstallAllUsers=0 TargetDir="%LOCALAPPDATA%\Programs\Python\Python313" Include_launcher=1 Include_pip=1 Include_test=0 PrependPath=1
    if errorlevel 1 (
      echo.
      echo Python installation did not finish successfully.
      echo.
      pause
      exit /b 1
    )
    if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" (
      set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    )
  ) else (
    echo.
    echo The included Python installer was not found.
    echo Install Python 3 from https://www.python.org/downloads/windows/ and run this file again.
    echo.
    pause
    exit /b 1
  )
)

if "%PYTHON_CMD%"=="" (
  where py >nul 2>nul
  if not errorlevel 1 (
    set "PYTHON_CMD=py -3"
  ) else (
    where python >nul 2>nul
    if not errorlevel 1 (
      set "PYTHON_CMD=python"
    )
  )
)

if not "%PYTHON_CMD%"=="" (
  %PYTHON_CMD% --version >nul 2>nul
  if errorlevel 1 (
    set "PYTHON_CMD="
  )
)

if "%PYTHON_CMD%"=="" (
  echo.
  echo Python was installed, but it could not be found yet.
  echo Close this window and run Start ContactsFreeShare Windows.bat again.
  echo.
  pause
  exit /b 1
)

%PYTHON_CMD% --version
if errorlevel 1 (
  echo.
  echo Python could not be started.
  echo.
  pause
  exit /b 1
)

for /f "tokens=2 delims= " %%V in ('%PYTHON_CMD% --version 2^>^&1') do set "PYTHON_VERSION=%%V"
echo Using Python %PYTHON_VERSION%

echo %PYTHON_VERSION% | findstr /b "3.12 3.13" >nul
if errorlevel 1 (
  echo.
  echo ContactsFreeShare offline dependencies are bundled for Python 3.12 and 3.13.
  echo Install Python 3.12 or 3.13, or run this launcher while connected to the Internet.
  echo.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 (
    echo.
    echo Python is installed, but the virtual environment could not be created.
    echo Close this window and run Start ContactsFreeShare Windows.bat again.
    echo.
    pause
    exit /b 1
  )
)

".venv\Scripts\python.exe" -c "print('ok')" >nul 2>nul
if errorlevel 1 (
  rmdir /s /q ".venv"
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 (
    echo.
    echo Python is installed, but the virtual environment could not be created.
    echo Close this window and run Start ContactsFreeShare Windows.bat again.
    echo.
    pause
    exit /b 1
  )
)

".venv\Scripts\python.exe" -c "import fastapi, uvicorn, jinja2, multipart" >nul 2>nul
if errorlevel 1 (
  echo Installing ContactsFreeShare Python dependencies...
  if exist "vendor\wheels" (
    ".venv\Scripts\python.exe" -m pip install --no-index --find-links "vendor\wheels" -r requirements.txt
  ) else (
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  )
  if errorlevel 1 (
    echo.
    echo ContactsFreeShare dependencies could not be installed.
    echo Connect to the Internet and run this file again, or use a package that already includes a prepared .venv folder.
    echo.
    pause
    exit /b 1
  )
)
".venv\Scripts\python.exe" run_contactsfreeshare.py
pause
SCRIPT

cat > "$APP_DIR/Install Desktop Shortcut Windows.bat" <<'SCRIPT'
@echo off
setlocal

set "SOURCE_DIR=%~dp0"
pushd "%~dp0"
if errorlevel 1 (
  echo.
  echo ContactsFreeShare could not open its app folder.
  echo Copy the ContactsFreeShare folder to a local Windows folder and run this file again.
  echo.
  pause
  exit /b 1
)

set "APP_DIR=%SOURCE_DIR%"
set "TARGET=%APP_DIR%Start ContactsFreeShare Windows.bat"
set "ICON=%APP_DIR%app\static\img\contactsfreeshare-icon.ico"
set "LOCAL_ICON_DIR=%LOCALAPPDATA%\ContactsFreeShare"
set "LOCAL_ICON=%LOCAL_ICON_DIR%\contactsfreeshare-icon-transparent.ico"
set "SHORTCUT_NAME=ContactsFS.lnk"

if not exist "%TARGET%" (
  echo Start ContactsFreeShare Windows.bat was not found in:
  echo %APP_DIR%
  echo.
  echo Keep this installer inside the ContactsFreeShare folder and run it again.
  pause
  exit /b 1
)

if exist "%ICON%" (
  if not exist "%LOCAL_ICON_DIR%" mkdir "%LOCAL_ICON_DIR%" >nul 2>nul
  copy /Y "%ICON%" "%LOCAL_ICON%" >nul 2>nul
  if exist "%LOCAL_ICON%" set "ICON=%LOCAL_ICON%"
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$desktop=[Environment]::GetFolderPath('Desktop');" ^
  "$shortcutPath=Join-Path $desktop '%SHORTCUT_NAME%';" ^
  "if (Test-Path $shortcutPath) { Remove-Item $shortcutPath -Force };" ^
  "$shell=New-Object -ComObject WScript.Shell;" ^
  "$shortcut=$shell.CreateShortcut($shortcutPath);" ^
  "$shortcut.TargetPath=$env:TARGET;" ^
  "$shortcut.WorkingDirectory=$desktop;" ^
  "$shortcut.Description='Open ContactsFreeShare';" ^
  "if (Test-Path $env:ICON) { $shortcut.IconLocation=($env:ICON + ',0') };" ^
  "$shortcut.Save()"

if errorlevel 1 (
  echo.
  echo The desktop shortcut could not be created.
  echo You can still start the app by double-clicking Start ContactsFreeShare Windows.bat.
  echo.
  pause
  exit /b 1
)

echo.
echo ContactsFS desktop shortcut installed.
echo Double-click the ContactsFS icon on your Desktop to open the app.
echo.
pause
SCRIPT

APP_VERSION="$(tr -d '[:space:]' < "$ROOT_DIR/APP_VERSION")"
APP_VERSION="${APP_VERSION:-1.0}"
MAC_PACKAGE="ContactsFreeShare-${APP_VERSION}-mac.zip"
WINDOWS_PACKAGE="ContactsFreeShare-${APP_VERSION}-windows.zip"
PUBLIC_MANIFEST_URL="${CONTACTSFREESHARE_UPDATE_MANIFEST_URL:-}"
CLEAN_UPDATE_PACKAGES="${CONTACTSFREESHARE_CLEAN_UPDATE_PACKAGES:-1}"
BUILD_MAC_PACKAGE="${CONTACTSFREESHARE_BUILD_MAC_PACKAGE:-1}"
BUILD_WINDOWS_PACKAGE="${CONTACTSFREESHARE_BUILD_WINDOWS_PACKAGE:-1}"

if [ -n "$PUBLIC_MANIFEST_URL" ]; then
  printf '%s\n' "$PUBLIC_MANIFEST_URL" > "$APP_DIR/UPDATE_MANIFEST_URL"
fi

if [ "$CLEAN_UPDATE_PACKAGES" != "0" ]; then
  if [ "$BUILD_MAC_PACKAGE" != "0" ]; then
    find "$BUILD_DIR" -maxdepth 1 -type f -name 'ContactsFreeShare-*-mac.zip' -delete
  fi
  if [ "$BUILD_WINDOWS_PACKAGE" != "0" ]; then
    find "$BUILD_DIR" -maxdepth 1 -type f -name 'ContactsFreeShare-*-windows.zip' -delete
  fi
  rm -f "$BUILD_DIR/app_update_manifest.json"
fi
if [ "$BUILD_MAC_PACKAGE" != "0" ]; then
  rm -f "$BUILD_DIR/$MAC_PACKAGE"
  (cd "$BUILD_DIR" && zip -qr "$MAC_PACKAGE" "ContactsFreeShare")
fi
if [ "$BUILD_WINDOWS_PACKAGE" != "0" ]; then
  rm -f "$BUILD_DIR/$WINDOWS_PACKAGE"
  (cd "$BUILD_DIR" && zip -qr "$WINDOWS_PACKAGE" "ContactsFreeShare")
fi

{
cat <<SCRIPT
{
  "format": "contactsfreeshare.app_update.v1",
  "latest_version": "$APP_VERSION",
  "release_date": "$(date '+%Y-%m-%d')",
  "notes": "Describe what changed in this release.",
  "packages": {
SCRIPT
package_separator=""
if [ "$BUILD_MAC_PACKAGE" != "0" ]; then
  if [ -n "$package_separator" ]; then
    printf ',\n'
  fi
  cat <<SCRIPT
    "mac": {
      "label": "Mac",
      "filename": "$MAC_PACKAGE",
      "download_url": "$MAC_PACKAGE",
      "file_id": "",
      "mime_type": "application/zip"
    }
SCRIPT
  package_separator=","
fi
if [ "$BUILD_WINDOWS_PACKAGE" != "0" ]; then
  if [ -n "$package_separator" ]; then
    printf ',\n'
  fi
  cat <<SCRIPT
    "windows": {
      "label": "Windows",
      "filename": "$WINDOWS_PACKAGE",
      "download_url": "$WINDOWS_PACKAGE",
      "file_id": "",
      "mime_type": "application/zip"
    }
SCRIPT
fi
cat <<SCRIPT
  }
}
SCRIPT
} > "$BUILD_DIR/app_update_manifest.example.json"

echo "Portable app created at:"
echo "$APP_DIR"
echo "Update packages created at:"
if [ "$BUILD_MAC_PACKAGE" != "0" ]; then
  echo "$BUILD_DIR/$MAC_PACKAGE"
fi
if [ "$BUILD_WINDOWS_PACKAGE" != "0" ]; then
  echo "$BUILD_DIR/$WINDOWS_PACKAGE"
fi
echo "Manifest template created at:"
echo "$BUILD_DIR/app_update_manifest.example.json"
if [ -n "$PUBLIC_MANIFEST_URL" ]; then
  echo "Public update manifest URL embedded at:"
  echo "$APP_DIR/UPDATE_MANIFEST_URL"
fi
