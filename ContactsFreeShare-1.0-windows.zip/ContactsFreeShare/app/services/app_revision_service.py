from __future__ import annotations

from urllib.error import HTTPError, URLError

from app.database import fetch_all, get_connection
from app.services.google_sync_service import (
    export_app_revisions_to_google_drive,
    get_google_sync_summary,
    import_app_revisions_from_google_drive,
)


DEFAULT_APP_REVISIONS = [
    {
        "date_display": "4/20/2026",
        "version": "1.0",
        "description": "made changes to menu items under ContactsFreeShare",
    }
]


def ensure_app_revisions() -> None:
    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS app_revisions (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              sort_order INTEGER NOT NULL,
              date_display TEXT NOT NULL DEFAULT '',
              version_text TEXT NOT NULL DEFAULT '',
              description TEXT NOT NULL DEFAULT '',
              created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
              updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_app_revisions_sort_order
            ON app_revisions (sort_order, id)
            """
        )
        existing = conn.execute("SELECT COUNT(*) AS count FROM app_revisions").fetchone()
        if int(existing["count"]) == 0:
            for index, revision in enumerate(DEFAULT_APP_REVISIONS, start=1):
                conn.execute(
                    """
                    INSERT INTO app_revisions (
                      sort_order,
                      date_display,
                      version_text,
                      description
                    )
                    VALUES (?, ?, ?, ?)
                    """,
                    (
                        index,
                        str(revision["date_display"]),
                        str(revision["version"]),
                        str(revision["description"]),
                    ),
                )
        conn.commit()


def list_app_revisions(*, limit: int | None = None) -> list[dict]:
    ensure_app_revisions()
    rows = fetch_all(
        """
        SELECT id, sort_order, date_display, version_text, description
        FROM app_revisions
        ORDER BY sort_order DESC, id DESC
        """
    )
    revisions = [
        {
            "id": int(row["id"]),
            "date_display": str(row["date_display"] or ""),
            "version": str(row["version_text"] or ""),
            "description": str(row["description"] or ""),
        }
        for row in rows
    ]
    if limit is not None and limit >= 0:
        revisions = revisions[:limit]
    return revisions


def _replace_app_revisions(revisions: list[dict]) -> list[dict]:
    normalized_revisions: list[dict] = []
    for revision in revisions:
        date_display = str(revision.get("date_display") or "").strip()
        version = str(revision.get("version") or "").strip()
        description = str(revision.get("description") or "").strip()
        if not any((date_display, version, description)):
            continue
        normalized_revisions.append(
            {
                "date_display": date_display,
                "version": version,
                "description": description,
            }
        )

    normalized_revisions = normalized_revisions[:5]
    if not normalized_revisions:
        normalized_revisions = [dict(DEFAULT_APP_REVISIONS[0])]

    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS app_revisions (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              sort_order INTEGER NOT NULL,
              date_display TEXT NOT NULL DEFAULT '',
              version_text TEXT NOT NULL DEFAULT '',
              description TEXT NOT NULL DEFAULT '',
              created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
              updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute("DELETE FROM app_revisions")
        for index, revision in enumerate(reversed(normalized_revisions), start=1):
            conn.execute(
                """
                INSERT INTO app_revisions (
                  sort_order,
                  date_display,
                  version_text,
                  description
                )
                VALUES (?, ?, ?, ?)
                """,
                (
                    index,
                    revision["date_display"],
                    revision["version"],
                    revision["description"],
                ),
            )
        conn.commit()
    return list_app_revisions(limit=5)


def sync_app_revisions_from_google_drive() -> list[dict]:
    drive_revisions = import_app_revisions_from_google_drive()
    return _replace_app_revisions(drive_revisions)


def save_app_revisions(revisions: list[dict]) -> list[dict]:
    normalized_revisions: list[dict] = []
    for revision in revisions:
        date_display = str(revision.get("date_display") or "").strip()
        version = str(revision.get("version") or "").strip()
        description = str(revision.get("description") or "").strip()
        if not any((date_display, version, description)):
            continue
        normalized_revisions.append(
            {
                "date_display": date_display,
                "version": version,
                "description": description,
            }
        )

    if not normalized_revisions:
        return list_app_revisions(limit=5)

    existing_revisions_desc = list_app_revisions(limit=5)
    combined_revisions = normalized_revisions + existing_revisions_desc
    latest_revisions = _replace_app_revisions(combined_revisions)

    google_summary = get_google_sync_summary()
    account = google_summary.get("account") or {}
    if str(account.get("status") or "") == "connected" and bool(account.get("drive_scope_ready")):
        try:
            export_app_revisions_to_google_drive(latest_revisions)
        except (RuntimeError, HTTPError, URLError):
            pass
    return latest_revisions
