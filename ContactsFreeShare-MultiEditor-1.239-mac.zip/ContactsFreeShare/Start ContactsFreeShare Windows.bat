@echo off
setlocal

set "UPDATE_RELAUNCH=0"
if /I "%~1"=="--update-relaunch" set "UPDATE_RELAUNCH=1"

pushd "%~dp0"
if errorlevel 1 (
  echo.
  echo ContactsFreeShare could not open its app folder.
  echo Copy the ContactsFreeShare folder to a local Windows folder and run this file again.
  echo.
  pause
  exit /b 1
)

call :find_compatible_python

if "%PYTHON_CMD%"=="" (
  echo Python 3.12 or newer was not found on this computer.
  echo Checked common locations such as:
  echo   %LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe
  echo   %LOCALAPPDATA%\Programs\Python\Python313\python.exe
  echo   %ProgramFiles%\Python313\python.exe
  set "INSTALLER_DIR=runtime\python-installers"
  set "PYTHON_LATEST="
  for /f "usebackq delims=" %%V in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$releases = Invoke-RestMethod 'https://www.python.org/api/v2/downloads/release/?is_published=true&pre_release=false&limit=300'; $latest = $releases ^| Where-Object { $_.name -match '^Python [0-9]' -and $_.name -notmatch 'install manager' } ^| ForEach-Object { [pscustomobject]@{ Version = [version]($_.name -replace '^Python ','') } } ^| Sort-Object Version -Descending ^| Select-Object -First 1; if ($null -eq $latest) { exit 1 }; $latest.Version.ToString()"`) do set "PYTHON_LATEST=%%V"
  if "%PYTHON_LATEST%"=="" (
    echo.
    echo ContactsFreeShare needs Python 3.12 or newer.
    echo Could not determine the latest Python release from python.org.
    echo Install Python from https://www.python.org/downloads/windows/ and run this file again.
    echo.
    pause
    exit /b 1
  )
  set "INSTALLER=%INSTALLER_DIR%\python-%PYTHON_LATEST%-amd64.exe"
  set "INSTALLER_URL=https://www.python.org/ftp/python/%PYTHON_LATEST%/python-%PYTHON_LATEST%-amd64.exe"
  if not exist "%INSTALLER_DIR%" mkdir "%INSTALLER_DIR%"
  if not exist "%INSTALLER%" (
    echo Downloading Python %PYTHON_LATEST% installer from python.org...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -Uri '%INSTALLER_URL%' -OutFile '%INSTALLER%' -UseBasicParsing } catch { exit 1 }"
    if errorlevel 1 (
      echo.
      echo Could not download the Python installer.
      echo Install Python from https://www.python.org/downloads/windows/ and run this file again.
      echo.
      pause
      exit /b 1
    )
  )
  for /f "tokens=1,2 delims=." %%A in ("%PYTHON_LATEST%") do set "PYTHON_TAG=%%A%%B"
  set "PYTHON_HOME=%LOCALAPPDATA%\Programs\Python\Python%PYTHON_TAG%"
  if exist "%PYTHON_HOME%\python.exe" (
    set "PYTHON_CMD=%PYTHON_HOME%\python.exe"
  ) else (
    echo Installing Python %PYTHON_LATEST%...
    "%INSTALLER%" /quiet InstallAllUsers=0 TargetDir="%PYTHON_HOME%" Include_launcher=1 Include_pip=1 Include_test=0 PrependPath=1
    if errorlevel 1 (
      echo.
      echo Python installation did not finish successfully.
      echo.
      pause
      exit /b 1
    )
    if exist "%PYTHON_HOME%\python.exe" (
      set "PYTHON_CMD=%PYTHON_HOME%\python.exe"
    )
  )
  call :find_compatible_python
)

if "%PYTHON_CMD%"=="" (
  echo.
  echo Python was installed, but it could not be found yet.
  echo Close this window and run Start ContactsFreeShare Windows.bat again.
  echo.
  pause
  exit /b 1
)

if not exist "%PYTHON_CMD%" (
  echo.
  echo ContactsFreeShare found Python at:
  echo   %PYTHON_CMD%
  echo but that file does not exist.
  echo.
  pause
  exit /b 1
)

"%PYTHON_CMD%" --version
if errorlevel 1 (
  echo.
  echo Python could not be started.
  echo Attempted command:
  echo   "%PYTHON_CMD%" --version
  echo.
  pause
  exit /b 1
)

for /f "tokens=2 delims= " %%V in ('"%PYTHON_CMD%" --version 2^>^&1') do set "PYTHON_VERSION=%%V"
echo Using Python %PYTHON_VERSION%

powershell -NoProfile -ExecutionPolicy Bypass -Command "$v=[version]('%PYTHON_VERSION%'); if ($v.Major -lt 3 -or ($v.Major -eq 3 -and $v.Minor -lt 12)) { exit 1 } else { exit 0 }"
if errorlevel 1 (
  call :find_compatible_python
  if not "%PYTHON_CMD%"=="" (
    for /f "tokens=2 delims= " %%V in ('"%PYTHON_CMD%" --version 2^>^&1') do set "PYTHON_VERSION=%%V"
    echo Using Python %PYTHON_VERSION%
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$v=[version]('%PYTHON_VERSION%'); if ($v.Major -lt 3 -or ($v.Major -eq 3 -and $v.Minor -lt 12)) { exit 1 } else { exit 0 }"
  )
  if errorlevel 1 (
    echo.
    echo ContactsFreeShare needs Python 3.12 or newer.
    echo Install a supported Python version, or run this launcher while connected to the Internet.
    echo.
    pause
    exit /b 1
  )
)

if not exist ".venv\Scripts\python.exe" (
  "%PYTHON_CMD%" -m venv .venv
  if errorlevel 1 (
    echo.
    echo Python is installed, but the virtual environment could not be created.
    echo Close this window and run Start ContactsFreeShare Windows.bat again.
    echo.
    pause
    exit /b 1
  )
)

".venv\Scripts\python.exe" -c "print('ok')" >nul 2>nul
if errorlevel 1 (
  rmdir /s /q ".venv"
  "%PYTHON_CMD%" -m venv .venv
  if errorlevel 1 (
    echo.
    echo Python is installed, but the virtual environment could not be created.
    echo Close this window and run Start ContactsFreeShare Windows.bat again.
    echo.
    pause
    exit /b 1
  )
)

".venv\Scripts\python.exe" -c "import fastapi, uvicorn, jinja2, multipart" >nul 2>nul
if errorlevel 1 (
  echo Installing ContactsFreeShare Python dependencies...
  if exist "vendor\wheels" (
    ".venv\Scripts\python.exe" -m pip install --no-index --find-links "vendor\wheels" -r requirements-portable-bundle.txt
    if errorlevel 1 (
      ".venv\Scripts\python.exe" -m pip install -r requirements-portable-bundle.txt
    )
  ) else (
    ".venv\Scripts\python.exe" -m pip install -r requirements-portable-bundle.txt
  )
  if errorlevel 1 (
    echo.
    echo ContactsFreeShare dependencies could not be installed.
    echo Connect to the Internet and run this file again, or use a package that already includes a prepared .venv folder.
    echo.
    pause
    exit /b 1
  )
)
".venv\Scripts\python.exe" run_contactsfreeshare.py
if "%UPDATE_RELAUNCH%"=="0" pause
exit /b 0

:find_compatible_python
set "PYTHON_CMD="

for /f "delims=" %%D in ('dir /b /ad /o-n "%LOCALAPPDATA%\Python\pythoncore-3*" 2^>nul') do (
  if not defined PYTHON_CMD call :try_python_exe "%LOCALAPPDATA%\Python\%%D\python.exe"
)
if not defined PYTHON_CMD call :try_python_exe "%LOCALAPPDATA%\Python\bin\python.exe"

for /f "delims=" %%D in ('dir /b /ad /o-n "%LOCALAPPDATA%\Programs\Python\Python3*" 2^>nul') do (
  if not defined PYTHON_CMD call :try_python_exe "%LOCALAPPDATA%\Programs\Python\%%D\python.exe"
)

for /f "delims=" %%D in ('dir /b /ad /o-n "%ProgramFiles%\Python3*" 2^>nul') do (
  if not defined PYTHON_CMD call :try_python_exe "%ProgramFiles%\%%D\python.exe"
)

for /f "delims=" %%D in ('dir /b /ad /o-n "%ProgramFiles(x86)%\Python3*" 2^>nul') do (
  if not defined PYTHON_CMD call :try_python_exe "%ProgramFiles(x86)%\%%D\python.exe"
)

where py >nul 2>nul
if not errorlevel 1 if not defined PYTHON_CMD (
  for %%T in (315 314 313 312) do (
    if not defined PYTHON_CMD (
      py -3.%%T -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
      if not errorlevel 1 (
        for /f "delims=" %%E in ('py -3.%%T -c "import sys; print(sys.executable)" 2^>nul') do (
          if not defined PYTHON_CMD call :try_python_exe "%%E"
        )
      )
    )
  )
)

if not defined PYTHON_CMD if exist "%~dp0runtime\find_python_windows.ps1" (
  for /f "usebackq delims=" %%P in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0runtime\find_python_windows.ps1" 2^>nul`) do (
    if not defined PYTHON_CMD call :try_python_exe "%%P"
  )
)

exit /b 0

:try_python_exe
if "%~1"=="" exit /b 0
if not exist "%~1" exit /b 0
echo %~1 | findstr /I /C:"\WindowsApps\" >nul 2>&1
if not errorlevel 1 exit /b 0
"%~1" -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if errorlevel 1 exit /b 0
set "PYTHON_CMD=%~1"
exit /b 0
