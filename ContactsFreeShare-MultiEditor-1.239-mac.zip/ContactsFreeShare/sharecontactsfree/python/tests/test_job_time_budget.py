"""A poll-driven import pass must stay inside the caller's slice.

Cloud Run kills any request that runs past 300s, and import work runs inside
poll/kick requests. A pass that ignores the caller's budget shows up in the UI
as a frozen counter.
"""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from app import db
from app.config import RECIPIENT_IMPORT_TIME_BUDGET_MS
from app.services import push_worker
from app.services.recipient_import import resolve_import_time_budget_ms

OWNER = "owner@example.com"
RECIPIENT = "friend@example.com"
RESOURCE = "contactGroups/g1"


class ImportTimeBudgetTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory()
        self._prev = db._active_database_path
        db._active_database_path = Path(self._tmpdir.name) / "test.db"
        db.init_db()

    def tearDown(self) -> None:
        db._active_database_path = self._prev
        self._tmpdir.cleanup()

    def test_pass_budget_never_exceeds_default(self) -> None:
        self.assertEqual(resolve_import_time_budget_ms(5_000), 5_000)
        self.assertEqual(resolve_import_time_budget_ms(0), 1_000)
        self.assertGreaterEqual(RECIPIENT_IMPORT_TIME_BUDGET_MS, 180_000)
        self.assertEqual(
            resolve_import_time_budget_ms(10_000_000), RECIPIENT_IMPORT_TIME_BUDGET_MS
        )
        self.assertEqual(resolve_import_time_budget_ms(None), RECIPIENT_IMPORT_TIME_BUDGET_MS)

    def test_hard_timeout_stays_under_cloud_run_request_limit(self) -> None:
        self.assertLess(push_worker.MAX_JOB_HARD_SECONDS, 300)

    def test_watchdog_does_not_shorten_poll_slices(self) -> None:
        self.assertEqual(
            push_worker._watchdog_join_seconds(25),
            float(push_worker.MAX_JOB_HARD_SECONDS),
        )
        self.assertEqual(
            push_worker._watchdog_join_seconds(None),
            float(push_worker.MAX_JOB_HARD_SECONDS),
        )

    def test_priority_email_is_claimed_before_older_jobs(self) -> None:
        charlie = db.enqueue_push_job(
            owner=OWNER,
            resource_name=RESOURCE,
            recipient_email="charliekerr.inbox@gmail.com",
            job_type="full_group",
            payload={},
        )
        emmy = db.enqueue_push_job(
            owner=OWNER,
            resource_name=RESOURCE,
            recipient_email="emmynelson1970@gmail.com",
            job_type="full_group",
            payload={},
        )
        with patch.dict(
            "os.environ",
            {"SHARE_JOB_PRIORITY_EMAIL": "emmynelson1970@gmail.com"},
        ):
            claimed = db.claim_push_jobs(1)
        self.assertEqual(len(claimed), 1)
        self.assertEqual(int(claimed[0]["id"]), emmy)
        self.assertNotEqual(int(claimed[0]["id"]), charlie)

    def test_newest_import_is_claimed_before_older_leftover(self) -> None:
        leftover = db.enqueue_push_job(
            owner=OWNER,
            resource_name=RESOURCE,
            recipient_email="emmynelson1970@gmail.com",
            job_type="full_group",
            payload={"resume": True},
        )
        newest = db.enqueue_push_job(
            owner=OWNER,
            resource_name=RESOURCE,
            recipient_email="joanna.bishop901@gmail.com",
            job_type="full_group",
            payload={},
        )
        claimed = db.claim_push_jobs(1)
        self.assertEqual(len(claimed), 1)
        self.assertEqual(int(claimed[0]["id"]), newest)
        self.assertNotEqual(int(claimed[0]["id"]), leftover)

    def test_shared_stale_photo_counter_is_not_resumed(self) -> None:
        db.save_app_data(
            RECIPIENT,
            {
                "sharedGroups": [
                    {
                        "owner": OWNER,
                        "resourceName": RESOURCE,
                        "recipientEmail": RECIPIENT,
                        "shareId": "share-stale-photos",
                        "status": "Shared",
                        "importPhase": "done",
                        "memberCount": 727,
                        "actualCount": 727,
                        "photoDoneCount": 111,
                        "photoTargetCount": 725,
                    }
                ]
            },
        )
        self.assertEqual(
            push_worker.resume_stalled_imports_for_recipient(RECIPIENT), 0
        )

    def test_progressing_job_is_not_stalled(self) -> None:
        job_id = db.enqueue_push_job(
            owner=OWNER,
            resource_name=RESOURCE,
            recipient_email=RECIPIENT,
            job_type="full_group",
            payload={},
        )
        db.update_push_job(job_id, touch=True)
        self.assertFalse(push_worker._job_is_stalled(job_id))

    def test_idle_photo_scan_is_not_resumed(self) -> None:
        db.save_app_data(
            RECIPIENT,
            {
                "sharedGroups": [
                    {
                        "owner": OWNER,
                        "resourceName": RESOURCE,
                        "recipientEmail": RECIPIENT,
                        "status": "Photos (0/0)",
                        "importPhase": "photos",
                        "photoDoneCount": 0,
                        "photoTargetCount": 0,
                        "photoNeedsRecipientScan": True,
                    }
                ]
            },
        )
        self.assertFalse(push_worker._group_needs_import_job(
            (db.get_app_data(RECIPIENT) or {})["sharedGroups"][0],
            RECIPIENT,
        ))
        self.assertEqual(
            push_worker.resume_stalled_imports_for_recipient(RECIPIENT), 0
        )

    def test_yielding_a_time_slice_does_not_burn_retry_attempts(self) -> None:
        job_id = db.enqueue_push_job(
            owner=OWNER,
            resource_name=RESOURCE,
            recipient_email=RECIPIENT,
            job_type="full_group",
            payload={},
        )
        for _ in range(30):
            db.claim_push_jobs(1)
            db.update_push_job(
                job_id, requeue=True, last_error="yielding", reset_attempts=True
            )
        row = db.list_push_jobs(OWNER, RESOURCE, limit=5)[0]
        self.assertEqual(row["status"], "queued")
        self.assertLessEqual(int(row["attempts"]), 1)

        db.reclaim_stale_push_jobs()
        row = db.list_push_jobs(OWNER, RESOURCE, limit=5)[0]
        self.assertNotEqual(row["status"], "error")

    def test_poll_resumes_an_import_whose_job_was_parked(self) -> None:
        db.save_app_data(
            RECIPIENT,
            {
                "sharedGroups": [
                    {
                        "owner": OWNER,
                        "resourceName": RESOURCE,
                        "recipientEmail": RECIPIENT,
                        "status": "Photos (0/726)",
                        "importPhase": "photos",
                        "memberCount": 726,
                    }
                ]
            },
        )
        self.assertEqual(
            push_worker.resume_stalled_imports_for_recipient(RECIPIENT), 1
        )
        self.assertTrue(db.has_active_push_job(OWNER, RESOURCE, RECIPIENT))
        # Already queued: do not pile on duplicates.
        self.assertEqual(
            push_worker.resume_stalled_imports_for_recipient(RECIPIENT), 0
        )

    def test_poll_repairs_a_finished_group_holding_extra_contacts(self) -> None:
        # 1169 contacts in Google against 726 records means duplicates.
        db.save_app_data(
            RECIPIENT,
            {
                "sharedGroups": [
                    {
                        "owner": OWNER,
                        "resourceName": RESOURCE,
                        "shareId": "share-dupe-repair",
                        "status": "Shared",
                        "importPhase": "done",
                        "actualCount": 1169,
                    }
                ]
            },
        )
        self.assertEqual(
            push_worker.resume_stalled_imports_for_recipient(RECIPIENT), 1
        )
        jobs = db.list_push_jobs(OWNER, RESOURCE, limit=20)
        for row in jobs:
            if row.get("status") in ("queued", "running"):
                db.update_push_job(int(row["id"]), status="done")
        db.save_recipient_token(RECIPIENT, {"token": "x", "refresh_token": "y"})
        # Scheduler kick (not just the recipient page) must queue the same repair.
        push_worker._resume_orphaned_imports()
        self.assertTrue(
            db.has_active_push_job(OWNER, RESOURCE, RECIPIENT)
        )
        self.assertFalse(
            push_worker._group_is_complete(RECIPIENT, OWNER, RESOURCE)
        )
        self.assertTrue(
            push_worker._group_is_pending(RECIPIENT, OWNER, RESOURCE)
        )

    def test_repair_runs_once_per_observed_count(self) -> None:
        db.save_app_data(
            RECIPIENT,
            {
                "sharedGroups": [
                    {
                        "owner": OWNER,
                        "resourceName": RESOURCE,
                        "shareId": "share-dupe-repair",
                        "status": "Shared",
                        "importPhase": "done",
                        "actualCount": 1169,
                        "repairCheckedActual": 1169,
                    }
                ]
            },
        )
        self.assertEqual(
            push_worker.resume_stalled_imports_for_recipient(RECIPIENT), 0
        )

    def test_shared_group_with_retry_indexes_is_not_treated_as_complete(self) -> None:
        db.save_app_data(
            RECIPIENT,
            {
                "sharedGroups": [
                    {
                        "owner": OWNER,
                        "resourceName": RESOURCE,
                        "shareId": "share-dupe-repair",
                        "status": "Shared",
                        "importPhase": "done",
                        "actualCount": 1169,
                        "repairCheckedActual": 1169,
                        "retryIndexes": [1, 2, 3],
                    }
                ]
            },
        )
        self.assertFalse(
            push_worker._group_is_complete(RECIPIENT, OWNER, RESOURCE)
        )
        self.assertEqual(
            push_worker.resume_stalled_imports_for_recipient(RECIPIENT), 1
        )

    def test_shared_group_with_too_few_contacts_is_resumed(self) -> None:
        db.save_app_data(
            RECIPIENT,
            {
                "sharedGroups": [
                    {
                        "owner": OWNER,
                        "resourceName": RESOURCE,
                        "shareId": "share-short",
                        "status": "Shared",
                        "importPhase": "done",
                        "memberCount": 726,
                        "actualCount": 200,
                    }
                ]
            },
        )
        self.assertFalse(
            push_worker._group_is_complete(RECIPIENT, OWNER, RESOURCE)
        )
        self.assertEqual(
            push_worker.resume_stalled_imports_for_recipient(RECIPIENT), 1
        )

    def test_poll_does_not_resume_a_finished_group(self) -> None:
        db.save_app_data(
            RECIPIENT,
            {
                "sharedGroups": [
                    {
                        "owner": OWNER,
                        "resourceName": RESOURCE,
                        "recipientEmail": RECIPIENT,
                        "shareId": "share-finished",
                        "status": "Shared",
                        "importPhase": "done",
                        "memberCount": 726,
                        "actualCount": 726,
                    }
                ]
            },
        )
        self.assertEqual(
            push_worker.resume_stalled_imports_for_recipient(RECIPIENT), 0
        )

    def test_poll_slice_is_passed_into_the_import_pass(self) -> None:
        job_id = db.enqueue_push_job(
            owner=OWNER,
            resource_name=RESOURCE,
            recipient_email=RECIPIENT,
            job_type="full_group",
            payload={},
        )
        seen: dict[str, int] = {}

        def _fake_import(recipient, owner, resource, max_ops=200, time_budget_ms=None):
            seen["budget_ms"] = int(time_budget_ms or 0)
            return {"busy": False}

        with (
            patch.object(push_worker, "start_push_worker"),
            patch.object(push_worker, "recipient_credentials", return_value=object()),
            patch.object(push_worker, "_mark_recipient_push_running"),
            patch.object(
                push_worker, "maybe_refresh_staged_shared_contacts_before_import"
            ),
            patch.object(push_worker, "_refresh_staged_then_backfill_photos"),
            patch.object(push_worker, "_group_is_complete", return_value=False),
            patch.object(push_worker, "_group_is_pending", return_value=False),
            patch.object(push_worker, "_sync_recipient_push_status_from_group"),
            patch.object(
                push_worker, "process_shared_import_for_group", _fake_import
            ),
        ):
            push_worker.pump_push_queue(max_seconds=5)

        self.assertLessEqual(seen.get("budget_ms", 0), 5_000)
        self.assertGreater(seen.get("budget_ms", 0), 0)
        row = db.list_push_jobs(OWNER, RESOURCE, limit=5)[0]
        self.assertEqual(int(row["id"]), job_id)


if __name__ == "__main__":
    unittest.main()
