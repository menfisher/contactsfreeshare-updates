#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

resolve_latest_stable_python_version() {
  local version=""
  version="$(
    curl -fsSL 'https://www.python.org/api/v2/downloads/release/?is_published=true&pre_release=false&limit=300' \
      | tr '{' '\n' \
      | grep '"name":"Python [0-9]' \
      | grep -v 'Python install manager' \
      | sed -n 's/.*"name":"Python \([0-9][0-9.]*\)".*/\1/p' \
      | awk -F. 'NF == 3 && $1 == 3 { print }' \
      | sort -t. -k1,1n -k2,2n -k3,3n \
      | tail -1
  )"
  if [ -z "$version" ]; then
    return 1
  fi
  printf '%s\n' "$version"
}

find_compatible_python() {
  local candidates=() path ver best_cmd="" best_ver=""
  while IFS= read -r path; do
    [ -n "$path" ] && candidates+=("$path")
  done < <(
    {
      command -v python3 2>/dev/null || true
      which -a python3 2>/dev/null || true
      for path in \
        "/opt/homebrew/bin/python3" \
        "/usr/local/bin/python3"
      do
        [ -x "$path" ] && printf '%s\n' "$path"
      done
      for path in /Library/Frameworks/Python.framework/Versions/3.*/bin/python3; do
        [ -x "$path" ] && printf '%s\n' "$path"
      done
      for path in /opt/homebrew/opt/python@3.*/bin/python3 /usr/local/opt/python@3.*/bin/python3; do
        [ -x "$path" ] && printf '%s\n' "$path"
      done
    } | awk 'NF && !seen[$0]++'
  )

  for path in "${candidates[@]}"; do
    ver="$("$path" - <<'PY' 2>/dev/null || true
import sys
print(".".join(map(str, sys.version_info[:3])))
PY
)"
    [ -z "$ver" ] && continue
    case "$ver" in
      3.[0-9]*)
        minor="${ver#3.}"
        minor="${minor%%.*}"
        if [ "$minor" -ge 12 ] 2>/dev/null; then
          if [ -z "$best_ver" ] || [ "$(printf '%s\n' "$best_ver" "$ver" | sort -t. -k1,1n -k2,2n -k3,3n | tail -1)" = "$ver" ]; then
            best_cmd="$path"
            best_ver="$ver"
          fi
        fi
        ;;
    esac
  done

  if [ -n "$best_cmd" ]; then
    printf '%s\n' "$best_cmd"
    return 0
  fi
  return 1
}

prompt_python_install() {
  PYTHON_CMD="$(find_compatible_python || true)"
  if [ -n "$PYTHON_CMD" ]; then
    PYTHON_VERSION_FOUND="$("$PYTHON_CMD" - <<'PY' 2>/dev/null || true
import sys
print(".".join(map(str, sys.version_info[:3])))
PY
)"
    echo
    echo "Found compatible Python ${PYTHON_VERSION_FOUND} at:"
    echo "  ${PYTHON_CMD}"
    echo "Skipping Python download/install."
    return 0
  fi

  PYTHON_INSTALLER_DIR="$APP_DIR/runtime/python-installers"
  PYTHON_VERSION="$(resolve_latest_stable_python_version || true)"
  if [ -z "$PYTHON_VERSION" ]; then
    echo
    echo "ContactsFreeShare needs Python 3.12 or newer."
    echo "Could not determine the latest Python release from python.org."
    echo "Install Python from https://www.python.org/downloads/macos/ and run this file again."
    echo
    read -r -p "Press Return to close."
    exit 1
  fi
  PYTHON_INSTALLER="$PYTHON_INSTALLER_DIR/python-${PYTHON_VERSION}-macos11.pkg"
  PYTHON_INSTALLER_URL="https://www.python.org/ftp/python/${PYTHON_VERSION}/python-${PYTHON_VERSION}-macos11.pkg"

  echo
  echo "ContactsFreeShare needs Python 3.12 or newer."
  mkdir -p "$PYTHON_INSTALLER_DIR"
  if [ ! -f "$PYTHON_INSTALLER" ]; then
    echo "Downloading Python ${PYTHON_VERSION} installer from python.org..."
    if ! curl -fL "$PYTHON_INSTALLER_URL" -o "$PYTHON_INSTALLER"; then
      echo
      echo "Could not download the Python installer."
      echo "Install Python from https://www.python.org/downloads/macos/ and run this file again."
      echo
      read -r -p "Press Return to close."
      exit 1
    fi
  fi
  echo "Opening the Python ${PYTHON_VERSION} installer now."
  echo "After the installer finishes, run Start ContactsFreeShare.command again."
  open "$PYTHON_INSTALLER"
  echo
  read -r -p "Press Return to close."
  exit 1
}

if [ -f ".venv/pyvenv.cfg" ]; then
  VENV_HOME="$(awk -F= '/^home = / { gsub(/^ /, "", $2); print $2; exit }' ".venv/pyvenv.cfg")"
  if [ -n "$VENV_HOME" ] && [ ! -d "$VENV_HOME" ]; then
    rm -rf ".venv"
  fi
fi

if [ ! -x ".venv/bin/python" ]; then
  PYTHON_CMD="$(find_compatible_python || true)"
  if [ -z "$PYTHON_CMD" ]; then
    prompt_python_install
    if [ -z "$PYTHON_CMD" ]; then
      exit 1
    fi
  fi
  "$PYTHON_CMD" -m venv .venv
fi

PYTHON=".venv/bin/python"
if ! "$PYTHON" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if sys.version_info >= (3, 12) else 1)
PY
then
  rm -rf ".venv"
  PYTHON_CMD="$(find_compatible_python || true)"
  if [ -z "$PYTHON_CMD" ]; then
    prompt_python_install
    if [ -z "$PYTHON_CMD" ]; then
      exit 1
    fi
  fi
  "$PYTHON_CMD" -m venv .venv
fi
if ! "$PYTHON" -c "import fastapi, uvicorn, jinja2, multipart" >/dev/null 2>&1; then
  echo "Installing ContactsFreeShare Python dependencies..."
  if [ -d "vendor/wheels" ]; then
    if ! "$PYTHON" -m pip install --no-index --find-links "vendor/wheels" -r requirements-portable-bundle.txt; then
      echo "Some bundled wheels did not match this Python version. Trying online install..."
      "$PYTHON" -m pip install -r requirements-portable-bundle.txt
    fi
  else
    "$PYTHON" -m pip install -r requirements-portable-bundle.txt
  fi
  if ! "$PYTHON" -c "import fastapi, uvicorn, jinja2, multipart" >/dev/null 2>&1; then
    echo
    echo "ContactsFreeShare dependencies could not be installed."
    echo "Connect to the Internet and run this file again."
    echo
    read -r -p "Press Return to close."
    exit 1
  fi
fi
"$PYTHON" run_contactsfreeshare.py
