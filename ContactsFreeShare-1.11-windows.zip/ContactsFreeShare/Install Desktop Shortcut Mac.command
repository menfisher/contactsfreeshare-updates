#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="$APP_DIR/Start ContactsFreeShare.command"
ICON_SRC="$APP_DIR/app/static/img/contactsfreeshare-icon.icns"
DESKTOP_DIR="$HOME/Desktop"
APP_BUNDLE="$DESKTOP_DIR/ContactsFreeShare.app"

if [ ! -f "$TARGET" ]; then
  echo "Start ContactsFreeShare.command was not found in:"
  echo "$APP_DIR"
  echo
  echo "Keep this installer inside the ContactsFreeShare folder and run it again."
  read -r -p "Press Return to close."
  exit 1
fi

rm -rf "$APP_BUNDLE"
mkdir -p "$APP_BUNDLE/Contents/MacOS" "$APP_BUNDLE/Contents/Resources"

if [ -f "$ICON_SRC" ]; then
  cp "$ICON_SRC" "$APP_BUNDLE/Contents/Resources/ContactsFreeShare.icns"
fi

cat > "$APP_BUNDLE/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleDisplayName</key>
  <string>ContactsFreeShare</string>
  <key>CFBundleExecutable</key>
  <string>ContactsFreeShare</string>
  <key>CFBundleIconFile</key>
  <string>ContactsFreeShare</string>
  <key>CFBundleIdentifier</key>
  <string>local.contactsfreeshare.launcher</string>
  <key>CFBundleName</key>
  <string>ContactsFreeShare</string>
  <key>CFBundlePackageType</key>
  <string>APPL</string>
  <key>LSMinimumSystemVersion</key>
  <string>10.13</string>
</dict>
</plist>
PLIST

{
  echo '#!/usr/bin/env bash'
  printf 'exec %q\n' "$TARGET"
} > "$APP_BUNDLE/Contents/MacOS/ContactsFreeShare"
chmod +x "$APP_BUNDLE/Contents/MacOS/ContactsFreeShare"
touch "$APP_BUNDLE"

echo
echo "ContactsFreeShare desktop app installed."
echo "Double-click the ContactsFreeShare icon on your Desktop to open the app."
echo "Keep the unzipped ContactsFreeShare folder in this location:"
echo "$APP_DIR"
echo
read -r -p "Press Return to close."
