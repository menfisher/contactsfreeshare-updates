const APP_NAME = "Address Book";

class Spreadsheet {
  constructor() {
    this.ss = SpreadsheetApp.getActive();
    this.name = APP_NAME;
    this.timezone = Session.getScriptTimeZone();
    this.sheetName = {
      contacts: "Contacts",
      deletedContacts: "Deleted",
      settings: "Settings",
    };
  }

  onOpen() {
    const ui = this.getUi();
    const menu = ui.createMenu(this.name);
    /**Change updatesInProgress = true to make updates to script */
    const updatesInProgress = false;

    if (updatesInProgress) {
      menu.addItem("❌ - UPDATES IN PROGRESS - ❌", "showUpdatesNotice");
      menu.addToUi();
    } else {
      menu.addItem("➡️ Import contacts", "getContacts");
      menu.addItem("✅ Create contacts", "createContacts");
      menu.addItem("⚠️ Update contacts", "updateContacts");
      menu.addItem("❌ Delete contacts", "deleteContacts");
      menu.addItem("🔃 Sort contacts using order on Settings tab", "sortContactSheet");
      menu.addSeparator();
      menu.addItem('👤 Contact Administration', 'showAddContactSidebar');
      menu.addSeparator();
      menu.addItem("📖 Create Address Book", "menuCreateAddressBooks_");
      menu.addItem("📄 Create Field List", "actionOpenCreateFieldList");
      menu.addSeparator();

      menu.addSubMenu(
        ui.createMenu('Sheet Settings Menu')
          .addItem('Create new Deleted tab', 'archiveAndRecreateDeletedTab')
          .addItem('Create new Changes tab', 'archiveAndRecreateChangesTab')
          .addItem('Update Fields/Meetings on Settings tab', 'updateSortItemsInSettings')
          .addItem('Refresh Sheet Colors - Set on Settings tab', 'refreshFormatting')
      );

      menu.addItem("Change Header color - Editing in progress", "sheetHeadercolor");
      menu.addSeparator();
      menu.addItem("Revisions", "actionShowRevisions");
      menu.addToUi();
    }
    _showUpdates_(REVISIONS, "We have new updates:", APP_NAME);
  }

  showUpdatesNotice() {
    SpreadsheetApp.getUi().alert("Updates in progress. Check back later.");
  }

  getUi() {
    return SpreadsheetApp.getUi();
  }

  alert(message, title = this.name) {
    const ui = this.getUi();
    return ui.alert(title, message, ui.ButtonSet.OK);
  }

  confirm(message, title = this.name) {
    const ui = this.getUi();
    return ui.alert(title, message, ui.ButtonSet.YES_NO);
  }

  toast(message, title = this.name, timeout = 15) {
    return this.ss.toast(message, title, timeout);
  }

  createRowValues(keys, item) {
    return keys.map((key) => item[key]);
  }

  /**
   * @param {SpreadsheetApp.Sheet} sheet
   */
  applyColors(sheet = this.ss.getActiveSheet()) {
    const settings = this.getSettings();
    const dataRange = sheet.getDataRange();
    const backgrounds = dataRange.getBackgrounds();
    const fontColors = dataRange.getFontColorObjects();
    const values = dataRange.getValues();
    const columns = values[0].length;
    let organizationTitle = null;
    let organizationName = null;
    let titleBackground = null;
    let titleFontColor = null;
    let nameBackground = null;
    let nameFontColor = null;
    let titlePrimaryFlag = false;
    let namePrimaryFlag = false;
    values.forEach((v, i) => {
      if (i === 0) {
        backgrounds[i] = Array(columns).fill(settings.header.background);
        fontColors[i] = Array(columns).fill(settings.header.fontColor);
      } else {
        const title = v[5];
        const name = v[6];
        if (title != organizationTitle) {
          organizationTitle = title;
          titlePrimaryFlag = !titlePrimaryFlag;
          titleBackground = titlePrimaryFlag
            ? settings.titlePrimary.background
            : settings.titleSecondary.background;
          titleFontColor = titlePrimaryFlag
            ? settings.titlePrimary.fontColor
            : settings.titleSecondary.fontColor;
        }
        if (`${title}${name}` != `${organizationTitle}${organizationName}`) {
          organizationName = name;
          namePrimaryFlag = !namePrimaryFlag;
          nameBackground = namePrimaryFlag
            ? settings.namePrimary.background
            : settings.nameSecondary.background;
          nameFontColor = namePrimaryFlag
            ? settings.namePrimary.fontColor
            : settings.nameSecondary.fontColor;
        }
        backgrounds[i] = [
          titleBackground,
          ...Array(4).fill("#ffffff"),
          titleBackground,
          ...Array(columns - 6).fill(nameBackground),
        ];
        fontColors[i] = [
          titleFontColor,
          ...Array(4).fill("#000000"),
          titleFontColor,
          ...Array(columns - 6).fill(nameFontColor),
        ];
      }
    });
    dataRange.setBackgrounds(backgrounds);
    dataRange.setFontColors(fontColors);
    return sheet;
  }

  /** sets Header row color for work alert and freezes row 1
   */
  applyColors2(rowColor, fontColor) {
    const sheets = ["Contacts", "Deleted"];
    sheets.forEach((name) => {
      const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
      if (!sheet) return; // ignored if sheet was not found
      const headerRange = sheet.getRange(1, 1, 1, sheet.getLastColumn());
      headerRange
        .setFontWeight("bold")
        .setFontColor(fontColor)
        .setBackground(rowColor)
        .setBorder(
          true,
          true,
          true,
          true,
          null,
          null,
          "black",
          SpreadsheetApp.BorderStyle.SOLID_MEDIUM,
        );
      sheet.setFrozenRows(1);
      if (name === "Contacts") {
        sheet.setFrozenColumns(1);
      } else {
        sheet.setFrozenColumns(0);
      }
    });
  }

  sheetHeadercolor() {
    const name = "⚙️ Work Alert in Contacts";
    const confirm = this.confirm(
      `Are you ready to work in Contacts?
      
      YES: Turn Header row color 🟥 to let others know you are working

      NO: Turn Header row color 🟩 to let others know you are finished
      
      X: Cancel
      `,
      name,
    );

    if (confirm === SpreadsheetApp.getUi().Button.NO) {
      let rowColor = "#2fff3e"; /** set row color green */
      let fontColor = "#000000"; /** set font color black */
      this.applyColors2(rowColor, fontColor);
      return this.toast("Goodbye!", name);
    }

    if (confirm !== SpreadsheetApp.getUi().Button.YES) {
      return this.toast("Cancel", name);
    }

    let rowColor = "#830303"; /** set row color red */
    let fontColor = "#fff000"; /** set font color to yellow */
    this.applyColors2(rowColor, fontColor);
    return this.toast("Welcome to work!", name);
  }

  sortSheet(sheet = _getSheetById_(SHEET_ID.CONTACTS, this.ss)) {
    const range = sheet.getRange(
      2,
      1,
      sheet.getLastRow() - 1,
      sheet.getLastColumn(),
    );
    range.sort([
      { column: 6, ascending: true }, // F Fields
      { column: 7, ascending: true }, // G Meetings
      { column: 9, ascending: true }, // I Family Name
      { column: 11, ascending: false }, // K Relation 1 - Type
    ]);
    SpreadsheetApp.flush();
    this.applyColors(sheet);
  }

  /**This sorts Sheet with order denoted in Settings tab */
  sortContactSheet(payload) {
    if (typeof payload === 'string') payload = JSON.parse(payload);
    const ignoreAQ = payload && payload.ignoreAQ;
    //const skipConfirm = payload.skipConfirm;
    //const title = "Sort Contacts";
    //if (!skipConfirm) {
      //const confirm = _confirm_(
        //'This will sort the contacts with the order in the tab "Settings"\n\nProceed?',
        //title,
      //);
      //const ui = _getUi_();
      //if (ui.Button.YES !== confirm) {
        //return "Cancelled";
      //}
    //}
    const name = "Contacts";
    const sheet = SpreadsheetApp.getActive().getSheetByName(name);
    if (!sheet) throw new Error(`Sheet "${name}" was not found.`);
    const [headers, ...records] = sheet.getDataRange().getValues();
    const keys = _createKeys_(headers);
    const settings = this.getSettings();
    const contacts = records
      .map((values, index) => {
        const item = _createItem_(keys, values);
        item.row_ = index + 2;
        item.headers_ = headers;
        return item;
      })
      .sort((a, b) => sortContacts_(a, b, settings, ignoreAQ));

    const sortedValues = contacts.map((v) => {
      return keys.map((key) => v[key]);
    });
    sortedValues.unshift(headers);
    sheet.clearContents();
    sheet
      .getRange(1, 1, sortedValues.length, sortedValues[0].length)
      .setValues(sortedValues);
    SpreadsheetApp.flush();
    this.applyColors(sheet);
    //_alert_("Contacts has been sorted according to Settings Tab!", title, "Success");
  }

  /** Writes a 2D array (values) into a Google Sheets sheet named sheetName */
  valuesToSheet(values, sheetName, clearContents = true, clearFormats = true) {
    const ws =
      this.ss.getSheetByName(sheetName) || this.ss.insertSheet(sheetName);
    if (clearContents) {
      ws.clearContents();
    }
    if (clearFormats) {
      ws.clearFormats();
      ws.getRange(1, 1, ws.getMaxRows(), ws.getMaxColumns()).removeCheckboxes();
    }
    const [headers, ...items] = values;
    ws.getRange(1, 1, 1, headers.length).setValues([headers]);
    if (items.length === 0) return ws;
    ws.getRange(
      ws.getLastRow() + 1,
      1,
      items.length,
      items[0].length,
    ).setValues(items);
    return ws;
  }

  /**
   * @param {SpreadsheetApp.Sheet} sheet
   */
  formatSheet(sheet, formats) {
    const settings = this.getSettings();
    SpreadsheetApp.flush();
    if (typeof sheet === "string") {
      sheet = this.ss.getSheetByName(sheet);
    }
    if (!sheet) return;
    const lastRow = sheet.getLastRow();
    if (lastRow <= 1) return;
    sheet
      .getRange(1, 1, sheet.getMaxRows(), sheet.getMaxColumns())
      .removeCheckboxes();
    const indexOfCheckbox = formats.indexOf("checkbox");
    const indexOfDate = formats.indexOf("yyyy/MM/dd hh:mm:ss");
    const indexOfBirthday = formats.indexOf("MM/dd/yyyy");
    sheet.getRange(2, indexOfCheckbox + 1, lastRow - 1, 1).insertCheckboxes();
    sheet
      .getRange(2, indexOfDate + 1, lastRow - 1, 1)
      .setNumberFormat(formats[indexOfDate]);
    sheet
      .getRange(2, indexOfBirthday + 1, lastRow - 1, 1)
      .setNumberFormat(formats[indexOfBirthday]);
    this.sortSheet(sheet);
    try {
      //sheet.expandAllColumnGroups();
      sheet.getRange("B:E").shiftColumnGroupDepth(-1);
      sheet.getRange("G:H").shiftColumnGroupDepth(-1);
      sheet.getRange("L:N").shiftColumnGroupDepth(-1);
      sheet.getRange("P:T").shiftColumnGroupDepth(-1);
      sheet.getRange("V:AC").shiftColumnGroupDepth(-1);
      sheet.getRange("AE:AG").shiftColumnGroupDepth(-1);
      sheet.getRange("AI:AJ").shiftColumnGroupDepth(-1);
      sheet.getRange("AL:AP").shiftColumnGroupDepth(-1);
    } catch (error) {
  
    }
    sheet.getRange("B:E").shiftColumnGroupDepth(1);
    sheet.getRange("G:H").shiftColumnGroupDepth(1);
    sheet.getRange("L:N").shiftColumnGroupDepth(1);
    sheet.getRange("P:T").shiftColumnGroupDepth(1);
    sheet.getRange("V:AC").shiftColumnGroupDepth(1);
    sheet.getRange("AE:AG").shiftColumnGroupDepth(1);
    sheet.getRange("AI:AJ").shiftColumnGroupDepth(1);
    sheet.getRange("AL:AP").shiftColumnGroupDepth(1);
    //sheet.collapseAllColumnGroups();

    const formatRange = sheet.getRange("A2:AQ");
    const rule = SpreadsheetApp.newConditionalFormatRule()
      .setRanges([formatRange])
      .whenFormulaSatisfied("=$A2=TRUE")
      .setBackground(
        settings.selected ? settings.selected.background : "#FFFF00",
      )
      .setFontColor(settings.selected ? settings.selected.fontColor : "#434343")
      .build();
    sheet.setConditionalFormatRules([rule]);
    return sheet;
  }

  getSettings() {
    const settings = {};
    const ws = this.ss.getSheetByName(this.sheetName.settings);
    if (!ws) return settings;
    const dataRange = ws.getDataRange();
    const values = dataRange.getValues();
    const backgrounds = dataRange.getBackgrounds();
    const fontColors = dataRange.getFontColorObjects();
    const titleOrders = {};
    const nameOrders = {};

    let currentTitleOfOrg;
    values.forEach(
      (
        [
          key,
          value,
          ,
          title,
          orderOfTitle,
          ,
          titleOfOrg,
          nameOfOrg,
          orderOfName,
        ],
        index,
      ) => {
        if (index === 0) return;
        if (key) {
          const color = fontColors[index][1].asRgbColor().asHexString();
          settings[key] = {
            value,
            background: backgrounds[index][1],
            fontColor: color.length === 7 ? color : `#${color.slice(-6)}`,
          };
        }
        if (title && orderOfTitle) {
          titleOrders[title] = orderOfTitle;
        }
        currentTitleOfOrg = titleOfOrg || currentTitleOfOrg;
        if (currentTitleOfOrg && nameOfOrg && orderOfName) {
          nameOrders[`${currentTitleOfOrg}:${nameOfOrg}`] = orderOfName;
        }
      },
    );
    settings.titleOrders = titleOrders;
    settings.nameOrders = nameOrders;
    return settings;
  }
}

class Contact extends Spreadsheet {
  constructor() {
    super();
    this.pageSize = 200;
    this.readMask =
      "names,emailAddresses,addresses,birthdays,coverPhotos,relations,urls,memberships,organizations,phoneNumbers";
    this.personFields =
      "addresses,biographies,birthdays,coverPhotos,emailAddresses,memberships,names,organizations,phoneNumbers,photos,relations,urls,userDefined";
    this.headerContactId = "Contact ID";
    this.headerSelected = "Selected";
    this.headerEtag = "Etag";
    this.headers = [
      { key: this.headerSelected, format: "checkbox" },
      { key: this.headerContactId, format: "@" },
      { key: this.headerEtag, format: "@" },
      { key: "Last Updated", format: "yyyy/MM/dd hh:mm:ss" },
      { key: "Status", format: "@" },
      { key: "Fields", format: "@" },
      { key: "Meetings", format: "@" },
      { key: "Group Membership", format: "@" },
      { key: "Family Name", format: "@" },
      { key: "Given Name", format: "@" },
      { key: "Relation 1 - Type", format: "@" },
      { key: "Relation 1 - Value", format: "@" },
      { key: "Relation 2 - Type", format: "@" },
      { key: "Relation 2 - Value", format: "@" },
      { key: "Phone 1 - Type", format: "@" },
      { key: "Phone 1 - Value", format: "@" },
      { key: "Phone 2 - Type", format: "@" },
      { key: "Phone 2 - Value", format: "@" },
      { key: "Phone 3 - Type", format: "@" },
      { key: "Phone 3 - Value", format: "@" },
      { key: "Address 1 - Type", format: "@" },
      { key: "Address 1 - Formatted", format: "@" },
      { key: "Address 1 - Coordinates", format: "@" },
      { key: "Address 2 - Type", format: "@" },
      { key: "Address 2 - Formatted", format: "@" },
      { key: "Address 2 - Coordinates", format: "@" },
      { key: "Address 3 - Type", format: "@" },
      { key: "Address 3 - Formatted", format: "@" },
      { key: "Address 3 - Coordinates", format: "@" },
      { key: "E-mail 1 - Type", format: "@" },
      { key: "E-mail 1 - Value", format: "@" },
      { key: "E-mail 2 - Type", format: "@" },
      { key: "E-mail 2 - Value", format: "@" },
      { key: "Photo", format: "@" },
      { key: "Birthday", format: "MM/dd/yyyy" },
      { key: "Notes", format: "@" },
      { key: "Custom Field 1 - Type", format: "@" },
      { key: "Custom Field 1 - Value", format: "@" },
      { key: "Custom Field 2 - Type", format: "@" },
      { key: "Custom Field 2 - Value", format: "@" },
      { key: "Custom Field 3 - Type", format: "@" },
      { key: "Custom Field 3 - Value", format: "@" },
      { key: "Mtg home-1/Elder-2", format: "#" },
    ];
    this.keys = this.headers.map((v) => v.key);
    this.groupNameSep = ":::";
  }

  getAllGroups() {
    const groups = {};
    let nextPageToken = null;
    do {
      const options = { pageSize: this.pageSize };
      if (nextPageToken) options.pageToken = nextPageToken;
      const response = People.ContactGroups.list(options);
      response.contactGroups.forEach(
        (item) => (groups[item.name] = item.resourceName),
      );
      nextPageToken = response.nextPageToken;
    } while (nextPageToken);
    return groups;
  }

  getAllGroupNames() {
    const groups = {};
    let nextPageToken = null;
    do {
      const options = { pageSize: this.pageSize };
      if (nextPageToken) options.pageToken = nextPageToken;
      const response = People.ContactGroups.list(options);
      response.contactGroups.forEach(
        (item) => (groups[item.resourceName] = item.name),
      );
      nextPageToken = response.nextPageToken;
    } while (nextPageToken);
    return groups;
  }

  createContactGroup(name) {
    return People.ContactGroups.create({ contactGroup: { name } });
  }

  createContactPerson(headers, values, includeResourceName = false, groups) {
    const contactPerson = {
      names: [
        {
          givenName: null,
          familyName: null,
        },
      ],
      birthdays: [
        {
          date: {
            day: 0,
            month: 0,
            year: 0,
          },
        },
      ],
      emailAddresses: [
        {
          type: null,
          value: null,
        },
        {
          type: null,
          value: null,
        },
      ],
      phoneNumbers: [
        {
          type: "",
          value: "",
        },
        {
          type: "",
          value: "",
        },
        {
          type: "",
          value: "",
        },
      ],
      addresses: [
        {
          type: "",
          formattedValue: "",
        },
        {
          type: "",
          formattedValue: "",
        },
        {
          type: "",
          formattedValue: "",
        },
      ],
      organizations: [
        {
          title: null,
          name: null,
        },
      ],
      memberships: [
        {
          contactGroupMembership: {
            contactGroupResourceName: null,
          },
        },
      ],
      relations: [
        {
          type: "",
          person: "",
        },
        {
          type: "",
          person: "",
        },
      ],
      // Websites 1 - 6 for address map URLs
      urls: [],
      userDefined: [
        {
          key: "",
          value: "",
        },
        {
          key: "",
          value: "",
        },
        {
          key: "",
          value: "",
        },
      ],
      biographies: [
        {
          contentType: "TEXT_PLAIN",
          value: null,
        },
      ],
    };

    const addressCoordinates = ["", "", ""];
    const addressTypes = ["", "", ""];
    headers.forEach((header, index) => {
      header = header.trim();
      const value = values[index];
      switch (header) {
        case "Fields":
          contactPerson.organizations[0].title = value;
          break;
        case "Meetings":
          contactPerson.organizations[0].name = value;
          break;
        case "Group Membership":
          const groupNames = value.split(this.groupNameSep);
          const memberships = [];
          groupNames.forEach((name) => {
            let group = groups[name];
            if (!group) {
              group = this.createContactGroup(name).resourceName;
              groups[name] = group;
            }
            memberships.push([
              {
                contactGroupMembership: {
                  contactGroupResourceName: group,
                },
              },
            ]);
          });
          contactPerson.memberships = memberships;
          break;
        case "Given Name":
          contactPerson.names[0].givenName = value;
          break;
        case "Family Name":
          contactPerson.names[0].familyName = value;
          break;
        case "Relation 1 - Type":
          contactPerson.relations[0].type = value;
          break;
        case "Relation 1 - Value":
          contactPerson.relations[0].person = value;
          break;
        case "Relation 2 - Type":
          contactPerson.relations[1].type = value;
          break;
        case "Relation 2 - Value":
          contactPerson.relations[1].person = value;
          break;
        case "Phone 1 - Type":
          contactPerson.phoneNumbers[0].type = value;
          break;
        case "Phone 1 - Value":
          contactPerson.phoneNumbers[0].value = value;
          break;
        case "Phone 2 - Type":
          contactPerson.phoneNumbers[1].type = value;
          break;
        case "Phone 2 - Value":
          contactPerson.phoneNumbers[1].value = value;
          break;
        case "Phone 3 - Type":
          contactPerson.phoneNumbers[2].type = value;
          break;
        case "Phone 3 - Value":
          contactPerson.phoneNumbers[2].value = value;
          break;
        case "Address 1 - Type":
          contactPerson.addresses[0].type = value;
          addressTypes[0] = value;
          break;
        case "Address 1 - Formatted":
          contactPerson.addresses[0].formattedValue = value;
          break;
        case "Address 1 - Coordinates":
          addressCoordinates[0] = value;
          break;
        case "Address 2 - Type":
          contactPerson.addresses[1].type = value;
          addressTypes[1] = value;
          break;
        case "Address 2 - Formatted":
          contactPerson.addresses[1].formattedValue = value;
          break;
        case "Address 2 - Coordinates":
          addressCoordinates[1] = value;
          break;
        case "Address 3 - Type":
          contactPerson.addresses[2].type = value;
          addressTypes[2] = value;
          break;
        case "Address 3 - Formatted":
          contactPerson.addresses[2].formattedValue = value;
          break;
        case "Address 3 - Coordinates":
          addressCoordinates[2] = value;
          break;
        case "E-mail 1 - Type":
          contactPerson.emailAddresses[0].type = value;
          break;
        case "E-mail 1 - Value":
          contactPerson.emailAddresses[0].value = value;
          break;
        case "E-mail 2 - Type":
          contactPerson.emailAddresses[1].type = value;
          break;
        case "E-mail 2 - Value":
          contactPerson.emailAddresses[1].value = value;
          break;
        case "E-mail 3 - Type":
          contactPerson.emailAddresses[2].type = value;
          break;
        case "E-mail 3 - Value":
          contactPerson.emailAddresses[2].value = value;
          break;
        case "Custom Field 1 - Type":
          contactPerson.userDefined[0].key = value;
          break;
        case "Custom Field 1 - Value":
          contactPerson.userDefined[0].value = value;
          break;
        case "Custom Field 2 - Type":
          contactPerson.userDefined[1].key = value;
          break;
        case "Custom Field 2 - Value":
          contactPerson.userDefined[1].value = value;
          break;
        case "Custom Field 3 - Type":
          contactPerson.userDefined[2].key = value;
          break;
        case "Custom Field 3 - Value":
          contactPerson.userDefined[2].value = value;
          break;
        case "Birthday":
          if (!value) {
            contactPerson.birthdays = [];
            break;
          }
          const [year, month, day] = Utilities.formatDate(
            typeof value === "object" ? value : new Date(value),
            this.timezone,
            "yyyy-MM-dd",
          ).split("-");

          contactPerson.birthdays[0].date.day = day;
          contactPerson.birthdays[0].date.month = month;
          contactPerson.birthdays[0].date.year = year;
          break;
        case "Notes":
          contactPerson.biographies[0].value = value;
          break;
        case "Photo":
          break;
        case this.headerContactId:
          if (value && includeResourceName) {
            contactPerson.resourceName = value;
          }
          break;
        case this.headerEtag:
          if (includeResourceName) contactPerson.etag = value;
          break;
      }
    });

    // Only create new URLs if coordinates are present
    const coordsMap = {}; // For cleanup purposes
    addressCoordinates.forEach((coordinates, i) => {
    const addressType = addressTypes[i] || `Address ${i + 1}`;
    if (coordinates) {
      const googleMapUrl = createMapUrl_(coordinates, "google");
      const appleMapUrl = createMapUrl_(coordinates, "apple");
      contactPerson.urls.push({ type: addressType, value: googleMapUrl });
      contactPerson.urls.push({ type: addressType, value: appleMapUrl });
      coordsMap[addressType] = coordinates;
    }
    });

    return { contactPerson };
  }

  createContacts() {
    const name = "✅ Create Contacts";
    const ws = this.ss.getSheetByName(this.sheetName.contacts);
    if (!ws) {
      return this.alert(
        `Sheet "${this.sheetName.contacts}" was not found in this spreadsheet!`,
        name,
      );
    }
    const [headers, ...items] = ws.getDataRange().getDisplayValues();
    const indexOfContactId =
      headers.indexOf(this.headerContactId) || headers.length;
    const indexOfSelected = headers.indexOf(this.headerSelected);
    const indexOfEtag = headers.indexOf(this.headerEtag);
    const indexOfLastUpdated = headers.indexOf("Last Updated");
    const indexOfStatus = headers.indexOf("Status");

    const groups = this.getAllGroups();
    const contacts = items
      .filter(
        (item) => !item[indexOfContactId] && item[indexOfSelected] == "TRUE",
      )
      .map((item) => this.createContactPerson(headers, item, false, groups));

    if (contacts.length === 0) {
      return this.alert(
        `No new contacts found in sheet "${this.sheetName.contacts}".
        Only rows without "${this.headerContactId}" and checked at column "${this.headerSelected}" will be created as new contacts.`,
        name,
      );
    }
    /**
    const confirm = this.confirm(
      `Are you sure you want to create ${contacts.length} new contact(s) with data in sheet "${this.sheetName.contacts}" in your account?`,
      name,
    );
    if (confirm !== SpreadsheetApp.getUi().Button.YES) {
      return this.toast("Cancelled", name);
    }
    */

    let finalResults = [];
    for (let i = 0; i < contacts.length; i += this.pageSize) {
      const resource = {
        contacts: contacts.slice(i, i + this.pageSize),
        readMask: "metadata",
      };
      const response = People.People.batchCreateContacts(resource);
      const results = response.createdPeople.map((v) => [
        false,
        v.requestedResourceName,
        v.person.etag,
        new Date(),
        v.httpStatusCode == 200 ? "Created" : JSON.stringify(v.status), // <-- sets Status column to 'created'
      ]);
      finalResults = [...finalResults, ...results];
    }

    const resultValues = items.map((item) => {
      if (!item[indexOfContactId] && item[indexOfSelected] == "TRUE") {
        return finalResults.shift();
      } else {
        return item.slice(indexOfSelected, indexOfSelected + 5);
      }
    });

    resultValues.unshift([
      this.headerSelected,
      this.headerContactId,
      this.headerEtag,
      "Last Updated",
      "Status",
    ]);
    ws.getRange(
      1,
      indexOfSelected + 1,
      resultValues.length,
      resultValues[0].length,
    ).setValues(resultValues);
    this.formatSheet(
      ws,
      this.headers.map((v) => v.format),
    );
    sortContactSheet();
    let rowColor = "#830303"; /** set row color red */
    let fontColor = "#fff000"; /** set font color to yellow */
    this.applyColors2(rowColor, fontColor);
    //this.updateSortItemsInSettings();
    //this.toast("Done!", name);
  }


  parseConnection(person, groupNames, sortNumbers) {
    const item = {};
    if (person.organizations && person.organizations.length) {
      const org = person.organizations[0];
      item["Fields"] = org.title || "";
      item["Meetings"] = org.name || "";
    }
    if (person.names) {
      item["Given Name"] = person.names[0].givenName;
      item["Family Name"] = person.names[0].familyName;
    }
    if (person.memberships) {
      const memberships = person.memberships
        .map(
          (v) => groupNames[v.contactGroupMembership.contactGroupResourceName],
        )
        .join(this.groupNameSep);
      item["Group Membership"] = memberships || null;
    }
    if (person.relations) {
      person.relations.forEach((v, i) => {
        item[`Relation ${i + 1} - Type`] = v.type;
        item[`Relation ${i + 1} - Value`] = v.person;
      });
    }
    if (person.phoneNumbers) {
      person.phoneNumbers.forEach((v, i) => {
        item[`Phone ${i + 1} - Type`] = v.type;
        item[`Phone ${i + 1} - Value`] = v.value;
      });
    }
    if (person.emailAddresses) {
      person.emailAddresses.forEach((v, i) => {
        item[`E-mail ${i + 1} - Type`] = v.type;
        item[`E-mail ${i + 1} - Value`] = v.value;
      });
    }
    if (person.urls) {
      person.urls.forEach((v, i) => {
        item[`Website ${i + 1} - Type`] = v.type;
        item[`Website ${i + 1} - Value`] = v.value;
      });
    }
    /**
    // Coordinates: extract from URLs!
    if (person.addresses?.length) {
      const getCoordinatesFromUrl = (url) => {
        if (!url) return "";
        const match = decodeURIComponent(url.replace(/\+/g, " ")).match(/[?&]q=([-.\d]+)\s*,\s*(-?\d+(?:\.\d+)?)/);
        return match ? `${match[1]}, ${match[2]}` : "";
      };
      
      person.addresses.forEach((addr, i) => {
        const addrType = addr.type || `Address ${i + 1}`;

        // Match URL that includes maps.google.com and loosely matches addrType
        const coordUrl = (person.urls || []).find(u =>
          u.value?.includes("maps.google.com") &&
          u.type?.toLowerCase().includes(addrType.toLowerCase())
        )?.value || "";
        const coordValue = getCoordinatesFromUrl(coordUrl);
        item[`Address ${i + 1} - Type`] = addrType;
        item[`Address ${i + 1} - Formatted`] = addr.formattedValue || "";
        if (coordValue) {
          item[`Address ${i + 1} - Coordinates`] = coordValue;
        }
      });
    }
    */
    
    if (person.addresses) {
      const coordinates = getCoordinatesFromWebsites_(person.urls);
      person.addresses.forEach((v, i) => {
        item[`Address ${i + 1} - Type`] = v.type;
        item[`Address ${i + 1} - Formatted`] = v.formattedValue;
        //item[`Address ${i + 1} - Coordinates`] = coordinates[v.type] || null;
      });
    }
    
    if (person.userDefined) {
      person.userDefined.forEach((v, i) => {
        item[`Custom Field ${i + 1} - Type`] = v.key;
        item[`Custom Field ${i + 1} - Value`] = v.value;
      });
    }

    if (person.birthdays) {
      const year =
        person.birthdays[0].date.year < 100
          ? `19${person.birthdays[0].date.year}`
          : person.birthdays[0].date.year;
      const month = person.birthdays[0].date.month;
      const day = person.birthdays[0].date.day;
      item["Birthday"] = [month, day, year].join("/");
    }
    if (person.biographies) {
      item["Notes"] = person.biographies[0].value;
    }
    if (person.coverPhotos) {
      item["Photo"] = person.coverPhotos[0].url;
    }
    if (person.photos) {
      item["Photo"] = person.photos[0].url;
    }

    item[this.headerContactId] = person.resourceName;
    item[this.headerEtag] = person.etag;
    item[this.headerSelected] = false;

    item["Mtg home-1/Elder-2"] = sortNumbers[person.resourceName] || null;

    return this.createRowValues(this.keys, item);
  }

  getSortNumbers() {
    const data = {};
    const sheet = this.ss.getSheetByName(this.sheetName.contacts);
    if (!sheet) return data;
    const filter = (v) => v.contactId && v.mtgHome1elder2 !== "";
    const items = _getItemsFromSheet_(sheet, filter);
    items.forEach(({ contactId, mtgHome1elder2 }) => {
      data[contactId] = mtgHome1elder2;
    });
    return data;
  }

  refreshFormatting() {
    const sheet = this.ss.getSheetByName(this.sheetName.contacts);
    if (sheet) {
      this.formatSheet(sheet, this.headers.map(v => v.format));
      this.toast("Formatting refreshed.", "Refresh");
    }
  }

  clearBordersBelowLastData(sheet, colStart, rowStart, colCount) {
    // Find last row with data in region
    var lastDataRow = 0;
    var lastRow = sheet.getLastRow();   // last row with content
    var maxRow = sheet.getMaxRows();    // actual last possible row in the sheet
    var data = sheet.getRange(rowStart, colStart, lastRow - rowStart + 1, colCount).getValues();
    for (var i = data.length - 1; i >= 0; i--) {
        if (data[i].join('').trim() !== '') {
            lastDataRow = i + rowStart;
            break;
        }
    }
    var firstEmptyRow = lastDataRow + 1;
    if (firstEmptyRow <= maxRow) {
      var rowsToClear = maxRow - firstEmptyRow + 1;
      if (rowsToClear > 0) {
        sheet.getRange(firstEmptyRow, colStart, rowsToClear, colCount)
             .setBorder(false, false, false, false, false, false);
      }
    }
  }

  updateSortItemsInSettings() {
    const sheetContacts = this.ss.getSheetByName(this.sheetName.contacts);
    const sheetSettings = this.ss.getSheetByName(this.sheetName.settings);
    if (!sheetContacts) {
      throw new Error(`Sheet "${this.sheetName.contacts}" was not found.`);
    }
    if (!sheetSettings) {
      throw new Error(`Sheet "${this.sheetName.settings}" was not found.`);
    }
    const [headers, ...values] = sheetContacts.getDataRange().getValues();
    const keys = _createKeys_(headers);
    const { titleOrders, nameOrders } = this.getSettings();
    const titles = {};
    const names = {};
    const indexOfTitle = keys.indexOf("fields");
    const indexOfName = keys.indexOf("meetings");

    values.forEach((v) => {
      const title = v[indexOfTitle];
      const name = v[indexOfName];
      if (!title || !name) return;
      if (!(title in titles)) {
        titles[title] = [title, titleOrders[title] || null];
      }
      const key = `${title}:${name}`;
      if (!(key in names)) {
        names[key] = [title, name, nameOrders[key] || null];
      }
    });
    const titleValues = Object.keys(titles)
      .sort()
      .map((key) => titles[key]);
    const nameValues = Object.keys(names)
      .sort()
      .map((key) => names[key]);
    let currentTitle;
    nameValues.forEach((v) => {
      if (currentTitle !== v[0]) {
        currentTitle = v[0];
      } else {
        v[0] = null;
      }
    });

    sheetSettings.getRange("D:I").clearContent();

    // Write sorted titles with header at row 1
    titleValues.unshift(["Fields", "Order"]);
    sheetSettings.getRange(1, 4, titleValues.length, titleValues[0].length).setValues(titleValues);

    // Clear all borders in the region below header FIRST!
    sheetSettings.getRange(2, 7, nameValues.length - 1, 3).setBorder(false, false, false, false, false, false);

    // Write the sorted names (Meetings) with header at row 1
    nameValues.unshift(["Fields", "Meetings", "Order"]);
    sheetSettings.getRange(1, 7, nameValues.length, nameValues[0].length).setValues(nameValues);

    // Draw the border under the header (AFTER all clears)
    sheetSettings.getRange(1, 7, 1, 3).setBorder(
      true, false, true, false, false, false, "black", SpreadsheetApp.BorderStyle.SOLID_MEDIUM
    );

    // --- CORRECT GROUP BORDER LOGIC (PLACE AT NEW GROUP'S START ROW) ---
    for (let i = 2; i <= nameValues.length; i++) {
        const currentGroupName = nameValues[i-1]?.[0];
      const prevGroupName = nameValues[i-2]?.[0];
      // Only draw a top border at the start of a new group, not the very first data row
      if (i > 2 && currentGroupName && currentGroupName !== prevGroupName) {
            sheetSettings.getRange(i, 7, 1, 3).setBorder(
              true, false, false, false, false, false, "black", SpreadsheetApp.BorderStyle.SOLID
            );
        }
    }

     // Color cols C & F (1 = A, 3 = C, 6 = F)
    const lastRow = sheetSettings.getLastRow();
    sheetSettings.getRange(2, 3, lastRow, 1).setBackground("#FFFFCC"); // Col C
    sheetSettings.getRange(2, 6, lastRow, 1).setBackground("#FFFFCC"); // Col F
    this.clearBordersBelowLastData(sheetSettings, 7, 2, 3);
  }

  getContactConnections() {
    let connections = [];
    let nextPageToken = null;
    do {
      const options = {
        pageSize: 500,
        personFields: this.personFields,
      };
      if (nextPageToken) {
        options.pageToken = nextPageToken;
      }
      const response = People.People.Connections.list("people/me", options);
      connections = [...connections, ...response.connections];
      nextPageToken = response.nextPageToken;
    } while (nextPageToken);
    return connections;
  }

  getContactEtags() {
    const connections = this.getContactConnections();
    const etags = {};
    connections.forEach((v) => (etags[v.resourceName] = v.etag));
    return etags;
  }

  /**
   * Get contacts from the account
   */
  getContacts() {
    const name = "📘 Get All Contacts";
    const confirm = this.confirm(
    `Import all Google contacts into sheet "${this.sheetName.contacts}"?`,
      name,
    );
    if (confirm !== SpreadsheetApp.getUi().Button.YES) {
    return "Cancelled";
    }

    // Step 1: Read previous data and build lookup map
    const ws = this.ss.getSheetByName(this.sheetName.contacts);
    let previousData = {};
    let headers = [];
    let indexOfLastUpdated = -1, indexOfStatus = -1, idIndex = -1, addr1Index = -1, addr2Index = -1, addr3Index = -1;
    if (ws) {
      const oldData = ws.getDataRange().getDisplayValues();
      if (oldData && oldData.length) {
      headers = oldData[0];
        indexOfLastUpdated = headers.indexOf("Last Updated");
        indexOfStatus = headers.indexOf("Status");
      idIndex = headers.indexOf(this.headerContactId);
      addr1Index = headers.indexOf("Address 1 - Coordinates");
      addr2Index = headers.indexOf("Address 2 - Coordinates");
      addr3Index = headers.indexOf("Address 3 - Coordinates");
        for (let i = 1; i < oldData.length; i++) {
          const row = oldData[i];
          const id = row[idIndex];
          if (id) {
            previousData[id] = {
              lastUpdated: indexOfLastUpdated !== -1 ? row[indexOfLastUpdated] : "",
              status: indexOfStatus !== -1 ? row[indexOfStatus] : "",
            addr1Coord: addr1Index !== -1 ? row[addr1Index] : "",
            addr2Coord: addr2Index !== -1 ? row[addr2Index] : "",
            addr3Coord: addr3Index !== -1 ? row[addr3Index] : ""
            };
          }
        }
      }
    }

    // Step 2: Get new contacts data
    const sortNumbers = this.getSortNumbers();
    const connections = this.getContactConnections();
    const groupNames = this.getAllGroupNames();
    const values = connections.map((connection) =>
      this.parseConnection(connection, groupNames, sortNumbers),
    );
    values.unshift(this.keys);

    // Step 3: Re-insert previous Last Updated and Status values where available
    const newHeaders = values[0];
    const idIndexNew = newHeaders.indexOf(this.headerContactId);
    const lastUpdatedNew = newHeaders.indexOf("Last Updated");
    const statusNew = newHeaders.indexOf("Status");
    const addr1IndexNew = newHeaders.indexOf("Address 1 - Coordinates");
    const addr2IndexNew = newHeaders.indexOf("Address 2 - Coordinates");
    const addr3IndexNew = newHeaders.indexOf("Address 3 - Coordinates");

    for (let i = 1; i < values.length; i++) {
      const id = values[i][idIndexNew];
      if (id && previousData[id]) {
        if (lastUpdatedNew !== -1) values[i][lastUpdatedNew] = previousData[id].lastUpdated;
        if (statusNew !== -1) values[i][statusNew] = previousData[id].status;
        if (addr1IndexNew !== -1 && !values[i][addr1IndexNew]) values[i][addr1IndexNew] = previousData[id].addr1Coord;
        if (addr2IndexNew !== -1 && !values[i][addr2IndexNew]) values[i][addr2IndexNew] = previousData[id].addr2Coord;
        if (addr3IndexNew !== -1 && !values[i][addr3IndexNew]) values[i][addr3IndexNew] = previousData[id].addr3Coord;
      }
    }

    // Step 4: Write updated data to the sheet
    const ws2 = this.valuesToSheet(values, this.sheetName.contacts, true, true);

    // Step 5: Do all formatting in bulk after writing
      this.formatSheet(
        ws2,
        this.headers.map((v) => v.format),
      );

    // Apply color to headers
    const rowColor = "#830303";
    const fontColor = "#fff000";
      this.applyColors2(rowColor, fontColor);

    // Batch set wrap strategies for three columns
    ws2.getRangeList(['C2:C', 'AH2:AH', 'AJ2:AJ'])
     .setWrapStrategy(SpreadsheetApp.WrapStrategy.CLIP);

    //centers data in Col AQ
    const lastRow = ws2.getLastRow();
    if (lastRow > 1) {
      ws2.getRange(2, 43, lastRow - 1, 1).setHorizontalAlignment('center');
    }

    // this.updateSortItemsInSettings(); // Uncomment if you want to update after import
    //this.toast("Done!", name);
  }

  /**
   * update/create contacts from the spreadsheet
   */
  updateContacts() {
    const name = "⚠️ Update Contacts";
    const ws = this.ss.getSheetByName(this.sheetName.contacts);
    if (!ws) return this.alert(`Sheet "${this.sheetName.contacts}" not found.`, name);

    const [headers, ...items] = ws.getDataRange().getDisplayValues();
    const indices = {
      contactId: headers.indexOf(this.headerContactId),
      etag: headers.indexOf(this.headerEtag),
      selected: headers.indexOf(this.headerSelected),
      lastUpdated: headers.indexOf("Last Updated"),
      photo: headers.indexOf("Photo"),
      status: headers.indexOf("Status"),
    };

    const ui = SpreadsheetApp.getUi();
    const groups = this.getAllGroups();
    const fieldMap = this.getFieldMap();

    const rowsToUpdate = items
      .map((item, idx) => ({ item, idx }))
      .filter(({ item }) =>
        (item[indices.selected] === "TRUE" || item[indices.selected] === true) && // <-- FIX parentheses
        item[indices.contactId] &&
        item[indices.etag]
      );

    if (rowsToUpdate.length === 0) {
      ui.alert(name, "No contacts selected.", ui.ButtonSet.OK);
      return;
    }

    const confirm = ui.alert(
      name,
      `You have ${rowsToUpdate.length} contact(s) selected to be updated.\n\nProceed?`,
      ui.ButtonSet.YES_NO
    );

    if (confirm !== ui.Button.YES) {
      // User cancelled: Reset selected rows quickly in batch
      const resetValues = items.map((row) => {
        if (row[indices.selected] === "TRUE" || row[indices.selected] === true) { // <-- FIX item -> row
          const liveContact = People.People.get(row[indices.contactId], {
            personFields: "names,emailAddresses,phoneNumbers,addresses,organizations,relations,urls,birthdays,photos,userDefined,metadata,biographies,memberships"
          });
          const resetRow = [...row];
          headers.forEach((h, j) => {
            if (fieldMap[h]) resetRow[j] = fieldMap[h](liveContact);
          });
          resetRow[indices.selected] = false;
          resetRow[indices.status] = "";
          return resetRow;
        }
        return row;
      });
      ws.getRange(2, 1, resetValues.length, resetValues[0].length).setValues(resetValues);
      return;
    }

    let totalUpdates = 0;
    let totalSkipped = 0;

    const updatedRows = items.map(row => [...row]); // copy all rows to batch-update at end

    rowsToUpdate.forEach(({ item, idx }) => {
      const id = item[indices.contactId];
      const liveContact = People.People.get(id, {
        personFields: "names,emailAddresses,phoneNumbers,addresses,organizations,relations,urls,birthdays,photos,userDefined,metadata,biographies,memberships"
      });

      const sheetPhoto = (item[indices.photo] || "").trim();
      const contactPhoto = (liveContact.photos?.[0]?.url || "").trim();

      let needsUpdate = false; // for NON-URL fields in the single-call path

      if (contactPhoto !== sheetPhoto) {
        // Only prompt if photo is different between Contacts and Sheets
        const response = ui.alert(
          name,
          `Row ${idx + 2} - A photo has changed in Contacts.\n\nYES = Keep Contacts photo\nNO = Overwrite with Sheets data\nCancel = Skip`,
          ui.ButtonSet.YES_NO_CANCEL
        );

        if (response === ui.Button.YES) {
          updatedRows[idx][indices.photo] = contactPhoto;
          updatedRows[idx][indices.status] = "updated";
          totalUpdates++;
          // still fall through to compare other fields
        } else if (response === ui.Button.NO) {
          needsUpdate = true; // allow non-photo fields to update
        } else {
          // Cancel: skip everything for this row
          totalSkipped++;
          updatedRows[idx][indices.selected] = false;
          updatedRows[idx][indices.lastUpdated] = new Date();
          return;
        }
      }

      // Compare other fields + derived URLs
      const changedFields = compareContactFieldsDetailed(headers, item, liveContact, fieldMap, ["Photo"]);
      const urlsChanged   = changedFields.includes("__urls__");
      const otherChanged  = changedFields.some(h => h !== "__urls__");

      if (!urlsChanged && !otherChanged && !needsUpdate) {
        totalSkipped++;
        updatedRows[idx][indices.selected] = false;
        updatedRows[idx][indices.lastUpdated] = new Date();
        return;
      }

      // Build one person payload (single-call update)
      const contact = this.createContactPerson(headers, item, true, groups);
      contact.contactPerson.resourceName = liveContact.resourceName;
      contact.contactPerson.etag = liveContact.etag;

      // If URLs changed, compute and stamp CONTACT source so we REPLACE (not append)
      if (urlsChanged) {
        const contactSource = (liveContact.metadata?.sources || []).find(s => s.type === "CONTACT");
        const contactSourceId = contactSource ? contactSource.id : null;
        const desiredUrls = buildMapUrlsFromRow_(headers, item); // [{value,type},...]

        contact.contactPerson.urls = (desiredUrls || []).map((u, i) => ({
          value: u.value,
          type: u.type || "OTHER",
          metadata: Object.assign(
            { primary: i === 0 },
            contactSourceId ? { source: { type: "CONTACT", id: contactSourceId } } : {}
          )
        }));

        // If all GPS are blank and you want to delete websites, send empty:
        // contact.contactPerson.urls = [];
      }

      // Build the update mask
      const maskParts = [];
      if (otherChanged || needsUpdate) {
        maskParts.push(
          "addresses","birthdays","emailAddresses","names",
          "organizations","phoneNumbers","relations",
          "userDefined","memberships","biographies"
        );
      }
      if (urlsChanged) maskParts.push("urls");
      const updateMask = Array.from(new Set(maskParts)).join(",");

      // Single updateContact call
      if (updateMask) {
        const updated = People.People.updateContact(
          contact.contactPerson,
          contact.contactPerson.resourceName,
          { updatePersonFields: updateMask }
        );

        if (updated?.etag) {
          updatedRows[idx][indices.etag] = updated.etag;
          updatedRows[idx][indices.status] = "updated";
          totalUpdates++;
        } else {
          updatedRows[idx][indices.status] = "skipped/no-change";
        }
      } else {
        // Nothing to update
        totalSkipped++;
      }

      updatedRows[idx][indices.selected] = false;
      updatedRows[idx][indices.lastUpdated] = new Date();
    }); // <-- FIX: close the forEach callback AND the .forEach(...);

    // Batch update ALL rows at once (speed!)
    ws.getRange(2, 1, updatedRows.length, updatedRows[0].length).setValues(updatedRows);

    // Final alerts
    if (totalUpdates === 0 && totalSkipped > 0) {
      ui.alert(name, "No changes made to any selected contacts.", ui.ButtonSet.OK);
    } else if (totalUpdates > 0) {
      ui.alert(name, `Contacts updated: ${totalUpdates}`, ui.ButtonSet.OK);
    }

    // Apply color formatting once at the end
    const rowColor = "#830303";
    const fontColor = "#fff000";
    this.applyColors2(rowColor, fontColor);
  }


  getFieldMap() {
    return {
      // Basic and org fields
      "Fields": (c) => c.organizations?.[0]?.title || "",
      "Meetings": (c) => c.organizations?.[0]?.name || "",
      "Group Membership": (c) =>
        (c.memberships || [])
          .map(m => m.contactGroupMembership?.contactGroupResourceName)
          .join(";"),
      "Family Name": (c) => c.names?.[0]?.familyName || "",
      "Given Name": (c) => c.names?.[0]?.givenName || "",
      // Relations
      "Relation 1 - Type": (c) => c.relations?.[0]?.type || "",
      "Relation 1 - Value": (c) => c.relations?.[0]?.person || "",
      "Relation 2 - Type": (c) => c.relations?.[1]?.type || "",
      "Relation 2 - Value": (c) => c.relations?.[1]?.person || "",
      // Phones
      "Phone 1 - Type": (c) => c.phoneNumbers?.[0]?.type || "",
      "Phone 1 - Value": (c) => c.phoneNumbers?.[0]?.value || "",
      "Phone 2 - Type": (c) => c.phoneNumbers?.[1]?.type || "",
      "Phone 2 - Value": (c) => c.phoneNumbers?.[1]?.value || "",
      "Phone 3 - Type": (c) => c.phoneNumbers?.[2]?.type || "",
      "Phone 3 - Value": (c) => c.phoneNumbers?.[2]?.value || "",
      // Addresses
      "Address 1 - Type": (c) => c.addresses?.[0]?.type || "",
      "Address 1 - Formatted": (c) => c.addresses?.[0]?.formattedValue || "",
      "Address 1 - Coordinates": (c) =>
        (c.urls?.find(u => u.type === (c.addresses?.[0]?.type || "Address 1"))?.value.replace(/^.*\?q=/, "") || ""),
      "Address 2 - Type": (c) => c.addresses?.[1]?.type || "",
      "Address 2 - Formatted": (c) => c.addresses?.[1]?.formattedValue || "",
      "Address 2 - Coordinates": (c) =>
        (c.urls?.find(u => u.type === (c.addresses?.[1]?.type || "Address 2"))?.value.replace(/^.*\?q=/, "") || ""),
      "Address 3 - Type": (c) => c.addresses?.[2]?.type || "",
      "Address 3 - Formatted": (c) => c.addresses?.[2]?.formattedValue || "",
      "Address 3 - Coordinates": (c) =>
        (c.urls?.find(u => u.type === (c.addresses?.[2]?.type || "Address 3"))?.value.replace(/^.*\?q=/, "") || ""),
      // Emails
      "E-mail 1 - Type": (c) => c.emailAddresses?.[0]?.type || "",
      "E-mail 1 - Value": (c) => c.emailAddresses?.[0]?.value || "",
      "E-mail 2 - Type": (c) => c.emailAddresses?.[1]?.type || "",
      "E-mail 2 - Value": (c) => c.emailAddresses?.[1]?.value || "",
      // Birthday, Notes
      "Birthday": (c) => {
        const d = c.birthdays?.[0]?.date;
        if (!d) return "";
        // Pad day/month to 2 digits
        const day = String(d.day).padStart(2, "0");
        const month = String(d.month).padStart(2, "0");
        const year = d.year ? String(d.year) : "";
        // Return "DD-MM-YYYY" if year is present, else "DD-MM"
        return year ? `${day}-${month}-${year}` : `${day}-${month}`;
      },
      "Notes": (c) => {
        if (!c.biographies || !Array.isArray(c.biographies)) return "";
        const note = c.biographies.find(bio => bio.value);
        return note ? note.value : "";
      },
      // User-defined fields
      "Custom Field 1 - Type": (c) => c.userDefined?.[0]?.key || "",
      "Custom Field 1 - Value": (c) => c.userDefined?.[0]?.value || "",
      "Custom Field 2 - Type": (c) => c.userDefined?.[1]?.key || "",
      "Custom Field 2 - Value": (c) => c.userDefined?.[1]?.value || "",
      "Custom Field 3 - Type": (c) => c.userDefined?.[2]?.key || "",
      "Custom Field 3 - Value": (c) => c.userDefined?.[2]?.value || "",
    };
  }

  
  /**
   * delete/contacts with ids in the spreadsheet
   */
  deleteContacts() {
    const name = "❌ Delete Contacts";
    const lastUpdated = new Date();
    const ws = this.ss.getSheetByName(this.sheetName.contacts);
    if (!ws) {
      return this.alert(
        `Sheet "${this.sheetName.contacts}" was not found in this spreadsheet!`,
        name,
      );
    }

    const [headers, ...items] = ws.getDataRange().getValues();
    const indexOfSelected = headers.indexOf(this.headerSelected);
    const indexOfContactId = headers.indexOf(this.headerContactId);
    const indexOfEtag = headers.indexOf(this.headerEtag);
    const indexOfLastUpdated = headers.indexOf("Last Updated");
    const indexOfStatus = headers.indexOf("Status");
    const itemsToBeDeleted = items.filter(
      (v) => v[indexOfSelected] && v[indexOfContactId] && v[indexOfEtag],
    );
    const itemsToBeKept = items.filter(
      (v) => !(v[indexOfSelected] && v[indexOfContactId] && v[indexOfEtag]),
    );
    const ids = itemsToBeDeleted.map((v) => v[indexOfContactId]);

    if (ids.length == 0) {
      return this.alert(
        `No contacts to be deleted.
        Only rows with "${this.headerContactId}", "${this.headerEtag}", and checked at column "${this.headerSelected}" will be deleted.`,
        name,
      );
    }

    const confirm = this.confirm(
      `Are you sure you want to delete ${ids.length} contacts with delete checked in sheet "${this.sheetName.contacts}" in your account?

      
      Yes: Delete Them
      No: Cancel & Uncheck Delete Rows
      X: Cancel with Checked Delete Rows
      `,
      name,
    );

    if (confirm === SpreadsheetApp.getUi().Button.NO) {
      ws.getRange(2, indexOfSelected + 1, items.length, 1).setValue(false);
      return this.toast("Cancelled and Unchecked", name);
    }

    if (confirm !== SpreadsheetApp.getUi().Button.YES) {
      return this.toast("Cancelled", name);
    }

    const pageSize = 500;
    for (let i = 0; i < ids.length; i += pageSize) {
      const resourceNames = ids.slice(i, i + pageSize);
      People.People.batchDeleteContacts({ resourceNames });
    }

    itemsToBeDeleted.forEach((item) => {
      item[indexOfSelected] = false;
      if (indexOfContactId > -1) item[indexOfContactId] = "";
      if (indexOfEtag > -1) item[indexOfEtag] = "";
      if (indexOfLastUpdated > -1) item[indexOfLastUpdated] = "";
      if (indexOfStatus > -1) item[indexOfStatus] = "";
    });

    const wsDeleted = this.valuesToSheet(
      [headers, ...itemsToBeDeleted],
      this.sheetName.deletedContacts,
      false,
      true,
    );
    const wsContacts = this.valuesToSheet(
      [headers, ...itemsToBeKept],
      this.sheetName.contacts,
      true,
      true,
    );
    this.formatSheet(
      wsDeleted,
      this.headers.map((v) => v.format),
    );
    this.formatSheet(
      wsContacts,
      this.headers.map((v) => v.format),
    );
    let rowColor = "#830303"; /** set row color red */
    let fontColor = "#fff000"; /** set font color to yellow */
    this.applyColors2(rowColor, fontColor);
    this.updateSortItemsInSettings();
    /**Clips data in Col AH & AJ in Contacts sheet */
    var sheet = this.ss.getSheetByName("Contacts");
    var range1 = sheet.getRange("AH2:AH");
    var range2 = sheet.getRange("AJ2:AJ");
    range1.setWrapStrategy(SpreadsheetApp.WrapStrategy.CLIP);
    range2.setWrapStrategy(SpreadsheetApp.WrapStrategy.CLIP);
    this.toast("Done!", name);
  }
}

const onOpen = (e) => new Spreadsheet().onOpen(e);
//const createContacts = () => new Contact().createContacts();
const getContacts = () => new Contact().getContacts();
const updateContacts = () => new Contact().updateContacts();
const deleteContacts = () => new Contact().deleteContacts();
//const sortContactSheet = () => new Contact().sortContactSheet();
const sheetHeadercolor = () => new Contact().sheetHeadercolor();
const applyColors2 = () => new Contact().applyColors2();
const showUpdatesNotice = () => new Contact().showUpdatesNotice();
const refreshFormatting = () => new Contact().refreshFormatting();
const actionShowRevisions = () =>
    _tryAction_(() => _showRevisions_(REVISIONS), ACTION.REVISIONS.CAPTION);

const updateSortItemsInSettings = () => {
  const title = "Update sort items";
  const ui = _getUi_();
  const confirm = _confirm_(
      `When Fields or Meetings have been added/deleted from Sheets,
      this updates the sort lists on the 'Settings' tab. \n\n
      Proceed?`,
      title,
  );
  if (ui.Button.YES !== confirm) {
    return "Cancelled";
  }

  new Contact().updateSortItemsInSettings();
  _alert_("Lists in the Settings tab have been updated.", title, "Success!");
};
