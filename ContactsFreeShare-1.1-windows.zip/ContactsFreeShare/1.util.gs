/**
 * Get the UI for SpreadsheetApp
 * @returns { GoogleAppsScript.Base.Ui } The Spreadsheet app UI
 */
const _getUi_ = () => SpreadsheetApp.getUi();

/**
 * Show a toast to the active Spreadsheet
 * @param {string} msg The message of the toast
 * @param {string} title The title of the toast
 * @param {number} timeoutInSeconds The timeout seconds of the toast
 * @returns {void}
 */
const _toast_ = (msg, title = "Toast", timeoutInSeconds = 5) =>
  SpreadsheetApp.getActive().toast(msg, title, timeoutInSeconds);

/**
 * Send an alert to the active Spreadsheet
 * @param {string} msg The message of the alert
 * @param {string} title The title of the alert
 * @param {string} type The type of the alert
 * @returns {void}
 */
const _alert_ = (msg, title = "Alert", type = null) => {
  const ui = SpreadsheetApp.getUi();
  if (type) {
    msg = [type, "", msg].join("\n");
  }
  ui.alert(title, msg, ui.ButtonSet.OK);
};

/**
 * Send a confirm dialog to the active Spreadsheet
 * @param {string} msg The message of the confirm dialog
 * @param {string} title The title of the confirm dialog
 * @param {string} type The type of the confirm dialog
 * @returns {GoogleAppsScript.Base.Button} The button user clicked
 */
const _confirm_ = (msg, title = "Confirm") => {
  const ui = SpreadsheetApp.getUi();
  return ui.alert(title, msg, ui.ButtonSet.YES_NO);
};

/**
 * Send a prompt to the active Spreadsheet
 * @param {string} msg The message of the prompt
 * @param {string} title The title of the prompt
 * @param {string} type The type of the prompt
 * @returns {GoogleAppsScript.Base.PromptResponse}
 */
const _prompt_ = (msg, title = "Prompt") => {
  const ui = SpreadsheetApp.getUi();
  return ui.prompt(title, msg, ui.ButtonSet.OK_CANCEL);
};

/**
 * Show the app revisions
 * @param {object[]} revisions A list of revision object
 * @param {object} options The options for the revision
 * @param {number} [options.count=3] The count of revisions
 * @param {string} [options.message=The latest 3 revisions:] The message of revisions
 * @param {string} [options.title=Revisions] The title of revisions
 * @returns {void}
 */
const _showRevisions_ = (revisions, options) => {
  const { count, message, title } = Object.assign(
    {
      count: 3,
      message: "The latest 3 revisions:",
      title: "Revision",
    },
    options,
  );
  const messageLines = revisions.slice(0, count).map(({ date, items }) => {
    return [
      date.toLocaleDateString(),
      ...items.map((item, index) => `${index + 1}. ${item}`),
      "",
    ].join("\n");
  });
  if (message) {
    messageLines.unshift(message + "\n");
  }
  _alert_(messageLines.join("\n"), title);
};

const _getSheetById_ = (sheetId, ss = SpreadsheetApp.getActive()) =>
  ss.getSheets().find((sheet) => sheet.getSheetId() == sheetId);

const _createItem_ = (keys, values) => {
  const item = {};
  keys.forEach((key, index) => key && (item[key] = values[index]));
  return item;
};

const _createKeys_ = (headers) => {
  return headers.map((v) => _toCamelCase_(v));
};

const _groupItemsByKey_ = (items, key) => {
  const group = {};
  items.forEach((item) => {
    const groupKey = item[key].toString().trim();
    if (!groupKey) return;
    if (groupKey in group) {
      return group[groupKey].push(item);
    }
    group[groupKey] = [item];
  });
  return group;
};

const _inchToPoint_ = (inch) => inch * 72;

const _percentage_ = (value, decimal = 0) => {
  return (value * 100).toFixed(decimal) + "%";
};

const _toCamelCase_ = (text) => {
  text = text
    .toString()
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, "");
  return text
    .split(/\s+/)
    .filter((v) => v)
    .map((v, i) => (i == 0 ? v : v.charAt(0).toUpperCase() + v.slice(1)))
    .join("");
};

const _openLink_ = (url, message = "", title = "Open") => {
  const lines = [
    `<div>Click this <a href="${url}" target="_blank">link</a> to open if the tab is open.</div>`,
  ];
  if (message) {
    lines.unshift(`<div>${message}</div>`);
  }
  lines.unshift(
    `<div style="font-size: 14px; font-family: Google Sans,Roboto,RobotoDraft,Helvetica,Arial,sans-serif;">`,
  );
  lines.push(`</div><script>window.open("${url}");</script>`);
  const dialog = HtmlService.createHtmlOutput(lines.join("\n"))
    .setHeight(220)
    .setWidth(220 * 1.7);
  _getUi_().showModalDialog(dialog, title);
};

/**
 * Get the current folder for the Spreadsheet
 * @returns {GoogleAppsScript.Drive.Folder}
 */
const _getCurrentFolder_ = () => {
  const file = DriveApp.getFileById(SpreadsheetApp.getActive().getId());
  const parents = file.getParents();
  if (parents.hasNext()) return parents.next();
  return DriveApp.getRootFolder();
};

/**
 * @param {GoogleAppsScript.Drive.Folder} parent
 * @param {string} name
 * @param {string} createNewIfNotFound
 * @return {GoogleAppsScript.Drive.Folder}
 */
const _getFolderByName_ = (parent, name, createNewIfNotFound = true) => {
  const folders = parent.getFoldersByName(name);
  if (folders.hasNext()) return folders.next();
  if (createNewIfNotFound) {
    return parent.createFolder(name);
  }
};

/**
 * Show the updates in the application
 * @param {object[]} revisions A list of revision object
 * @param {string} [message=We have new updates:] The message of updates
 * @param {string} [title=Updates] The title of updates
 * @returns {void}
 */
const _showUpdates_ = (
  revisions,
  message = "We have new updates:",
  title = "Updates",
) => {
  const key = "revision";
  const userProps = PropertiesService.getUserProperties();
  const lastRevisionNumber = userProps.getProperty(key);
  const currentRevisionNumber = revisions[0].date.getTime();
  if (lastRevisionNumber == currentRevisionNumber) return;
  userProps.setProperty(key, currentRevisionNumber);
  _showRevisions_(revisions, {
    count: 1,
    message,
    title,
  });
};

const _getErrorMessage_ = (error) =>
  error.stack ? error.stack.split("\n").slice(0, 2).join("\n") : error.message;

const _tryAction_ = (action, title = "Action") => {
  try {
    action();
  } catch (error) {
    console.log(error.stack);
    const msg = _getErrorMessage_(error);
    _toast_(msg, title, 0.01);
    _alert_(msg, title, "🟥 Error");
  }
};

const _fillLetters_ =
  (length, fillWith = " ", left = true) =>
  (text) => {
    if (text.length >= length) return text;
    const letters = Array(length - text.length)
      .fill(fillWith)
      .join("");
    return left ? `${letters}${text}` : `${text}${letters}`;
  };

const _splitTextToFixedLength_ =
  (length = 55, fillWith = " ", fillLeft = true) =>
  (text) => {
    const words = text.split(" ");
    const lines = [];
    const fillLetters = _fillLetters_(length, fillWith, fillLeft);
    words.reduce((prev, current, index) => {
      const value = `${prev} ${current}`;
      if (value.length === length) {
        lines.push(value);
        return "";
      }
      if (value.length < length) {
        if (index === words.length - 1) {
          lines.push(fillLetters(value));
        }
        return value;
      }
      if (value.length > length) {
        lines.push(fillLetters(prev));
        if (index === words.length - 1) {
          lines.push(fillLetters(current));
        }
        return current;
      }
    }, "");
    return lines;
  };

const _getUsedRows_ = (body) => {
  return body.getText().split(/[\r\n]/).length;
};

const _getEmptyRows_ =
  (lines = 33) =>
  (rows) => {
    if (rows === 0) return lines;
    const reminder = rows % lines;
    return reminder === 0 ? 0 : lines - reminder;
  };

const _openSidebar_ =
  (filename) =>
  (title, payload = null) => {
    const ui = _getUi_();
    const template = HtmlService.createTemplateFromFile(filename);
    if (payload) {
      Object.entries(payload).forEach(
        ([key, value]) => (template[key] = value),
      );
    }
    const sidebar = template.evaluate().setTitle(title);
    ui.showSidebar(sidebar);
  };

const _getColumnValues_ = (sheet) => (column) => {
  return sheet
    .getDataRange()
    .getValues()
    .map((v) => v[column]);
};

/**
 *@param {GoogleAppsScript.Spreadsheet.Sheet} sheet
 */
function _getItemsFromSheet_(sheet, filter = null) {
  const [headers, ...records] = sheet.getDataRange().getValues();
  const keys = _createKeys_(headers);
  const items = [];
  records.forEach((values, index) => {
    const item = _createItem_(keys, values);
    item.row_ = index + 2;
    if (!filter) return items.push(item);
    filter(item) && items.push(item);
  });
  return items;
}

function compareContactFieldsDetailed(headers, sheetRow, liveContact, fieldMap, ignoreFields = []) {
  const changedFields = [];
  for (let i = 0; i < headers.length; i++) {
    const h = headers[i];
    if (!fieldMap[h] || ignoreFields.includes(h)) continue;
    let sheetVal = (sheetRow[i] == null ? "" : sheetRow[i]).toString().trim();
    let contactVal = (fieldMap[h](liveContact) == null ? "" : fieldMap[h](liveContact)).toString().trim();

    // Special normalization for Birthday (to DD-MM-YYYY)
    if (h === "Birthday") {
      let s = sheetVal.replace(/[\s]/g, "");
      let parts = null;
      if (s.match(/^\d{2}-\d{2}-\d{4}$/)) {
        // Already "DD-MM-YYYY"
        sheetVal = s;
      } else if ((parts = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/))) {
        // "M/D/YYYY" or "DD/MM/YYYY"
        sheetVal =
          `${parts[2].padStart(2, "0")}-` +  // Day
          `${parts[1].padStart(2, "0")}-` +  // Month
          `${parts[3]}`;
      } else if ((parts = s.match(/^(\d{1,2})\/(\d{1,2})$/))) {
        // "M/D" or "DD/MM" (no year)
        sheetVal =
          `${parts[2].padStart(2, "0")}-` +
          `${parts[1].padStart(2, "0")}`;
      }
    }
    if (sheetVal === "" && contactVal === "") continue; // treat all blank as equal
    if (sheetVal !== contactVal) changedFields.push(h);
  }
  // ---- SPECIAL: derived URLs from W/Z/AC vs CONTACT-source urls ----
  try {
    const desired = buildMapUrlsFromRow_(headers, sheetRow);   // [{value,type},...]
    const current = getContactSourceUrls_(liveContact);         // [{value,type},...]

    // If all three GPS cells are blank and there are no current urls, they're equal.
    // Otherwise, compare normalized sets.
    if (!urlsEqual_(desired, current)) {
      changedFields.push("__urls__"); // synthetic marker used by updateContacts()
    }
  } catch (e) {
    // Don't break updates if something goes wrong;
    // Logger.log("URL compare error: " + e);
  }
  return changedFields;
}

// Builds the exact map URLs to store from the current sheet row.
// Uses header names so it’s resilient to column order changes.
function buildMapUrlsFromRow_(headers, row) {
  const a1TypeIdx   = headers.indexOf("Address 1 - Type");
  const a2TypeIdx   = headers.indexOf("Address 2 - Type");
  const a3TypeIdx   = headers.indexOf("Address 3 - Type");
  const a1CoordIdx  = headers.indexOf("Address 1 - Coordinates"); // W
  const a2CoordIdx  = headers.indexOf("Address 2 - Coordinates"); // Z
  const a3CoordIdx  = headers.indexOf("Address 3 - Coordinates"); // AC

  const addrTypes = [
    a1TypeIdx >= 0 ? row[a1TypeIdx] : "Address 1",
    a2TypeIdx >= 0 ? row[a2TypeIdx] : "Address 2",
    a3TypeIdx >= 0 ? row[a3TypeIdx] : "Address 3",
  ];

  const coords = [
    a1CoordIdx >= 0 ? (row[a1CoordIdx] || "").toString().trim() : "",
    a2CoordIdx >= 0 ? (row[a2CoordIdx] || "").toString().trim() : "",
    a3CoordIdx >= 0 ? (row[a3CoordIdx] || "").toString().trim() : "",
  ];

  const urls = [];
  coords.forEach((c, i) => {
    if (!c) return;
    const g = createMapUrl_(c, "google");
    const a = createMapUrl_(c, "apple");
    const type = (addrTypes[i] || `Address ${i + 1}`) || "OTHER";
    urls.push({ value: g, type });
    urls.push({ value: a, type });
  });
  return urls;
}

// Extract only CONTACT-source urls from liveContact and normalize for comparison.
function getContactSourceUrls_(liveContact) {
  const urls = liveContact?.urls || [];
  const contactSource = (liveContact?.metadata?.sources || []).find(s => s.type === "CONTACT");
  const id = contactSource?.id;

  // Keep only CONTACT-source entries (or all if source not present), value non-empty
  const filtered = urls.filter(u => {
    const v = (u?.value || "").toString().trim();
    if (!v) return false;
    const src = u?.metadata?.source;
    // If we have an id, match strictly. If no id metadata exists (rare), include anyway.
    return id ? (src?.type === "CONTACT" && src?.id === id) : true;
  }).map(u => ({ value: u.value, type: u.type || "OTHER" }));

  return normalizeUrlList_(filtered);
}

// Sort + de-dup for stable equality check
function normalizeUrlList_(list) {
  const seen = new Set();
  const out = [];
  list.slice().sort((a, b) => {
    const ta = (a.type || "");
    const tb = (b.type || "");
    if (ta < tb) return -1;
    if (ta > tb) return 1;
    const va = (a.value || "");
    const vb = (b.value || "");
    if (va < vb) return -1;
    if (va > vb) return 1;
    return 0;
  }).forEach(u => {
    const key = `${u.type}||${u.value}`;
    if (!seen.has(key)) { seen.add(key); out.push(u); }
  });
  return out;
}

function urlsEqual_(a, b) {
  const na = normalizeUrlList_(a);
  const nb = normalizeUrlList_(b);
  if (na.length !== nb.length) return false;
  for (let i = 0; i < na.length; i++) {
    if (na[i].type !== nb[i].type || na[i].value !== nb[i].value) return false;
  }
  return true;
}

const _fillBetween_ =
  (max = 66, fillWith = " ") =>
  (start, end = "") => {
    const left = max - start.length - end.length;
    if (left < 0) {
      return `${start}${end}`.slice(0, max);
    }
    return start.padEnd(start.length + left, fillWith) + end;
  };

const _findAllMatches_ = (text, regex) => {
  const indices = [];
  let match;
  const globalRegex = new RegExp(
    regex,
    regex.flags.includes("g") ? regex.flags : regex.flags + "g",
  );

  while ((match = globalRegex.exec(text)) !== null) {
    indices.push(match.index);
  }
  return indices;
};

const getCoordinatesFromWebsites_ = (data) => {
  const results = {};
  if (!data) return results;
  data.forEach(({ type, value }) => {
    if (!value.includes("/?q=")) return;
    const rawCoordinates = value.split("/?q=")[1];
    const parsedCoordinates = parseMap_(decodeURIComponent(rawCoordinates.replace(/\+/g, " ")));
    results[type] = parsedCoordinates.lat && parsedCoordinates.lng
      ? `${parsedCoordinates.lat}, ${parsedCoordinates.lng}`
      : rawCoordinates;
  });
  return results;
};

const cleanMapUrls_ = (urls, addressCoordinates) => {
  if (!Array.isArray(urls)) return [];

  return urls.filter((url) => {
    if (!url.type || !url.value) return false;

    const coord = addressCoordinates[url.type];
    if (!coord) {
      // Coordinate was removed from sheet, so drop this map URL
      return !url.value.includes("maps.google.com") &&
             !url.value.includes("maps.apple.com");
    }
    return true; // Keep valid coordinates
  });
};

/**
   * @param {GoogleAppsScript.Spreadsheet.RichTextValue} richText
   * @param {GoogleAppsScript.Document.Paragraph} paragraph
   */
  const richTextToParagraph_ = (richText, paragraph) => {
    richText.getRuns().forEach((run) => {
      let value = run.getText();
      const style = run.getTextStyle();
      if (!value) return;
      const text = paragraph.appendText(value);
      text.setFontSize(DEFAULT.FONT_SIZE_SMALL);
      text.setBold(style.isBold());
      text.setUnderline(style.isUnderline());
      text.setItalic(style.isItalic());
      text.setStrikethrough(style.isStrikethrough());
    });
  };
  
  const parseMap_ = (url) => {
    const res = /q=([-\d\.]+)\s*,\s*([-\d\.]+)/.exec(url);
    return res ? { lat: res[1], lng: res[2] } : { lat: "", lng: "" };
  };
  
  const createNameLetter_ = (item) => {
    const wifeNameLetter = item.relation1Value.slice(0, 1).toUpperCase();
    const nameLetter = item.givenName.slice(0, 1).toUpperCase();
    if (wifeNameLetter != nameLetter) return nameLetter + " ";
    return (
      item.givenName.charAt(0).toUpperCase() +
      item.givenName.charAt(1).toLowerCase()
    );
  };
  
  const updatePhoneProperties_ = (item) => {
    if (item.phone.length === 0) return;
    item.phone.forEach((phone) => {
      phone.nameLetter = createNameLetter_(item);
      phone.customField3Value = item.customField3Value;
    });
  };
  
  const createContactItem_ = (keys, values, meetings) => {
    const item = {};
    keys.forEach((key, index) => {
    const value =
      typeof values[index] == "string" ? values[index].trim() : values[index];
    const nextValue =
      typeof values[index + 1] == "string"
        ? values[index + 1].trim()
        : values[index + 1];
  
      if (key.endsWith("- Type")) {
        let [_, category, i] = /(.+)\s+(\d+)/.exec(key);
        category = _toCamelCase_(category);
        const { lat, lng } = parseMap_(nextValue);
        const subItem = {
        type: value.toLowerCase(),
          value: nextValue,
          givenName: item.givenName,
          lat,
          lng,
        };
        const isValidSubItem = Boolean(subItem.type || subItem.value);
        if (i == "1") {
          item[category] = isValidSubItem ? [subItem] : [];
        } else {
          isValidSubItem && item[category].push(subItem);
        }
      }
      key = _toCamelCase_(key);
      item[key] = value;
    });
  
    item.title = item[HEADER.ORG_TITLE];
    item.name = item[HEADER.ORG_NAME];
  
    const meetingKey = createMeetingKey_(item.title, item.name);
    const meeting = meetings[meetingKey];
    if (meeting) {
      item.custom = meeting;
    }
  
    item[HEADER.LAST_NAME] = item[HEADER.LAST_NAME].toUpperCase();
    item.firstName = item[HEADER.FIRST_NAME];
    item.lastName = item[HEADER.LAST_NAME];
    item.fullName = [item.firstName, item.lastName].filter((v) => v).join(" ");
    item.hasOnlyOneContact = item.relation.length ? false : true;
    item.lines = 1;
    updatePhoneProperties_(item);
    return item;
  };
  
  const getSpouseContact_ = (contact) => {
    return contact.relation.find((v) => v.type.trim().toLowerCase() == "spouse");
  };
  
  const isFamilyContact_ = (contact, contacts) => {
    const title = contact.fields.toUpperCase();
    const familyName = contact.familyName.toUpperCase();
    const givenName = contact.givenName.toUpperCase();
    const foundFamilyContact = contacts.find((c) => {
      const familyNameToCheck = c.familyName.toUpperCase();
      const titleToCheck = c.fields.toUpperCase();
      if (titleToCheck != title) return false;
      if (familyName != familyNameToCheck) return false;
      const familyNames = c.relation.map((v) => v.value.trim().toUpperCase());
      return familyNames.some(
        (name) => name == givenName || name.includes(givenName),
      );
    });
    if (!foundFamilyContact) return false;
    foundFamilyContact.hasOnlyOneContact = false;
    foundFamilyContact.lines++;
    const contactPhones = contact.phone.filter(
      (item) =>
        foundFamilyContact.phone.some((v) => v.value == item.value) === false,
    );
    if (contactPhones.length) {
      foundFamilyContact.phone = [...foundFamilyContact.phone, ...contactPhones];
    }
    foundFamilyContact.customField3Value = [
      foundFamilyContact.customField3Value,
      contact.customField3Value,
    ]
      .filter((v) => v)
      .join("\n");
    return true;
  };
  
  const isMeetingHome_ = (value) => {
    return /^meeting home$/i.test(value.toString().trim());
  };
  
  const isMeetingHomeAndElder_ = (value) => {
    return /^meeting home\/elder$/i.test(value.toString().trim());
  };
  
  const isMeetingElder_ = (value) => {
    return /^elder$/i.test(value.toString().trim());
  };

const createMeetingKey_ = (title, name) => {
    return [title, name]
      .map((v) => v.toString().trim())
      .join("")
      .toUpperCase();
};
  
const getMeetingType_ = (type) => {
  if (/meeting/i.test(type)) return "meeting";
  if (/field/i.test(type)) return "field";
  if (/more/i.test(type)) return "more";
};

const parseTableValues_ = (value) => {
    return value.split(/\n+/).map((line) => {
      return line.split(/\s\s+/);
    });
  };
  
  /**
   * @param {GoogleAppsScript.Document.Paragraph} p
   * @param {string} text
   */
  const setPhoneHyperlink_ = (p, text) => {
    const match = text.match(/(\d{3}-\d{3}-\d{4})/);
    if (!match) return;
    const phone = match[0];
    const startIndex = match.index;
    const url = `tel:${phone}`;
    p.setLinkUrl(startIndex, startIndex + phone.length - 1, url);
  };
  
  const getContactRequiredRows_ = (lines) => {
    const lineWithAddress = lines.find((v) => v.address);
  
    const addressLines = lineWithAddress
      ? lineWithAddress.address.split("\n").length
      : 1;
    return lines.length + addressLines;
  };

  const fillSpacesBetweenWords_ = (
    start,
    end,
    maxLetters = DEFAULT.LINE_LETTERS,
  ) => {
    const spaces = maxLetters - `${start}${end}`.length;
    if (spaces > 0) {
      return [start, ...Array(spaces).fill(" "), end].join("");
    }
    return [start.slice(0, spaces - 3), "   ", end].join("");
  };

  const getPhoneSuffix_ = (phones) => {
    if (phones.length == 1) {
      return phones.map((v) => v.givenName.slice(0, 1).toUpperCase());
    }
    if (phones.length == 2) {
      const firstNameLetter = phones[0].givenName.slice(0, 1).toUpperCase();
      const secondNameLetter = phones[1].givenName.slice(0, 1).toUpperCase();
      if (firstNameLetter !== secondNameLetter) {
        return [firstNameLetter, secondNameLetter];
      }
      return [phones[0].givenName.slice(0, 2), phones[0].givenName.slice(0, 2)];
    }
    if (phones.length == 3) {
      const [first, second, third] = phones.map((v) => {
        return v.givenName.slice(0, 1).toUpperCase();
      });
      if (first !== second && second !== third) {
        return [first, second, third];
      }
      if (first == second && second == third) {
        return phones.map((v) => v.givenName.slice(0, 2));
      }
      if (first == second) {
        return [
          phones[0].givenName.slice(0, 2),
          phones[1].givenName.slice(0, 2),
          third,
        ];
      }
      if (second == third) {
        return [
          first,
          phones[1].givenName.slice(0, 2),
          phones[2].givenName.slice(0, 2),
        ];
      }
      if (first == third) {
        return [
          phones[0].givenName.slice(0, 2),
          second,
          phones[2].givenName.slice(0, 2),
        ];
      }
    }
    return phones.map((v) => v.givenName.slice(0, 1).toUpperCase());
  };
  
  const createContactLines_ = (item) => {
    const lines = [];
    const splitAndFillRight = _splitTextToFixedLength_(
      DEFAULT.LINE_LETTERS,
      " ",
      false,
    );
  
    if (!item.givenName && (!item.phone || item.phone.length === 0)) {
      return lines;
    }
    const spaces = " ";
  
    const familyName = item.familyName;
  
    let sepParents = " & ";
  
    // new logic for separators
    const rel = item.relation1Type.toLowerCase();
    if (["wife", "husband"].includes(rel)) {
      sepParents = " & ";
    } else if (["children", "son", "daughter", "child"].includes(rel)) {
      sepParents = "; ";
    } else if (
      ["grandchildren", "grandchild", "grandson", "granddaughter"].includes(rel)
    ) {
      sepParents = ": (grandchd) ";
    } else if (rel == "other") {
      sepParents = " - ";
    } else {
      sepParents = "/ " + `${item.relation1Type} `;
    }
    const parents = [item.givenName, item.relation1Value]
      .filter((v) => v)
      .join(sepParents);
  
    const children = item.relation2Value.trim();

  const names = children
    ? `${familyName}, ${parents}; ${children}`
    : `${familyName}, ${parents}`;
  
    const address = [item.address1Formatted, item.customField3Value]
      .filter((v) => v)
      .join("\n");
  
    let addressLines = address.split("\n").filter((v) => v);
    const hasOnlyOneContact = item.hasOnlyOneContact;
  
  const phone =
    item.givenName && item.phone.length === 0
      ? [{ value: DEFAULT.PHONE_PLACEHOLDER + "  " }]
      : [...item.phone];
    phone.map((v, i) => {
      let phoneLetter = v.nameLetter;
      if (v.type == "home") {
        phoneLetter = "  ";
    } else if (v.type == "mobile" && hasOnlyOneContact) {
          phoneLetter = "c ";
    } else if (v.type == "work" && hasOnlyOneContact) {
      phoneLetter = "w";
    } else if (v.type == "work" && item.lines === 1 && i > 0) {
      phoneLetter = `${v.nameLetter.trim()}w`;
    } else if (v.type == item.relation1Value.toLowerCase()) {
      phoneLetter = "Xx"; // for testing
    }
      if (i == 0) {
        const value = [v.value, phoneLetter, names].join(spaces);
        if (value.length <= DEFAULT.LINE_LETTERS) {
          return lines.push({
            value,
            familyName: item.familyName,
          });
        }
        const [firstValue, ...restValues] = splitAndFillRight(value);
        addressLines = [...restValues.map((v) => v.trim()), ...addressLines];
        return lines.push({
          value: firstValue.trim(),
          familyName: item.familyName,
        });
      }
      if (addressLines[i - 1]) {
        const left = [v.value, phoneLetter].join(spaces);
        const right = addressLines[i - 1];
        if (left.length + right.length <= DEFAULT.LINE_LETTERS) {
          return lines.push(fillSpacesBetweenWords_(left, right));
        }
        return lines.push(`${left}${right}`);
      }
      return lines.push([v.value, phoneLetter].join(spaces));
    });
    const restAddressLines = addressLines.slice(phone.length - 1).join("\n");
    lines.push({
      address: restAddressLines,
      map: { google: item.website1Value, apple: item.website2Value },
    });
    return lines;
  };

// ===== Unique phone tag generator for a family/household group =====
function _normUpper_(s) {
  return String(s || "")
    .normalize("NFKC")
    .replace(/\u00A0/g, " ")
    .trim()
    .replace(/\s+/g, " ")
    .toUpperCase();
}

// Build a function that returns a short, unique tag per person in `group`.
// Escalation phases:
// 1) given[0]                       → "D"
// 2) given[0..1]                    → "DR"
// 3) given[0..2]                    → "DRE"
// 4) given[0] + family[0]           → "DB"
// 5) given[0..2] + family[0]        → "DREB"
// 6) grow given-name up to 4 chars  → "DREA"
// 7) final fallback: add 1..N       → "DREA2", "DREA3", ...
function buildPhoneTagFnForGroup_(group) {
  // Normalize once
  const people = group.map((p, i) => ({
    idx: i,
    p,
    g: _normUpper_(p.givenName),
    f: _normUpper_(p.familyName)
  }));

  // Deterministic order (so numeric suffixes are stable)
  people.sort((a, b) => (a.f + "|" + a.g).localeCompare(b.f + "|" + b.g));

  const candidates = (x) => {
    const list = [];
    const g = x.g, f = x.f;
    if (g) {
      list.push(g.slice(0,1));            // D
      list.push(g.slice(0,2));            // DR
      list.push(g.slice(0,3));            // DRE
    }
    if (g && f) {
      list.push(g.slice(0,1) + f.slice(0,1));       // DB
      list.push(g.slice(0,3) + f.slice(0,1));       // DREB
    }
    if (g) {
      list.push(g.slice(0,4));                       // DREA
    }
    // Remove empties/dupes while preserving order
    const seen = new Set(); 
    return list.filter(t => t && !seen.has(t) && (seen.add(t), true));
  };

  const assigned = new Map();         // person.idx -> tag
  const used     = new Map();         // tag -> count

  // Phase-wise assignment
  const phases = [];
  people.forEach(x => phases.push({ x, list: candidates(x), pos: 0 }));

  const take = (want) => {
    const n = (used.get(want) || 0) + 1;
    used.set(want, n);
    return (n === 1) ? want : (want + n); // add numeric suffix if re-used
  };

  // First pass: try each candidate in order; only bump numeric when *still* colliding.
  for (const ph of phases) {
    let tag = ph.list[ph.pos] || (ph.x.g || "X").slice(0,1); // always have something
    // Reserve; if already used, the `take()` will add number (DRE2, etc.)
    tag = take(tag);
    assigned.set(ph.x.idx, tag);
  }

  // Now there can still be duplicates like ("DRE","DRE2") across different persons
  // but they’re already unique strings, so we’re done.

  // Build lookup for fast use in rendering
  const idxToTag = assigned;

  return (person) => {
    // Find this person by normalized names
    const G = _normUpper_(person.givenName);
    const F = _normUpper_(person.familyName);
    const hit = people.find(z => z.g === G && z.f === F);
    if (hit) return idxToTag.get(hit.idx);
    // If the object is a different clone, fall back to its own normalized candidates:
    const tmp = { g: G, f: F };
    const first = candidates(tmp)[0] || (G.slice(0,1) || "X");
    // Ensure we don’t clash with the existing group:
    let tag = first, k = 1;
    while ([...idxToTag.values()].includes(tag)) { k++; tag = first + k; }
    return tag;
  };
}
