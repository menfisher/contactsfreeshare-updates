const apiCreateFieldList = (payload) => {
  payload = JSON.parse(payload);
  payload.twoColumns = true;
  return JSON.stringify(createFieldList_(payload));
};

const apiCreateFieldListNew = (payload) => {
  payload = JSON.parse(payload);
  payload.twoColumns = true;
  return JSON.stringify(createAddressBookNew_(payload));
};
