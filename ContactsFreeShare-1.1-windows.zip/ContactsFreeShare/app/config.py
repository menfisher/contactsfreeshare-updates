from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent
APP_DIR = PROJECT_ROOT / "app"
TEMPLATES_DIR = APP_DIR / "templates"
STATIC_DIR = APP_DIR / "static"
SCHEMA_DIR = PROJECT_ROOT / "db"
SCHEMA_PATH = SCHEMA_DIR / "schema.sql"
MEETING_V2_SCHEMA_PATH = SCHEMA_DIR / "meeting_layout_v2.sql"

APP_TITLE = "Contacts Website"
HOST = "127.0.0.1"
PORT = 8000


def _raise_open_file_limit() -> None:
    if os.name == "nt":
        return
    try:
        import resource

        soft_limit, hard_limit = resource.getrlimit(resource.RLIMIT_NOFILE)
        target = min(max(soft_limit, 4096), hard_limit)
        if target > soft_limit:
            resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard_limit))
    except (ImportError, OSError, ValueError):
        pass


_raise_open_file_limit()


def _truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _default_app_data_dir() -> Path:
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "ContactsFreeShare"
    if os.name == "nt":
        root = os.getenv("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        return Path(root) / "ContactsFreeShare"
    return Path(os.getenv("XDG_DATA_HOME") or (Path.home() / ".local" / "share")) / "ContactsFreeShare"


def _is_portable_build() -> bool:
    return (PROJECT_ROOT / "BUILD_INFO.txt").exists()


def _candidate_app_data_dirs() -> list[Path]:
    candidates: list[Path] = []
    configured = os.getenv("CONTACTSFREESHARE_DATA_DIR")
    if configured:
        candidates.append(Path(configured).expanduser())
    candidates.append(_default_app_data_dir())
    candidates.append(Path.home() / "ContactsFreeShareData")
    candidates.append(PROJECT_ROOT / "runtime")
    candidates.append(Path(tempfile.gettempdir()) / "ContactsFreeShare")

    unique_candidates: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        unique_candidates.append(candidate)
    return unique_candidates


def _select_writable_app_data_dir() -> Path:
    for candidate in _candidate_app_data_dirs():
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            probe = candidate / ".write-test"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink(missing_ok=True)
            return candidate
        except OSError:
            continue
    return _default_app_data_dir()


USE_APP_DATA = _truthy(os.getenv("CONTACTSFREESHARE_USE_APP_DATA")) or _is_portable_build()
APP_DATA_DIR = _select_writable_app_data_dir() if USE_APP_DATA else Path(os.getenv("CONTACTSFREESHARE_DATA_DIR") or _default_app_data_dir()).expanduser()
RUNTIME_ROOT = APP_DATA_DIR if USE_APP_DATA else PROJECT_ROOT
DB_DIR = RUNTIME_ROOT / "db"
IMPORTS_DIR = RUNTIME_ROOT / "imports"
UPLOADS_DIR = RUNTIME_ROOT / "uploads"
DB_PATH = DB_DIR / "app.sqlite3"
ERROR_LOG_PATH = RUNTIME_ROOT / "logs" / "errors.log"


def _load_dotenv() -> None:
    dotenv_paths = [PROJECT_ROOT / ".env"]
    if USE_APP_DATA:
        dotenv_paths.append(APP_DATA_DIR / ".env")

    for dotenv_path in dotenv_paths:
        if not dotenv_path.exists():
            continue
        for raw_line in dotenv_path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value


_load_dotenv()

GOOGLE_OAUTH_CLIENT_ID = os.getenv("GOOGLE_OAUTH_CLIENT_ID", "").strip()
GOOGLE_OAUTH_CLIENT_SECRET = os.getenv("GOOGLE_OAUTH_CLIENT_SECRET", "").strip()
GOOGLE_OAUTH_REDIRECT_URI = os.getenv("GOOGLE_OAUTH_REDIRECT_URI", f"http://{HOST}:{PORT}/google/connect/callback").strip()
