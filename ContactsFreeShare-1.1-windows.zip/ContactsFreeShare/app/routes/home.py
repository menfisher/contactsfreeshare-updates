from urllib.error import HTTPError, URLError

from fastapi import APIRouter, Form, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates

from app.config import TEMPLATES_DIR
from app.services.app_info_service import get_current_app_version
from app.services.app_revision_service import list_app_revisions, save_app_revisions, sync_app_revisions_from_google_drive
from app.services.app_update_service import (
    download_google_drive_update_package,
    get_app_update_status,
    get_update_package,
)
from app.services.changes_list_service import add_changes_entry, list_changes_entries, update_changes_entry
from app.services.contact_service import get_contact_row_colors
from app.services.google_sync_service import (
    can_edit_changes_list,
    get_current_changes_list_initials,
    get_google_sync_summary,
    get_notice_message,
    is_multi_editor_enabled,
)


router = APIRouter()
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
templates.env.globals["app_version"] = get_current_app_version


@router.get("/")
def home():
    target = "/presets/google-connect" if is_multi_editor_enabled() else "/contacts/"
    return RedirectResponse(url=target, status_code=302)


@router.get("/changes-list", response_class=HTMLResponse)
def changes_list(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="changes_list.html",
        context={
            "row_colors": get_contact_row_colors(),
            "entries": list_changes_entries(),
            "google_sync": get_google_sync_summary(),
            "can_edit_changes": can_edit_changes_list(),
        },
    )


@router.post("/changes-list/rows")
def changes_list_add_row():
    if not can_edit_changes_list():
        return JSONResponse(
            {"ok": False, "error": "Sign in before editing the Changes List."},
            status_code=403,
            headers={"Cache-Control": "no-store"},
        )
    entry = add_changes_entry()
    return JSONResponse({"ok": True, "entry": entry}, headers={"Cache-Control": "no-store"})


@router.post("/changes-list/rows/{entry_id}/save")
def changes_list_save_row(
    entry_id: int,
    name_event: str = Form(default=""),
    changes_text: str = Form(default=""),
):
    initials = get_current_changes_list_initials()
    if not initials:
        return JSONResponse(
            {"ok": False, "error": "Sign in before editing the Changes List."},
            status_code=403,
            headers={"Cache-Control": "no-store"},
        )
    entry = update_changes_entry(
        entry_id,
        name_event=name_event,
        changes_text=changes_text,
        initials=initials,
    )
    return JSONResponse({"ok": bool(entry), "entry": entry}, headers={"Cache-Control": "no-store"})


@router.get("/app-revisions", response_class=HTMLResponse)
def app_revisions(
    request: Request,
    notice: str = Query(default=""),
    update_checked: int = Query(default=0),
):
    try:
        google_summary = get_google_sync_summary()
        account = google_summary.get("account") or {}
        if str(account.get("status") or "") == "connected" and bool(account.get("drive_scope_ready")):
            all_revisions = sync_app_revisions_from_google_drive()
        else:
            all_revisions = list_app_revisions(limit=5)
    except (RuntimeError, HTTPError, URLError):
        all_revisions = list_app_revisions(limit=5)
    return templates.TemplateResponse(
        request=request,
        name="app_revisions.html",
        context={
            "row_colors": get_contact_row_colors(),
            "revisions": all_revisions,
            "editor_revisions": all_revisions,
            "notice_message": get_notice_message(notice),
            "update_status": get_app_update_status() if update_checked else None,
        },
    )


@router.post("/app-revisions/save")
async def app_revisions_save(request: Request):
    form = await request.form()
    date_values = form.getlist("new_date_display")
    version_values = form.getlist("new_version")
    description_values = form.getlist("new_description")
    revisions = []
    for index in range(max(len(date_values), len(version_values), len(description_values))):
        revisions.append(
            {
                "date_display": str(date_values[index] if index < len(date_values) else ""),
                "version": str(version_values[index] if index < len(version_values) else ""),
                "description": str(description_values[index] if index < len(description_values) else ""),
            }
        )
    save_app_revisions(revisions)
    return RedirectResponse(url="/app-revisions", status_code=303)


@router.get("/app-revisions/check-updates")
def app_revisions_check_updates(return_to: str = Query(default="/app-revisions")):
    safe_return_to = return_to if return_to.startswith("/") else "/app-revisions"
    try:
        google_summary = get_google_sync_summary()
        account = google_summary.get("account") or {}
        if str(account.get("status") or "") != "connected":
            notice = "drive_not_connected"
        elif not bool(account.get("drive_scope_ready")):
            notice = "drive_scope_missing"
        else:
            sync_app_revisions_from_google_drive()
            notice = "drive_import_success"
    except (RuntimeError, HTTPError, URLError):
        notice = "drive_import_failed"
    separator = "&" if "?" in safe_return_to else "?"
    return RedirectResponse(url=f"{safe_return_to}{separator}notice={notice}", status_code=303)


@router.get("/app-updates/check")
def app_updates_check():
    status = get_app_update_status()
    if not status.get("ok"):
        notice = "app_update_check_failed"
    elif status.get("update_available"):
        notice = "app_update_available"
    else:
        notice = "app_update_current"
    return RedirectResponse(url=f"/app-revisions?update_checked=1&notice={notice}", status_code=303)


@router.get("/app-updates/download/{platform_key}")
def app_updates_download(platform_key: str):
    try:
        package = get_update_package(platform_key)
        download_url = str(package.get("download_url") or "").strip()
        if download_url:
            return RedirectResponse(url=download_url, status_code=303)
        downloaded = download_google_drive_update_package(platform_key)
    except (RuntimeError, HTTPError, URLError, OSError):
        return RedirectResponse(url="/app-revisions?update_checked=1&notice=app_update_download_failed", status_code=303)

    filename = str(downloaded.get("filename") or "ContactsFreeShare-update.zip").replace('"', "")
    mime_type = str(downloaded.get("mime_type") or "application/octet-stream")
    content = downloaded.get("content") or b""
    return Response(
        content=content,
        media_type=mime_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
