from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo

from app.database import get_connection


CHANGES_LIST_TIMEZONE = ZoneInfo("America/Chicago")


def _now_text() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _changes_timestamp(initials: str) -> str:
    now = datetime.now(CHANGES_LIST_TIMEZONE)
    normalized_initials = str(initials or "").strip()
    return f"{normalized_initials}, {now:%m/%d/%Y}, {now:%H:%M}"


def _normalize_stored_timestamp(value: str) -> str:
    parts = [part.strip() for part in str(value or "").split(",")]
    if len(parts) != 3 or "/" not in parts[1]:
        return str(value or "")
    date_parts = parts[1].split("/")
    if len(date_parts) != 3:
        return str(value or "")
    try:
        first = int(date_parts[0])
        second = int(date_parts[1])
    except ValueError:
        return str(value or "")
    if first <= 12:
        return str(value or "")
    return f"{parts[0]}, {second:02d}/{first:02d}/{date_parts[2]}, {parts[2]}"


def _entry_has_content(entry: dict) -> bool:
    return bool(
        str(entry.get("automatic_date") or "").strip()
        or str(entry.get("name_event") or "").strip()
        or str(entry.get("changes_text") or "").strip()
    )


def ensure_changes_list_entries() -> None:
    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS changes_list_entries (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              sort_order INTEGER NOT NULL,
              automatic_date TEXT NOT NULL DEFAULT '',
              name_event TEXT NOT NULL DEFAULT '',
              changes_text TEXT NOT NULL DEFAULT '',
              created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
              updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_changes_list_entries_sort_order
            ON changes_list_entries (sort_order, id)
            """
        )
        blank_rows = conn.execute(
            """
            SELECT id
            FROM changes_list_entries
            WHERE automatic_date = '' AND name_event = '' AND changes_text = ''
            ORDER BY sort_order, id
            """
        ).fetchall()
        for blank_row in blank_rows[1:]:
            conn.execute(
                "DELETE FROM changes_list_entries WHERE id = ?",
                (int(blank_row["id"]),),
            )
        top_row = conn.execute(
            """
            SELECT automatic_date, name_event, changes_text
            FROM changes_list_entries
            ORDER BY sort_order, id
            LIMIT 1
            """
        ).fetchone()
        top_row_has_content = bool(
            top_row
            and (
                str(top_row["automatic_date"] or "").strip()
                or str(top_row["name_event"] or "").strip()
                or str(top_row["changes_text"] or "").strip()
            )
        )
        if top_row_has_content:
            min_row = conn.execute(
                "SELECT COALESCE(MIN(sort_order), 0) AS min_sort_order FROM changes_list_entries"
            ).fetchone()
            next_sort_order = int(min_row["min_sort_order"] or 0) - 1
            conn.execute(
                """
                INSERT INTO changes_list_entries (sort_order)
                VALUES (?)
                """,
                (next_sort_order,),
            )
        elif not top_row:
            conn.execute(
                """
                INSERT INTO changes_list_entries (sort_order)
                VALUES (1)
                """
            )
        dated_rows = conn.execute(
            """
            SELECT id, automatic_date
            FROM changes_list_entries
            WHERE automatic_date != ''
            """
        ).fetchall()
        for dated_row in dated_rows:
            current_value = str(dated_row["automatic_date"] or "")
            normalized_value = _normalize_stored_timestamp(current_value)
            if normalized_value != current_value:
                conn.execute(
                    """
                    UPDATE changes_list_entries
                    SET automatic_date = ?, updated_at = ?
                    WHERE id = ?
                    """,
                    (normalized_value, _now_text(), int(dated_row["id"])),
                )
        conn.commit()


def list_changes_entries() -> list[dict]:
    ensure_changes_list_entries()
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT id, sort_order, automatic_date, name_event, changes_text
            FROM changes_list_entries
            ORDER BY sort_order, id
            """
        ).fetchall()
    return [
        {
            "id": int(row["id"]),
            "sort_order": int(row["sort_order"] or 0),
            "automatic_date": str(row["automatic_date"] or ""),
            "name_event": str(row["name_event"] or ""),
            "changes_text": str(row["changes_text"] or ""),
        }
        for row in rows
    ]


def mark_changes_list_for_drive_export(conn=None) -> None:
    if conn is not None:
        conn.execute(
            """
            UPDATE google_sync_state
            SET changes_list_needs_drive_export = 1, updated_at = ?
            WHERE id = 1
            """,
            (_now_text(),),
        )
        return
    with get_connection() as managed_conn:
        mark_changes_list_for_drive_export(managed_conn)
        managed_conn.commit()


def add_changes_entry() -> dict:
    ensure_changes_list_entries()
    with get_connection() as conn:
        top_row = conn.execute(
            """
            SELECT id, automatic_date, name_event, changes_text
            FROM changes_list_entries
            ORDER BY sort_order, id
            LIMIT 1
            """
        ).fetchone()
        if top_row and not _entry_has_content(dict(top_row)):
            return get_changes_entry(int(top_row["id"]))
        row = conn.execute(
            "SELECT COALESCE(MIN(sort_order), 0) AS min_sort_order FROM changes_list_entries"
        ).fetchone()
        next_sort_order = int(row["min_sort_order"] or 0) - 1
        cursor = conn.execute(
            """
            INSERT INTO changes_list_entries (sort_order, updated_at)
            VALUES (?, ?)
            """,
            (next_sort_order, _now_text()),
        )
        entry_id = int(cursor.lastrowid)
        conn.commit()
    return get_changes_entry(entry_id)


def get_changes_entry(entry_id: int) -> dict:
    ensure_changes_list_entries()
    with get_connection() as conn:
        row = conn.execute(
            """
            SELECT id, sort_order, automatic_date, name_event, changes_text
            FROM changes_list_entries
            WHERE id = ?
            """,
            (int(entry_id),),
        ).fetchone()
    if not row:
        return {}
    return {
        "id": int(row["id"]),
        "sort_order": int(row["sort_order"] or 0),
        "automatic_date": str(row["automatic_date"] or ""),
        "name_event": str(row["name_event"] or ""),
        "changes_text": str(row["changes_text"] or ""),
    }


def update_changes_entry(entry_id: int, *, name_event: str, changes_text: str, initials: str) -> dict:
    ensure_changes_list_entries()
    cleaned_name_event = str(name_event or "").strip()
    cleaned_changes_text = str(changes_text or "").strip()
    cleaned_initials = str(initials or "").strip()
    if not cleaned_initials:
        return {}
    with get_connection() as conn:
        existing = conn.execute(
            """
            SELECT id, automatic_date
            FROM changes_list_entries
            WHERE id = ?
            """,
            (int(entry_id),),
        ).fetchone()
        if not existing:
            return {}
        automatic_date = str(existing["automatic_date"] or "")
        if not automatic_date and (cleaned_name_event or cleaned_changes_text):
            automatic_date = _changes_timestamp(cleaned_initials)
        conn.execute(
            """
            UPDATE changes_list_entries
            SET automatic_date = ?, name_event = ?, changes_text = ?, updated_at = ?
            WHERE id = ?
            """,
            (automatic_date, cleaned_name_event, cleaned_changes_text, _now_text(), int(entry_id)),
        )
        mark_changes_list_for_drive_export(conn)
        conn.commit()
    return get_changes_entry(entry_id)


def export_changes_list_payload() -> list[dict]:
    return list_changes_entries()


def replace_changes_list_from_payload(entries: object) -> bool:
    if not isinstance(entries, list):
        return False
    normalized_entries: list[dict] = []
    for index, item in enumerate(entries, start=1):
        if not isinstance(item, dict):
            continue
        try:
            sort_order = int(item.get("sort_order") or index)
        except (TypeError, ValueError):
            sort_order = index
        normalized_entries.append(
            {
                "sort_order": sort_order,
                "automatic_date": str(item.get("automatic_date") or "").strip(),
                "name_event": str(item.get("name_event") or "").strip(),
                "changes_text": str(item.get("changes_text") or "").strip(),
            }
        )
    normalized_entries = [entry for entry in normalized_entries if _entry_has_content(entry)]
    normalized_entries.insert(
        0,
        {
            "sort_order": 1,
            "automatic_date": "",
            "name_event": "",
            "changes_text": "",
        },
    )
    with get_connection() as conn:
        conn.execute("DELETE FROM changes_list_entries")
        for index, entry in enumerate(normalized_entries, start=1):
            conn.execute(
                """
                INSERT INTO changes_list_entries (
                  sort_order,
                  automatic_date,
                  name_event,
                  changes_text,
                  updated_at
                )
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    int(entry["sort_order"] or index),
                    entry["automatic_date"],
                    entry["name_event"],
                    entry["changes_text"],
                    _now_text(),
                ),
            )
        conn.commit()
    return True
