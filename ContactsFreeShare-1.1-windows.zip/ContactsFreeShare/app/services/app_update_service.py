from __future__ import annotations

import json
import os
import re
import sys
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen

from app.config import APP_DATA_DIR, PROJECT_ROOT
from app.services.app_info_service import get_current_app_version
from app.services.google_sync_service import (
    download_app_update_package_from_google_drive,
    get_google_sync_summary,
    import_app_update_manifest_from_google_drive,
)


MANIFEST_FORMAT = "contactsfreeshare.app_update.v1"
UPDATE_MANIFEST_URL_ENV = "CONTACTSFREESHARE_UPDATE_MANIFEST_URL"
UPDATE_MANIFEST_URL_FILE = PROJECT_ROOT / "UPDATE_MANIFEST_URL"
PLACEHOLDER_MANIFEST_URL_PARTS = ("your-public-host", "example.com")


def _version_parts(version: str) -> list[int | str]:
    parts: list[int | str] = []
    for part in re.split(r"[^A-Za-z0-9]+", str(version or "").strip()):
        if not part:
            continue
        parts.append(int(part) if part.isdigit() else part.lower())
    return parts or [0]


def _compare_versions(left: str, right: str) -> int:
    left_parts = _version_parts(left)
    right_parts = _version_parts(right)
    max_len = max(len(left_parts), len(right_parts))
    for index in range(max_len):
        left_part = left_parts[index] if index < len(left_parts) else 0
        right_part = right_parts[index] if index < len(right_parts) else 0
        if left_part == right_part:
            continue
        if isinstance(left_part, int) and isinstance(right_part, int):
            return 1 if left_part > right_part else -1
        return 1 if str(left_part) > str(right_part) else -1
    return 0


def _current_platform_key() -> str:
    if sys.platform == "darwin":
        return "mac"
    if os.name == "nt":
        return "windows"
    return "other"


def _load_manifest_from_url(url: str) -> dict:
    request = Request(url, headers={"Accept": "application/json"}, method="GET")
    with urlopen(request, timeout=30) as response:
        payload = json.loads(response.read().decode("utf-8"))
    return payload if isinstance(payload, dict) else {}


def _read_dotenv_value(key: str) -> str:
    for dotenv_path in [PROJECT_ROOT / ".env", APP_DATA_DIR / ".env"]:
        try:
            lines = dotenv_path.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        for raw_line in lines:
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            raw_key, raw_value = line.split("=", 1)
            if raw_key.strip() == key:
                return raw_value.strip().strip('"').strip("'")
    return ""


def _is_placeholder_manifest_url(url: str) -> bool:
    normalized_url = str(url or "").strip().lower()
    return any(part in normalized_url for part in PLACEHOLDER_MANIFEST_URL_PARTS)


def _get_public_manifest_url() -> str:
    manifest_url = str(os.getenv(UPDATE_MANIFEST_URL_ENV) or "").strip()
    if manifest_url and not _is_placeholder_manifest_url(manifest_url):
        return manifest_url
    dotenv_manifest_url = _read_dotenv_value(UPDATE_MANIFEST_URL_ENV)
    if dotenv_manifest_url:
        return dotenv_manifest_url
    try:
        return UPDATE_MANIFEST_URL_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def _load_update_manifest() -> tuple[dict, str]:
    manifest_url = _get_public_manifest_url()
    if manifest_url:
        if _is_placeholder_manifest_url(manifest_url):
            raise RuntimeError("Set CONTACTSFREESHARE_UPDATE_MANIFEST_URL to the real public app_update_manifest.json URL before checking for app updates.")
        manifest = _load_manifest_from_url(manifest_url)
        manifest["_manifest_url"] = manifest_url
        return manifest, "url"

    google_summary = get_google_sync_summary()
    account = google_summary.get("account") or {}
    if str(account.get("status") or "") != "connected":
        raise RuntimeError("Connect Google Drive before checking for app updates.")
    if not bool(account.get("drive_scope_ready")):
        raise RuntimeError("Reconnect Google and allow Drive access before checking for app updates.")
    drive_payload = import_app_update_manifest_from_google_drive()
    return dict(drive_payload.get("manifest") or {}), "google_drive"


def normalize_update_manifest(manifest: dict) -> dict:
    manifest_url = str(manifest.get("_manifest_url") or "").strip()
    packages = manifest.get("packages") if isinstance(manifest.get("packages"), dict) else {}
    normalized_packages: dict[str, dict] = {}
    for platform_key, package in packages.items():
        if not isinstance(package, dict):
            continue
        download_url = str(package.get("download_url") or "").strip()
        if download_url and manifest_url:
            download_url = urljoin(manifest_url, download_url)
        normalized_packages[str(platform_key)] = {
            "platform": str(platform_key),
            "label": str(package.get("label") or platform_key).strip(),
            "filename": str(package.get("filename") or "").strip(),
            "file_id": str(package.get("file_id") or "").strip(),
            "download_url": download_url,
            "mime_type": str(package.get("mime_type") or "application/zip").strip(),
        }
    return {
        "format": str(manifest.get("format") or "").strip(),
        "latest_version": str(manifest.get("latest_version") or "").strip(),
        "release_date": str(manifest.get("release_date") or "").strip(),
        "notes": str(manifest.get("notes") or "").strip(),
        "packages": normalized_packages,
    }


def get_app_update_status() -> dict:
    current_version = get_current_app_version()
    platform_key = _current_platform_key()
    try:
        raw_manifest, source = _load_update_manifest()
        manifest = normalize_update_manifest(raw_manifest)
    except (RuntimeError, HTTPError, URLError, OSError, ValueError, json.JSONDecodeError) as exc:
        return {
            "ok": False,
            "source": "",
            "current_version": current_version,
            "latest_version": "",
            "platform": platform_key,
            "update_available": False,
            "packages": {},
            "message": str(exc),
        }

    latest_version = manifest["latest_version"]
    update_available = bool(latest_version) and _compare_versions(latest_version, current_version) > 0
    package = manifest["packages"].get(platform_key) or {}
    return {
        "ok": True,
        "source": source,
        "format": manifest["format"] or MANIFEST_FORMAT,
        "current_version": current_version,
        "latest_version": latest_version,
        "release_date": manifest["release_date"],
        "notes": manifest["notes"],
        "platform": platform_key,
        "current_platform_package": package,
        "packages": manifest["packages"],
        "update_available": update_available,
    }


def get_update_package(platform_key: str) -> dict:
    status = get_app_update_status()
    if not status.get("ok"):
        raise RuntimeError(str(status.get("message") or "App update check failed."))
    packages = status.get("packages") if isinstance(status.get("packages"), dict) else {}
    package = packages.get(str(platform_key or "").strip())
    if not isinstance(package, dict):
        raise RuntimeError("No update package is available for that platform.")
    return package


def download_google_drive_update_package(platform_key: str) -> dict:
    package = get_update_package(platform_key)
    file_id = str(package.get("file_id") or "").strip()
    if not file_id:
        raise RuntimeError("This update package does not have a Google Drive file ID.")
    downloaded = download_app_update_package_from_google_drive(file_id=file_id)
    filename = str(package.get("filename") or "").strip() or str(downloaded.get("filename") or "").strip()
    return {
        **downloaded,
        "filename": filename or "ContactsFreeShare-update.zip",
        "mime_type": str(package.get("mime_type") or downloaded.get("mime_type") or "application/zip"),
    }
