from __future__ import annotations

import json
import math
import re
import base64
import binascii
from html import unescape
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


def _clean(value: object) -> str:
    return str(value or "").strip()


def _pdf_escape(value: object) -> str:
    return str(value or "").replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _safe_filename_part(value: object) -> str:
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", _clean(value))
    return text.strip("_") or "Address_Book"


def address_book_pdf_filename(book_title: str) -> str:
    return f"{_safe_filename_part(book_title)}_{datetime.now().strftime('%Y-%m-%d')}.pdf"


def _sort_key(value: object) -> str:
    return _clean(value).lower()


def _match_key(value: object) -> str:
    return re.sub(r"[^a-z0-9]+", " ", _clean(value).lower()).strip()


def _meeting_heading(meeting_name: str, home_last_name: object = "") -> str:
    home_name = _clean(home_last_name)
    return f"{meeting_name} ({home_name})" if meeting_name and home_name else meeting_name


def _order_payload(raw_json: object) -> dict[str, Any]:
    try:
        payload = json.loads(str(raw_json or "") or "{}")
    except json.JSONDecodeError:
        return {"fields": []}
    return payload if isinstance(payload, dict) else {"fields": []}


def order_address_book_fields(fields: list[dict], mode: str, raw_order_json: object) -> list[dict]:
    copied_fields = [
        {
            **field,
            "meetings": [dict(meeting) for meeting in field.get("meetings", [])],
        }
        for field in fields
    ]
    if mode != "custom":
        for field in copied_fields:
            field["meetings"] = sorted(field.get("meetings", []), key=lambda item: _sort_key(item.get("name")))
        return sorted(copied_fields, key=lambda item: _sort_key(item.get("name")))

    payload = _order_payload(raw_order_json)
    field_orders: dict[str, int] = {}
    meeting_orders: dict[tuple[str, str], int] = {}
    for field_index, field in enumerate(payload.get("fields") or [], start=1):
        if not isinstance(field, dict):
            continue
        field_name = _clean(field.get("name"))
        if not field_name:
            continue
        try:
            field_order = int(field.get("order") or field_index)
        except (TypeError, ValueError):
            field_order = field_index
        field_orders[field_name] = field_order
        for meeting_index, meeting in enumerate(field.get("meetings") or [], start=1):
            if not isinstance(meeting, dict):
                continue
            meeting_name = _clean(meeting.get("name"))
            if not meeting_name:
                continue
            try:
                meeting_order = int(meeting.get("order") or meeting_index)
            except (TypeError, ValueError):
                meeting_order = meeting_index
            meeting_orders[(field_name, meeting_name)] = meeting_order

    for field in copied_fields:
        field_name = _clean(field.get("name"))
        field["meetings"] = sorted(
            field.get("meetings", []),
            key=lambda item: (
                meeting_orders.get((field_name, _clean(item.get("name"))), 1_000_000),
                _sort_key(item.get("name")),
            ),
        )
    return sorted(
        copied_fields,
        key=lambda item: (
            field_orders.get(_clean(item.get("name")), 1_000_000),
            _sort_key(item.get("name")),
        ),
    )


@dataclass
class _PdfLine:
    text: str
    x: float
    y: float
    size: float
    bold: bool = False
    uri: str = ""
    width: float = 0.0
    link_page_index: int | None = None
    link_page_y: float | None = None
    color: tuple[float, float, float] = (0.0, 0.0, 0.0)
    effect: str = ""
    rotate_180: bool = False


def _contrast_pdf_color(color: tuple[float, float, float]) -> tuple[float, float, float]:
    luminance = (0.299 * color[0]) + (0.587 * color[1]) + (0.114 * color[2])
    return (0.0, 0.0, 0.0) if luminance > 0.42 else (1.0, 1.0, 1.0)


def _offset_pdf_color(
    color: tuple[float, float, float],
    amount: float,
) -> tuple[float, float, float]:
    return tuple(min(1.0, max(0.0, channel + amount)) for channel in color)


def _pdf_line_content(line: _PdfLine) -> list[str]:
    font_ref = "/F2" if line.bold else "/F1"
    line_width = line.width or _text_width(line.text, line.size)

    def draw(x_offset: float, y_offset: float, color: tuple[float, float, float]) -> str:
        r, g, b = color
        if line.rotate_180:
            return (
                f"{r:.3f} {g:.3f} {b:.3f} rg BT {font_ref} {line.size:.2f} Tf "
                f"-1 0 0 -1 {line.x + line_width + x_offset:.2f} {line.y + line.size + y_offset:.2f} Tm "
                f"({_pdf_escape(line.text)}) Tj ET"
            )
        return (
            f"{r:.3f} {g:.3f} {b:.3f} rg BT {font_ref} {line.size:.2f} Tf "
            f"1 0 0 1 {line.x + x_offset:.2f} {line.y + y_offset:.2f} Tm "
            f"({_pdf_escape(line.text)}) Tj ET"
        )

    effect = _clean(line.effect).lower()
    if not effect or effect == "none":
        return [draw(0.0, 0.0, line.color)]

    step = max(0.45, min(2.2, line.size * 0.055))
    contrast = _contrast_pdf_color(line.color)
    dark = (0.0, 0.0, 0.0)
    light = (1.0, 1.0, 1.0)
    shadow = tuple(channel * 0.22 for channel in line.color)

    if effect == "outline":
        parts = [
            draw(-step, 0.0, contrast),
            draw(step, 0.0, contrast),
            draw(0.0, -step, contrast),
            draw(0.0, step, contrast),
            draw(-step, -step, contrast),
            draw(step, -step, contrast),
            draw(-step, step, contrast),
            draw(step, step, contrast),
        ]
        parts.append(draw(0.0, 0.0, line.color))
        return parts
    if effect == "shadow":
        return [draw(step * 1.5, -step * 1.5, shadow), draw(0.0, 0.0, line.color)]
    if effect == "embossed":
        return [draw(-step, step, light), draw(step, -step, dark), draw(0.0, 0.0, line.color)]
    if effect == "engraved":
        return [
            draw(-step, step, dark),
            draw(step, -step, light),
            draw(0.0, 0.0, _offset_pdf_color(line.color, -0.08)),
        ]
    if effect == "bevel":
        return [
            draw(-step * 0.8, step * 0.8, light),
            draw(step * 0.9, -step * 0.9, dark),
            draw(step * 1.6, -step * 1.6, shadow),
            draw(0.0, 0.0, line.color),
        ]
    return [draw(0.0, 0.0, line.color)]


@dataclass
class _PdfRule:
    x1: float
    y1: float
    x2: float
    y2: float
    width: float = 0.45


@dataclass
class _PdfImage:
    data: bytes
    pixel_width: int
    pixel_height: int
    x: float
    y: float
    width: float
    height: float
    rotate_180: bool = False


@dataclass
class _PdfPage:
    width: float
    height: float
    lines: list[_PdfLine] = field(default_factory=list)
    rules: list[_PdfRule] = field(default_factory=list)
    images: list[_PdfImage] = field(default_factory=list)


@dataclass
class _TocEntry:
    field_name: str
    meeting_heading: str
    page: int
    is_heading_only: bool = False
    toc_page_index: int = 0
    heading_lines: list[_PdfLine] = field(default_factory=list)


@dataclass
class _IndexEntry:
    name: str
    page: int
    target_y: float = 0.0


class _PdfWriter:
    def __init__(self, width: float, height: float) -> None:
        self.width = width
        self.height = height
        self.pages: list[_PdfPage] = []

    def add_page(self) -> _PdfPage:
        page = _PdfPage(self.width, self.height)
        self.pages.append(page)
        return page

    def bytes(self) -> bytes:
        objects: list[bytes] = []

        def add_object(raw: str | bytes) -> int:
            objects.append(raw.encode("latin-1") if isinstance(raw, str) else raw)
            return len(objects)

        font_regular = add_object("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
        font_bold = add_object("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>")
        page_refs: list[int] = []
        pending_pages: list[tuple[_PdfPage, int, dict[str, int]]] = []
        content_refs: set[int] = set()

        for page in self.pages:
            xobject_refs: dict[str, int] = {}
            for index, image in enumerate(page.images, start=1):
                image_name = f"Im{index}"
                image_ref = add_object(
                    (
                        f"<< /Type /XObject /Subtype /Image /Width {max(1, image.pixel_width)} "
                        f"/Height {max(1, image.pixel_height)} /ColorSpace /DeviceRGB "
                        f"/BitsPerComponent 8 /Filter /DCTDecode /Length {len(image.data)} >>\nstream\n"
                    ).encode("latin-1")
                    + image.data
                    + b"\nendstream"
                )
                xobject_refs[image_name] = image_ref
            content_parts = []
            for index, image in enumerate(page.images, start=1):
                if image.rotate_180:
                    content_parts.append(
                        f"q {-image.width:.2f} 0 0 {-image.height:.2f} "
                        f"{image.x + image.width:.2f} {image.y + image.height:.2f} cm /Im{index} Do Q"
                    )
                else:
                    content_parts.append(
                        f"q {image.width:.2f} 0 0 {image.height:.2f} {image.x:.2f} {image.y:.2f} cm /Im{index} Do Q"
                    )
            for rule in page.rules:
                content_parts.append(
                    f"q {rule.width:.2f} w {rule.x1:.2f} {rule.y1:.2f} m {rule.x2:.2f} {rule.y2:.2f} l S Q"
                )
            for line in page.lines:
                content_parts.extend(_pdf_line_content(line))
            content_ref = add_object("\n".join(content_parts).encode("latin-1", errors="replace"))
            content_refs.add(content_ref)
            page_ref = add_object(b"")
            page_refs.append(page_ref)
            pending_pages.append((page, content_ref, xobject_refs))

        pages_ref = add_object(b"")
        catalog_ref = add_object(f"<< /Type /Catalog /Pages {pages_ref} 0 R >>")

        for page_ref, (page, content_ref, xobject_refs) in zip(page_refs, pending_pages):
            annots: list[int] = []
            for line in page.lines:
                if not line.uri and line.link_page_index is None:
                    continue
                text_width = line.width or _text_width(line.text, line.size)
                rect = f"/Rect [{line.x:.2f} {line.y - 1:.2f} {line.x + text_width:.2f} {line.y + line.size + 1:.2f}] "
                if line.link_page_index is not None:
                    target_index = max(0, min(len(page_refs) - 1, line.link_page_index))
                    target_ref = page_refs[target_index]
                    destination = (
                        f"[{target_ref} 0 R /XYZ null {line.link_page_y:.2f} null]"
                        if line.link_page_y is not None
                        else f"[{target_ref} 0 R /Fit]"
                    )
                    annot = add_object(
                        "<< /Type /Annot /Subtype /Link "
                        f"{rect}/Border [0 0 0] /A << /S /GoTo /D {destination} >> >>"
                    )
                else:
                    annot = add_object(
                        "<< /Type /Annot /Subtype /Link "
                        f"{rect}/Border [0 0 0] /A << /S /URI /URI ({_pdf_escape(line.uri)}) >> >>"
                    )
                annots.append(annot)
            annot_refs = " ".join(f"{item} 0 R" for item in annots)
            xobject_resource = ""
            if xobject_refs:
                xobject_resource = " /XObject << " + " ".join(
                    f"/{name} {ref} 0 R" for name, ref in xobject_refs.items()
                ) + " >>"
            objects[page_ref - 1] = (
                "<< /Type /Page "
                f"/Parent {pages_ref} 0 R "
                f"/MediaBox [0 0 {page.width:.2f} {page.height:.2f}] "
                f"/Resources << /Font << /F1 {font_regular} 0 R /F2 {font_bold} 0 R >>{xobject_resource} >> "
                f"/Contents {content_ref} 0 R "
                f"/Annots [{annot_refs}] >>"
            ).encode("latin-1")

        objects[pages_ref - 1] = (
            f"<< /Type /Pages /Kids [{' '.join(f'{ref} 0 R' for ref in page_refs)}] /Count {len(page_refs)} >>"
        ).encode("latin-1")

        chunks = [b"%PDF-1.4\n"]
        offsets = [0]
        for index, obj in enumerate(objects, start=1):
            offsets.append(sum(len(chunk) for chunk in chunks))
            chunks.append(f"{index} 0 obj\n".encode("latin-1"))
            if index in content_refs:
                chunks.append(f"<< /Length {len(obj)} >>\nstream\n".encode("latin-1"))
                chunks.append(obj)
                chunks.append(b"\nendstream\n")
            else:
                chunks.append(obj)
                chunks.append(b"\n")
            chunks.append(b"endobj\n")
        xref_start = sum(len(chunk) for chunk in chunks)
        chunks.append(f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode("latin-1"))
        for offset in offsets[1:]:
            chunks.append(f"{offset:010d} 00000 n \n".encode("latin-1"))
        chunks.append(
            f"trailer\n<< /Size {len(objects) + 1} /Root {catalog_ref} 0 R >>\nstartxref\n{xref_start}\n%%EOF\n".encode("latin-1")
        )
        return b"".join(chunks)


def _text_width(text: str, size: float) -> float:
    # Helvetica core-font widths in 1/1000 em units for the characters this
    # report commonly uses. Unknown characters fall back to Helvetica's
    # average lowercase width.
    widths = {
        " ": 278, "!": 278, '"': 355, "#": 556, "$": 556, "%": 889, "&": 667, "'": 191,
        "(": 333, ")": 333, "*": 389, "+": 584, ",": 278, "-": 333, ".": 278, "/": 278,
        "0": 556, "1": 556, "2": 556, "3": 556, "4": 556, "5": 556, "6": 556, "7": 556, "8": 556, "9": 556,
        ":": 278, ";": 278, "<": 584, "=": 584, ">": 584, "?": 556, "@": 1015,
        "A": 667, "B": 667, "C": 722, "D": 722, "E": 667, "F": 611, "G": 778, "H": 722, "I": 278,
        "J": 500, "K": 667, "L": 556, "M": 833, "N": 722, "O": 778, "P": 667, "Q": 778, "R": 722,
        "S": 667, "T": 611, "U": 722, "V": 667, "W": 944, "X": 667, "Y": 667, "Z": 611,
        "[": 278, "\\": 278, "]": 278, "^": 469, "_": 556, "`": 333,
        "a": 556, "b": 556, "c": 500, "d": 556, "e": 556, "f": 278, "g": 556, "h": 556, "i": 222,
        "j": 222, "k": 500, "l": 222, "m": 833, "n": 556, "o": 556, "p": 556, "q": 556, "r": 333,
        "s": 500, "t": 278, "u": 556, "v": 500, "w": 722, "x": 500, "y": 500, "z": 500,
        "{": 334, "|": 260, "}": 334, "~": 584,
    }
    return sum(widths.get(char, 556) for char in str(text or "")) * size / 1000.0


def _wrap_text(text: str, size: float, max_width: float) -> list[str]:
    words = _clean(text).split()
    if not words:
        return []
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if current and _text_width(candidate, size) > max_width:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines


def _short_date() -> str:
    return datetime.now().strftime("%m/%d/%Y")


def _map_url(provider: str, coordinates: str) -> str:
    value = re.sub(r"\s*,\s*", ",", _clean(coordinates))
    if not value:
        return ""
    host = "maps.apple.com" if provider == "apple" else "maps.google.com"
    return f"http://{host}/?q={value}"


def _phone_digits(value: object) -> str:
    return re.sub(r"\D", "", str(value or ""))


def _plain_text(value: object) -> str:
    return _clean(unescape(re.sub(r"<[^>]+>", " ", str(value or ""))))


def _html_text_lines(value: object) -> list[str]:
    text = str(value or "")
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</(?:div|p|li)\s*>", "\n", text, flags=re.IGNORECASE)
    lines = [_plain_text(line) for line in text.splitlines()]
    while lines and not lines[-1]:
        lines.pop()
    return lines


def _html_line_count(value: object) -> int:
    return max(1, len(_html_text_lines(value)))


def _meeting_row_line_count(row: dict) -> int:
    kind = _clean(row.get("kind"))
    if kind in {"blank", "divider"}:
        return 1
    if kind == "flow":
        return max([1, *[_html_line_count(column.get("html")) for column in row.get("columns") or []]])
    return max([1, *[_html_line_count(cell.get("html")) for cell in row.get("cells") or []]])


def _meeting_row_chunks(rows: list[dict]) -> list[list[dict]]:
    chunks: list[list[dict]] = []
    table_chunk: list[dict] = []
    in_table = False
    current_group = ""
    grouped_rows: list[dict] = []

    def flush_group() -> None:
        nonlocal current_group, grouped_rows
        if grouped_rows:
            chunks.append(grouped_rows)
        current_group = ""
        grouped_rows = []

    for row in rows:
        group = _clean(row.get("keep_together_group"))
        if group:
            if in_table:
                table_chunk.append(row)
                if bool(row.get("is_table_end_row")):
                    chunks.append(table_chunk)
                    table_chunk = []
                    in_table = False
                continue
            if current_group and group != current_group:
                flush_group()
            current_group = group
            grouped_rows.append(row)
            continue
        flush_group()
        if bool(row.get("is_table_start_row")) and not in_table:
            if table_chunk:
                chunks.append(table_chunk)
            table_chunk = [row]
            in_table = True
            if bool(row.get("is_table_end_row")):
                chunks.append(table_chunk)
                table_chunk = []
                in_table = False
            continue
        if in_table:
            table_chunk.append(row)
            if bool(row.get("is_table_end_row")):
                chunks.append(table_chunk)
                table_chunk = []
                in_table = False
            continue
        chunks.append([row])
        if table_chunk:
            chunks.append(table_chunk)
    flush_group()
    return chunks


def _fit_text(text: str, size: float, max_width: float) -> str:
    value = _clean(text)
    if _text_width(value, size) <= max_width:
        return value
    suffix = "..."
    while value and _text_width(value + suffix, size) > max_width:
        value = value[:-1].rstrip()
    return (value + suffix) if value else suffix


def _index_contact_name(name: object) -> str:
    return _clean(str(name or "").split(";", 1)[0])


def _cover_image_from_data_url(data_url: object, pixel_width: object, pixel_height: object) -> tuple[bytes, int, int] | None:
    raw = str(data_url or "").strip()
    if not raw:
        return None
    match = re.match(r"^data:image/jpeg;base64,(?P<data>[A-Za-z0-9+/=\s]+)$", raw)
    if not match:
        return None
    try:
        image_data = base64.b64decode(re.sub(r"\s+", "", match.group("data")), validate=True)
        width = int(float(pixel_width or 0))
        height = int(float(pixel_height or 0))
    except (ValueError, TypeError, binascii.Error):
        return None
    if not image_data or width <= 0 or height <= 0:
        return None
    return image_data, width, height


def _pdf_color(value: object) -> tuple[float, float, float]:
    text = _clean(value)
    match = re.match(r"^#?([0-9a-fA-F]{6})$", text)
    if not match:
        return (1.0, 1.0, 1.0)
    raw = match.group(1)
    return tuple(int(raw[index:index + 2], 16) / 255.0 for index in (0, 2, 4))


def _cover_title_lines(text: object, size: float, max_width: float) -> list[str]:
    return [line.rstrip() for line in str(text or "").splitlines() if line.strip()]


def _build_toc_pages(
    *,
    entries: list[_TocEntry],
    book_title: str,
    page_width: float,
    page_height: float,
    margin_left: float,
    margin_right: float,
    margin_top: float,
    margin_bottom: float,
    base_font_size: float,
    page_offset: int,
    compact: bool = False,
) -> list[_PdfPage]:
    if not entries:
        return []

    toc_pages: list[_PdfPage] = []
    if compact:
        title_size = base_font_size
        field_size = base_font_size
        item_size = base_font_size
    else:
        title_size = max(base_font_size + 4.0, 12.0)
        field_size = max(base_font_size + 3.0, 10.0)
        item_size = max(base_font_size + 3.0, 10.0)
    line_step = item_size * 1.15
    content_width = page_width - margin_left - margin_right
    title_text = _fit_text(f"{_clean(book_title) or 'Address Book'} - {_short_date()}", title_size, content_width)
    indent = item_size * 1.2
    page_number_width = max(_text_width("888", item_size), item_size * 2.1)
    page_number_x = page_width - margin_right - page_number_width
    item_max_width = max(24.0, page_number_x - margin_left - indent - (item_size * 0.5))
    y = 0.0

    def add_toc_page() -> _PdfPage:
        nonlocal y
        page = _PdfPage(page_width, page_height)
        toc_pages.append(page)
        y = page_height - margin_top
        if len(toc_pages) == 1:
            y -= line_step * 0.85
            title_x = max(margin_left, (page_width - _text_width(title_text, title_size)) / 2)
            page.lines.append(_PdfLine(title_text, title_x, y, title_size, bold=True))
            y -= line_step * 1.7
        else:
            y -= line_step * 1.25
        return page

    def add_footer(page: _PdfPage) -> None:
        text = f"Table of Contents - Page {len(toc_pages)}"
        page.lines.append(
            _PdfLine(
                text,
                x=max(margin_left, (page_width - _text_width(text, item_size)) / 2),
                y=margin_bottom / 2,
                size=item_size,
            )
        )

    page = add_toc_page()
    current_field = ""
    for entry in entries:
        if entry.is_heading_only:
            if y - line_step < margin_bottom:
                add_footer(page)
                page = add_toc_page()
            entry.toc_page_index = len(toc_pages) - 1
            display_page = str(entry.page + page_offset)
            page_text_width = _text_width(display_page, item_size)
            target_page_index = max(0, entry.page + page_offset - 1)
            item_text = _fit_text(entry.meeting_heading, field_size, content_width - page_number_width - item_size)
            item_width = _text_width(item_text, field_size)
            dots_x = margin_left + item_width + (item_size * 0.35)
            dots_width = max(0.0, page_number_x - dots_x - (item_size * 0.5))
            dot_count = max(0, int(dots_width / max(1.0, _text_width(".", item_size))))
            page.lines.append(_PdfLine(item_text, margin_left, y, field_size, bold=True, link_page_index=target_page_index))
            if dot_count:
                page.lines.append(_PdfLine("." * dot_count, dots_x, y, item_size, bold=True, link_page_index=target_page_index))
            page.lines.append(_PdfLine(display_page, page_width - margin_right - page_text_width, y, item_size, link_page_index=target_page_index))
            y -= line_step
            current_field = ""
            continue
        needs_field = bool(entry.field_name) and entry.field_name != current_field
        required_lines = 2 if needs_field else 1
        if y - (required_lines * line_step) < margin_bottom:
            add_footer(page)
            page = add_toc_page()
        if needs_field:
            current_field = entry.field_name
            page.lines.append(_PdfLine(current_field, margin_left, y, field_size, bold=True))
            y -= line_step
        display_page = str(entry.page + page_offset)
        page_text_width = _text_width(display_page, item_size)
        target_page_index = max(0, entry.page + page_offset - 1)
        entry.toc_page_index = len(toc_pages) - 1
        text_x = margin_left + indent
        item_text = _fit_text(entry.meeting_heading, item_size, item_max_width)
        item_width = _text_width(item_text, item_size)
        dots_x = text_x + item_width + (item_size * 0.35)
        dots_width = max(0.0, page_number_x - dots_x - (item_size * 0.5))
        dot_count = max(0, int(dots_width / max(1.0, _text_width(".", item_size))))
        if dot_count:
            page.lines.append(_PdfLine("." * dot_count, dots_x, y, item_size, bold=True, link_page_index=target_page_index))
        page.lines.append(_PdfLine(item_text, text_x, y, item_size, link_page_index=target_page_index))
        page.lines.append(_PdfLine(display_page, page_width - margin_right - page_text_width, y, item_size, link_page_index=target_page_index))
        y -= line_step

    add_footer(page)
    return toc_pages


def _shift_content_footers(pages: list[_PdfPage], page_offset: int) -> None:
    if page_offset <= 0:
        return
    footer_pattern = re.compile(r"^(?P<label>.+ - Page )(?P<page>\d+)$")
    for page in pages:
        for line in page.lines:
            match = footer_pattern.match(line.text)
            if not match or match.group("label") == "Table of Contents - Page ":
                continue
            line.text = f"{match.group('label')}{int(match.group('page')) + page_offset}"
            line.x = max(0.0, (page.width - _text_width(line.text, line.size)) / 2)


def _build_index_pages(
    *,
    entries: list[_IndexEntry],
    page_width: float,
    page_height: float,
    margin_left: float,
    margin_right: float,
    margin_top: float,
    margin_bottom: float,
    base_font_size: float,
    start_page_number: int,
    title_link_page_index: int | None = None,
    compact: bool = False,
) -> list[_PdfPage]:
    if not entries:
        return []

    sorted_entries = sorted(entries, key=lambda item: (_sort_key(item.name), item.page))
    index_pages: list[_PdfPage] = []
    if compact:
        title_size = base_font_size
        letter_size = base_font_size
        item_size = base_font_size
    else:
        title_size = max(base_font_size + 4.0, 12.0)
        letter_size = max(base_font_size + 3.0, 10.0)
        item_size = max(base_font_size + 3.0, 10.0)
    line_step = item_size * 1.15
    content_width = page_width - margin_left - margin_right
    page_number_width = max(_text_width("888", item_size), item_size * 2.1)
    page_number_x = page_width - margin_right - page_number_width
    name_max_width = max(24.0, page_number_x - margin_left - (item_size * 0.5))
    y = 0.0

    def index_page_number() -> int:
        return start_page_number + len(index_pages) - 1

    def add_index_page() -> _PdfPage:
        nonlocal y
        page = _PdfPage(page_width, page_height)
        index_pages.append(page)
        y = page_height - margin_top
        y -= line_step * 0.85
        title = "Index"
        title_x = max(margin_left, (page_width - _text_width(title, title_size)) / 2)
        page.lines.append(_PdfLine(title, title_x, y, title_size, bold=True, link_page_index=title_link_page_index))
        y -= line_step * 1.7
        return page

    def add_footer(page: _PdfPage) -> None:
        text = f"Index - Page {index_page_number()}"
        page.lines.append(
            _PdfLine(
                text,
                x=max(margin_left, (page_width - _text_width(text, item_size)) / 2),
                y=margin_bottom / 2,
                size=item_size,
            )
        )

    page = add_index_page()
    current_letter = ""
    for entry in sorted_entries:
        first_char = (_clean(entry.name)[:1] or "#").upper()
        letter = first_char if first_char.isalpha() else "#"
        needs_letter = letter != current_letter
        required_lines = 2 if needs_letter else 1
        if y - (required_lines * line_step) < margin_bottom:
            add_footer(page)
            page = add_index_page()
        if needs_letter:
            current_letter = letter
            page.lines.append(_PdfLine(letter, margin_left, y, letter_size, bold=True))
            y -= line_step

        display_page = str(entry.page)
        page_text_width = _text_width(display_page, item_size)
        target_page_index = max(0, entry.page - 1)
        name_text = _fit_text(entry.name, item_size, name_max_width)
        name_width = _text_width(name_text, item_size)
        dots_x = margin_left + name_width + (item_size * 0.35)
        dots_width = max(0.0, page_number_x - dots_x - (item_size * 0.5))
        dot_count = max(0, int(dots_width / max(1.0, _text_width(".", item_size))))
        page.lines.append(_PdfLine(name_text, margin_left, y, item_size, link_page_index=target_page_index, link_page_y=entry.target_y))
        if dot_count:
            page.lines.append(_PdfLine("." * dot_count, dots_x, y, item_size, bold=True, link_page_index=target_page_index, link_page_y=entry.target_y))
        page.lines.append(_PdfLine(display_page, page_width - margin_right - page_text_width, y, item_size, link_page_index=target_page_index, link_page_y=entry.target_y))
        y -= line_step

    add_footer(page)
    return index_pages


def _clamp_impose_indices(indices: list[int], total_pages: int) -> list[int]:
    return [index if 0 <= index < total_pages else -1 for index in indices]


def _build_cut_sheet_maps(total_pages: int) -> list[dict[str, list[int]]]:
    padded = int(math.ceil(max(1, total_pages) / 8.0) * 8)
    quarter = padded // 4
    sheets: list[dict[str, list[int]]] = []
    for sheet_index in range(max(1, quarter // 2)):
        front_number = (sheet_index * 2) + 1
        back_number = front_number + 1
        front = [
            front_number - 1,
            front_number + quarter - 1,
            front_number + (2 * quarter) - 1,
            front_number + (3 * quarter) - 1,
        ]
        back = [
            back_number + quarter - 1,
            back_number - 1,
            back_number + (3 * quarter) - 1,
            back_number + (2 * quarter) - 1,
        ]
        sheets.append(
            {
                "front": _clamp_impose_indices(front, total_pages),
                "back": _clamp_impose_indices(back, total_pages),
            }
        )
    return sheets


def _build_booklet_sheet_maps(total_pages: int) -> list[dict[str, list[int]]]:
    padded = int(math.ceil(max(1, total_pages) / 8.0) * 8)
    sheet_count = padded // 8
    quarter = padded // 4
    sheets: list[dict[str, list[int]]] = []

    def norm(page_number: int) -> int:
        return page_number - 1 if 1 <= page_number <= total_pages else -1

    for sheet_index in range(sheet_count):
        left = padded - (2 * sheet_index)
        right = 1 + (2 * sheet_index)
        sheets.append(
            {
                "front": [
                    norm(left),
                    norm(right),
                    norm(left - quarter),
                    norm(right + quarter),
                ],
                "back": [
                    norm(right + 1),
                    norm(left - 1),
                    norm(right + quarter + 1),
                    norm(left - quarter - 1),
                ],
            }
        )
    return sheets


def _letter_positions(page_width: float, page_height: float, *, right_justify: bool) -> list[tuple[float, float]]:
    letter_width = 8.5 * 72.0
    letter_height = 11.0 * 72.0
    block_width = page_width * 2.0
    block_height = page_height * 2.0
    offset_x = max(0.0, letter_width - block_width) if right_justify else 0.0
    top_y = letter_height - page_height
    bottom_y = letter_height - block_height
    return [
        (offset_x, top_y),
        (offset_x + page_width, top_y),
        (offset_x, bottom_y),
        (offset_x + page_width, bottom_y),
    ]


def _draw_cut_marks(page: _PdfPage, slot_width: float, slot_height: float, *, right_justify: bool) -> None:
    letter_width = page.width
    letter_height = page.height
    block_width = slot_width * 2.0
    block_height = slot_height * 2.0
    offset_x = max(0.0, letter_width - block_width) if right_justify else 0.0
    x0 = offset_x
    x1 = offset_x + slot_width
    x2 = offset_x + block_width
    y0 = letter_height
    y1 = letter_height - slot_height
    y2 = letter_height - block_height
    tick = 4.0

    def plus(x: float, y: float) -> None:
        page.rules.append(_PdfRule(x - tick, y, x + tick, y, 0.5))
        page.rules.append(_PdfRule(x, y - tick, x, y + tick, 0.5))

    top_xs = [x0, x1] if right_justify else [x1, x2]
    for x in top_xs:
        plus(x, y0)
    for x in [x0, x1, x2]:
        plus(x, y1)
        plus(x, y2)


BOOKLET_FOLD_GUTTER_PER_SHEET_PT = 0.36
BOOKLET_FOLD_GUTTER_MAX_PT = 8.64


def _booklet_fold_gutter_offset(slot_index: int, sheet_index: int, sheet_count: int) -> float:
    if sheet_count <= 1:
        return 0.0
    outside_sheet_depth = max(0, sheet_count - sheet_index - 1)
    offset = min(BOOKLET_FOLD_GUTTER_MAX_PT, outside_sheet_depth * BOOKLET_FOLD_GUTTER_PER_SHEET_PT)
    if slot_index in {0, 2}:
        return -offset
    return offset


def _clone_page_into_slot(
    dest: _PdfPage,
    source: _PdfPage,
    slot_x: float,
    slot_y: float,
    *,
    rotate_180: bool = False,
    content_offset_x: float = 0.0,
) -> None:
    def rotate_point(x: float, y: float) -> tuple[float, float]:
        return slot_x + source.width - x + content_offset_x, slot_y + source.height - y

    for rule in source.rules:
        if rotate_180:
            x1, y1 = rotate_point(rule.x1, rule.y1)
            x2, y2 = rotate_point(rule.x2, rule.y2)
            dest.rules.append(_PdfRule(x1, y1, x2, y2, rule.width))
        else:
            dest.rules.append(
                _PdfRule(
                    slot_x + rule.x1 + content_offset_x,
                    slot_y + rule.y1,
                    slot_x + rule.x2 + content_offset_x,
                    slot_y + rule.y2,
                    rule.width,
                )
            )

    for image in source.images:
        if rotate_180:
            dest.images.append(
                _PdfImage(
                    image.data,
                    image.pixel_width,
                    image.pixel_height,
                    slot_x + source.width - image.x - image.width + content_offset_x,
                    slot_y + source.height - image.y - image.height,
                    image.width,
                    image.height,
                    rotate_180=not image.rotate_180,
                )
            )
        else:
            dest.images.append(
                _PdfImage(
                    image.data,
                    image.pixel_width,
                    image.pixel_height,
                    slot_x + image.x + content_offset_x,
                    slot_y + image.y,
                    image.width,
                    image.height,
                    rotate_180=image.rotate_180,
                )
            )

    for line in source.lines:
        line_width = line.width or _text_width(line.text, line.size)
        if rotate_180:
            x = slot_x + source.width - line.x - line_width + content_offset_x
            y = slot_y + source.height - line.y - line.size
        else:
            x = slot_x + line.x + content_offset_x
            y = slot_y + line.y
        dest.lines.append(
            _PdfLine(
                text=line.text,
                x=x,
                y=y,
                size=line.size,
                bold=line.bold,
                width=line.width,
                color=line.color,
                effect=line.effect,
                rotate_180=rotate_180 or line.rotate_180,
            )
        )


def _impose_pages_to_letter(pages: list[_PdfPage], binding: str) -> list[_PdfPage]:
    if not pages:
        return []
    mode = _clean(binding).lower()
    if mode not in {"side_spiral", "top_spiral", "stapled_folded"}:
        mode = "side_spiral"
    page_width = pages[0].width
    page_height = pages[0].height
    letter_width = 8.5 * 72.0
    letter_height = 11.0 * 72.0
    positions_front = _letter_positions(page_width, page_height, right_justify=False)
    positions_back = _letter_positions(page_width, page_height, right_justify=True)
    sheet_maps = _build_booklet_sheet_maps(len(pages)) if mode == "stapled_folded" else _build_cut_sheet_maps(len(pages))
    imposed_pages: list[_PdfPage] = []

    sheet_count = len(sheet_maps)
    for sheet_index, sheet_map in enumerate(sheet_maps):
        for side in ("front", "back"):
            sheet = _PdfPage(letter_width, letter_height)
            positions = positions_front if side == "front" else positions_back
            rotate_back = mode == "top_spiral" and side == "back"
            for slot_index, page_index in enumerate(sheet_map[side]):
                if page_index < 0 or page_index >= len(pages):
                    continue
                slot_x, slot_y = positions[slot_index]
                fold_offset_x = _booklet_fold_gutter_offset(slot_index, sheet_index, sheet_count) if mode == "stapled_folded" else 0.0
                _clone_page_into_slot(
                    sheet,
                    pages[page_index],
                    slot_x,
                    slot_y,
                    rotate_180=rotate_back,
                    content_offset_x=fold_offset_x,
                )
            _draw_cut_marks(sheet, page_width, page_height, right_justify=(side == "back"))
            imposed_pages.append(sheet)

    return imposed_pages


def build_address_book_pdf(
    *,
    fields: list[dict],
    meeting_preview_sections: list[dict],
    settings: dict[str, Any],
    layout: dict[str, Any],
    print_order_mode: str,
    print_order_json: str,
    cover_image_data: str = "",
    cover_image_width: int | str = 0,
    cover_image_height: int | str = 0,
    cover_title_enabled: bool = False,
    cover_title_text: str = "",
    cover_title_font_size: int | str = 30,
    cover_title_color: str = "#ffffff",
    cover_title_effect: str = "shadow",
    cover_title_x: int | float | str = 0.5,
    cover_title_y: int | float | str = 0.24,
    cover_title_preview_width: int | float | str = 0,
    cover_date_enabled: bool = False,
    cover_date_text: str = "",
    cover_date_font_size: int | str = 18,
    cover_date_color: str = "#ffffff",
    cover_date_x: int | float | str = 0.5,
    cover_date_y: int | float | str = 0.82,
    paper_book_binding: str = "",
) -> bytes:
    ordered_fields = order_address_book_fields(fields, print_order_mode, print_order_json)
    page_width = max(72.0, float(layout.get("trim_width_in") or 3.5) * 72.0)
    page_height = max(72.0, float(layout.get("trim_height_in") or 5.5) * 72.0)
    margin_left = max(6.0, float(layout.get("margin_left_in") or 0.14) * 72.0)
    margin_right = max(6.0, float(layout.get("margin_right_in") or 0.14) * 72.0)
    margin_top = max(6.0, float(layout.get("margin_top_in") or 0.14) * 72.0)
    margin_bottom = max(6.0, float(layout.get("margin_bottom_in") or 0.14) * 72.0)
    font_size = max(4.0, float(layout.get("base_font_size_pt") or 7.0))
    line_step = font_size * max(0.8, float(layout.get("line_height") or 1.2))
    provider = "apple" if settings.get("address_map_provider") == "apple" else "google"
    address_align_right = settings.get("address_align") != "left"

    writer = _PdfWriter(page_width, page_height)
    page = writer.add_page()
    y = page_height - margin_top
    page_number = 1
    content_width = page_width - margin_left - margin_right
    toc_entries: list[_TocEntry] = []
    index_entries: list[_IndexEntry] = []
    current_toc_entry: _TocEntry | None = None

    def new_page(field_name: str = "", meeting_heading: str = "") -> None:
        nonlocal page, y, page_number
        page_number += 1
        page = writer.add_page()
        y = page_height - margin_top
        if meeting_heading:
            heading_line = add_center(f"{meeting_heading} - (continued)", font_size + 1, bold=True)
            if current_toc_entry:
                current_toc_entry.heading_lines.append(heading_line)
            add_rule()

    def ensure_space(lines_needed: int, field_name: str = "", meeting_heading: str = "") -> None:
        if y - (lines_needed * line_step) < margin_bottom:
            add_footer(field_name)
            new_page(field_name, meeting_heading)

    def add_text(text: str, x: float, *, size: float | None = None, bold: bool = False, uri: str = "") -> None:
        page.lines.append(_PdfLine(text=text, x=x, y=y, size=size or font_size, bold=bold, uri=uri))

    def add_contact_name(text: str, x: float, max_width: float) -> None:
        wrapped = _wrap_text(text, font_size, max_width)
        line = wrapped[0] if wrapped else text
        comma_index = line.find(",")
        if comma_index <= 0:
            add_text(line, x)
            return
        last_name = line[:comma_index]
        rest = line[comma_index:]
        page.lines.append(_PdfLine(text=last_name, x=x, y=y, size=font_size, bold=True))
        page.lines.append(_PdfLine(text=rest, x=x + _text_width(last_name, font_size), y=y, size=font_size))

    def add_center(text: str, size: float, *, bold: bool = False, link_page_index: int | None = None) -> _PdfLine:
        nonlocal y
        x = (page_width - _text_width(text, size)) / 2
        line = _PdfLine(text=text, x=max(margin_left, x), y=y, size=size, bold=bold, link_page_index=link_page_index)
        page.lines.append(line)
        y -= line_step
        return line

    def add_rule() -> None:
        nonlocal y
        page.rules.append(_PdfRule(margin_left, y + (line_step * 0.3), page_width - margin_right, y + (line_step * 0.3)))
        y -= line_step

    def add_footer(field_name: str) -> None:
        text = f"{field_name or 'All Fields'} - Page {page_number}"
        page.lines.append(_PdfLine(text=text, x=max(margin_left, (page_width - _text_width(text, font_size)) / 2), y=margin_bottom / 2, size=font_size, bold=True))

    def add_meeting_preview_row(row: dict) -> None:
        nonlocal y
        kind = _clean(row.get("kind"))
        row_font_size = max(4.0, float(row.get("font_size_pt") or font_size))
        row_line_count = _meeting_row_line_count(row)

        def add_row_underline() -> None:
            if bool(row.get("is_underlined_row")):
                line_y = y - (row_line_count * line_step) + (line_step * 0.75)
                page.rules.append(_PdfRule(margin_left, line_y, page_width - margin_right, line_y))

        if kind == "blank":
            y -= line_step
            return
        if kind == "divider":
            add_rule()
            return
        if kind == "flow":
            grid_width = content_width
            for column in row.get("columns") or []:
                lines = _html_text_lines(column.get("html"))
                if not lines:
                    continue
                col_start = max(1, min(28, int(column.get("col_start") or 1)))
                x = margin_left + ((col_start - 1) / 28.0) * grid_width
                for line_index, text in enumerate(lines):
                    if text:
                        page.lines.append(_PdfLine(text=text, x=x, y=y - (line_index * line_step), size=row_font_size))
            add_row_underline()
            y -= line_step * row_line_count
            return
        for cell in row.get("cells") or []:
            lines = _html_text_lines(cell.get("html"))
            if not lines:
                continue
            col_start = max(1, min(28, int(cell.get("col_start") or 1)))
            col_span = max(1, min(28, int(cell.get("col_span") or 28)))
            cell_width = (col_span / 28.0) * content_width
            x = margin_left + ((col_start - 1) / 28.0) * content_width
            align = _clean(cell.get("align"))
            for line_index, text in enumerate(lines):
                if not text:
                    continue
                line_x = x
                text_width = _text_width(text, row_font_size)
                if align in {"center", "auto"}:
                    line_x += max(0, (cell_width - text_width) / 2)
                elif align == "right":
                    line_x += max(0, cell_width - text_width)
                page.lines.append(_PdfLine(text=text, x=line_x, y=y - (line_index * line_step), size=row_font_size, bold=bool(cell.get("is_bold"))))
                if bool(cell.get("is_underlined")):
                    underline_y = y - (line_index * line_step) - (row_font_size * 0.18)
                    page.rules.append(_PdfRule(line_x, underline_y, line_x + text_width, underline_y, 0.35))
        add_row_underline()
        y -= line_step * row_line_count

    def meeting_rows(field_name: str, meeting_name: str) -> list[dict]:
        selected_field = _match_key(field_name)
        selected_meeting = _match_key(meeting_name)
        for section in meeting_preview_sections:
            meeting_key = _match_key(section.get("meeting"))
            field_key = _match_key(section.get("field"))
            meeting_matches = (
                meeting_key == selected_meeting
                or meeting_key.startswith(selected_meeting)
                or selected_meeting.startswith(meeting_key)
            )
            field_matches = (
                field_key == selected_field
                or (selected_field and field_key.startswith(selected_field))
                or (field_key and selected_field.startswith(field_key))
            )
            if meeting_matches and field_matches:
                return list(section.get("rows") or [])
        for section in meeting_preview_sections:
            meeting_key = _match_key(section.get("meeting"))
            if meeting_key == selected_meeting or meeting_key.startswith(selected_meeting) or selected_meeting.startswith(meeting_key):
                return list(section.get("rows") or [])
        return []

    for field in ordered_fields:
        field_name = _clean(field.get("name"))
        for meeting in field.get("meetings", []):
            meeting_name = _clean(meeting.get("name"))
            heading = _meeting_heading(meeting_name, meeting.get("home_last_name"))
            ensure_space(4, field_name, heading)
            current_toc_entry = _TocEntry(field_name=field_name, meeting_heading=heading, page=page_number)
            toc_entries.append(current_toc_entry)
            heading_line = add_center(heading, font_size + 1, bold=True)
            current_toc_entry.heading_lines.append(heading_line)
            add_rule()
            for contact in meeting.get("contacts", []):
                phones = list(contact.get("phones") or [])
                addresses = list(contact.get("addresses") or [])
                name = _clean(contact.get("name"))
                address_lines: list[tuple[str, str]] = []
                for address in addresses:
                    entry = address if isinstance(address, dict) else {"text": address}
                    uri = _map_url(provider, _clean(entry.get("coordinates"))) if entry.get("has_coordinates") or entry.get("coordinates") else ""
                    for line in _clean(entry.get("text")).splitlines():
                        if line.strip():
                            address_lines.append((line.strip(), uri))
                row_lines = 1 + max(0, len(phones) - 1, len(address_lines))
                ensure_space(row_lines + 1, field_name, heading)
                index_name = _index_contact_name(name)
                if index_name:
                    index_entries.append(_IndexEntry(name=index_name, page=page_number, target_y=min(page_height, y + (font_size * 2.4))))
                phone_x = margin_left
                space_width = _text_width(" ", font_size)
                phone_code_x = phone_x + _text_width("000-000-0000", font_size) + (space_width * 1.5)
                main_text_x = phone_code_x + _text_width("MM", font_size)

                def draw_phone(phone_item: object, *, use_full_custom_label: bool = False) -> None:
                    phone_value = _clean(phone_item.get("value") if isinstance(phone_item, dict) else phone_item)
                    digits = _phone_digits(phone_value)
                    if len(digits) == 10:
                        call_text = f"{digits[:3]}-{digits[3:6]}"
                        text_text = digits[6:]
                        page.lines.append(_PdfLine(call_text, phone_x, y, font_size, uri=f"tel:{digits}", width=_text_width(call_text, font_size)))
                        page.lines.append(_PdfLine("-", phone_x + _text_width(call_text, font_size), y, font_size))
                        page.lines.append(_PdfLine(text_text, phone_x + _text_width(f"{call_text}-", font_size), y, font_size, uri=f"sms:{digits}", width=_text_width(text_text, font_size)))
                    else:
                        add_text(phone_value, phone_x)
                    custom_label = _clean(phone_item.get("custom_label") if isinstance(phone_item, dict) else "")
                    phone_code = custom_label if use_full_custom_label and custom_label else _clean(phone_item.get("code") if isinstance(phone_item, dict) else "")
                    add_text(phone_code, phone_code_x)

                if phones:
                    draw_phone(phones[0])
                name_x = main_text_x
                add_contact_name(name, name_x, max(24, page_width - margin_right - name_x))
                y -= line_step
                for line_index in range(max(0, len(phones) - 1, len(address_lines))):
                    ensure_space(1, field_name, heading)
                    if line_index + 1 < len(phones):
                        draw_phone(phones[line_index + 1], use_full_custom_label=True)
                    if line_index < len(address_lines):
                        line, uri = address_lines[line_index]
                        x = main_text_x
                        if address_align_right:
                            x = max(margin_left, page_width - margin_right - _text_width(line, font_size))
                        add_text(line, x, uri=uri)
                    y -= line_step
                y -= line_step * 0.25
            bible_rows = meeting_rows(field_name, meeting_name)
            if bible_rows:
                bible_chunks = _meeting_row_chunks(bible_rows)
                first_chunk_lines = sum(_meeting_row_line_count(row) for row in bible_chunks[0]) if bible_chunks else 0
                ensure_space(first_chunk_lines + 1, field_name, heading)
                y -= line_step
                for chunk in bible_chunks:
                    chunk_lines = sum(_meeting_row_line_count(row) for row in chunk)
                    no_meeting_association = any(bool(row.get("is_table_start_row")) and bool(row.get("no_meeting_association")) for row in chunk)
                    if no_meeting_association:
                        add_footer(field_name)
                        new_page()
                    ensure_space(chunk_lines, field_name, "" if no_meeting_association else heading)
                    for row in chunk:
                        add_meeting_preview_row(row)
            add_footer(field_name)
            if meeting is not (field.get("meetings") or [])[-1] or field is not ordered_fields[-1]:
                new_page()

    if not writer.pages:
        writer.add_page()
    content_page_count = len(writer.pages)
    cover_image = _cover_image_from_data_url(cover_image_data, cover_image_width, cover_image_height)
    front_page_count = 1 if cover_image else 0
    compact_toc_index = bool(_clean(paper_book_binding))
    index_toc_entry = (
        _TocEntry(field_name="", meeting_heading="Index", page=content_page_count + 1, is_heading_only=True)
        if index_entries
        else None
    )
    all_toc_entries = [*toc_entries, *([index_toc_entry] if index_toc_entry else [])]
    if all_toc_entries:
        toc_pages: list[_PdfPage] = []
        toc_page_count = 0
        for _ in range(4):
            toc_pages = _build_toc_pages(
                entries=all_toc_entries,
                book_title=str(layout.get("book_title") or "Address Book"),
                page_width=page_width,
                page_height=page_height,
                margin_left=margin_left,
                margin_right=margin_right,
                margin_top=margin_top,
                margin_bottom=margin_bottom,
                base_font_size=font_size,
                page_offset=toc_page_count + front_page_count,
                compact=compact_toc_index,
            )
            if len(toc_pages) == toc_page_count:
                break
            toc_page_count = len(toc_pages)
        _shift_content_footers(writer.pages, len(toc_pages) + front_page_count)
        for entry in toc_entries:
            for heading_line in entry.heading_lines:
                heading_line.link_page_index = front_page_count + entry.toc_page_index
        for entry in index_entries:
            entry.page += len(toc_pages) + front_page_count
        index_pages = _build_index_pages(
            entries=index_entries,
            page_width=page_width,
            page_height=page_height,
            margin_left=margin_left,
            margin_right=margin_right,
            margin_top=margin_top,
            margin_bottom=margin_bottom,
            base_font_size=font_size,
            start_page_number=front_page_count + len(toc_pages) + content_page_count + 1,
            title_link_page_index=front_page_count + index_toc_entry.toc_page_index if index_toc_entry else None,
            compact=compact_toc_index,
        )
        cover_pages: list[_PdfPage] = []
        if cover_image:
            image_data, image_width, image_height = cover_image
            cover_page = _PdfPage(page_width, page_height)
            cover_page.images.append(_PdfImage(image_data, image_width, image_height, 0, 0, page_width, page_height))
            if cover_title_enabled:
                try:
                    preview_font_size = min(max(float(cover_title_font_size or 30), 8.0), 120.0)
                except (TypeError, ValueError):
                    preview_font_size = 30.0
                try:
                    preview_width = max(float(cover_title_preview_width or 0), 1.0)
                except (TypeError, ValueError):
                    preview_width = 0.0
                title_size = preview_font_size
                if preview_width > 1:
                    title_size = preview_font_size * (page_width / preview_width)
                title_size = min(max(title_size, 4.0), 72.0)
                title_lines = _cover_title_lines(cover_title_text, title_size, page_width * 0.86)
                title_color = _pdf_color(cover_title_color)
                title_effect = _clean(cover_title_effect).lower()
                if title_effect not in {"outline", "shadow", "embossed", "engraved", "bevel", "none"}:
                    title_effect = "shadow"
                title_step = title_size * 1.18
                try:
                    title_x_ratio = min(max(float(cover_title_x), 0.05), 0.95)
                    title_y_ratio = min(max(float(cover_title_y), 0.05), 0.95)
                except (TypeError, ValueError):
                    title_x_ratio = 0.5
                    title_y_ratio = 0.24
                center_x = page_width * title_x_ratio
                center_y = page_height * (1.0 - title_y_ratio)
                title_y = center_y + (((len(title_lines[:6]) - 1) * title_step) / 2)
                for line_index, title_line in enumerate(title_lines[:6]):
                    line_width = _text_width(title_line, title_size)
                    cover_page.lines.append(
                        _PdfLine(
                            title_line,
                            x=min(max(0.0, center_x - (line_width / 2)), max(0.0, page_width - line_width)),
                            y=title_y - (line_index * title_step),
                            size=title_size,
                            bold=True,
                            color=title_color,
                            effect=title_effect,
                        )
                    )
            if cover_date_enabled and _clean(cover_date_text):
                try:
                    date_preview_font_size = min(max(float(cover_date_font_size or 18), 8.0), 120.0)
                except (TypeError, ValueError):
                    date_preview_font_size = 18.0
                try:
                    preview_width = max(float(cover_title_preview_width or 0), 1.0)
                except (TypeError, ValueError):
                    preview_width = 0.0
                date_size = date_preview_font_size
                if preview_width > 1:
                    date_size = date_preview_font_size * (page_width / preview_width)
                date_size = min(max(date_size, 4.0), 72.0)
                date_text = _fit_text(cover_date_text, date_size, page_width * 0.92)
                date_color = _pdf_color(cover_date_color)
                try:
                    date_x_ratio = min(max(float(cover_date_x), 0.05), 0.95)
                    date_y_ratio = min(max(float(cover_date_y), 0.05), 0.95)
                except (TypeError, ValueError):
                    date_x_ratio = 0.5
                    date_y_ratio = 0.82
                center_x = page_width * date_x_ratio
                center_y = page_height * (1.0 - date_y_ratio)
                line_width = _text_width(date_text, date_size)
                cover_page.lines.append(
                    _PdfLine(
                        date_text,
                        x=min(max(0.0, center_x - (line_width / 2)), max(0.0, page_width - line_width)),
                        y=center_y,
                        size=date_size,
                        bold=True,
                        color=date_color,
                    )
                )
            cover_pages.append(cover_page)
        writer.pages = cover_pages + toc_pages + writer.pages + index_pages
    if _clean(paper_book_binding):
        writer.pages = _impose_pages_to_letter(writer.pages, paper_book_binding)
    return writer.bytes()
