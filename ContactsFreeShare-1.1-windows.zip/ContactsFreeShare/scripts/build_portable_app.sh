#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$ROOT_DIR/dist"
APP_DIR="$BUILD_DIR/ContactsFreeShare"

rm -rf "$APP_DIR"
mkdir -p "$APP_DIR"

rsync -a \
  --exclude '.git' \
  --exclude '.venv' \
  --exclude '__pycache__' \
  --exclude '*.pyc' \
  --exclude '.env' \
  --exclude 'UPDATE_MANIFEST_URL' \
  --exclude 'db/app.sqlite3' \
  --exclude 'db/app.sqlite3-*' \
  --exclude 'db/contacts.db' \
  --exclude 'app/static/uploads' \
  --exclude 'logs' \
  --exclude 'runtime' \
  --exclude 'uploads' \
  --exclude 'dist' \
  "$ROOT_DIR/" "$APP_DIR/"

{
  echo "ContactsFreeShare portable build"
  echo "built_at=$(date '+%Y-%m-%d %H:%M:%S %Z')"
  echo "source_dir=$ROOT_DIR"
} > "$APP_DIR/BUILD_INFO.txt"

cat > "$APP_DIR/Start ContactsFreeShare.command" <<'SCRIPT'
#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi

source ".venv/bin/activate"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python run_contactsfreeshare.py
SCRIPT

chmod +x "$APP_DIR/Start ContactsFreeShare.command"

cat > "$APP_DIR/Start ContactsFreeShare Windows.bat" <<'SCRIPT'
@echo off
setlocal

cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 (
    python -m venv .venv
  )
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python run_contactsfreeshare.py
pause
SCRIPT

APP_VERSION="$(tr -d '[:space:]' < "$ROOT_DIR/APP_VERSION")"
APP_VERSION="${APP_VERSION:-1.0}"
MAC_PACKAGE="ContactsFreeShare-${APP_VERSION}-mac.zip"
WINDOWS_PACKAGE="ContactsFreeShare-${APP_VERSION}-windows.zip"
PUBLIC_MANIFEST_URL="${CONTACTSFREESHARE_UPDATE_MANIFEST_URL:-}"

if [ -n "$PUBLIC_MANIFEST_URL" ]; then
  printf '%s\n' "$PUBLIC_MANIFEST_URL" > "$APP_DIR/UPDATE_MANIFEST_URL"
fi

rm -f "$BUILD_DIR/$MAC_PACKAGE" "$BUILD_DIR/$WINDOWS_PACKAGE"
(cd "$BUILD_DIR" && zip -qr "$MAC_PACKAGE" "ContactsFreeShare")
(cd "$BUILD_DIR" && zip -qr "$WINDOWS_PACKAGE" "ContactsFreeShare")

cat > "$BUILD_DIR/app_update_manifest.example.json" <<SCRIPT
{
  "format": "contactsfreeshare.app_update.v1",
  "latest_version": "$APP_VERSION",
  "release_date": "$(date '+%Y-%m-%d')",
  "notes": "Describe what changed in this release.",
  "packages": {
    "mac": {
      "label": "Mac",
      "filename": "$MAC_PACKAGE",
      "download_url": "$MAC_PACKAGE",
      "file_id": "",
      "mime_type": "application/zip"
    },
    "windows": {
      "label": "Windows",
      "filename": "$WINDOWS_PACKAGE",
      "download_url": "$WINDOWS_PACKAGE",
      "file_id": "",
      "mime_type": "application/zip"
    }
  }
}
SCRIPT

echo "Portable app created at:"
echo "$APP_DIR"
echo "Update packages created at:"
echo "$BUILD_DIR/$MAC_PACKAGE"
echo "$BUILD_DIR/$WINDOWS_PACKAGE"
echo "Manifest template created at:"
echo "$BUILD_DIR/app_update_manifest.example.json"
if [ -n "$PUBLIC_MANIFEST_URL" ]; then
  echo "Public update manifest URL embedded at:"
  echo "$APP_DIR/UPDATE_MANIFEST_URL"
fi
