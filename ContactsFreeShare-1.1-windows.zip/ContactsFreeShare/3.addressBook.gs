/*************************************************
 * BLOCK 1 — SETTINGS / CONSTANTS / FIELD ORDER
 *************************************************/

const SETTINGS = {
  SPREADSHEET_ID: "",
  SPREADSHEET_NAME: "ALMSLA Contacts",
  SN: {
    CONTACTS: "Contacts",
    MEETINGS: "Meetings",
  },
  BOOK: {
    WIDTH: 3.5,
    HEIGHT: 5,
    LETTERS: 66,
    ROWS: 42,
    MARGIN: 0.14,
    SIZE: 7,
    FONT: "Arial",
    ROWS_LARGE: 20,
    LETTERS_LARGE: 33,
    SIZE_LARGE: 14,
  },
  TWO_COLUMN: {
    WIDTH: 7,
    HEIGHT: 10,
    FIRST_PAGE_ROWS: 83,
    ROWS: 87,
  },
  FOLDER: {
    BOOK: "AL MS LA",
    PDF_PHONE: "PDF's - for phone",
    PDF_PHONE_SHARED_NAME: "PDF & Addbook files",
    PDF_PHONE_SHARED_ID: "1FJBkRyh8IPrR8fLJZCJK8X4tkydrRMeI",
    PDF_PRINT: "PDF's - for printing",
    PRINTED_BOOK: "Printed Book",
    FIELD_LIST: "Field List",
  },
  TOC: {
    COVER_FOLDER_PATH: "Cover Pictures",
    COVER_OPACITY: 1,
  },
};

const FIELD_LIST_BASE_FONT_SIZE_PT = 6.5;
const FIELD_LIST_MIN_FONT_SIZE_PT = 6;
const FIELD_LIST_MAX_FONT_SIZE_PT = 8;
const FIELD_LIST_BASE_GROUP_HEADER_SIZE_PT = 7.5;
const FIELD_LIST_BASE_TITLE_SIZE_PT = 10;
const FIELD_LIST_BASE_FOOTER_SIZE_PT = 6.5;
const ADDRESS_BOOK_BASE_FONT_SIZE_PT = 6.5;

const ACTION = {
  CREATE_ADDRESS_BOOK: {
    CAPTION: "Create address book",
    ACTION: "actionCreateAddressBook",
  },
  CREATE_ADDRESS_BOOK_NEW: {
    CAPTION: "Create address book new",
    ACTION: "actionCreateAddressBookNew",
  },
  CREATE_FIELD_LIST: {
    CAPTION: "Create field list",
    ACTION: "actionOpenCreateFieldList",
    TITLE: "Create Field List",
  },
  REVISIONS: {
    CAPTION: "Revisions",
    ACTION: "actionShowRevisions",
  },
};

const HEADER = {
  ORG_TITLE: "fields",
  ORG_NAME: "meetings",
  FIRST_NAME: "givenName",
  LAST_NAME: "familyName",
};

const DEBUG_ROW_RULER = true;

function onEdit(e) {
  if (!e || !e.range) return;

  _safeOnEditStep_(rowHighlightRestore, e);
  _safeOnEditStep_(addTimestamp, e);
  _safeOnEditStep_(clearMeetingDataCacheOnEdit_, e);
  _safeOnEditStep_(updateSettingsOnEdit_, e);
}

function _safeOnEditStep_(fn, e) {
  try {
    fn(e);
  } catch (err) {
    // Ignore errors to avoid breaking onEdit execution.
  }
}

function clearMeetingDataCacheOnEdit_(e) {
  const sheet = e.range.getSheet();
  const sheetName = sheet ? sheet.getName() : "(no sheet)";
  if (!sheet || String(sheetName).trim() !== "MeetingData") return;
  const props = PropertiesService.getScriptProperties();
  props.deleteProperty(MEETINGDATA_CACHE_KEY);
  props.deleteProperty(MEETINGDATA_CACHE_META);
  props.setProperty(MEETINGDATA_CACHE_EDIT, String(Date.now()));
}

function updateSettingsOnEdit_(e) {
  const sheet = e.range.getSheet();
  if (sheet.getName() !== "Settings") return;
  // Only refresh if editing Column B (where colors/values are)
  if (e.range.getColumn() === 2) {
    new Contact().refreshFormatting();
  }
}

function _getActiveSpreadsheet_() {
  let lastErr = null;
  for (let i = 0; i < 2; i++) {
    try {
      return SpreadsheetApp.getActiveSpreadsheet();
    } catch (err) {
      lastErr = err;
      Utilities.sleep(100 * (i + 1));
    }
  }

  const spreadsheetId = _getSpreadsheetId_();
  if (spreadsheetId) {
    try {
      return SpreadsheetApp.openById(spreadsheetId);
    } catch (err) {
      lastErr = err;
    }
  }

  throw new Error(
    "Unable to access the spreadsheet. " +
      (lastErr && lastErr.message ? lastErr.message : lastErr)
  );
}

function _getSpreadsheetId_() {
  if (SETTINGS.SPREADSHEET_ID) return SETTINGS.SPREADSHEET_ID;
  if (SETTINGS.SPREADSHEET_NAME) {
    const namedId = _findFileIdByName_(
      SETTINGS.SPREADSHEET_NAME,
      MimeType.GOOGLE_SHEETS
    );
    if (namedId) return namedId;
  }
  return _getOnlySpreadsheetId_();
}

function _findFileIdByName_(name, expectedMimeType, parentFolderId = "") {
  if (!name) return "";
  let files = null;
  if (parentFolderId) {
    const folder = DriveApp.getFolderById(parentFolderId);
    files = folder.getFilesByName(name);
  } else {
    files = DriveApp.getFilesByName(name);
  }

  while (files.hasNext()) {
    const file = files.next();
    if (!expectedMimeType || file.getMimeType() === expectedMimeType) {
      return file.getId();
    }
  }
  return "";
}

function _getOnlySpreadsheetId_() {
  const files = DriveApp.getFilesByType(MimeType.GOOGLE_SHEETS);
  if (!files.hasNext()) {
    throw new Error(
      "No spreadsheets found. Create one or set SETTINGS.SPREADSHEET_ID/SETTINGS.SPREADSHEET_NAME."
    );
  }
  const first = files.next();
  if (files.hasNext()) {
    throw new Error(
      "Only one spreadsheet can exist. Set SETTINGS.SPREADSHEET_NAME or remove extra sheets."
    );
  }
  return first.getId();
}

function _getTemplateFileId_(templateName) {
  if (!templateName) return "";
  const ss = _getActiveSpreadsheet_();
  const parentFolderId = _getParentFolderSafe_(ss.getId()).getId();
  return _findFileIdByName_(
    templateName,
    MimeType.GOOGLE_DOCS,
    parentFolderId
  );
}

function _getContactsSheet_() {
  const ss = _getActiveSpreadsheet_();
  const sheet = ss.getSheetByName(SETTINGS.SN.CONTACTS);

  if (!sheet) {
    throw new Error(`Contacts sheet "${SETTINGS.SN.CONTACTS}" not found`);
  }
  return sheet;
}

function _getBookTitleWithDate_() {
  const baseTitle = SETTINGS.FOLDER.BOOK;

  const today = new Date();
  const mm = String(today.getMonth() + 1).padStart(2, "0");
  const dd = String(today.getDate()).padStart(2, "0");
  const yyyy = today.getFullYear();

  return `${baseTitle} — ${mm}/${dd}/${yyyy}`;
}

let FIELD_ORDER_MAP_CACHE = null;

function _getFieldOrderMapFromSettings_(settingsSheet) {
  // 🔑 Return cached result if already computed
  if (FIELD_ORDER_MAP_CACHE) {
    return FIELD_ORDER_MAP_CACHE;
  }

  if (!settingsSheet) {
    FIELD_ORDER_MAP_CACHE = {};
    return FIELD_ORDER_MAP_CACHE;
  }

  const lastRow = settingsSheet.getLastRow();
  if (lastRow < 2) {
    FIELD_ORDER_MAP_CACHE = {};
    return FIELD_ORDER_MAP_CACHE;
  }

  // Col D = Field name, Col E = order
  const values = settingsSheet
    .getRange(2, 4, lastRow - 1, 2)
    .getValues();

  const map = Object.create(null); // slightly faster + no prototype keys

  for (let i = 0; i < values.length; i++) {
    const fieldName = values[i][0];
    const order     = values[i][1];

    if (!fieldName) continue;

    const name = String(fieldName).trim();
    if (!name) continue;

    const num = Number(order);
    if (!Number.isNaN(num)) {
      map[name] = num;
    }
  }

  // 🔒 Cache once per execution
  FIELD_ORDER_MAP_CACHE = map;
  return map;
}

function _getMeetingOrderMapFromSettings_(settingsSheet) {
  if (!settingsSheet) return {};

  const lastRow = settingsSheet.getLastRow();
  if (lastRow < 2) return {};

  // Col H = Meeting name, Col I = order
  const values = settingsSheet
    .getRange(2, 8, lastRow - 1, 2)
    .getValues();

  const map = Object.create(null);

  for (let i = 0; i < values.length; i++) {
    const meetingName = values[i][0];
    const order = values[i][1];

    if (!meetingName) continue;
    const key = _normKey_(meetingName);
    if (!key) continue;

    const num = Number(order);
    if (!Number.isNaN(num)) {
      map[key] = num;
    }
  }

  return map;
}

const MEETINGDATA_CACHE_KEY = "MEETINGDATA_INDEX_CACHE";
const MEETINGDATA_CACHE_META = "MEETINGDATA_INDEX_META";
const MEETINGDATA_CACHE_EDIT = "MEETINGDATA_LAST_EDIT";

function _isMeetingDataIndexShapeValid_(index) {
  if (!index || typeof index !== "object") return false;
  const keys = Object.keys(index);
  if (!keys.length) return true;

  for (let i = 0; i < keys.length; i++) {
    const tables = index[keys[i]];
    if (!Array.isArray(tables)) return false;
    if (!tables.length) continue;
    const table = tables[0];
    if (!table) return false;
    if (!Array.isArray(table.rows)) return false;
    if (typeof table.startRow !== "number") return false;
    if (typeof table.realMaxCol !== "number") return false;
  }

  return true;
}

/**
 * Get cached MeetingDataIndex if valid, otherwise rebuild and cache it.
 */
function getMeetingDataIndexCached_() {
  const props = PropertiesService.getScriptProperties();

  const metaRaw  = props.getProperty(MEETINGDATA_CACHE_META);
  const cacheRaw = props.getProperty(MEETINGDATA_CACHE_KEY);

  // ---------- Use cache if valid ----------
  if (metaRaw && cacheRaw) {
    try {
      JSON.parse(metaRaw);
      const cachedIndex = JSON.parse(cacheRaw);
      if (_isMeetingDataIndexShapeValid_(cachedIndex)) {
        return cachedIndex;
      }
    } catch (e) {
      // fall through to rebuild
    }
  }

  // ---------- Rebuild STRUCTURE-ONLY index ----------
  const index = loadAllMeetingDataIndexed_StructureOnly_();

  // ---------- Persist safe cache ----------
  props.setProperty(
    MEETINGDATA_CACHE_META,
    JSON.stringify({ version: Date.now() })
  );
  props.setProperty(
    MEETINGDATA_CACHE_KEY,
    JSON.stringify(index)
  );

  return index;
}

function _getMeetingDataCacheVersion_() {
  const props = PropertiesService.getScriptProperties();
  const metaRaw = props.getProperty(MEETINGDATA_CACHE_META);
  if (!metaRaw) return "unknown";
  try {
    const meta = JSON.parse(metaRaw);
    return String(meta.version || "unknown");
  } catch (err) {
    return "unknown";
  }
}

function _getMeetingDataEditVersion_() {
  const props = PropertiesService.getScriptProperties();
  const raw = props.getProperty(MEETINGDATA_CACHE_EDIT);
  return raw ? String(raw) : "unknown";
}

function _hashCacheKey_(value) {
  const raw = Utilities.computeDigest(
    Utilities.DigestAlgorithm.MD5,
    String(value || "")
  );
  return Utilities.base64EncodeWebSafe(raw);
}

function _parseTableFontSizePtFromFlags_(formatFlags) {
  if (!Array.isArray(formatFlags)) return null;
  for (let i = 0; i < formatFlags.length; i++) {
    const flag = String(formatFlags[i] || "").trim();
    const match = flag.match(/^(\d+(?:\.\d+)?)f$/);
    if (!match) continue;
    const num = Number(match[1]);
    if (!Number.isNaN(num) && num > 0) return num;
  }
  return null;
}

/*************************************************
 * NOTE: depends on getContacts_() + template file existing
 *************************************************/
function menuCreateAddressBooks_() {
  const title = "Create Address Book";
  const sheet = _getContactsSheet_();
  const result = getContacts_(null, sheet);
  const organizations = result.organizations || {};
  const fields = Object.keys(organizations).sort();

  const tpl = HtmlService.createTemplateFromFile("11.CreateAddressBooksDialog");
  tpl.fieldsJson = JSON.stringify(fields);

  const html = tpl.evaluate().setTitle(title).setWidth(360).setHeight(480);
  SpreadsheetApp.getUi().showSidebar(html);
}

function actionOpenCreateFieldList() {
  const title = ACTION.CREATE_FIELD_LIST.TITLE;
  const html = HtmlService.createTemplateFromFile("12.fieldList")
    .evaluate()
    .setTitle(title)
    .setWidth(540)
    .setHeight(480);
  SpreadsheetApp.getUi().showSidebar(html);
}


const splitAddressForCityAndState_ = (address) => {
  const words = address.split(",");
  return [words.slice(0, -2).join(","), words.slice(-2).join(",")];
};

const splitFormattedAddressLines_ = (address) => {
  if (!address || typeof address !== "string") return [];
  return address
    .split(/\r?\n/)
    .map((line) => String(line || "").trim())
    .filter(Boolean);
};

const buildAddressDisplayValue_ = (formattedAddress, addressType, index) => {
  const lines = splitFormattedAddressLines_(formattedAddress);
  if (!lines.length) return "";
  if (addressType && index > 1) {
    lines[0] = `${addressType}: ${lines[0]}`;
  }
  return lines.join("\n");
};

const splitAddress_ = (address, maxLineLength = 50) => {
  if (!address || typeof address !== "string") return [];
  const words = address.split(" ");
  const lines = [];
  let currentLine = "";

  for (const word of words) {
    if (currentLine.length === 0) currentLine = word;
    else if (currentLine.length + 1 + word.length <= maxLineLength) currentLine += " " + word;
    else {
      lines.push(currentLine);
      currentLine = word;
    }
  }
  if (currentLine.length > 0) lines.push(currentLine);
  return lines;
};

/*************************************************
 * BLOCK 3 — SORT + CONTACT LOAD
 *************************************************/

const sortContacts_ = (a, b, settings, ignoreAQ) => {
  const { titleOrders, nameOrders } = settings;

  const titleOrderA = titleOrders[a.fields];
  const titleOrderB = titleOrders[b.fields];

  const hasTOA = titleOrderA !== undefined;
  const hasTOB = titleOrderB !== undefined;
  if (hasTOA && hasTOB && titleOrderA !== titleOrderB) return titleOrderA - titleOrderB;
  if (hasTOA && !hasTOB) return -1;
  if (!hasTOA && hasTOB) return 1;

  if (a.fields > b.fields) return 1;
  if (a.fields < b.fields) return -1;

  const nameKeyA = `${a.fields}:${a.meetings}`;
  const nameKeyB = `${b.fields}:${b.meetings}`;
  const nameOrderA = nameOrders[nameKeyA];
  const nameOrderB = nameOrders[nameKeyB];

  const hasNOA = nameOrderA !== undefined;
  const hasNOB = nameOrderB !== undefined;
  if (hasNOA && hasNOB && nameOrderA !== nameOrderB) return nameOrderA - nameOrderB;
  if (hasNOA && !hasNOB) return -1;
  if (!hasNOA && hasNOB) return 1;

  if (a.meetings > b.meetings) return 1;
  if (a.meetings < b.meetings) return -1;

  if (!ignoreAQ) {
    const aqA = a.mtgHome1elder2 || "";
    const aqB = b.mtgHome1elder2 || "";
    if (aqA === "" && aqB !== "") return 1;
    if (aqA !== "" && aqB === "") return -1;
    if (aqA > aqB) return 1;
    if (aqA < aqB) return -1;
  }

  if (a.familyName > b.familyName) return 1;
  if (a.familyName < b.familyName) return -1;

  if (a.givenName === b.givenName) return 0;
  if (a.givenName === "") return 1;
  if (b.givenName === "") return -1;
  return a.givenName > b.givenName ? 1 : -1;
};

const CONTACTS_CACHE = new Map();
let SETTINGS_CACHE = null;

function getSettingsCached_() {
  if (SETTINGS_CACHE) return SETTINGS_CACHE;
  SETTINGS_CACHE = new Spreadsheet().getSettings();
  return SETTINGS_CACHE;
}

function getContacts_(orgs, sheet) {
  if (!sheet) {
    throw new Error(`Contacts sheet not provided`);
  }

  const cacheKey = `${sheet.getSheetId()}::${orgs ? orgs.join("|") : "__ALL__"}`;
  const cached = CONTACTS_CACHE.get(cacheKey);
  if (cached) return cached;

  const [headers, ...records] = sheet.getDataRange().getValues();
  const keys = _createKeys_(headers);
  const data = {};
  const organizations = {};
  const orgMeetingSets = {};
  const settings = getSettingsCached_();
  const orgSet = orgs ? new Set(orgs) : null;

  records.forEach((values, index) => {
    const item = _createItem_(keys, values);

    const gn = String(item.givenName || "").trim();
    const letters = gn.replace(/[^A-Za-z]/g, "");
    item.givenNameAllCaps =
      !!letters && letters === letters.toUpperCase() && letters !== letters.toLowerCase();

    if (orgSet && !orgSet.has(item.fields)) return;

    const { fields, meetings, address1Formatted } = item;
    item._fieldsKey = _normKey_(fields);
    item._meetingsKey = _normKey_(meetings);
    item.groupby = `${fields}, ${meetings}`;
    item.meetingKey = `${fields}${meetings}`;

    let meetingSet = orgMeetingSets[fields];
    if (!meetingSet) {
      meetingSet = new Set();
      orgMeetingSets[fields] = meetingSet;
    }
    meetingSet.add(meetings);

    if (!data[item.groupby]) data[item.groupby] = {};
    if (!data[item.groupby][address1Formatted]) {
      data[item.groupby][address1Formatted] = [];
    }

    data[item.groupby][address1Formatted].push(item);
  });

  Object.keys(orgMeetingSets).forEach((field) => {
    organizations[field] = Array.from(orgMeetingSets[field]);
  });

  const result = { contacts: data, organizations };
  CONTACTS_CACHE.set(cacheKey, result);
  return result;
}

/*************************************************
 * BLOCK 4 — SIDEBAR ENTRYPOINTS (CLEANED)
 * REMOVED: createAddressBookFromSidebar (Doc address book path)
 *************************************************/

function getAllFieldsForAddressBook() {
  const ss = _getActiveSpreadsheet_();
  const contactsSheet = ss.getSheetByName(SETTINGS.SN.CONTACTS);
  const settingsSheet = ss.getSheetByName("Settings");

  if (!contactsSheet) {
    throw new Error(`Contacts sheet "${SETTINGS.SN.CONTACTS}" not found`);
  }

  const driveFile = DriveApp.getFileById(ss.getId());
  const cacheKey = _getFieldsCacheKey_(driveFile, contactsSheet);
  const cachedFields = _getCachedFields_(cacheKey);
  if (cachedFields) return cachedFields;

  const { organizations } = getContacts_(null, contactsSheet);
  const fields = Object.keys(organizations || {});

  const orderMap = _getFieldOrderMapFromSettings_(settingsSheet);

  fields.sort((a, b) => {
    const oa = orderMap[a];
    const ob = orderMap[b];
    const hasA = typeof oa === "number";
    const hasB = typeof ob === "number";
    if (hasA && hasB && oa !== ob) return oa - ob;
    if (hasA && !hasB) return -1;
    if (!hasA && hasB) return 1;
    return a.localeCompare(b);
  });

  _setCachedFields_(cacheKey, fields);
  return fields;
}

function getMeetingsForField(fieldName) {
  const field = String(fieldName || "").trim();
  if (!field) return [];

  const ss = _getActiveSpreadsheet_();
  const contactsSheet = ss.getSheetByName(SETTINGS.SN.CONTACTS);
  if (!contactsSheet) {
    throw new Error(`Contacts sheet "${SETTINGS.SN.CONTACTS}" not found`);
  }

  const { organizations } = getContacts_(null, contactsSheet);
  const meetings = (organizations && organizations[field]) ? organizations[field].slice() : [];
  if (!meetings.length) return [];

  const settingsSheet = ss.getSheetByName("Settings");
  const meetingOrderMap = _getMeetingOrderMapFromSettings_(settingsSheet);
  meetings.sort((a, b) => {
    const ka = _normKey_(a);
    const kb = _normKey_(b);
    const oa = meetingOrderMap[ka];
    const ob = meetingOrderMap[kb];
    const hasA = typeof oa === "number";
    const hasB = typeof ob === "number";
    if (hasA && hasB && oa !== ob) return oa - ob;
    if (hasA && !hasB) return -1;
    if (!hasA && hasB) return 1;
    return String(a).localeCompare(String(b));
  });

  return meetings;
}

function getCoverPictureFiles() {
  try {
    const folder = _getCoverFolder_();
    if (!folder) {
      console.warn("Cover folder not found.");
      return [];
    }

    const files = folder.getFiles();
    const imageFiles = [];
    while (files.hasNext()) {
      const file = files.next();
      if (file.getMimeType().startsWith("image/")) {
        imageFiles.push(file.getName());
      }
    }
    return imageFiles.sort();
  } catch (e) {
    console.error("Error getting cover pictures: " + e);
    return [];
  }
}

function createAddressBookHtmlFromSidebar(options) {
  const requestId = options && options.requestId ? String(options.requestId) : Utilities.getUuid();

  if (options && options.printMode === "print" && !options.fontSizePt) {
    PropertiesService.getScriptProperties().setProperty(
      "ADDRESS_BOOK_BUILD_STATUS",
      JSON.stringify({
        state: "running",
        requestId: requestId,
        message: "Waiting for print settings..."
      })
    );
    _showPrintFontSizeDialog_(options, requestId);
    return { state: "running", requestId: requestId };
  }

  const built = _buildCreateAddressBookPayloadFromSidebar_(options);
  if (built.error) return built.error;

  built.payload.outputFolderName = built.payload.printPaperBook
    ? SETTINGS.FOLDER.PDF_PRINT
    : SETTINGS.FOLDER.PDF_PHONE;

  return _runAddressBookBuildDirect_(built.payload, requestId);
}

function _showPrintFontSizeDialog_(options, requestId) {
  options.requestId = requestId;
  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <base target="_top">
      <style>
        body { font-family: Arial, sans-serif; padding: 12px; text-align: center; }
        .btn { background: #4285f4; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-size: 14px; margin: 0 5px; }
        .btn:hover { background: #357abd; }
        .btn:disabled { background: #ccc; cursor: default; }
        .btn.cancel { background: #f44336; }
        .btn.cancel:hover { background: #d32f2f; }
        .btn.cancel:disabled { background: #ccc; }
        input { padding: 6px; width: 80px; font-size: 14px; text-align: center; }
        p { margin-bottom: 15px; font-size: 14px; }
      </style>
    </head>
    <body>
      <p>Enter font size for print (pt):</p>
      <input type="number" id="fontSize" value="6.5" step="0.1" min="4" max="14">
      <br><br>
      <button id="btnCreate" class="btn" onclick="submit()">Create PDF</button>
      <button id="btnCancel" class="btn cancel" onclick="google.script.host.close()">Cancel</button>
      <script>
        var originalOptions = ${JSON.stringify(options)};
        function submit() {
          var btnCreate = document.getElementById('btnCreate');
          var btnCancel = document.getElementById('btnCancel');
          btnCreate.disabled = true;
          btnCancel.disabled = true;
          btnCreate.textContent = "Creating...";

          var size = parseFloat(document.getElementById('fontSize').value) || 6.5;
          originalOptions.fontSizePt = size;
          google.script.run
            .withSuccessHandler(function() { google.script.host.close(); })
            .withFailureHandler(function(err) {
               var msg = String(err);
               // Suppress "NetworkError: Connection failure due to HTTP 0"
               if (msg.indexOf("NetworkError") >= 0 && msg.indexOf("HTTP 0") >= 0) {
                 google.script.host.close();
                 return;
               }
               btnCreate.disabled = false;
               btnCancel.disabled = false;
               btnCreate.textContent = "Create PDF";
               alert("Error: " + err);
            })
            .createAddressBookHtmlFromSidebar(originalOptions);
        }
      </script>
    </body>
    </html>
  `;
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutput(htmlContent).setWidth(300).setHeight(200), "Print Settings");
}

function startPrintBookImpositionFromSidebar(options) {
  const requestId = options && options.requestId ? String(options.requestId) : "";
  _showImposeChoiceDialog_(requestId);
  return "Choose imposition.";
}

function _getFieldsCacheKey_(driveFile, contactsSheet) {
  const lastUpdated = driveFile.getLastUpdated().getTime();
  return [
    "FIELDS_CACHE",
    contactsSheet.getSheetId(),
    lastUpdated
  ].join(":");
}

function _getCachedFields_(cacheKey) {
  const cache = CacheService.getScriptCache();
  const cached = cache.get(cacheKey);
  if (!cached) return null;
  try {
    return JSON.parse(cached);
  } catch (err) {
    return null;
  }
}

function _setCachedFields_(cacheKey, fields) {
  try {
    CacheService.getScriptCache().put(
      cacheKey,
      JSON.stringify(fields || []),
      21600
    );
  } catch (err) {
    // Cache failures should not block field loading.
  }
}

function _runAddressBookBuildDirect_(payload, requestId) {
  const statusKey = "ADDRESS_BOOK_BUILD_STATUS";
  const props = PropertiesService.getScriptProperties();
  const lock = LockService.getScriptLock();

  if (!lock.tryLock(30000)) {
    throw new Error("System busy. Please try again.");
  }

  try {
    const existing = _readAddressBookBuildStatus_(props);
    if (existing && existing.requestId === requestId && existing.state === "done") {
      return existing;
    }

    props.setProperty(
      statusKey,
      JSON.stringify({
        state: "running",
        requestId,
        startedAt: new Date().toISOString()
      })
    );

    payload.showPdfOutput = true;
    payload.showHtmlOutput = false;
    let pdfFile;
    let lastErr;
    for (let i = 0; i < 3; i++) {
      try {
        pdfFile = createAddressBookHtml_(payload);
        break;
      } catch (err) {
        lastErr = err;
        console.warn(`Address Book creation attempt ${i + 1} failed: ${err.message}`);
        Utilities.sleep(3000);
      }
    }
    if (!pdfFile) throw lastErr;
    const done = {
      state: "done",
      requestId,
      finishedAt: new Date().toISOString(),
      pdfFileId: pdfFile && pdfFile.getId ? pdfFile.getId() : null,
      pdfFileName: pdfFile && pdfFile.getName ? pdfFile.getName() : null
    };
    props.setProperty(statusKey, JSON.stringify(done));
    return done;
  } catch (err) {
    props.setProperty(
      statusKey,
      JSON.stringify({
        state: "error",
        requestId,
        finishedAt: new Date().toISOString(),
        message: err && err.message ? err.message : String(err)
      })
    );
    throw err;
  } finally {
    lock.releaseLock();
  }
}

function getAddressBookBuildStatus() {
  const props = PropertiesService.getScriptProperties();
  return _readAddressBookBuildStatus_(props);
}

function getAddressBookBuildStatusByRequestId(requestId) {
  const status = getAddressBookBuildStatus();
  if (!status || !requestId) return null;
  return status.requestId === String(requestId) ? status : null;
}

function _readAddressBookBuildStatus_(props) {
  const raw = props.getProperty("ADDRESS_BOOK_BUILD_STATUS");
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (err) {
    return { state: "error", message: "Invalid status payload." };
  }
}

function _buildCreateAddressBookPayloadFromSidebar_(options) {
  options = options || {};
  const useAllFields = !!options.useAllFields;
  const selected = options.selectedFields || [];
  const mapType = options.mapType || "google";
  const addressAlign = options.addressAlign || "left";
  const printPaperBook = options.printMode === "print";

  const { organizations } = getContacts_(null, _getContactsSheet_());
  const allFieldNames = Object.keys(organizations);
  const settingsSheet = _getActiveSpreadsheet_().getSheetByName("Settings");
  const fieldOrderMap = _getFieldOrderMapFromSettings_(settingsSheet);
  allFieldNames.sort((a, b) => {
    const oa = fieldOrderMap[a];
    const ob = fieldOrderMap[b];
    const hasA = typeof oa === "number";
    const hasB = typeof ob === "number";
    if (hasA && hasB && oa !== ob) return oa - ob;
    if (hasA && !hasB) return -1;
    if (!hasA && hasB) return 1;
    return a.localeCompare(b);
  });
  const debugTables = !!options.debugTables;

  let orgs;
  if (useAllFields) {
    orgs = allFieldNames;
  } else {
    const allowed = new Set(selected);
    orgs = allFieldNames.filter((f) => allowed.has(f));
  }

  if (!orgs.length) return { error: "No valid Fields selected." };

  return {
    orgCount: orgs.length,
    payload: {
      orgs,
      mapType,
      fontSizePt: options.fontSizePt,
      allFieldsSelected: useAllFields,
      italicNoGps: options.italicNoGps,
      addressAlign,
      debugTables,
      printPaperBook,
      includeCover: !!options.includeCover,
      coverFileName: options.coverFileName || null
    }
  };
}

/*************************************************
 * BLOCK 1/2 — FAMILY + PHONE + ADDRESS LOGIC (shared)
 *************************************************/

const normalize = (s) => s?.trim().toLowerCase() || "";

const _isLikelyPersonNameLabel_ = (value) => {
  const text = String(value || "").trim();
  if (!text) return false;
  return /^[A-Za-z][A-Za-z' -]*$/.test(text);
};

const createFamilyMetadata_ = ({
  givenName,
  givenNameAllCaps,
  familyName,
  wife,
  children,
  others,
}) => {
  let names = familyName.toUpperCase();
  const displayGiven = givenNameAllCaps ? givenName.toUpperCase() : givenName;

  const parents = wife ? `${displayGiven} & ${wife}` : displayGiven;
  if (parents) names += `, ${parents}`;
  if (children.length || others.length) names += `; ${[...children, ...others].join(", ")}`;

  let nameLetters = "";
  const firstLetterHusband = givenName.slice(0, 1).toUpperCase();

  if (wife) {
    const firstLetterWife = wife.slice(0, 1).toUpperCase();
    if (firstLetterWife == firstLetterHusband) {
      nameLetters = firstLetterHusband + givenName.charAt(1).toLowerCase();
    } else {
      nameLetters = firstLetterHusband;
    }
  } else {
    nameLetters = firstLetterHusband;
  }
  return { names, nameLetters: nameLetters.padEnd(2, " ") };
};

const createMapUrl_ = (query, mapType = "google") => {
  if (!query) return "";
  if (mapType == "None") return "";
  return encodeURI(
    mapType == "apple" ? `http://maps.apple.com/?q=${query}` : `http://maps.google.com/?q=${query}`
  );
};

const createHusband_ = (contacts) => {
  const husband = {
    familyName: "",
    givenName: "",
    wife: "",
    children: [],
    others: [],
    householdGivenNames: [],
    hasOnlyOneContact: false,
    phone: "",
    swap: false,
  };

  contacts.forEach((contact) => {
    const { givenName, familyName } = contact;
    if (givenName) husband.householdGivenNames.push(givenName);
    if (!husband.phone) {
      husband.phone = contact.phone1Value || contact.phone2Value || contact.phone3Value || "";
    }
    const indexes = [1, 2];
    indexes.forEach((i) => {
      const type = (contact[`relation${i}Type`] || "").trim().toLowerCase();
      const value = (contact[`relation${i}Value`] || "").trim();
      if (!husband.givenName) {
        husband.givenName = givenName;
        husband.givenNameAllCaps = contact.givenNameAllCaps;
      }
      !husband.familyName && (husband.familyName = familyName);
      if (!value) return;

      if (type == "wife") {
        husband.wife = value;
        husband.givenName = givenName;
      } else if (type == "husband") {
        husband.wife = givenName;
        husband.givenName = value;
        husband.swap = true;
      } else if (type == "son" || type == "daughter") {
        husband.children.push(value);
      } else {
        husband.others.push(value);
      }
    });
  });

  if (husband.swap && contacts.length === 1) {
    const wife = husband.wife;
    husband.wife = husband.givenName;
    husband.givenName = wife;
  } else {
    husband.swap = false;
  }

  husband.children = [...new Set(husband.children)];
  husband.others = [...new Set(husband.others)];
  husband.householdGivenNames = [...new Set(husband.householdGivenNames.filter(Boolean))];
  return husband;
};

const updateContactData_ = (phones, addresses, addressValues, contact, husband, mapType = "google") => {
  const indexes = [1, 2, 3];
  indexes.forEach((index) => {
    const addressKey = `address${index}Formatted`;
    const addressTypeKey = `address${index}Type`;
    const addressCoordinatesKey = `address${index}Coordinates`;
    const phoneValueKey = `phone${index}Value`;
    const phoneTypeKey = `phone${index}Type`;

    if (contact[addressKey]) {
      const addressType = contact[addressTypeKey];
      const value = buildAddressDisplayValue_(
        contact[addressKey],
        addressType,
        index
      );
      if (value && !addressValues.includes(value)) {
        addressValues.push(value);
        addresses.push({
          value,
          map: createMapUrl_(contact[addressCoordinatesKey] || value, mapType),
          hasCoordinates: contact[addressCoordinatesKey],
          coordinates: contact[addressCoordinatesKey] || null,
        });
      }
    }

    const phone = contact[phoneValueKey];
    if (!phone) return;
    const isPhoneDuplicated = phones.find((v) => v.value == phone);
    if (isPhoneDuplicated) return;

    let role = "";
    const personName = contact.givenName?.trim();

    if (normalize(personName) === normalize(husband.givenName)) role = "husband";
    else if (normalize(personName) === normalize(husband.wife)) role = "wife";
    else if (husband.children.includes(personName)) role = "child";
    else if (husband.others.includes(personName)) role = "other";
    else role = "unknown";

    phones.push({
      value: phone,
      type: contact[phoneTypeKey],
      familyName: contact.familyName,
      givenName: contact.givenName,
      role: role,
      sourceOrder: phones.length,
    });
  });
};

const buildConflictNames_ = (husband, phones) => {
  const namesSet = new Set();

  const familyNames = [
    husband.givenName,
    husband.wife,
    ...husband.children,
    ...husband.others,
    ...(husband.householdGivenNames || []),
  ]
    .filter(Boolean)
    .map(normalize);

  phones.forEach((phone) => {
    if (!phone) return;
    const { type, givenName } = phone;
    const typeNorm = normalize(type);
    const isKnownType = KNOWN_PHONE_TYPES_.includes(typeNorm);
    const isLikelyPersonName = !isKnownType && _isLikelyPersonNameLabel_(type);

    const isTypeFamilyName = familyNames.includes(typeNorm);

    const isChildOrOther =
      husband.children.includes(type) ||
      husband.others.includes(type) ||
      isTypeFamilyName ||
      isLikelyPersonName;

    const name = isChildOrOther ? type : givenName;
    if (name) namesSet.add(normalize(name));
  });

  if (husband.givenName) namesSet.add(normalize(husband.givenName));
  if (husband.wife) namesSet.add(normalize(husband.wife));

  return Array.from(namesSet);
};

const createNameLetterNew_ = (name, husband) => {
  const capitalize3 = (s) =>
    s.charAt(0).toUpperCase() + s.charAt(1).toLowerCase() + (s.charAt(2)?.toLowerCase() || "");

  const nameLower = normalize(name);
  const allMembers = husband._conflictNames || [
    normalize(husband.givenName),
    normalize(husband.wife),
    ...husband.children.map(normalize),
    ...husband.others.map(normalize),
  ];

  const first = nameLower.charAt(0);
  const second = nameLower.charAt(1) || "";
  const firstTwo = first + second;

  const shareFirst = allMembers.filter((n) => n && n.charAt(0) === first);
  if (shareFirst.length === 1) return first.toUpperCase();

  const shareFirstTwo = shareFirst.filter((n) => n.startsWith(firstTwo));
  if (shareFirstTwo.length === 1) return first.toUpperCase() + second.toLowerCase();

  return capitalize3(nameLower);
};

const KNOWN_PHONE_TYPES_ = ["home", "mobile", "work", "nh", "other"];

const formatPhoneTypeLabel_ = (label, compact = true) => {
  const value = String(label || "").trim();
  if (!value) return compact ? "  " : "";
  if (!compact) return value;
  return value.slice(0, 2).padEnd(2, " ");
};

const createPhoneLetter_ = (phone, husband, compact = true) => {
  if (!phone) return compact ? "  " : "";

  const { type, givenName } = phone;
  const rawType = String(type || "").trim();
  const typeNorm = normalize(type);
  const givenNameNorm = normalize(givenName);
  const isKnownType = KNOWN_PHONE_TYPES_.includes(typeNorm);
  const isLikelyPersonName = !isKnownType && _isLikelyPersonNameLabel_(rawType);

  const familyNames = [
    husband.givenName,
    husband.wife,
    ...husband.children,
    ...husband.others,
    ...(husband.householdGivenNames || []),
  ]
    .filter(Boolean)
    .map(normalize);

  const isTypeFamilyName = familyNames.includes(typeNorm);
  const conflictNames = (husband._conflictNames || []).filter(Boolean);
  const isTypeKnownPerson = conflictNames.includes(typeNorm);
  const isTypeOwnGivenName = !!typeNorm && typeNorm === givenNameNorm;

  const isChildOrOther =
    husband.children.includes(type) ||
    husband.others.includes(type) ||
    isTypeFamilyName ||
    isTypeKnownPerson ||
    isTypeOwnGivenName ||
    isLikelyPersonName;

  if (typeNorm === "home") return compact ? "  " : "";
  if (typeNorm === "nh") return formatPhoneTypeLabel_("nh", compact);
  if (typeNorm === "mobile" && husband.hasOnlyOneContact) return formatPhoneTypeLabel_("c", compact);

  const name = isChildOrOther ? type : givenName;
  const nameLetter = createNameLetterNew_(name, husband);

  if (typeNorm === "work") {
    const workLabel = husband.hasOnlyOneContact ? "w" : `${nameLetter.trim()}w`;
    return formatPhoneTypeLabel_(workLabel, compact);
  }

  if (!isKnownType && rawType && !isChildOrOther) return formatPhoneTypeLabel_(rawType, compact);

  return formatPhoneTypeLabel_(nameLetter, compact);
};

function processPhoneLetters(phones) {
  const knownRoles = ["husband", "wife", "child", "other"];

  const rolePriority = { husband: 0, wife: 1, child: 2, other: 3, unknown: 4 };
  const typePriority = { home: 0, mobile: 1, work: 2, nh: 3, other: 4 };

  const normalizedPhones = phones.map((phone) => {
    const rawType = normalize(phone.type);
    const isKnownType = KNOWN_PHONE_TYPES_.includes(rawType);
    const isNameAsType = !isKnownType;

    let role = phone.role || "unknown";
    if (isNameAsType) {
      if (role === "husband" || role === "wife" || !knownRoles.includes(role)) role = "child";
    }

    return { ...phone, role, isNameAsType, normalizedType: isNameAsType ? "name" : rawType };
  });

  normalizedPhones.sort((a, b) => {
    if (a.isNameAsType !== b.isNameAsType) return a.isNameAsType ? 1 : -1;

    const roleA = rolePriority[a.role] ?? 99;
    const roleB = rolePriority[b.role] ?? 99;
    if (roleA !== roleB) return roleA - roleB;

    if (!a.isNameAsType && !b.isNameAsType) {
      const typeA = typePriority[a.normalizedType] ?? 99;
      const typeB = typePriority[b.normalizedType] ?? 99;
      if (typeA !== typeB) return typeA - typeB;
    }

    return (a.sourceOrder ?? 0) - (b.sourceOrder ?? 0);
  });

  return normalizedPhones;
}

const createFamilyContactLines_ = (contacts, mapType = "google", italicNoCoords = true) => {
  const phones = [];
  const addresses = [];
  const addressValues = [];

  contacts.sort((a, b) => {
    const relationA = a.relation1Type;
    const relationB = b.relation1Type;
    if (relationB == "wife") return 1;
    if (relationB == "husband" && relationA != "wife") return 1;
    return -1;
  });

  const husband = createHusband_(contacts);

  contacts.forEach((contact) => {
    updateContactData_(phones, addresses, addressValues, contact, husband, mapType);
  });

  const sortedPhones = processPhoneLetters(phones);
  phones.length = 0;
  phones.push(...sortedPhones);

  husband._conflictNames = buildConflictNames_(husband, phones);

  husband.hasOnlyOneContact =
    !husband.wife && husband.children.length == 0 && husband.others.length == 0;

  // NOTE: depends on _fillBetween_ and _splitTextToFixedLength_ from your existing project
  const fill = _fillBetween_(SETTINGS.BOOK.LETTERS, " ");
  const lines = [];
  const maxLines = Math.max(phones.length, addresses.length + 1);

  const renderedPhoneIndices = new Set();
  let phoneIndex = 0;

  const getNextUnusedPhone = () => {
    while (phoneIndex < phones.length) {
      if (!renderedPhoneIndices.has(phoneIndex)) {
        renderedPhoneIndices.add(phoneIndex);
        return phones[phoneIndex++];
      }
      phoneIndex++;
    }
    return null;
  };

  Array(maxLines).fill(null).forEach((_, i) => {
    let phone = null;
    let phonePrefix = "".padEnd(15, " ");
    let styles = [];

    if (i === 0) {
      const { names } = createFamilyMetadata_(husband);
      const firstPhone = phones[0];
      const firstLetter = createPhoneLetter_(firstPhone, husband, true);
      phonePrefix = firstPhone ? `${firstPhone.value} ${firstLetter}` : "".padEnd(15, " ");

      renderedPhoneIndices.add(0);

      styles = firstPhone
        ? [{ start: 0, length: firstPhone.value.length, url: `tel:${firstPhone.value}` }]
        : [];

      styles.push({
        start: phonePrefix.length + 1,
        length: husband.familyName.length,
        bold: true,
      });

      if (`${phonePrefix} ${names}`.length > SETTINGS.BOOK.LETTERS) {
        _splitTextToFixedLength_(SETTINGS.BOOK.LETTERS - phonePrefix.length - 1, "", false)(names)
          .forEach((value, j) => {
            value = value.trim();
            if (j === 0) {
              lines.push({ text: fill(`${phonePrefix} ${value}`, ""), styles });
            } else {
              const nextPhone = getNextUnusedPhone();
              const nextPrefix = nextPhone
                ? `${nextPhone.value} ${createPhoneLetter_(nextPhone, husband, false)}`
                : "".padEnd(15, " ");
              lines.push({
                text: `${nextPrefix}   ${value}`,
                styles: nextPhone
                  ? [{ start: 0, length: nextPhone.value.length, url: `tel:${nextPhone.value}` }]
                  : [],
              });
            }
          });
      } else {
        lines.push({ text: fill(`${phonePrefix} ${names}`, ""), styles });
      }
      return;
    }

    phone = getNextUnusedPhone();
    phonePrefix = phone ? `${phone.value} ${createPhoneLetter_(phone, husband, false)}` : "".padEnd(15, " ");
    styles = phone ? [{ start: 0, length: phone.value.length, url: `tel:${phone.value}` }] : [];

    const address = addresses[i - 1];
    if (address) {
      const rawAddressLines = splitFormattedAddressLines_(address.value);
      const addressLines = rawAddressLines.flatMap((line) => {
        if (line.length + phonePrefix.length > SETTINGS.BOOK.LETTERS) {
          return splitAddressForCityAndState_(line).filter(Boolean);
        }
        return [line];
      });

      addressLines.forEach((value, index) => {
        const lineStyles = [...styles];
        const text = index === 0 ? fill(phonePrefix, value) : fill("", value);
        address.map &&
          lineStyles.push({
            start: value.length * -1,
            length: value.length,
            url: address.map,
            italic: italicNoCoords && !address.hasCoordinates,
          });
        lines.push({ text, styles: lineStyles });
      });
      return;
    }

    lines.push({ text: fill(phonePrefix, ""), styles });
  });

  return { lines, husband };
};

/*************************************************
 * BLOCK 2 — HTML FAMILY CARD + FIELDINFO/MeetingData RENDER
 *************************************************/

// Escape HTML special characters
function _escapeHtml_(text) {
  return String(text || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function _phoneHtml_(phone) {
  if (!phone) return "";
  const safe = _escapeHtml_(phone);
  const tel = phone.replace(/[^\d+]/g, "");
  return `<a href="tel:${tel}" style="color: black; text-decoration: none;">${safe}</a>`;
}

function _buildAddressHtml_(addrObj, mapType, italicNoGps) {
  if (!addrObj || !addrObj.value) return "";

  const mapUrl = createMapUrl_(
    addrObj.hasCoordinates ? addrObj.coordinates : addrObj.value,
    mapType
  );

  const style =
    italicNoGps && !addrObj.hasCoordinates
      ? ' style="font-style: italic;"'
      : "";

  return (
    `<a href="${mapUrl}"${style}>` +
    _escapeHtml_(addrObj.value).replace(/\n/g, "<br>") +
    `</a>`
  );
}

function buildFamilyCardHtmlFromLines_(render, mapType) {
  return buildFamilyCardHtml_(
    render.contacts,
    mapType,
    render.italicNoGps
  );
}

/**
 * Build ONE family "card" as HTML using existing husband/phone logic.
 */
function buildFamilyCardHtml_(contacts, mapType, italicNoGps) {
  mapType = mapType || "google";

  const phones = [];
  const addresses = [];
  const addressValues = [];

  contacts = contacts.slice().sort((a, b) => {
    const relationA = a.relation1Type;
    const relationB = b.relation1Type;
    if (relationB == "wife") return 1;
    if (relationB == "husband" && relationA != "wife") return 1;
    return -1;
  });

  const husband = createHusband_(contacts);

  contacts.forEach((contact) => {
    updateContactData_(phones, addresses, addressValues, contact, husband, mapType);
  });

  const sortedPhones = processPhoneLetters(phones);
  phones.length = 0;
  phones.push(...sortedPhones);

  husband._conflictNames = buildConflictNames_(husband, phones);
  husband.hasOnlyOneContact =
    !husband.wife && husband.children.length === 0 && husband.others.length === 0;

  const { names } = createFamilyMetadata_(husband);

  let lastName = names;
  let restName = "";
  const commaIdx = names.indexOf(",");
  if (commaIdx >= 0) {
    lastName = names.slice(0, commaIdx).trim();
    restName = names.slice(commaIdx + 1).trim();
  }

  const mainPhoneObj = phones[0] || null;
  const secondPhoneObj = phones[1] || null;
  const thirdPhoneObj = phones[2] || null;

  const mainPhone = mainPhoneObj ? mainPhoneObj.value : "";
  const secondPhone = secondPhoneObj ? secondPhoneObj.value : "";
  const thirdPhone = thirdPhoneObj ? thirdPhoneObj.value : "";

  const mainCode = mainPhoneObj ? createPhoneLetter_(mainPhoneObj, husband, true) : "  ";
  const secondCode = secondPhoneObj ? createPhoneLetter_(secondPhoneObj, husband, false) : "";
  const thirdCode = thirdPhoneObj ? createPhoneLetter_(thirdPhoneObj, husband, false) : "";

  const addr1Obj = addresses[0] || null;
  const addr2Obj = addresses[1] || null;

  const addr1Text = addr1Obj ? addr1Obj.value : "";
  const addr2Text = addr2Obj ? addr2Obj.value : "";

  const htmlParts = [];

  htmlParts.push('<div class="card2">');

  htmlParts.push('<div class="left">');

  if (mainPhone) {
    htmlParts.push(
      `<div class="left-line"><span class="p">${_phoneHtml_(mainPhone)}</span><span class="c">${_escapeHtml_(mainCode)}</span></div>`
    );
  }

  if (secondPhone) {
    htmlParts.push(
      `<div class="left-line"><span class="p">${_phoneHtml_(secondPhone)}</span><span class="c">${_escapeHtml_(secondCode)}</span></div>`
    );
  } else if (addr1Text) {
    htmlParts.push(`<div class="left-line"><span class="p"></span><span class="c"></span></div>`);
  }

  if (thirdPhone) {
    htmlParts.push(
      `<div class="left-line"><span class="p">${_phoneHtml_(thirdPhone)}</span><span class="c">${_escapeHtml_(thirdCode)}</span></div>`
    );
  } else if (addr2Text) {
    htmlParts.push(`<div class="left-line"><span class="p"></span><span class="c"></span></div>`);
  }

  htmlParts.push('</div>');

  htmlParts.push('<div class="right">');

  htmlParts.push(`<div class="name">${_escapeHtml_(lastName)}`);
  if (restName) {
    htmlParts.push(`, <span class="rest">${_escapeHtml_(restName)}</span>`);
  }
  htmlParts.push(`</div>`);

  addresses.forEach((addrObj) => {
    htmlParts.push(
      `<div class="address">${_buildAddressHtml_(addrObj, mapType, italicNoGps)}</div>`
    );
  });

  htmlParts.push('</div>');
  htmlParts.push('</div>\n');

  return htmlParts.join("");
}

let CURRENT_FIELD_CONTEXT = null;
let CURRENT_MEETING_CONTEXT = null;
let CURRENT_TABLE_INDEX = 0;

function _renderTextWithStyles_(text, styles) {
  if (!styles || !styles.length) return _escapeHtml_(text || "");

  const spans = (styles || []).slice().sort((a, b) => (a.start || 0) - (b.start || 0));
  let html = "";
  let pos = 0;

  spans.forEach((s) => {
    const start = Math.max(0, s.start || 0);
    const len = s.length || 0;
    const end = Math.min(text.length, start + len);

    if (start > pos) html += _escapeHtml_(text.substring(pos, start));

    if (end > start) {
      const seg = text.substring(start, end);
      let styleStr = "";
      if (s.bold) styleStr += "font-weight:bold;";
      if (s.italic) styleStr += "font-style:italic;";
      if (s.underline) styleStr += "text-decoration:underline;";
      if (s.size) styleStr += "font-size:" + s.size + "pt;";

      if (styleStr) html += `<span style="${styleStr}">${_escapeHtml_(seg)}</span>`;
      else html += _escapeHtml_(seg);
    }
    pos = end;
  });

  if (pos < text.length) html += _escapeHtml_(text.substring(pos));
  return html;
}

function _renderStyledLineToHtml_(line) {
  if (!line) return "";

  const rawText = line.text != null ? String(line.text) : "";
  const styles = line.styles || [];

  if (rawText.replace(/\s/g, "") === "") return '<div class="info-line blank">&nbsp;</div>\n';

  const text = rawText;

  let alignClass = "";
  for (const s of styles) {
    if (s.align) {
      if (s.align === DocumentApp.HorizontalAlignment.CENTER) alignClass = "align-center";
      else if (s.align === DocumentApp.HorizontalAlignment.RIGHT) alignClass = "align-right";
      else if (s.align === DocumentApp.HorizontalAlignment.JUSTIFY) alignClass = "align-justify";
      else alignClass = "align-left";
      break;
    }
  }

  const hasMultiSpace = /\s{2,}/.test(text);
  const classes = ["info-line"];
  if (alignClass) classes.push(alignClass);
  if (hasMultiSpace && alignClass !== "align-center") classes.push("preserve-space");

  const innerHtml = _renderTextWithStyles_(text, styles);

  return `<div class="${classes.join(" ")}">${innerHtml}</div>\n`;
}

function _normKey_(s) {
  return String(s || "")
    .normalize("NFKC")
    .replace(/\u00A0/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .toUpperCase();
}

function loadAllNamedTablesWithMergeInfo_(meeting, field) {
  const ss = _getActiveSpreadsheet_();
  const sheet = ss.getSheetByName("MeetingData");
  if (!sheet) throw new Error("Missing 'MeetingData' sheet");

  const dataRange = sheet.getDataRange();
  const values = dataRange.getValues();
  const rich = dataRange.getRichTextValues();
  const results = [];

  const wantField = _normKey_(field);
  const wantMeeting = _normKey_(meeting);

  for (let i = 1; i < values.length; i++) {
    const rowField = _normKey_(values[i][0]);
    const rowMeeting = _normKey_(values[i][1]);
    if (rowField !== wantField || rowMeeting !== wantMeeting) continue;

    const startRow = i;
    const rows = [];
    const richRows = [];
    const formatFlags = String(values[i][2] || "").toLowerCase().split(/[,\s]+/).filter(Boolean);

    const isUnionMeeting = formatFlags.includes("um") || formatFlags.includes("umt");
    const fontSizePt = _parseTableFontSizePtFromFlags_(formatFlags);
    const underlineRows = [];
    if (formatFlags.includes("ul")) underlineRows.push(0);
    const COL_OFFSET = 3; // Columns A,B,C stripped → D = 0
    rows.push(values[i].slice(3));
    richRows.push(rich[i].slice(3));

    for (let j = i + 1; j < values.length; j++) {
      const nextField = String(values[j][0] || "").trim();
      const nextMeeting = String(values[j][1] || "").trim();
      if (nextField && nextMeeting) break;

      const rowFlags = String(values[j][2] || "").toLowerCase().split(/[,\s]+/).filter(Boolean);
      const localRowIndex = rows.length;
      if (rowFlags.includes("ul")) underlineRows.push(localRowIndex);

      rows.push(values[j].slice(3));
      richRows.push(rich[j].slice(3));
    }

    let realMaxCol = 1;
    rows.forEach((r) =>
      r.forEach((cell, c) => {
        if (String(cell).trim()) realMaxCol = Math.max(realMaxCol, c + 1);
      })
    );

    const mergeMap = {};
    const rowCount = rows.length;

    if (rowCount) {
      const range = sheet.getRange(startRow + 1, 4, rowCount, realMaxCol);
      range.getMergedRanges().forEach((r) => {
        const localRow = r.getRow() - (startRow + 1);
        const localCol = r.getColumn() - 4;
        mergeMap[`${localRow},${localCol}`] = { rowspan: r.getNumRows(), colspan: r.getNumColumns() };
      });
    }

    results.push({
      rows,
      richRows,
      mergeMap,
      startRow,
      isUnionMeeting,
      fontSizePt,
      underlineRows,
      colOffset: COL_OFFSET
    });
  }

  return results;
}

function _getUsedColumnIndices_(rows) {
  let maxCol = 0;

  for (const row of rows || []) {
    for (let i = (row?.length || 0) - 1; i >= 0; i--) {
      if (String(row[i] ?? "").trim() !== "") {
        maxCol = Math.max(maxCol, i + 1);
        break;
      }
    }
  }

  return Array.from({ length: maxCol }, (_, i) => i);
}

function _renderRichTextToHtml_(richText) {
  if (!richText || !richText.getText) return "";

  const esc = (s) =>
    _escapeHtml_(s).replace(/\n/g, "<br>");

  const runs = richText.getRuns();
  if (!runs || !runs.length) return esc(richText.getText());

  let html = "";

  for (const run of runs) {
    const text = esc(run.getText());
    const style = run.getTextStyle();

    let open = "";
    let close = "";

    if (style.isBold()) {
      open += "<b>";
      close = "</b>" + close;
    }

    if (style.isItalic()) {
      open += "<i>";
      close = "</i>" + close;
    }

    if (style.isUnderline()) {
      open += "<u>";
      close = "</u>" + close;
    }

    html += open + text + close;
  }

  return html;
}

function _hasHybridMergedRow_(rows, richRows) {
  const TOTAL = 28;

  for (let rowIndex = 0; rowIndex < rows.length; rowIndex++) {
    const row = rows[rowIndex];
    const richRow = richRows?.[rowIndex] || [];

    let nonEmptyCount = 0;
    let firstNonEmptyIndex = -1;

    for (let c = 0; c < TOTAL; c++) {
      const raw = String(row?.[c] ?? "").trim();
      const rich = richRow?.[c]?.getText?.().trim();

      const hasValue = !!raw || !!rich;
      if (hasValue) {
        nonEmptyCount++;
        if (firstNonEmptyIndex === -1) {
          firstNonEmptyIndex = c;
        }
      }
    }

    // A hybrid row has exactly one non-empty cell, positioned at column 0
    if (nonEmptyCount === 1 && firstNonEmptyIndex === 0) {
      return true;
    }
  }

  return false;
}

function _renderTableWithMergeAndStyles_({
  rows,
  richRows,
  mergeMap,
  underlineRows,
  usedColIndices,
  measuredWidths,
  className = "field-info-table",
  centered = false,
  isUnionMeeting = false,
  isWysiwyg = false,
  fontSizePt = null
}) {
  if (!rows || !rows.length) return "";

  const TOTAL_WYSIWYG_COLS = 28;
  const out = [];

  // ---------- WYSIWYG padding ----------
  if (isWysiwyg) {
    const padRow = (r) => {
      const out = Array(TOTAL_WYSIWYG_COLS).fill("");
      for (let i = 0; i < Math.min(TOTAL_WYSIWYG_COLS, r?.length || 0); i++) {
        out[i] = r[i];
      }
      return out;
    };
    const padRich = (r) => {
      const out = Array(TOTAL_WYSIWYG_COLS).fill(null);
      for (let i = 0; i < Math.min(TOTAL_WYSIWYG_COLS, r?.length || 0); i++) {
        out[i] = r[i];
      }
      return out;
    };
    rows = rows.map(padRow);
    richRows = (richRows || []).map(padRich);
  }

  // ---------- underline rows (rehydrate after cache) ----------
  const underlineSet =
    underlineRows instanceof Set
      ? underlineRows
      : new Set(Array.isArray(underlineRows) ? underlineRows : []);

  // ---------- covered cells ----------
  const covered = new Set();
  Object.entries(mergeMap || {}).forEach(([k, span]) => {
    const [r0, c0] = k.split(",").map(Number);
    const rs = Math.max(1, span.rowspan || 1);
    const cs = Math.max(1, span.colspan || 1);
    for (let r = r0; r < r0 + rs; r++) {
      for (let c = c0; c < c0 + cs; c++) {
        if (r !== r0 || c !== c0) covered.add(`${r},${c}`);
      }
    }
  });

  const usedCols = isWysiwyg
    ? Array.from({ length: TOTAL_WYSIWYG_COLS }, (_, i) => i)
    : (Array.isArray(usedColIndices) ? usedColIndices : _getUsedColumnIndices_(rows));

  const totalCols = isWysiwyg
    ? TOTAL_WYSIWYG_COLS
    : (usedCols.length > 0 ? Math.max(...usedCols) + 1 : 1);

  // ---------- column widths ----------
  let colPercents;
  if (isWysiwyg) {
    colPercents = centered
      ? [100]
      : Array(totalCols).fill(100 / totalCols);
  } else {
    const measured = Array.isArray(measuredWidths)
      ? measuredWidths
      : _clampWidths_(
          _measureColumnWidths_(rows, richRows, usedCols, mergeMap)
        );
    colPercents = centered && isUnionMeeting
      ? Array(usedCols.length).fill(100 / usedCols.length)
      : _normalizeWidthsWithGap_(measured, 4);
  }

  // ---------- table start ----------
  if (centered) out.push(`<div class="table-outer-wrapper fully-merged-center">`);
  out.push(`<div class="table-block table-atomic${centered ? " centered" : ""}">`);
  const fontSizeStyle = fontSizePt ? ` style="font-size:${fontSizePt}pt;"` : "";
  out.push(`<table class="${className}"${fontSizeStyle}>`);
  out.push("<colgroup>");

  const colCount = centered ? colPercents.length : totalCols;
  for (let i = 0; i < colCount; i++) {
    out.push(`<col style="width:${(colPercents[i] || 0).toFixed(4)}%;" />`);
  }
  out.push("</colgroup>");

  // ---------- rows ----------
  for (let r = 0; r < rows.length; r++) {
    const row = rows[r] || [];
    const richRow = richRows?.[r] || [];
    const underline = underlineSet.has(r);
    const isBlank = row.every((cell, c) => {
      const raw = String(cell ?? "").trim();
      const rt = richRow[c]?.getText?.().trim();
      return !raw && !rt;
    });

    if (isBlank) {
      out.push(
        `<tr class="blank-row${underline ? " underline-row" : ""}">` +
        `<td colspan="${totalCols}"${underline ? ' class="underline-cell"' : ''}>&nbsp;</td></tr>`
      );
      continue;
    }

    out.push("<tr>");

    for (let c = 0; c < totalCols; c++) {
      const key = `${r},${c}`;
      if (covered.has(key)) continue;

      const span = mergeMap?.[key];
      const colspan = span?.colspan > 1 ? ` colspan="${span.colspan}"` : "";
      const rowspan = span?.rowspan > 1 ? ` rowspan="${span.rowspan}"` : "";
      const center = span?.colspan > 1 ? ' style="text-align:center;"' : "";
      const cls = underline ? ' class="underline-cell"' : "";

      let cellHtml;
      const rt = richRow[c];
      if (rt?.getText) {
        cellHtml = _renderRichTextToHtml_(rt);
      } else {
        cellHtml = _escapeHtml_(row[c] ?? "");
      }

      out.push(
        `<td${cls}${colspan}${rowspan}${center}>${cellHtml}</td>`
      );
    }

    out.push("</tr>");
  }

  // ---------- close ----------
  out.push("</table></div>");
  if (centered) out.push("</div>");

  return out.join("");
}

// --- helper: how many rows remain on the current logical page?
function _remainingRows_(rowsUsed, maxRows) {
  return maxRows - rowsUsed;
}

function _countExactTableRows_(table) {
  if (!table || !Array.isArray(table.rows)) return 0;

  // Each row in table.rows renders exactly one visual row,
  // including blank rows.
  return table.rows.length;
}

function _isSingleCellRow_(rowIndex, rows, usedColIndices) {
  const row = rows[rowIndex] || [];
  let count = 0;

  for (const c of usedColIndices) {
    if (String(row[c] ?? "").trim() !== "") count++;
    if (count > 1) return false;
  }

  return count === 1;
}

function _validateMergedRows_(rows, mergeMap, usedColIndices, ctx) {
  const errors = [];
  const colCount = usedColIndices.length;

  rows.forEach((row, rowIndex) => {
    if (_isLabelPlusMergedRemainderRow_(rowIndex, rows, mergeMap, usedColIndices)) return;
    if (_isSingleCellRow_(rowIndex, rows, usedColIndices)) return;
    const mergesInRow = Object.entries(mergeMap || {})
      .filter(([k]) => Number(k.split(",")[0]) === rowIndex)
      .map(([k, span]) => ({
        col: Number(k.split(",")[1]),
        colspan: Math.max(1, Number(span.colspan || 1)),
      }));

    if (!mergesInRow.length) return;

    let coveredCols = 0;

    mergesInRow.forEach(({ col, colspan }) => {
      const start = col;
      const end = col + colspan - 1;

      usedColIndices.forEach(logicalCol => {
        if (logicalCol >= start && logicalCol <= end) {
          coveredCols++;
        }
      });
    });

    if (coveredCols !== colCount) {
      errors.push(
        `MeetingData error:
          Field: ${ctx.field}
          Meeting: ${ctx.meeting}
          Table #: ${ctx.tableIndex + 1}
          Row #: ${rowIndex + 1}
          Merged cells do not span the full logical row.
          Expected ${colCount} logical columns, got ${coveredCols}.`
      );
    }
  });

  if (errors.length) {
    throw new Error(
      "MeetingData MERGE VALIDATION FAILED\n\n" + errors.join("\n\n")
    );
  }
}

function _measureColumnWidths_(rows, richRows, usedColIndices, mergeMap = {}) {
  const widths = Array(usedColIndices.length).fill(0);

  // Build covered set (cells that are part of a merge but not the top-left start)
  const covered = new Set();
  Object.entries(mergeMap || {}).forEach(([mk, span]) => {
    const [r0, c0] = mk.split(",").map(Number);
    const rs = Math.max(1, Number(span?.rowspan || 1));
    const cs = Math.max(1, Number(span?.colspan || 1));

    for (let r = r0; r < r0 + rs; r++) {
      for (let c = c0; c < c0 + cs; c++) {
        if (r === r0 && c === c0) continue;
        covered.add(`${r},${c}`);
      }
    }
  });

  rows.forEach((row, r) => {
    row = row || [];

    // NEW: special exception row detection
    const isLabelMergedRow = _isLabelPlusMergedRemainderRow_(
      r,
      rows,
      mergeMap,
      usedColIndices
    );

    usedColIndices.forEach((colIndex, ci) => {
      const key = `${r},${colIndex}`;

      // Skip cells covered by merges (not the start cell)
      if (covered.has(key)) return;

      // NEW: if this is a label+merged remainder row, do NOT let cols 1..N affect widths
      if (isLabelMergedRow && ci > 0) return;

      const cell = row[colIndex];
      if (cell == null) return;

      const text = String(cell).trim();
      if (!text) return;

      widths[ci] = Math.max(widths[ci], text.length);
    });
  });

  return widths;
}

function _clampWidths_(charWidths) {
  const MIN = 3;
  const MAX = 40;

  return charWidths.map(w =>
    Math.min(MAX, Math.max(MIN, w))
  );
}

function _normalizeWidths_(charWidths) {
  const total = charWidths.reduce((a, b) => a + b, 0) || 1;
  return charWidths.map(w => (w / total) * 100);
}

function _normalizeWidthsWithGap_(charWidths, gap = 4) {
  const padded = charWidths.map(w => w + gap);
  const total = padded.reduce((a, b) => a + b, 0) || 1;
  return padded.map(w => (w / total) * 100);
}

function _isLabelPlusMergedRemainderRow_(rowIndex, rows, mergeMap, usedColIndices) {
  const row = rows[rowIndex] || [];
  if (!usedColIndices || !usedColIndices.length) return false;

  const firstLogicalCol = usedColIndices[0];

  // First logical column MUST contain data (the label)
  if (String(row[firstLogicalCol] || "").trim() === "") return false;

  // Collect merges that START on this row
  const mergesInRow = Object.entries(mergeMap || {})
    .filter(([k]) => Number(k.split(",")[0]) === rowIndex)
    .map(([k, span]) => {
      const start = Number(k.split(",")[1]);
      const colspan = Math.max(1, Number(span?.colspan || 1));
      return { start, end: start + colspan - 1 };
    });

  if (!mergesInRow.length) return false;

  // We allow ONE exception:
  // - col 0 (first logical col) may be unmerged label
  // - every other logical column must be covered by SOME merge span
  let coveredRemainder = 0;
  for (let i = 1; i < usedColIndices.length; i++) {
    const col = usedColIndices[i];
    if (mergesInRow.some(m => col >= m.start && col <= m.end)) {
      coveredRemainder++;
    }
  }

  return coveredRemainder === (usedColIndices.length - 1);
}

function _isWysiwygTableFromMergeMap_(mergeMap) {
  const TOTAL = 28;
  if (!mergeMap || Object.keys(mergeMap).length === 0) {
    return true;
  }

  return Object.values(mergeMap).every((span) => {
    return Number(span.colspan) === TOTAL;
  });
}

function _isFullyMergedTable_(rows, mergeMap, totalCols) {
  const TOTAL = totalCols || 28;
  for (let rowIndex = 0; rowIndex < rows.length; rowIndex++) {
    const row = rows[rowIndex] || [];
    const isBlank = row.every((cell) => {
      return String(cell ?? "").trim() === "";
    });
    if (isBlank) continue;

    const cellCount = row.filter((cell) => {
      return String(cell ?? "").trim().length > 0;
    }).length;
    if (cellCount !== 1) return false;

    const mergeKey = `${rowIndex},0`;
    const span = mergeMap?.[mergeKey];
    if (span?.colspan !== TOTAL) return false;
  }

  return true;
}

function loadAllMeetingDataIndexed_StructureOnly_() {
  const ss = _getActiveSpreadsheet_();
  const sheet = ss.getSheetByName("MeetingData");
  if (!sheet) return {};

  const dataRange = sheet.getDataRange();
  const values = dataRange.getValues();
  const mergedRanges = dataRange.getMergedRanges();
  const index = {};

  for (let i = 1; i < values.length; i++) {
    const field = _normKey_(values[i][0]);
    const meeting = _normKey_(values[i][1]);
    if (!field || !meeting) continue;

    const key = `${field}@@${meeting}`;

    const formatFlags = String(values[i][2] || "")
      .toLowerCase()
      .split(/[,\s]+/)
      .filter(Boolean);

    const isUnionMeeting = formatFlags.includes("um") || formatFlags.includes("umt");
    const keepWithNext = formatFlags.includes("umt");
    const fontSizePt = _parseTableFontSizePtFromFlags_(formatFlags);
    const underlineRows = [];
    if (formatFlags.includes("ul")) underlineRows.push(0);

    const rows = [values[i].slice(3)];
    const startRow = i;

    for (let j = i + 1; j < values.length; j++) {
      if (values[j][0] || values[j][1]) break;

      const rowFlags = String(values[j][2] || "")
        .toLowerCase()
        .split(/[,\s]+/)
        .filter(Boolean);

      if (rowFlags.includes("ul")) {
        underlineRows.push(rows.length);
      }

      rows.push(values[j].slice(3));
    }

    // ----- determine width for RichText re-fetch -----
    let realMaxCol = 1;
    rows.forEach(r =>
      r.forEach((cell, c) => {
        if (String(cell ?? "").trim()) {
          realMaxCol = Math.max(realMaxCol, c + 1);
        }
      })
    );

    // ----- merge map (still safe to cache) -----
    const mergeMap = {};
    const rowCount = rows.length;
    if (rowCount) {
      const rowStart = startRow + 1;
      const rowEnd = rowStart + rowCount - 1;
      const colStart = 4;
      const colEnd = colStart + realMaxCol - 1;

      mergedRanges.forEach(r => {
        const rRowStart = r.getRow();
        const rRowEnd = rRowStart + r.getNumRows() - 1;
        const rColStart = r.getColumn();
        const rColEnd = rColStart + r.getNumColumns() - 1;

        if (
          rRowEnd < rowStart ||
          rRowStart > rowEnd ||
          rColEnd < colStart ||
          rColStart > colEnd
        ) {
          return;
        }

        const localRow = rRowStart - rowStart;
        const localCol = rColStart - colStart;
        mergeMap[`${localRow},${localCol}`] = {
          rowspan: r.getNumRows(),
          colspan: r.getNumColumns()
        };
      });
    }

    if (!index[key]) index[key] = [];
    const isWysiwyg = _isWysiwygTableFromMergeMap_(mergeMap);
    const isFullyMerged = _isFullyMergedTable_(rows, mergeMap, 28);
    let usedColIndices = null;
    let measuredWidths = null;

    if (!isWysiwyg) {
      usedColIndices = _getUsedColumnIndices_(rows);
      measuredWidths = _clampWidths_(
        _measureColumnWidths_(rows, null, usedColIndices, mergeMap)
      );
    }

    index[key].push({
      rows,
      mergeMap,
      underlineRows,
      isUnionMeeting,
      keepWithNext,
      fontSizePt,
      startRow,
      realMaxCol,
      isWysiwyg,
      isFullyMerged,
      usedColIndices,
      measuredWidths
    });
  }

  return index;
}

const familyRenderCache = new WeakMap();

function _getFamilyRender_(familyContacts, mapType, italicNoGps) {
  let cached = familyRenderCache.get(familyContacts);
  if (!cached) {
    const render = createFamilyContactLines_(
      familyContacts,
      mapType,
      italicNoGps
    );

    // 🔑 PRESERVE original contacts
    cached = {
      ...render,
      contacts: familyContacts,
      italicNoGps
    };

    familyRenderCache.set(familyContacts, cached);
  }
  return cached;
}

function _getAddressBookMaxRows_(fontSizePt) {
  const base = SETTINGS.BOOK.ROWS;
  const baseSize = ADDRESS_BOOK_BASE_FONT_SIZE_PT;
  const size = Number(fontSizePt) || baseSize;
  const scale = baseSize / size;
  return Math.floor(base * scale);
}

/*************************************************
 * HTML ADDRESS BOOK — CORE PIPELINE
 *************************************************/
function createAddressBookHtml_(payload = {}) {
  let {
    orgs,
    mapType,
    allFieldsSelected,
    italicNoGps,
    fontSizePt,
    includeCover = false,
    coverFileName = null,
    addressAlign,
    debugTables = false,
    printPaperBook = false,
    outputFolderName = null,
    showHtmlOutput = false,
    showPdfOutput = true,
    deletePdfOutput = false
  } = payload;
  if (!mapType) mapType = "google";
  if (!addressAlign) addressAlign = "left";
  const safeFontSizePt = Number(fontSizePt) || ADDRESS_BOOK_BASE_FONT_SIZE_PT;

  const ss = _getActiveSpreadsheet_();

  const SHEETS = {
    CONTACTS: ss.getSheetByName(SETTINGS.SN.CONTACTS),
    MEETING_DATA: ss.getSheetByName("MeetingData"),
    SETTINGS: ss.getSheetByName("Settings"),
  };

  if (!SHEETS.CONTACTS) {
    throw new Error(`Contacts sheet "${SETTINGS.SN.CONTACTS}" not found`);
  }

  const addrAlignCss =
    addressAlign === "right" ? "text-align: right;" : "text-align: left;";

  const title = "Create Address Book (HTML)";
  _toast_("Processing contacts …", title, -1);

  const driveFile = DriveApp.getFileById(ss.getId());
  const MeetingDataIndex = getMeetingDataIndexCached_(driveFile);
  const meetingDataVersion = _getMeetingDataCacheVersion_();
  const meetingDataEditVersion = _getMeetingDataEditVersion_();
  const meetingOrderMap = _getMeetingOrderMapFromSettings_(SHEETS.SETTINGS);
  const fieldOrderMap = _getFieldOrderMapFromSettings_(SHEETS.SETTINGS);
  const fieldOrderNormMap = Object.create(null);
  Object.keys(fieldOrderMap || {}).forEach((name) => {
    fieldOrderNormMap[_normKey_(name)] = fieldOrderMap[name];
  });
  const tableHtmlCache = CacheService.getScriptCache();
  const { contacts } = getContacts_(orgs, SHEETS.CONTACTS);

  const indexEntries = [];
  const tocEntries = [];

  const pageBuckets = [];
  let pageIndex = 0;

  const MAX_ROWS = _getAddressBookMaxRows_(safeFontSizePt);

  /*************************************************
   * MAIN LOOP — one Field+Meeting group at a time
   *************************************************/
  const meetingEntries = Object.entries(contacts);
  const meetingSortCache = new Map();
  const getMeetingSort = (entry) => {
    if (meetingSortCache.has(entry[0])) return meetingSortCache.get(entry[0]);

    const item = entry[1] || {};
    let org = "";
    let meeting = "";

    const firstBucket = Object.values(item)[0];
    const firstContact = firstBucket && firstBucket[0];

    if (firstContact) {
      org = String(firstContact.fields || "");
      meeting = String(firstContact.meetings || "");
    } else {
      const parts = String(entry[0] || "").split(", ");
      org = parts.shift() || "";
      meeting = parts.join(", ");
    }

    const fieldKey = _normKey_(org);
    const meetingKey = _normKey_(meeting);
    const fieldOrder = fieldOrderNormMap[fieldKey];
    const order = meetingOrderMap[meetingKey];
    const sort = {
      fieldOrder: typeof fieldOrder === "number" ? fieldOrder : Number.POSITIVE_INFINITY,
      order: typeof order === "number" ? order : Number.POSITIVE_INFINITY,
      org,
      meeting
    };
    meetingSortCache.set(entry[0], sort);
    return sort;
  };

  meetingEntries.sort((a, b) => {
    const sa = getMeetingSort(a);
    const sb = getMeetingSort(b);
    if (sa.fieldOrder !== sb.fieldOrder) return sa.fieldOrder - sb.fieldOrder;
    if (sa.org !== sb.org) return sa.org.localeCompare(sb.org);
    if (sa.order !== sb.order) return sa.order - sb.order;
    return sa.meeting.localeCompare(sb.meeting);
  });

  meetingEntries.forEach(([key, item]) => {
    let org = "";
    let meeting = "";
    let orgKey = "";
    let meetingKey = "";

    const firstBucket = Object.values(item)[0];
    const firstContact = firstBucket && firstBucket[0];

    if (firstContact) {
      org = String(firstContact.fields || "");
      meeting = String(firstContact.meetings || "");
      orgKey = firstContact._fieldsKey || _normKey_(org);
      meetingKey = firstContact._meetingsKey || _normKey_(meeting);
    } else {
      const parts = key.split(", ");
      org = parts.shift() || "";
      meeting = parts.join(", ");
      orgKey = _normKey_(org);
      meetingKey = _normKey_(meeting);
    }

    const anchorId = _makeAnchorId_(org, meeting);

    tocEntries.push({
      org,
      meeting,
      anchorId,
      page: pageIndex + 1,
    });

    CURRENT_FIELD_CONTEXT = org;

    let rowsUsed = 0;
    let hasRenderableContent = false;

    let groupHtmlParts = [];
    groupHtmlParts.push(
      `<div class="group-header" id="${anchorId}">` +
        `<a href="#toc-${anchorId}" style="color:black; text-decoration:none;">` +
          _escapeHtml_(meeting) +
        `</a>` +
      `</div>\n`
    );

    rowsUsed += 1;

    /*************************************************
     * HOUSEHOLD → FAMILY GROUPING
     * OPTIMIZED: precompute normalized keys ONCE
     *************************************************/
    const householdBuckets = new Map();

    Object.values(item).forEach((arr) => {
      (arr || []).forEach((c) => {
        // 🔑 Precompute normalized keys once
        if (!c._famKey) {
          c._famKey   = _normKey_(c.familyName || "");
          c._givenKey = _normKey_(c.givenName || "");
          c._addrKey  = _normKey_(
            c.address1Formatted ||
            c.address2Formatted ||
            c.address3Formatted ||
            ""
          );
        }

        const rel1 = (c.relation1Type || "").toLowerCase();
        const rel2 = (c.relation2Type || "").toLowerCase();

        const isSpouse =
          rel1 === "husband" || rel1 === "wife" ||
          rel2 === "husband" || rel2 === "wife";

        const hhKey = isSpouse
          ? `${c._famKey}@@${c._addrKey}`
          : `${c._famKey}@@${c._addrKey}@@${c._givenKey}`;

        if (!householdBuckets.has(hhKey)) {
          householdBuckets.set(hhKey, []);
        }
        householdBuckets.get(hhKey).push(c);
      });
    });

    const familyGroups = [];

    for (const householdArr of householdBuckets.values()) {
      if (shouldSkipHousehold_(householdArr)) continue;

      const groups = createFamilyGroups_(householdArr);
      groups.forEach((familyContacts) => {
        const first = familyContacts[0] || {};
        familyGroups.push({
          contacts: familyContacts,
          fam: first._famKey || "",
          giv: first._givenKey || "",
          aq:
            familyContacts
              .map(c => String(c.mtgHome1elder2 || "").trim())
              .find(v => v !== "") || ""
        });
      });
    }

    if (familyGroups.length > 1) {
      familyGroups.sort((a, b) => {
        if (a.aq === "" && b.aq !== "") return 1;
        if (a.aq !== "" && b.aq === "") return -1;
        if (a.aq !== b.aq) return a.aq.localeCompare(b.aq);
        if (a.fam !== b.fam) return a.fam.localeCompare(b.fam);
        return a.giv.localeCompare(b.giv);
      });
    }

    /*************************************************
     * RENDER FAMILY GROUPS
     *************************************************/
    familyGroups.forEach((group) => {
      const familyContacts = group.contacts;

      // 🔑 SINGLE render (cached)
      const render = _getFamilyRender_(
        familyContacts,
        mapType,
        italicNoGps
      );

      const need = render.lines.length;
      const remain = MAX_ROWS - rowsUsed;

      if (need > remain && rowsUsed > 0 && hasRenderableContent) {
        pageBuckets.push({ inner: groupHtmlParts.join(""), org });
        pageIndex++;

        groupHtmlParts = [];
        rowsUsed = 0;
        hasRenderableContent = false;

        groupHtmlParts.push(
          `<div class="group-header">` +
            `<a href="#toc-${anchorId}" style="color:black; text-decoration:none;">` +
              _escapeHtml_(meeting + " - continued") +
            `</a>` +
          `</div>\n`
        );

        rowsUsed += 1;
      }

      groupHtmlParts.push(buildFamilyCardHtmlFromLines_(render, mapType));
      rowsUsed += need;
      hasRenderableContent = true;

      // 🔑 OPTIMIZED: reuse cached husband
      const anchor = render.husband;
      if (anchor?.familyName && anchor?.givenName) {
        indexEntries.push({
          last: String(anchor.familyName).toUpperCase(),
          first: String(anchor.givenName),
          page: pageIndex + 1,
        });
      }
    });

    /*************************************************
     * RENDER MEETING INFO (MeetingData)
     *************************************************/

    const tableKey = `${orgKey}@@${meetingKey}`;
    const meetingTables = MeetingDataIndex[tableKey] || [];
    let umCount = 0;

    // ---------- OPTIMIZED RichText prefetch (ONCE per meeting) ----------
    const sheet = SHEETS.MEETING_DATA;

    let meetingRichRows = null;
    let richStartRow = null;

    if (meetingTables.length) {
      const firstTable = meetingTables[0];
      const lastTable  = meetingTables[meetingTables.length - 1];

      richStartRow = firstTable.startRow;

      const richRowCount =
        (lastTable.startRow + lastTable.rows.length) - richStartRow;

      const maxCol = Math.max(
        ...meetingTables.map(t => t.realMaxCol)
      );

        // ONE RPC CALL ONLY
        meetingRichRows = sheet
          .getRange(
            richStartRow + 1, // sheet rows are 1-based
            4,                // column D
            richRowCount,
            maxCol
          )
          .getRichTextValues();
      }

    // ---------- TABLE LOOP ----------
    for (let i = 0; i < meetingTables.length; i++) {
      const table = meetingTables[i];

      // Slice RichText for this table
      const offset = table.startRow - richStartRow;
      const richRows = meetingRichRows
        ? meetingRichRows.slice(
            offset,
            offset + table.rows.length
          )
        : null;

      CURRENT_MEETING_CONTEXT = meeting;
      CURRENT_TABLE_INDEX = i;

      let brokeForThisTable = false;
      const tableRows = _countExactTableRows_(table);
      const TABLE_OVERHEAD_ROWS = 0;

      let need =
        tableRows +
        TABLE_OVERHEAD_ROWS;

      // umt = keep with next table
      if (table.keepWithNext && meetingTables[i + 1]) {
        const nextTable = meetingTables[i + 1];
        const nextRows = _countExactTableRows_(nextTable);
        need += nextRows;
      }
      const remain = _remainingRows_(rowsUsed, MAX_ROWS);

      if (need > remain && rowsUsed > 0) {
        pageBuckets.push({ inner: groupHtmlParts.join(""), org });
        pageIndex++;

        groupHtmlParts = [];
        rowsUsed = 0;
        brokeForThisTable = true;
      }

      // ✅ Print continued header only after a real break
      if (rowsUsed === 0 && brokeForThisTable) {
        groupHtmlParts.push(
          `<div class="group-header">` +
            `<a href="#toc-${anchorId}" style="color:black; text-decoration:none;">` +
              _escapeHtml_(meeting + " - continued") +
            `</a>` +
          `</div>\n`
        );

        rowsUsed += 1;          // (also fix: header is 1 row, not 2)
      }

      // ✅ Now that we know we're on the correct page, insert blank-before if applicable
      // TABLE LAYOUT RULES:
      // Rule #2: WYSIWYG tables use a fixed 28-column grid (wysiwyg-host)
      // Rule #3: Hybrid tables stay on the 28-column grid; merged rows center within the grid (hybrid-wysiwyg)
      // Rule #4: Fully-merged tables may shrink-wrap and center as a unit (fully-merged-center)
      // IMPORTANT: Hybrid tables must NEVER be treated as centered tables.

      // ---- RENDER THIS TABLE (ATOMIC)
      const className = table.isUnionMeeting
        ? (umCount++ === 0
            ? "field-info-table top-table"
            : "field-info-table bottom-table")
        : "field-info-table top-table";

      const isWysiwyg =
        typeof table.isWysiwyg === "boolean"
          ? table.isWysiwyg
          : _isWysiwygTableFromMergeMap_(table.mergeMap);
      const totalCols = 28;
      const isFullyMerged =
        typeof table.isFullyMerged === "boolean"
          ? table.isFullyMerged
          : _isFullyMergedTable_(table.rows, table.mergeMap, totalCols);

      const hasHybridMergedRow = isWysiwyg && _hasHybridMergedRow_(table.rows, table.richRows);
      const isCenteredTable = isFullyMerged;

      // Base WYSIWYG class ALWAYS applied if WYSIWYG
      const wysiwygClass = isWysiwyg ? " wysiwyg-host" : "";

      // Modifier class (Rule #3 or Rule #4)
      const wrapperClass =
        isCenteredTable
          ? " fully-merged-center"
          : (hasHybridMergedRow ? " hybrid-wysiwyg" : "");

      groupHtmlParts.push(`<div class="info-block field-info${wysiwygClass}${wrapperClass}">\n`);

      // --- WYSIWYG MODE: do NOT slice, do NOT center
      const cacheKey = _hashCacheKey_(
        [
          "tableHtml",
          meetingDataVersion,
          meetingDataEditVersion,
          tableKey,
          i,
          className,
          isCenteredTable ? "1" : "0",
          isWysiwyg ? "1" : "0",
          table.fontSizePt != null ? String(table.fontSizePt) : ""
        ].join("|")
      );

      let tableHtml = tableHtmlCache.get(cacheKey);
      if (!tableHtml) {
        tableHtml = _renderTableWithMergeAndStyles_({
          ...table,
          richRows,
          className,
          centered: isCenteredTable,
          isUnionMeeting: table.isUnionMeeting,
          isWysiwyg,
          fontSizePt: table.fontSizePt
        });

        try {
          tableHtmlCache.put(cacheKey, tableHtml, 21600);
        } catch (err) {
          // Cache can reject oversized values; fall back silently.
        }
      }

      // Append exactly ONE table to the group
      groupHtmlParts.push(tableHtml);
      groupHtmlParts.push(`</div>\n`);

      // count what we actually consumed on the page
      rowsUsed += (tableRows + TABLE_OVERHEAD_ROWS);
    }

    // ---- FINAL FLUSH
    const groupHtmlFinal = groupHtmlParts.join("");
    if (groupHtmlFinal.trim()) {
      pageBuckets.push({ inner: groupHtmlFinal, org });
      pageIndex++;
    }
  });

  /*************************************************
   * "What you see is what you get" table rendering
   ************************************************/
  function _isWysiwygTable_(table) {
    return _isWysiwygTableFromMergeMap_(table.mergeMap);
  }

  /*************************************************
   * BUILD TOC + INDEX
   *************************************************/
  tocEntries.push({
    org: "Index",
    meeting: "Index",
    anchorId: "index",
    page: pageIndex + 1,
  });

  const tocPagesBase = _countTocPages_(tocEntries, MAX_ROWS);
  const hasCover = !printPaperBook && includeCover && !!_getTocCoverImageDataUrl_(coverFileName);
  const tocPages = tocPagesBase;
  const contentPages = pageBuckets.length;
  const indexStartPage = tocPages + contentPages + 1;

  tocEntries.forEach((e) => { e.page += tocPages; });
  indexEntries.forEach((e) => { e.page += tocPages; });
  const tocHtml = _buildHtmlToc_(tocEntries, MAX_ROWS, hasCover, coverFileName);
  const pagesHtml = pageBuckets
    .map((p, i) => _wrapPageHtml_(p.inner, p.org, i + tocPages))
    .join("");
  const indexHtml = _buildHtmlIndex_(indexEntries, indexStartPage, MAX_ROWS);

  const html = _wrapAddressBookHtml_(
    tocHtml + pagesHtml + indexHtml,
    addrAlignCss,
    debugTables,
    printPaperBook,
    safeFontSizePt
  );

  /*************************************************
   * SAVE FILE + CONVERT TO PDF
   *************************************************/
  const date = Utilities.formatDate(
    new Date(),
    Session.getScriptTimeZone(),
    "yyyy-MM-dd"
  );

  let name;
  if (printPaperBook) {
    name = `${SETTINGS.FOLDER.BOOK} PrintBook ${date}`;
  } else if (allFieldsSelected) {
    name = `${SETTINGS.FOLDER.BOOK} ${date}`;
  } else if (orgs?.length) {
    name = `${orgs.join(" | ")} Address Book ${date}`;
  } else {
    name = `Address Book ${date}`;
  }

  const parent = _getParentFolderSafe_(ss.getId());

  const targetFolder = outputFolderName || SETTINGS.FOLDER.BOOK;
  // The "phone" PDF should always go to a specific root-level folder
  const phoneFolder = _getFolderByNameLocal_(DriveApp.getRootFolder(), SETTINGS.FOLDER.PDF_PHONE, true);
  const primaryFolder =
    targetFolder === SETTINGS.FOLDER.PDF_PHONE
      ? phoneFolder
      // Other PDFs (like for printing) are saved relative to the spreadsheet
      : _getFolderByNameLocal_(parent, targetFolder, true);
  const htmlFolder =
    targetFolder === SETTINGS.FOLDER.PDF_PHONE && !showHtmlOutput
      ? parent
      : primaryFolder;

  const htmlFile = htmlFolder.createFile(name + ".html", html, MimeType.HTML);
  const pdfFile = _createPdfFileWithRetry_(
    primaryFolder,
    htmlFile,
    name + ".pdf",
    3
  );

  if (targetFolder === SETTINGS.FOLDER.PDF_PHONE) {
    if (phoneFolder) {
      pdfFile.moveTo(phoneFolder);
    } else {
      throw new Error(`Phone folder "${SETTINGS.FOLDER.PDF_PHONE}" not found.`);
    }
    _copyPhonePdfToSharedFolder_(pdfFile);
  } else {
    const fileName = pdfFile.getName();
    if (phoneFolder) {
      _deleteFilesByName_(phoneFolder, fileName);
      pdfFile.makeCopy(fileName, phoneFolder);
    }
  }

  if (!showHtmlOutput) {
    try {
      htmlFile.setTrashed(true);
    } catch (err) {
      // Ignore Drive trash errors so PDF creation still completes.
    }
  }

  if (showPdfOutput) {
    _openLink_(pdfFile.getUrl(), "New PDF address book has been created.", title);
  }
  if (showHtmlOutput) {
    _openLink_(htmlFile.getUrl(), "HTML output has been created.", title);
  }
  if (deletePdfOutput) {
    pdfFile.setTrashed(true);
  }
  ss.toast("Done.", title, 1);
  return pdfFile;
}

function _createFileWithRetry_(folder, filename, content, mimeType, maxAttempts) {
  const attempts = Math.max(1, Number(maxAttempts) || 1);
  let lastErr = null;

  for (let i = 0; i < attempts; i++) {
    try {
      return folder.createFile(filename, content, mimeType);
    } catch (err) {
      lastErr = err;
      Utilities.sleep(500 * Math.pow(2, i));
    }
  }

  throw lastErr;
}

function _createPdfFileWithRetry_(folder, htmlFile, pdfName, maxAttempts) {
  const attempts = Math.max(1, Number(maxAttempts) || 1);
  let lastErr = null;

  for (let i = 0; i < attempts; i++) {
    try {
      const pdfBlob = htmlFile.getBlob().getAs(MimeType.PDF).setName(pdfName);
      return folder.createFile(pdfBlob);
    } catch (err) {
      lastErr = err;
      Utilities.sleep(500 * Math.pow(2, i));
    }
  }

  throw lastErr;
}

/*************************************************
 * PAGE / TOC / INDEX HELPERS
 *************************************************/
function _wrapPageHtml_(inner, org, page, options = {}) {
  const className = options.className ? `page ${options.className}` : "page";
  const pageNumber =
    options.pageNumber != null ? options.pageNumber : (page + 1);
  const showFooter = options.hideFooter ? false : true;
  return (
    `<section class="${className}">` +
      '<div class="page-inner">' +
        inner +
      '</div>' +
      (showFooter
        ? `<div class="page-footer">${_escapeHtml_(org)} · Page ${pageNumber}</div>`
        : "") +
    '</section>\n'
  );
}

function _countTocPages_(tocEntries, rowsPerPage = SETTINGS.BOOK.ROWS) {
  const grouped = _groupTocByOrg_(tocEntries);

  let rowCount = 0;
  let pageCount = 1;

  // Title row
  rowCount++;

  grouped.forEach((entries) => {
    rowCount++; // org header
    entries.forEach(() => {
      rowCount++; // toc line
      if (rowCount >= rowsPerPage) {
        pageCount++;
        rowCount = 0;
      }
    });
  });

  return pageCount;
}

function _groupTocByOrg_(tocEntries) {
  const map = new Map();

  tocEntries.forEach(e => {
    if (!map.has(e.org)) map.set(e.org, []);
    map.get(e.org).push(e);
  });

  return map;
}

function _buildHtmlToc_(tocEntries, rowsPerPage, includeCover = false, coverFileName = null) {
  const grouped = _groupTocByOrg_(tocEntries);
  const coverDataUrl = includeCover ? _getTocCoverImageDataUrl_(coverFileName) : "";

  let pagesHtml = "";
  let chunk = "";
  let rowCount = 0;
  let pageIndex = 1;
  const limit = rowsPerPage || SETTINGS.BOOK.ROWS;

  if (coverDataUrl) {
    pagesHtml += _wrapPageHtml_(
      _buildTocCoverPageHtml_(coverDataUrl),
      "Cover",
      pageIndex - 1,
      { className: "cover-page", hideFooter: true }
    );
    pageIndex++;
  }

  const flushPage = () => {
    const pageNumber = pageIndex + (includeCover ? -1 : 0);
    pagesHtml += _wrapPageHtml_(
      `<div class="toc-page">${chunk}</div>`,
      "Table of Contents",
      pageIndex - 1,
      { pageNumber }
    );
    chunk = "";
    rowCount = 0;
  };

  // Title on first page
  chunk += `<div class="group-header">${_getBookTitleWithDate_()}</div>\n`;
  rowCount++;

  grouped.forEach((entries, org) => {
    chunk += `<div class="toc-org">${_escapeHtml_(org)}</div>\n`;
    rowCount++;

    entries.forEach(e => {
      const label = e.meeting || org;

      chunk +=
        `<div class="toc-line" id="toc-${e.anchorId}">
           <span class="toc-meeting">
             <a href="#${e.anchorId}">${_escapeHtml_(label)}</a>
           </span>
           <span class="toc-dots"></span>
           <span class="toc-page-number">${e.page}</span>
         </div>\n`;

      rowCount++;

      if (rowCount >= limit) {
        flushPage();
        pageIndex++;
      }
    });
  });

  if (chunk.trim()) {
    flushPage();
  }

  return pagesHtml;
}

function _buildHtmlIndex_(entries, startPageNumber = 1, rowsPerPage) {
  // Count in HALF-LINE units for better precision (no wasted space)
  const UNITS_PER_ROW = 2;
  // 🔒 Reserve space for footer + rendering variance (Index only)
  const INDEX_ROWS_PER_PAGE = (rowsPerPage || SETTINGS.BOOK.ROWS) - 1;
  const ROWS_PER_PAGE_UNITS = INDEX_ROWS_PER_PAGE * UNITS_PER_ROW;
  const COST_ENTRY_UNITS  = 2; // 1 full line
  const COST_LETTER_UNITS = 2; // 1 full line (bold but same line-height)
  const COST_SPACER_UNITS = 0;

  if (!entries.length) return "";

  entries.sort((a, b) => {
    if (a.last !== b.last) return a.last.localeCompare(b.last);
    return a.first.localeCompare(b.first);
  });

  // ★ NEW: density metric (used only for index-header row costing)
  const lettersSet = new Set(
    entries.map(e => (e.last.charAt(0) || "").toUpperCase())
  );
  const avgEntriesPerLetter = entries.length / Math.max(lettersSet.size, 1);

  let pagesHtml = "";
  let chunk = "";
  let unitsUsed = 0;
  let pageIndex = 1;
  let currentLetter = "";

  let pageUnitLimit = ROWS_PER_PAGE_UNITS; // ★ NEW

  const startPage = () => {
    chunk = indexHeaderHtml;
    unitsUsed = avgEntriesPerLetter > 10 ? 0 : COST_ENTRY_UNITS;
    pageUnitLimit = ROWS_PER_PAGE_UNITS; // ★ NEW (reset per page)
  };

  const flushPage = () => {
    pagesHtml += _wrapPageHtml_(
      `<div class="index-page">${chunk}</div>`,
      "Index",
      (pageIndex - 1) + (startPageNumber - 1)
    );
    pageIndex++;
    chunk = "";
    unitsUsed = 0;
    currentLetter = "";
  };

  startPage();

  entries.forEach((e) => {
    const letter = (e.last.charAt(0) || "").toUpperCase();

    // Calculate how many units we need for this entry
    let needed = COST_ENTRY_UNITS;

    if (letter !== currentLetter) {
      needed += COST_LETTER_UNITS;
      if (currentLetter !== "") needed += COST_SPACER_UNITS;
    }

    // ★ CHANGED: compare against pageUnitLimit instead of ROWS_PER_PAGE_UNITS
    if (unitsUsed + needed > ROWS_PER_PAGE_UNITS) {
      flushPage();
      startPage();
    }

    // Render letter header (and optional spacer) if needed
    if (letter !== currentLetter) {
      if (currentLetter !== "") {
        chunk += `<div class="index-spacer"></div>\n`;
        unitsUsed += COST_SPACER_UNITS;
      }

      chunk += `<div class="index-letter">${_escapeHtml_(letter)}</div>\n`;
      unitsUsed += COST_LETTER_UNITS;

      currentLetter = letter;
    }

    // Render entry line
    chunk +=
      `<div class="index-line">
         <span class="index-name">${_escapeHtml_(e.last + ", " + e.first)}</span>
         <span class="index-dots"></span>
         <span class="index-page">${e.page}</span>
       </div>\n`;

    unitsUsed += COST_ENTRY_UNITS;
  });

  if (chunk.trim()) {
    pagesHtml += _wrapPageHtml_(
      `<div class="index-page">${chunk}</div>`,
      "Index",
      (pageIndex - 1) + (startPageNumber - 1)
    );
  }

  return pagesHtml;
}

function _hasRealContent_(html) {
  if (!html) return false;

  // If either family cards OR table blocks exist, it’s real content
  return /class="card2"/.test(html) || /class="table-block"/.test(html);
}

function _makeAnchorId_(org, meeting) {
  return (
    "grp-" +
    _normKey_(org + "-" + meeting)
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
  );
}

const shouldSkipHousehold_ = (householdArr) => {
        const hasSpouseRow = householdArr.some((c) => {
          const r1 = (c.relation1Type || "").trim().toLowerCase();
          const r2 = (c.relation2Type || "").trim().toLowerCase();
          return (
            r1 === "husband" ||
            r1 === "wife" ||
            r2 === "husband" ||
            r2 === "wife"
          );
        });

        if (hasSpouseRow) return false;

        return householdArr.some((c) =>
          (c.givenName || "").trim().startsWith("-")
        );
      };

const indexHeaderHtml =
  '<div class="group-header" id="index">' +
    '<a href="#toc-index" style="color:black; text-decoration:none;">Index</a>' +
  '</div>\n';

function _getTocCoverImageDataUrl_(fileName) {
  const folder = _getCoverFolder_();
  if (!folder) {
    return "";
  }

  let file = null;
  if (fileName) {
    const files = folder.getFilesByName(fileName);
    while (files.hasNext()) {
      const candidate = files.next();
      if (candidate.getMimeType().startsWith("image/")) {
        file = candidate;
        break;
      }
    }
  }

  if (!file) {
    return "";
  }

  const blob = file.getBlob();
  const contentType = blob.getContentType() || "image/png";
  const base64 = Utilities.base64Encode(blob.getBytes());
  return `data:${contentType};base64,${base64}`;
}

function _getCoverFolder_() {
  const folderName = SETTINGS.TOC.COVER_FOLDER_PATH;
  if (!folderName) return null;

  // 1. Try to find the folder relative to the spreadsheet file (most common).
  try {
    const ss = _getActiveSpreadsheet_();
    const parent = _getParentFolderSafe_(ss.getId());
    const iter = parent.getFoldersByName(folderName);
    if (iter.hasNext()) return iter.next();
  } catch (e) {
    console.warn("Relative folder search failed: " + e);
  }

  // 2. Try Root folder explicitly
  try {
    const iter = DriveApp.getRootFolder().getFoldersByName(folderName);
    if (iter.hasNext()) return iter.next();
  } catch (e) {
    console.warn("Root folder search failed: " + e);
  }

  // 3. Fallback: Search the entire Drive for the folder by name.
  try {
    const iter = DriveApp.getFoldersByName(folderName);
    if (iter.hasNext()) return iter.next();
  } catch (e) {
    console.warn("Global folder search failed: " + e);
  }

  return null;
}

function _getFolderByPath_(path) {
  if (!path) return null;
  const parts = String(path)
    .split("/")
    .map((p) => p.trim())
    .filter(Boolean);
  if (!parts.length) return null;

  let current = DriveApp.getRootFolder();
  for (const part of parts) {
    const next = current.getFoldersByName(part);
    if (!next.hasNext()) return null;
    current = next.next();
  }
  return current;
}

function _getFolderByNameLocal_(parent, name, createIfMissing) {
  if (!name) return null;
  const base = parent || DriveApp.getRootFolder();
  const iter = base.getFoldersByName(name);
  if (iter.hasNext()) return iter.next();
  if (createIfMissing) return base.createFolder(name);
  return null;
}

function _getParentFolderSafe_(fileId) {
  const file = DriveApp.getFileById(fileId);
  const parents = file.getParents();
  return parents.hasNext() ? parents.next() : DriveApp.getRootFolder();
}

function _copyPhonePdfToSharedFolder_(pdfFile) {
  if (!pdfFile) return;

  const fileName = pdfFile.getName();
  const sharedId = SETTINGS.FOLDER.PDF_PHONE_SHARED_ID;
  if (sharedId) {
    try {
      const folder = DriveApp.getFolderById(sharedId);
      try {
        _deleteFilesByBaseName_(folder, fileName);
      } catch (err) {
        // Ignore cleanup failures.
      }
      pdfFile.makeCopy(fileName, folder);
      return;
    } catch (err) {
      // Fall through to name search.
    }
  }

  const sharedName = SETTINGS.FOLDER.PDF_PHONE_SHARED_NAME;
  if (!sharedName) return;

  const sharedIter = DriveApp.getFoldersByName(sharedName);
  if (!sharedIter.hasNext()) return;

  const folder = sharedIter.next();
  try {
    _deleteFilesByBaseName_(folder, fileName);
  } catch (err) {
    // Ignore cleanup failures.
  }
  pdfFile.makeCopy(fileName, folder);
}

function _deleteFilesByName_(folder, name) {
  if (!folder || !name) return;
  const files = folder.getFilesByName(name);
  while (files.hasNext()) {
    files.next().setTrashed(true);
  }
}

function _stripDateSuffix_(name) {
  const base = String(name || "").replace(/\.[^.]+$/, "");
  return base
    .replace(/\s*\d{4}-\d{2}-\d{2}\s*$/, "")
    .replace(/\s*\d{2}-\d{2}-\d{4}\s*$/, "")
    .replace(/\s*\d{1,2}\/\d{1,2}\/\d{2,4}\s*$/, "")
    .trim();
}

function _deleteFilesByBaseName_(folder, name) {
  if (!folder || !name) return;
  const target = _stripDateSuffix_(name);
  if (!target) return;

  const files = folder.getFiles();
  while (files.hasNext()) {
    const file = files.next();
    const base = _stripDateSuffix_(file.getName());
    if (base === target) {
      try {
        file.setTrashed(true);
      } catch (err) {
        try {
          folder.removeFile(file);
        } catch (removeErr) {
          // Ignore cleanup failures.
        }
      }
    }
  }
}

function _buildTocCoverPageHtml_(coverDataUrl) {
  if (!coverDataUrl) return "";
  return (
    '<div class="toc-cover-page">' +
      `<img class="toc-cover-image" src="${coverDataUrl}" alt="">` +
    '</div>'
  );
}

function createFamilyGroups_(contacts) {
    if (!Array.isArray(contacts) || contacts.length <= 1) return [contacts];

    const normText = (s) =>
      String(s || "")
        .normalize("NFKC")
        .replace(/\u00A0/g, " ")  // NBSP → space
        .trim()
        .replace(/\s+/g, " ");

    const normName = (s) => normText(s).toUpperCase();

    // Only these relation types create links (edit/extend to your labels as needed)
    const SPOUSE_TYPES = new Set(["HUSBAND", "WIFE", "SPOUSE", "PARTNER"]);

    // Normalize nodes we’ll compare
    const nodes = contacts.map((c, idx) => ({
      idx,
      given:  normName(c?.givenName),
      fam:    normName(c?.familyName),
      r1Type: normName(c?.relation1Type),
      r1Val:  normName(c?.relation1Value), // whole cell, as-is
      r2Type: normName(c?.relation2Type),
      r2Val:  normName(c?.relation2Value), // whole cell, as-is
    }));

    // Index by given name → may return multiple indices for same given
    const nameToIdx = new Map();
    nodes.forEach(n => {
      const arr = nameToIdx.get(n.given);
      if (arr) arr.push(n.idx); else nameToIdx.set(n.given, [n.idx]);
    });

    const adj = Array.from({ length: nodes.length }, () => new Set());
    const link = (a, b) => { if (a !== b) { adj[a].add(b); adj[b].add(a); } };
    const getByGiven = (gn) => nameToIdx.get(gn) || [];

    // Link ONLY when a spouse-type relation's value EXACTLY equals the partner's given name
    for (const n of nodes) {
      const rels = [
        { t: n.r1Type, v: n.r1Val },
        { t: n.r2Type, v: n.r2Val },
      ];
      for (const r of rels) {
        if (!r.v || !SPOUSE_TYPES.has(r.t)) continue;
        for (const j of getByGiven(r.v)) {
          const m = nodes[j];
          // Optional reciprocity (safer). Comment out if you want one-sided to count.
          const mRels = [
            { t: m.r1Type, v: m.r1Val },
            { t: m.r2Type, v: m.r2Val },
          ];
          const mIsSpouseOfN = mRels.some(rr => SPOUSE_TYPES.has(rr.t) && rr.v === n.given);
          if (mIsSpouseOfN) link(n.idx, j);
        }
      }
    }

    // Connected components => groups
    const seen = new Array(nodes.length).fill(false);
    const groups = [];
    for (let i = 0; i < nodes.length; i++) {
      if (seen[i]) continue;
      const comp = [];
      const stack = [i];
      seen[i] = true;
      while (stack.length) {
        const v = stack.pop();
        comp.push(contacts[nodes[v].idx]);
        adj[v].forEach(w => { if (!seen[w]) { seen[w] = true; stack.push(w); } });
      }
      groups.push(comp);
    }

    return groups;
}

/*************************************************
 * HTML WRAPPER
 *************************************************/

function _wrapAddressBookHtml_(pagesHtml, addrAlignCss, debugTables = false, printPaperBook = false, fontSizePt = 6.5) {
  const widthIn  = SETTINGS.BOOK.WIDTH  || 3.5;
  const heightIn = SETTINGS.BOOK.HEIGHT || 5;

  const debugCss = debugTables ? `
    table.field-info-table {
      table-layout: fixed !important;
    }
    table.field-info-table td {
      border: 0.25pt solid rgba(0, 0, 255, 0.35) !important;
      width: 16px;
    }
  ` : `
    table.field-info-table td {
      border: none;
    }
  `;
  const printCss = printPaperBook ? `
    .page-inner { padding-left: 0.1875in; padding-right: 0.1875in; }
    .page:nth-of-type(odd) .page-inner { padding-left: 0.3125in; padding-right: 0.1875in; }
    .page:nth-of-type(even) .page-inner { padding-left: 0.1875in; padding-right: 0.3125in; }
  ` : "";

  return `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${_getBookTitleWithDate_()}</title>
  <style>
    @page {
      /* font-size: ${fontSizePt}pt; */
      size: ${widthIn}in ${heightIn}in;
      margin: 0;
    }

    body {
      margin: 0;
      font-family: "Arial";
      font-size: ${fontSizePt}pt;
      line-height: 1.1;
    }

    /* One logical 3.5x5 page per meeting group */
    .page {
      page-break-after: always;
      display: grid;
      grid-template-rows: 1fr auto; /* content + footer */
      box-sizing: border-box;
      width: 100%;
      height: ${heightIn}in;
      overflow: hidden;
    }

    .page-content {
      flex: 1 1 auto;
      overflow: hidden; /* or auto/scroll if you want to allow scrollable tables */
    }

    .page:last-child {
      page-break-after: auto;
    }

    .page:first-of-type {
      page-break-before: auto;
    }

    .page-inner {
      height: auto;
      padding: 0.18in;
      padding-bottom: 0; /* leave space for the footer */
      box-sizing: border-box;
      position: relative; /* ← REQUIRED */
    }

    .page-footer {
      position: static; /*position: absolute;*/
      bottom: 0;
      left: 0;
      right: 0;
      text-align: center;
      width: 100%;
      font-size: ${fontSizePt}pt;
      padding-bottom: 0.18in;
    }

    /* ==========================
     * TABLE OF CONTENTS (SCOPED)
     * ========================== */
    .toc-page .toc-org {
      font-weight: bold;
      margin-top: 0.6em;
      margin-bottom: 0.2em;
      text-align: left;
    }

    .toc-page .toc-line {
      display: grid;
      grid-template-columns: max-content 1fr max-content;
      align-items: baseline;
      margin-left: 1.2em; /* indent under Field */
      font-size: ${fontSizePt}pt;
    }

    .toc-page .toc-dots {
      border-bottom: 1px dotted #000;
      margin: 0 0.4em;
      height: 0.6em;
    }

    .toc-page .toc-line a {
      text-decoration: none;
      color: black;
    }

    .toc-page .toc-page-number {
      text-align: right;
      padding-left: 1em;
      padding-right: 0.12in;
    }

    .toc-cover-page {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      height: 100%;
    }

    .toc-cover-image {
      width: 100%;
      height: 100%;
      object-fit: cover;
      opacity: ${SETTINGS.TOC.COVER_OPACITY};
    }

    .page.cover-page .page-inner {
      padding: 0;
    }

    .page.cover-page .page-footer {
      display: none;
    }

    .toc-org {
      font-weight: bold;
      margin-top: 0.6em;
      margin-bottom: 0.2em;
      text-align: left;
    }

    .toc-meeting {
      text-align: left;
    }

    /* Meeting / Field header */
    .group-header {
      font-weight: bold;
      text-align: center;
      margin-bottom: 3pt;
    }

    /* Gap between contact cards and info blocks */
    .info-gap {
      height: 1em;
    }

    /* Info blocks */
    .info-block {
      font-size: ${fontSizePt}pt;
      line-height: 1.2;
      margin-top: 0;
    }

    .info-block.field-info {
      break-inside: auto;
      page-break-inside: auto;
      break-before: auto;
      page-break-before: auto;
    }

    /* Union meeting tables: expand columns but stay centered */
    .info-block.field-info.centered.union-meeting {
      width: 100%;
    }

    .info-block.field-info.centered.union-meeting .table-block {
      display: block;
    }

    /* Only for centered field-info tables */
    .info-block.field-info.centered table.field-info-table {
      table-layout: fixed;
    }

    .info-line {
      margin: 0;
      display: block;
      width: 100%;
    }

    .info-line.preserve-space {
      white-space: pre;
    }

    .info-line.blank {
      height: 1em;
      display: block;
    }

    .info-line.align-center  { text-align: center; }
    .info-line.align-right   { text-align: right; }
    .info-line.align-justify { text-align: justify; }
    .info-line.align-left    { text-align: left; }

    /* ===============================
    * FieldInfo table (MeetingData)
    * =============================== */
    /* Each individual table is atomic */
    .table-atomic {
      break-inside: avoid;
      page-break-inside: avoid;
      break-before: auto;
      page-break-before: auto;
    }

    table.field-info-table {
      border-collapse: collapse;
      font-family: ${SETTINGS.BOOK.FONT};
      font-size: ${fontSizePt}pt;
    }

    table.field-info-table td {
      border: none;
      padding: 0;
      text-align: left;
      vertical-align: top;
      white-space: nowrap;
      overflow: visible;
      text-overflow: clip;
      word-break: normal;      /* never break words */
      overflow-wrap: normal;
    }

    table.field-info-table tr.blank-row td {
      padding-top: 0;
      height: 1.2em;
      line-height: 1.2;
    }

    /* IMPORTANT:
    * Table underlines MUST be cell-based (.underline-cell).
    * Do NOT add row-level (<tr>) underline rules — they break merges and rich text.
    */
    /* Row underline from 'ul' — structural only */
    table.field-info-table td.underline-cell {
      border-bottom: 1pt solid #000;
    }

    .table-gap {
      height: 0.65em;
    }

    .table-block {
      display: block;
      break-inside: avoid;
      page-break-inside: avoid;
    }

    .table-block.centered {
      display: inline-block;
      margin-left: auto;
      margin-right: auto;
    }

    /* ============================
    * WYSIWYG TABLE — HARD OVERRIDE
    * ============================ */
    .info-block.field-info.wysiwyg-host .table-block {
      display: block !important;
      width: 100% !important;
      max-width: 100% !important;
      margin: 0 !important;
    }

    .table-break {
      break-before: page;
      page-break-before: always;
    }

    /* WYSIWYG tables must escape flex layout entirely */
    .info-block.field-info.wysiwyg-host {
      display: block !important;
      align-self: flex-start !important;
      width: 100%;
    }

    /* WYSIWYG tables: fixed grid like Sheets — EXCEPT fully-merged centered ones */
    .info-block.field-info.wysiwyg-host:not(.fully-merged-center) table.field-info-table {
        width: 100%;
        table-layout: fixed;
    }

    /* WYSIWYG — override only if fully-merged and safe to center */
    .info-block.field-info.wysiwyg-host.fully-merged-center .table-block {
      display: inline-block !important;
      margin-left: auto !important;
      margin-right: auto !important;
      width: auto !important;
      max-width: none !important;
    }

    .info-block.field-info.wysiwyg-host.fully-merged-center table.field-info-table {
      table-layout: auto !important;
      width: auto !important;
    }

    /* Family card */
    .card2 {
      display: grid;
      grid-template-columns: 14ch 1fr; /* 12ch phone + 2ch code = 14ch */
      column-gap: 0.5ch;
      page-break-inside: avoid;
      margin-bottom: 1pt;
      align-items: start;
    }

    /* LEFT column: phones/codes stack tightly */
    .card2 .left {
      display: grid;
      grid-template-columns: 12ch 2ch;
      grid-auto-rows: min-content;
      row-gap: 0;
      align-content: start;
    }

    .card2 .left-line { display: contents; }
    .card2 .left .p { grid-column: 1; }
    .card2 .left .c { grid-column: 2; text-align: left; white-space: nowrap; }

    /* RIGHT column */
    .card2 .right { align-self: start; }

    .card2 .name {
      font-weight: bold;
      padding-left: 2ch;
      text-indent: -1ch;
    }

    .card2 .name .rest { font-weight: normal; }

    .card2 .address {
      padding-left: 2ch;
      ${addrAlignCss || "text-align: left;"}
    }

    .card2 .address a {
      color: #000;
      text-decoration: none;
    }
    .card2 .address a:hover {
      color: #000;
      text-decoration: none;
    }

    /* ==========================
    * BACK-OF-BOOK INDEX
    * ========================== */

    .index-page .index-letter {
      font-weight: bold;
      margin: 0;
      text-align: left;
      line-height: 1.1;
    }

    .index-page .index-spacer {
      height: 0.55em;
      display: block;
    }

    .index-page .index-line {
      display: grid;
      grid-template-columns: max-content 1fr max-content;
      align-items: baseline;
      font-size: ${fontSizePt}pt;
    }

    .index-page .index-name {
      white-space: nowrap;
    }

    .index-page .index-dots {
      border-bottom: 1px dotted #000;
      margin: 0 0.4em;
      height: 0.6em;
    }

    .index-page .index-page {
      text-align: right;
    }

    /* ===== OVERRIDE: let fully‑merged tables auto‑size ===== */
    .info-block.field-info.fully-merged-center table.field-info-table {
      table-layout: auto !important;
      width: auto !important;
    }

    /* Outer flexbox to center a shrink‑to‑fit table */
    .table-outer-wrapper.fully-merged-center {
      display: flex !important;
      justify-content: center !important;
      width: 100%;
    }

    /* Keep the inner block shrink‑to‑fit */
    .table-outer-wrapper.fully-merged-center .table-block {
      display: inline-block !important;
      width: auto !important;
      max-width: none !important;
    }

    /* Table itself auto width */
    .table-outer-wrapper.fully-merged-center .table-block table.field-info-table {
      display: inline-table !important;
      table-layout: auto !important;
      width: auto !important;
    }
    
    ${debugCss}
    ${printCss}
  </style>
</head>
<body${printPaperBook ? ' class="print-paper"' : ''}>
${pagesHtml}
</body>
</html>`;
}

function printSelectedFieldList(fieldName, includeMeetingInfo, addressAlign, showSeparatorLines, fontSizePt, meetings) {
  const field = String(fieldName || "").trim();
  if (!field) throw new Error("Select a field first.");

  let lastErr = null;
  for (let i = 0; i < 3; i++) {
    try {
      return createFieldListHtml_({
        orgs: [field],
        includeMeetingNotes: !!includeMeetingInfo,
        mapType: "google",
        italicNoGps: true,
        addressAlign: addressAlign,
        showSeparatorLines: showSeparatorLines !== false,
        fontSizePt: fontSizePt,
        meetings: meetings
      });
    } catch (err) {
      lastErr = err;
      console.warn(`Field List creation attempt ${i + 1} failed: ${err.message}`);
      Utilities.sleep(2000);
    }
  }
  throw lastErr;
}

function _coerceFieldListFontSizePt_(value) {
  const num = Number(value);
  if (!num || Number.isNaN(num)) return FIELD_LIST_BASE_FONT_SIZE_PT;
  return Math.min(FIELD_LIST_MAX_FONT_SIZE_PT, Math.max(FIELD_LIST_MIN_FONT_SIZE_PT, num));
}

function _scaleFieldListPt_(base, fontSizePt) {
  return base * (fontSizePt / FIELD_LIST_BASE_FONT_SIZE_PT);
}

function _getFieldListMaxRows_(columnIndex, fontSizePt) {
  const firstRows = Number(SETTINGS.TWO_COLUMN.FIRST_PAGE_ROWS) || 0;
  const otherRows = Number(SETTINGS.TWO_COLUMN.ROWS) || firstRows;
  const baseRows =
    columnIndex < 2
      ? firstRows
      : (firstRows ? Math.min(firstRows, otherRows) : otherRows);
  const fontScale = FIELD_LIST_BASE_FONT_SIZE_PT / Math.max(fontSizePt || FIELD_LIST_BASE_FONT_SIZE_PT, 0.1);
  const scaledRows = Math.floor(baseRows * fontScale);
  const safetyRows = fontSizePt > FIELD_LIST_BASE_FONT_SIZE_PT ? 1 : 0;
  return Math.max(1, scaledRows - 2 - safetyRows);
}

function createFieldListHtml_(payload = {}) {
  let {
    orgs,
    includeMeetingNotes = true,
    mapType = "google",
    italicNoGps = true,
    addressAlign = "left",
    showSeparatorLines = true,
    fontSizePt,
    meetings
  } = payload;
  fontSizePt = _coerceFieldListFontSizePt_(fontSizePt);
  if (!Array.isArray(orgs) || !orgs.length) {
    throw new Error("No Field selected.");
  }

  const fieldName = String(orgs[0] || "").trim();
  if (!fieldName) throw new Error("No Field selected.");

  const ss = _getActiveSpreadsheet_();
  const contactsSheet = ss.getSheetByName(SETTINGS.SN.CONTACTS);
  const meetingSheet = ss.getSheetByName("MeetingData");

  if (!contactsSheet) {
    throw new Error(`Contacts sheet "${SETTINGS.SN.CONTACTS}" not found`);
  }
  if (includeMeetingNotes && !meetingSheet) {
    throw new Error("Missing 'MeetingData' sheet");
  }

  const title = "Create Field List";
  ss.toast("Processing field list…", title, -1);

  const driveFile = DriveApp.getFileById(ss.getId());
  const meetingDataIndex = includeMeetingNotes
    ? getMeetingDataIndexCached_(driveFile)
    : {};
  const meetingDataVersion = includeMeetingNotes
    ? _getMeetingDataCacheVersion_()
    : "";
  const settingsSheet = ss.getSheetByName("Settings");
  const meetingOrderMap = _getMeetingOrderMapFromSettings_(settingsSheet);
  const tableHtmlCache = CacheService.getScriptCache();
  const { contacts } = getContacts_(orgs, contactsSheet);

  const pageBuckets = [];
  let layoutPageIndex = 0;
  let pageRowsUsed = 0;
  let pageParts = [];

  const getMaxRowsForPage = () => _getFieldListMaxRows_(layoutPageIndex * 2, fontSizePt);

  const flushPage = () => {
    const html = pageParts.join("");
    if (html.trim()) {
      pageBuckets.push({ inner: html, org: fieldName });
    }
    pageParts = [];
    pageRowsUsed = 0;
    layoutPageIndex++;
  };

  const meetingEntries = Object.entries(contacts);
  const meetingSortCache = new Map();
  const getMeetingSort = (entry) => {
    if (meetingSortCache.has(entry[0])) return meetingSortCache.get(entry[0]);

    const item = entry[1] || {};
    let meeting = "";

    const firstBucket = Object.values(item)[0];
    const firstContact = firstBucket && firstBucket[0];

    if (firstContact) {
      meeting = String(firstContact.meetings || "");
    } else {
      const parts = String(entry[0] || "").split(", ");
      parts.shift();
      meeting = parts.join(", ");
    }

    const meetingKey = _normKey_(meeting);
    const order = meetingOrderMap[meetingKey];
    const sort = {
      order: typeof order === "number" ? order : Number.POSITIVE_INFINITY,
      meeting: meeting
    };
    meetingSortCache.set(entry[0], sort);
    return sort;
  };

  meetingEntries.sort((a, b) => {
    const sa = getMeetingSort(a);
    const sb = getMeetingSort(b);
    if (sa.order !== sb.order) return sa.order - sb.order;
    return sa.meeting.localeCompare(sb.meeting);
  });

  const meetingFilter =
    Array.isArray(meetings) && meetings.length
      ? new Set(meetings.map(_normKey_))
      : null;

  meetingEntries.forEach(([key, item]) => {
    let org = "";
    let meeting = "";
    let orgKey = "";
    let meetingKey = "";

    const firstBucket = Object.values(item)[0];
    const firstContact = firstBucket && firstBucket[0];

    if (firstContact) {
      org = String(firstContact.fields || "");
      meeting = String(firstContact.meetings || "");
      orgKey = firstContact._fieldsKey || _normKey_(org);
      meetingKey = firstContact._meetingsKey || _normKey_(meeting);
    } else {
      const parts = key.split(", ");
      org = parts.shift() || "";
      meeting = parts.join(", ");
      orgKey = _normKey_(org);
      meetingKey = _normKey_(meeting);
    }

    if (meetingFilter && !meetingFilter.has(meetingKey)) {
      return;
    }

    const householdBuckets = new Map();

    Object.values(item).forEach((arr) => {
      (arr || []).forEach((c) => {
        if (!c._famKey) {
          c._famKey = _normKey_(c.familyName || "");
          c._givenKey = _normKey_(c.givenName || "");
          c._addrKey = _normKey_(
            c.address1Formatted ||
            c.address2Formatted ||
            c.address3Formatted ||
            ""
          );
        }

        const rel1 = (c.relation1Type || "").toLowerCase();
        const rel2 = (c.relation2Type || "").toLowerCase();

        const isSpouse =
          rel1 === "husband" || rel1 === "wife" ||
          rel2 === "husband" || rel2 === "wife";

        const hhKey = isSpouse
          ? `${c._famKey}@@${c._addrKey}`
          : `${c._famKey}@@${c._addrKey}@@${c._givenKey}`;

        if (!householdBuckets.has(hhKey)) {
          householdBuckets.set(hhKey, []);
        }
        householdBuckets.get(hhKey).push(c);
      });
    });

    const familyGroups = [];

    for (const householdArr of householdBuckets.values()) {
      if (shouldSkipHousehold_(householdArr)) continue;

      const groups = createFamilyGroups_(householdArr);
      groups.forEach((familyContacts) => {
        const first = familyContacts[0] || {};
        familyGroups.push({
          contacts: familyContacts,
          fam: first._famKey || "",
          giv: first._givenKey || "",
          aq:
            familyContacts
              .map(c => String(c.mtgHome1elder2 || "").trim())
              .find(v => v !== "") || ""
        });
      });
    }

    if (familyGroups.length > 1) {
      familyGroups.sort((a, b) => {
        if (a.aq === "" && b.aq !== "") return 1;
        if (a.aq !== "" && b.aq === "") return -1;
        if (a.aq !== b.aq) return a.aq.localeCompare(b.aq);
        if (a.fam !== b.fam) return a.fam.localeCompare(b.fam);
        return a.giv.localeCompare(b.giv);
      });
    }

    let meetingTables = [];
    if (includeMeetingNotes) {
      const tableKey = `${orgKey}@@${meetingKey}`;
      meetingTables = meetingDataIndex[tableKey] || [];
    }

    const tableKey = `${orgKey}@@${meetingKey}`;
    const items = _buildFieldListMeetingItems_(
      familyGroups,
      mapType,
      italicNoGps,
      includeMeetingNotes,
      meetingTables,
      meetingSheet,
      meetingDataVersion,
      tableKey
    );

    if (!items.length) {
      return;
    }

    const meetingCounts = _countFieldListItemTypes_(items, 0, items.length);
    const meetingHasTables = meetingCounts.tableGroups > 0;

    let startIndex = 0;
    let isContinued = false;

    while (startIndex < items.length) {
      const pageMaxRows = getMaxRowsForPage();
      let availableRows = pageMaxRows - pageRowsUsed;
      const separatorRows = pageRowsUsed > 0 && !isContinued ? 1 : 0;
      availableRows -= separatorRows;

      const HEADER_ROWS = 1;
      availableRows -= HEADER_ROWS;

      if (availableRows <= 0) {
        flushPage();
        continue;
      }

      let segment = _buildFieldListMeetingSegment_(
        items,
        startIndex,
        availableRows,
        tableHtmlCache
      );

      if (!segment && pageRowsUsed > 0) {
        flushPage();
        continue;
      }

      if (!segment) {
        segment = _buildFieldListMeetingSegment_(
          items,
          startIndex,
          availableRows,
          tableHtmlCache,
          true
        );
      }

      if (!segment) {
        break;
      }

      const segmentCounts = _countFieldListItemTypes_(
        items,
        startIndex,
        segment.endIndex
      );
      const meetingContinues = segment.endIndex < items.length;
      const shouldDeferToNextPage =
        !isContinued &&
        pageRowsUsed > 0 &&
        meetingContinues &&
        (
          (meetingHasTables && segmentCounts.tableGroups === 0) ||
          (
            segmentCounts.tableGroups === 0 &&
            segmentCounts.families === 2 &&
            (meetingHasTables || meetingCounts.families > 2)
          ) ||
          segmentCounts.families === 3 ||
          segmentCounts.families === 4
        );

      if (shouldDeferToNextPage) {
        flushPage();
        continue;
      }

      if (pageRowsUsed > 0 && !isContinued) {
        pageParts.push(`<div class="meeting-separator"></div>\n`);
        pageRowsUsed += 1;
      }

      const label = isContinued ? meeting + " - continued" : meeting;
      pageParts.push(
        _renderFieldListMeetingBlock_(label, segment.leftHtml, segment.rightHtml)
      );

      pageRowsUsed += HEADER_ROWS + segment.maxRows;
      startIndex = segment.endIndex;
      isContinued = true;

      if (pageRowsUsed >= getMaxRowsForPage()) {
        flushPage();
      }
    }
  });

  if (pageParts.length) {
    pageBuckets.push({ inner: pageParts.join(""), org: fieldName });
  }

  if (!pageBuckets.length) {
    throw new Error("No meetings found for this field.");
  }

  const headerTitle = `${fieldName} Field List - ${Utilities.formatDate(
    new Date(),
    Session.getScriptTimeZone(),
    "MM/dd/yyyy"
  )}`;
  let pagesHtml = "";
  let pageIndex = 1;

  for (let i = 0; i < pageBuckets.length; i++) {
    const inner = pageBuckets[i] ? pageBuckets[i].inner : "";
    pagesHtml += _wrapFieldListPageHtml_(
      inner,
      pageIndex,
      fieldName,
      headerTitle
    );
    pageIndex++;
  }

  const html = _wrapFieldListHtml_(
    pagesHtml,
    fieldName,
    addressAlign,
    showSeparatorLines,
    fontSizePt
  );

  const date = Utilities.formatDate(
    new Date(),
    Session.getScriptTimeZone(),
    "yyyy-MM-dd"
  );

  const name = `${fieldName} Field List ${includeMeetingNotes ? "with" : "without"} Meeting Info ${date}`;

  const parent = _getParentFolderSafe_(ss.getId());

  const folder = _getFolderByNameLocal_(parent, SETTINGS.FOLDER.FIELD_LIST, true);

  const htmlFile = _createFileWithRetry_(folder, name + ".html", html, MimeType.HTML, 3);
  const pdfFile = _createPdfFileWithRetry_(
    folder,
    htmlFile,
    name + ".pdf",
    3
  );

  htmlFile.setTrashed(true);

  if (typeof _openLink_ === "function") {
    _openLink_(pdfFile.getUrl(), "New PDF field list has been created.", title);
  } else {
    ss.toast("Field list created.", title, 3);
  }

  ss.toast("Done.", title, 1);
  return pdfFile;
}

function _buildFieldListMeetingItems_(
  familyGroups,
  mapType,
  italicNoGps,
  includeMeetingNotes,
  meetingTables,
  meetingSheet,
  meetingDataVersion,
  tableKey
) {
  const items = [];
  const meetingDataEditVersion = _getMeetingDataEditVersion_();

  familyGroups.forEach((group) => {
    const render = _getFamilyRender_(
      group.contacts,
      mapType,
      italicNoGps
    );

    items.push({
      type: "family",
      rows: render.lines.length,
      html: buildFamilyCardHtmlFromLines_(render, mapType)
    });
  });

  if (!includeMeetingNotes || !meetingTables.length) {
    return items;
  }

  let meetingRichRows = null;
  let richStartRow = null;

  if (meetingTables.length) {
    const firstTable = meetingTables[0];
    const lastTable = meetingTables[meetingTables.length - 1];

    richStartRow = firstTable.startRow;

    const richRowCount =
      (lastTable.startRow + lastTable.rows.length) - richStartRow;

    const maxCol = Math.max(
      ...meetingTables.map(t => t.realMaxCol)
    );

    meetingRichRows = meetingSheet
      .getRange(
        richStartRow + 1,
        4,
        richRowCount,
        maxCol
      )
      .getRichTextValues();
  }

  let umCount = 0;

  for (let i = 0; i < meetingTables.length; i++) {
    const groupTables = [];
    let table = meetingTables[i];

    while (table) {
      const offset = table.startRow - richStartRow;
      const richRows = meetingRichRows
        ? meetingRichRows.slice(
            offset,
            offset + table.rows.length
          )
        : null;

      const tableRows = _countExactTableRows_(table);
      const className = table.isUnionMeeting
        ? (umCount++ === 0
            ? "field-info-table top-table"
            : "field-info-table bottom-table")
        : "field-info-table top-table";

      const isWysiwyg =
        typeof table.isWysiwyg === "boolean"
          ? table.isWysiwyg
          : _isWysiwygTableFromMergeMap_(table.mergeMap);

      const totalCols = 28;
      const isFullyMerged =
        typeof table.isFullyMerged === "boolean"
          ? table.isFullyMerged
          : _isFullyMergedTable_(table.rows, table.mergeMap, totalCols);

      const hasHybridMergedRow = isWysiwyg && _hasHybridMergedRow_(table.rows, richRows);
      const isCenteredTable = isFullyMerged;

      const cacheKey = _hashCacheKey_(
        [
          "tableHtml",
          meetingDataVersion,
          meetingDataEditVersion,
          tableKey,
          i,
          className,
          isCenteredTable ? "1" : "0",
          isWysiwyg ? "1" : "0",
          table.fontSizePt != null ? String(table.fontSizePt) : ""
        ].join("|")
      );

      groupTables.push({
        type: "table",
        table: table,
        tableRows: tableRows,
        className: className,
        isWysiwyg: isWysiwyg,
        isCenteredTable: isCenteredTable,
        hasHybridMergedRow: hasHybridMergedRow,
        richRows: richRows,
        fontSizePt: table.fontSizePt,
        cacheKey: cacheKey
      });

      if (table.keepWithNext && meetingTables[i + 1]) {
        i++;
        table = meetingTables[i];
      } else {
        table = null;
      }
    }

    items.push({
      type: "tableGroup",
      tables: groupTables
    });
  }

  return items;
}

function _countFieldListRowsForItems_(items, startIndex, endIndex) {
  let rowsUsed = 0;
  for (let i = startIndex; i < endIndex; i++) {
    const item = items[i];
    if (item.type === "family") {
      rowsUsed += item.rows;
      continue;
    }

    if (item.type !== "tableGroup") continue;

    item.tables.forEach((tableMeta) => {
      rowsUsed += tableMeta.tableRows;
    });
  }

  return rowsUsed;
}

function _countFieldListItemTypes_(items, startIndex, endIndex) {
  let families = 0;
  let tableGroups = 0;

  for (let i = startIndex; i < endIndex; i++) {
    const item = items[i];
    if (item.type === "family") families++;
    else if (item.type === "tableGroup") tableGroups++;
  }

  return {
    families,
    tableGroups,
    total: endIndex - startIndex
  };
}

function _findBestFieldListSplit_(items, startIndex, endIndex) {
  const count = endIndex - startIndex;
  if (count <= 0) return null;

  let best = null;
  const startSplit = count === 1 ? endIndex : startIndex + 1;
  const endSplit = count === 1 ? endIndex : endIndex - 1;

  for (let split = startSplit; split <= endSplit; split++) {
    const leftRows = _countFieldListRowsForItems_(items, startIndex, split);
    const rightRows = _countFieldListRowsForItems_(items, split, endIndex);
    const maxRows = Math.max(leftRows, rightRows);
    const diff = Math.abs(leftRows - rightRows);

    if (!best || maxRows < best.maxRows || (maxRows === best.maxRows && diff < best.diff)) {
      best = {
        splitIndex: split,
        leftRows: leftRows,
        rightRows: rightRows,
        maxRows: maxRows,
        diff: diff
      };
    }
  }

  return best;
}

function _buildFieldListMeetingSegment_(
  items,
  startIndex,
  maxContentRows,
  tableHtmlCache,
  force
) {
  if (force) {
    const endIndex = Math.min(startIndex + 1, items.length);
    const split = _findBestFieldListSplit_(items, startIndex, endIndex);
    if (!split) return null;
    return _renderFieldListMeetingSegment_(
      items,
      startIndex,
      endIndex,
      split,
      tableHtmlCache
    );
  }

  let bestSegment = null;

  for (let endIndex = startIndex + 1; endIndex <= items.length; endIndex++) {
    const split = _findBestFieldListSplit_(items, startIndex, endIndex);
    if (!split) continue;

    if (split.maxRows <= maxContentRows) {
      bestSegment = { endIndex, split };
      continue;
    }

    break;
  }

  if (!bestSegment) return null;

  return _renderFieldListMeetingSegment_(
    items,
    startIndex,
    bestSegment.endIndex,
    bestSegment.split,
    tableHtmlCache
  );
}

function _renderFieldListMeetingSegment_(
  items,
  startIndex,
  endIndex,
  split,
  tableHtmlCache
) {
  const left = _renderFieldListMeetingColumn_(
    items,
    startIndex,
    split.splitIndex,
    tableHtmlCache
  );
  const right = _renderFieldListMeetingColumn_(
    items,
    split.splitIndex,
    endIndex,
    tableHtmlCache
  );

  return {
    endIndex: endIndex,
    leftHtml: left.html,
    rightHtml: right.html,
    leftRows: left.rowsUsed,
    rightRows: right.rowsUsed,
    maxRows: Math.max(left.rowsUsed, right.rowsUsed)
  };
}

function _renderFieldListMeetingColumn_(
  items,
  startIndex,
  endIndex,
  tableHtmlCache
) {
  let rowsUsed = 0;
  const out = [];

  for (let i = startIndex; i < endIndex; i++) {
    const item = items[i];
    if (item.type === "family") {
      out.push(item.html);
      rowsUsed += item.rows;
      continue;
    }

    if (item.type !== "tableGroup") continue;

    item.tables.forEach((tableMeta) => {
      const tableHtml = _renderFieldListTableHtml_(tableMeta, tableHtmlCache);
      if (tableHtml) {
        out.push(tableHtml);
        rowsUsed += tableMeta.tableRows;
      }
    });
  }

  return {
    html: out.join(""),
    rowsUsed: rowsUsed
  };
}

function _renderFieldListTableHtml_(tableMeta, tableHtmlCache) {
  const table = tableMeta.table;

  const wysiwygClass = tableMeta.isWysiwyg ? " wysiwyg-host" : "";
  const wrapperClass =
    tableMeta.isCenteredTable
      ? " fully-merged-center"
      : (tableMeta.hasHybridMergedRow ? " hybrid-wysiwyg" : "");

  let tableHtml = tableHtmlCache.get(tableMeta.cacheKey);
  if (!tableHtml) {
    tableHtml = _renderTableWithMergeAndStyles_({
      ...table,
      richRows: tableMeta.richRows,
      className: tableMeta.className,
      centered: tableMeta.isCenteredTable,
      isUnionMeeting: table.isUnionMeeting,
      isWysiwyg: tableMeta.isWysiwyg,
      fontSizePt: tableMeta.fontSizePt
    });

    try {
      tableHtmlCache.put(tableMeta.cacheKey, tableHtml, 21600);
    } catch (err) {
      // Cache can reject oversized values; fall back silently.
    }
  }

  if (!tableHtml) return "";

  return (
    `<div class="info-block field-info${wysiwygClass}${wrapperClass}">\n` +
      tableHtml +
    `</div>\n`
  );
}

function _renderFieldListMeetingBlock_(label, leftHtml, rightHtml) {
  return (
    `<div class="meeting-block">` +
      `<div class="group-header">${_escapeHtml_(label)}</div>` +
      `<div class="meeting-columns">` +
        `<div class="meeting-column">${leftHtml || ""}</div>` +
        `<div class="meeting-column">${rightHtml || ""}</div>` +
      `</div>` +
    `</div>\n`
  );
}

function _wrapFieldListPageHtml_(innerHtml, pageNumber, fieldLabel, headerTitle) {
  return (
    `<section class="page">` +
      `<div class="page-inner two-col">` +
        `<div class="field-list-title">${_escapeHtml_(headerTitle || "")}</div>` +
        `<div class="meeting-list">${innerHtml || ""}</div>` +
      `</div>` +
      `<div class="page-footer">${_escapeHtml_(fieldLabel)} · Page ${pageNumber}</div>` +
    `</section>\n`
  );
}

function _wrapFieldListHtml_(pagesHtml, fieldLabel, addressAlign, showSeparatorLines, fontSizePt) {
  const widthIn = SETTINGS.TWO_COLUMN.WIDTH || 8.5;
  const heightIn = SETTINGS.TWO_COLUMN.HEIGHT || 11;
  const addrAlignCss = addressAlign === "right" ? "text-align: right;" : "text-align: left;";
  const bodyClass = showSeparatorLines ? "" : ' class="no-separator-lines"';
  const safeFontSizePt = _coerceFieldListFontSizePt_(fontSizePt);
  const titleSizePt = _scaleFieldListPt_(FIELD_LIST_BASE_TITLE_SIZE_PT, safeFontSizePt);
  const groupHeaderSizePt = _scaleFieldListPt_(FIELD_LIST_BASE_GROUP_HEADER_SIZE_PT, safeFontSizePt);
  const footerSizePt = _scaleFieldListPt_(FIELD_LIST_BASE_FOOTER_SIZE_PT, safeFontSizePt);

  return `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${_escapeHtml_(fieldLabel)} Field List</title>
  <style>
    :root { --field-list-font-pt: ${safeFontSizePt.toFixed(2)}pt; }
    @page {
      size: ${widthIn}in ${heightIn}in;
      margin: 0;
    }

    body {
      margin: 0;
      font-family: "Arial";
      font-size: var(--field-list-font-pt);
      line-height: 1.1;
    }

    .page {
      page-break-after: always;
      display: grid;
      grid-template-rows: 1fr auto;
      box-sizing: border-box;
      width: 100%;
      height: ${heightIn}in;
      overflow: hidden;
      position: relative;
    }

    .page:last-child {
      page-break-after: auto;
    }

    .page-inner {
      height: auto;
      padding: 0.25in 0.25in 0.5in;
      box-sizing: border-box;
    }

    .page-inner.two-col {
      display: grid;
      grid-template-rows: auto 1fr;
      row-gap: 0;
    }

    .field-list-title {
      grid-column: 1 / -1;
      text-align: center;
      font-weight: bold;
      font-size: ${titleSizePt.toFixed(2)}pt;
      margin-bottom: 6pt;
    }

    .meeting-list {
      display: block;
      padding-bottom: 0.25in;
    }

    .meeting-block {
      break-inside: avoid;
      page-break-inside: avoid;
    }

    .meeting-columns {
      display: grid;
      grid-template-columns: 1fr 1fr;
      column-gap: 0.3125in;
      position: relative;
    }

    .meeting-column {
      overflow: hidden;
    }

    .page-footer {
      position: absolute;
      bottom: 0.25in;
      left: 0;
      right: 0;
      text-align: center;
      width: 100%;
      font-size: ${footerSizePt.toFixed(2)}pt;
    }

    .group-header {
      font-weight: bold;
      text-align: center;
      margin-bottom: 3pt;
      font-size: ${groupHeaderSizePt.toFixed(2)}pt;
    }

    .meeting-separator {
      height: 1em;
      border-top: 0.5pt solid #b5b5b5;
      margin: 2pt 0;
    }

    .no-separator-lines .meeting-separator {
      display: none;
    }

    .info-block {
      font-size: var(--field-list-font-pt);
      line-height: 1.2;
      margin-top: 0;
    }

    .info-block.field-info {
      break-inside: avoid;
      page-break-inside: avoid;
    }

    .info-line {
      margin: 0;
      display: block;
      width: 100%;
    }

    .info-line.preserve-space {
      white-space: pre;
    }

    .info-line.blank {
      height: 1em;
      display: block;
    }

    .info-line.align-center  { text-align: center; }
    .info-line.align-right   { text-align: right; }
    .info-line.align-justify { text-align: justify; }
    .info-line.align-left    { text-align: left; }

    .table-atomic {
      break-inside: avoid;
      page-break-inside: avoid;
    }

    table.field-info-table {
      border-collapse: collapse;
      font-family: ${SETTINGS.BOOK.FONT};
      font-size: var(--field-list-font-pt);
    }

    table.field-info-table td {
      border: none;
      padding: 0;
      text-align: left;
      vertical-align: top;
      white-space: nowrap;
      overflow: visible;
      text-overflow: clip;
      word-break: normal;
      overflow-wrap: normal;
    }

    table.field-info-table tr.blank-row td {
      padding-top: 0;
      height: 1.2em;
      line-height: 1.2;
    }

    table.field-info-table td.underline-cell {
      border-bottom: 1pt solid #000;
    }

    .table-block {
      display: block;
      break-inside: avoid;
      page-break-inside: avoid;
    }

    .table-block.centered {
      display: inline-block;
      margin-left: auto;
      margin-right: auto;
    }

    .info-block.field-info.wysiwyg-host .table-block {
      display: block !important;
      width: 100% !important;
      max-width: 100% !important;
      margin: 0 !important;
    }

    .info-block.field-info.wysiwyg-host {
      display: block !important;
      align-self: flex-start !important;
      width: 100%;
    }

    .info-block.field-info.wysiwyg-host:not(.fully-merged-center) table.field-info-table {
      width: 100%;
      table-layout: fixed;
    }

    .info-block.field-info.wysiwyg-host.fully-merged-center .table-block {
      display: inline-block !important;
      margin-left: auto !important;
      margin-right: auto !important;
      width: auto !important;
      max-width: none !important;
    }

    .info-block.field-info.wysiwyg-host.fully-merged-center table.field-info-table {
      table-layout: auto !important;
      width: auto !important;
    }

    .table-outer-wrapper.fully-merged-center {
      display: flex !important;
      justify-content: center !important;
      width: 100%;
    }

    .table-outer-wrapper.fully-merged-center .table-block {
      display: inline-block !important;
      width: auto !important;
      max-width: none !important;
    }

    .table-outer-wrapper.fully-merged-center .table-block table.field-info-table {
      display: inline-table !important;
      table-layout: auto !important;
      width: auto !important;
    }

    .card2 {
      display: grid;
      grid-template-columns: 14ch 1fr;
      column-gap: 0.5ch;
      break-inside: avoid;
      page-break-inside: avoid;
      margin-bottom: 1pt;
      align-items: start;
      font-size: var(--field-list-font-pt);
      font-family: "Arial";
    }

    .card2 .left {
      display: grid;
      grid-template-columns: 12ch 2ch;
      grid-auto-rows: min-content;
      row-gap: 0;
      align-content: start;
    }

    .card2 .left-line { display: contents; }
    .card2 .left .p { grid-column: 1; }
    .card2 .left .c { grid-column: 2; text-align: left; white-space: nowrap; }

    .card2 .right { align-self: start; }

    .card2 .name {
      font-weight: bold;
      padding-left: 2ch;
      text-indent: -1ch;
    }

    .card2 .name .rest { font-weight: normal; }

    .card2 .address {
      padding-left: 2ch;
      ${addrAlignCss}
    }

    .card2 .address a {
      color: #000;
      text-decoration: none;
    }
    .card2 .address a:hover {
      color: #000;
      text-decoration: none;
    }
  </style>
</head>
<body${bodyClass}>
<!-- fieldListFontSizePt: ${safeFontSizePt.toFixed(2)} -->
${pagesHtml}
</body>
</html>`;
}
