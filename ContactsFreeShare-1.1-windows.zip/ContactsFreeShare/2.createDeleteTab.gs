function archiveAndRecreateDeletedTab() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const ui = SpreadsheetApp.getUi();
  const response = ui.alert(
    "Archive Deleted Tab",
    "Move Deleted tab to Drive/Archive and create new Deleted tab\n\nProceed?",
    ui.ButtonSet.YES_NO
  );

  if (response !== ui.Button.YES) return;

  const deletedSheetName = "Deleted";
  const oldSheet = ss.getSheetByName(deletedSheetName);

  // 1. Archive existing "Deleted" sheet if it exists
  if (oldSheet) {
    const year = Utilities.formatDate(new Date(), ss.getSpreadsheetTimeZone(), "yyyy");
    const archiveName = deletedSheetName + year;

    // Create a new spreadsheet for the archive
    const newSS = SpreadsheetApp.create(archiveName);
    const copiedSheet = oldSheet.copyTo(newSS);
    copiedSheet.setName(archiveName);
    copiedSheet.setFrozenRows(1);

    // Remove the default "Sheet1" from the new spreadsheet
    const defaultSheet = newSS.getSheetByName("Sheet1");
    if (defaultSheet) {
      newSS.deleteSheet(defaultSheet);
    }

    // Move the new spreadsheet to the "Archive" folder
    const folderName = "Archive";
    const root = DriveApp.getRootFolder();
    const folders = root.getFoldersByName(folderName);
    const archiveFolder = folders.hasNext() ? folders.next() : root.createFolder(folderName);

    const file = DriveApp.getFileById(newSS.getId());
    file.moveTo(archiveFolder);

    // Delete the old sheet from the current spreadsheet
    ss.deleteSheet(oldSheet);
  }

  // 2. Create a new "Deleted" sheet
  let newSheet = ss.getSheetByName(deletedSheetName);
  if (newSheet) {
    newSheet.clear();
  } else {
    newSheet = ss.insertSheet(deletedSheetName);
  }

  // 3. Set Headers
  const headers = [
    "Selected",
    "Contact ID",
    "Etag",
    "Last Updated",
    "Status",
    "Fields",
    "Meetings",
    "Group Membership",
    "Family Name",
    "Given Name",
    "Relation 1 - Type",
    "Relation 1 - Value",
    "Relation 2 - Type",
    "Relation 2 - Value",
    "Phone 1 - Type",
    "Phone 1 - Value",
    "Phone 2 - Type",
    "Phone 2 - Value",
    "Phone 3 - Type",
    "Phone 3 - Value",
    "Address 1 - Type",
    "Address 1 - Formatted",
    "Address 1 - Coordinates",
    "Address 2 - Type",
    "Address 2 - Formatted",
    "Address 2 - Coordinates",
    "Address 3 - Type",
    "Address 3 - Formatted",
    "Address 3 - Coordinates",
    "E-mail 1 - Type",
    "E-mail 1 - Value",
    "E-mail 2 - Type",
    "E-mail 2 - Value",
    "Photo",
    "Birthday",
    "Notes",
    "Custom Field 1 - Type",
    "Custom Field 1 - Value",
    "Custom Field 2 - Type",
    "Custom Field 2 - Value",
    "Custom Field 3 - Type",
    "Custom Field 3 - Value",
    "Mtg home-1/Elder-2"
  ];

  newSheet.getRange(1, 1, 1, headers.length)
    .setValues([headers])
    .setBackground("#2fff3e")
    .setFontWeight("bold");
  newSheet.setFrozenRows(1);

  // 4. Apply Column Grouping
  const sheet = newSheet;
  try {
    //sheet.expandAllColumnGroups();
    sheet.getRange("B:E").shiftColumnGroupDepth(-1);
    sheet.getRange("G:H").shiftColumnGroupDepth(-1);
    sheet.getRange("L:N").shiftColumnGroupDepth(-1);
    sheet.getRange("P:T").shiftColumnGroupDepth(-1);
    sheet.getRange("V:AC").shiftColumnGroupDepth(-1);
    sheet.getRange("AE:AG").shiftColumnGroupDepth(-1);
    sheet.getRange("AI:AJ").shiftColumnGroupDepth(-1);
    sheet.getRange("AL:AP").shiftColumnGroupDepth(-1);
  } catch (error) {

  }
  sheet.getRange("B:E").shiftColumnGroupDepth(1);
  sheet.getRange("G:H").shiftColumnGroupDepth(1);
  sheet.getRange("L:N").shiftColumnGroupDepth(1);
  sheet.getRange("P:T").shiftColumnGroupDepth(1);
  sheet.getRange("V:AC").shiftColumnGroupDepth(1);
  sheet.getRange("AE:AG").shiftColumnGroupDepth(1);
  sheet.getRange("AI:AJ").shiftColumnGroupDepth(1);
  sheet.getRange("AL:AP").shiftColumnGroupDepth(1);
}