function addTimestamp(e) {
  //variables
  var targetColumn = 6;
  var ws1 = "Changes";
  var body1 = e.source
    .getActiveSheet()
    .getRange(e.range.getRow(), 5)
    .getValue();
  var body2 = e.source
    .getActiveSheet()
    .getRange(e.range.getRow(), 6)
    .getValue();

  //get modified row and column and cell
  var row = e.range.getRow();
  var col = e.range.getColumn();

  const startRow = 2;
  if (
    (col == targetColumn) &
    (row >= startRow) &
    (e.source.getActiveSheet().getName() == ws1)
  ) {
    e.source
      .getActiveSheet()
      .getRange(row, 4)
      .setValue(new Date())
      .setNumberFormat("ddd, M-d-yyyy at H:MM am/pm");
    try {
      GmailApp.sendEmail(
        "menfisher@gmail.com",
        "AlMsLa Contacts Sheet updated",
        body1 + " , " + body2
      );
    } catch (err) {
      console.info(err.message);
    }
  }
}
