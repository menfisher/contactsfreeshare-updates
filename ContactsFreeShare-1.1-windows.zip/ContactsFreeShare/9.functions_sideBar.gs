function rowHighlightRestore(e) {
  // Only act on the Contacts sheet
  const sheet = e.range.getSheet();
  if (sheet.getName() !== 'Contacts') return;

  const col = e.range.getColumn();
  const row = e.range.getRow();
  const numCols = sheet.getLastColumn();

  // Col A is column 1, skip the header
  if (col === 1 && row > 1) {
    const value = e.range.getValue();
    if (value === true || value === 'TRUE' || value === 'true') {
      // Check if this row is the orange highlight row
      const userProps = PropertiesService.getUserProperties();
      const lastHighlightedRow = Number(userProps.getProperty('lastHighlightedRow'));
      if (lastHighlightedRow === row) {
        // Restore original background if we have it
        const prevColorsStr = userProps.getProperty(`rowColors_${row}`);
        if (prevColorsStr) {
          const prevColors = JSON.parse(prevColorsStr);
          sheet.getRange(row, 1, 1, numCols).setBackgrounds(prevColors);
          userProps.deleteProperty(`rowColors_${row}`);
        } else {
          sheet.getRange(row, 1, 1, numCols).setBackground(null);
        }
        userProps.deleteProperty('lastHighlightedRow');
      }
    }
  }
}

function showAddContactSidebar() {
  var colFOptions = getUniqueColumnValues(6);
  var colGOptions = getMeetingsForFieldMap();
  const html = HtmlService.createTemplateFromFile('10.sidebar_addContact');
  html.colFOptions = JSON.stringify(colFOptions);
  html.colGOptions = JSON.stringify(colGOptions);
  SpreadsheetApp.getUi().showSidebar(html.evaluate().setTitle('Contact Administration'));
}

function getUniqueColumnValues(columnNumber) {
  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  const data = sheet.getRange(2, columnNumber, sheet.getLastRow()-1).getValues();
  return [...new Set(data.flat().filter(String))];
}

/**
 * Returns an object mapping each field group (Col F) to its unique meetings (Col G)
 * @returns {Object} e.g. { "Field A": ["Meeting 1", "Meeting 2"], ... }
 */
function getMeetingsForFieldMap() {
  var sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  var data = sheet.getDataRange().getValues();
  var fieldCol = 5; // Col F
  var meetingCol = 6; // Col G
  var map = {};
  for (var i = 1; i < data.length; i++) {
    var field = data[i][fieldCol];
    var meeting = data[i][meetingCol];
    if (!field || !meeting) continue;
    if (!map[field]) map[field] = [];
    if (map[field].indexOf(meeting) === -1) map[field].push(meeting);
  }
  return map;
}

function showSidebar() {
    const sheetContacts = SpreadsheetApp.getActive().getSheetByName('Contacts');
    const orgsCol = sheetContacts.getRange(2, 6, sheetContacts.getLastRow()-1, 1).getValues().flat();
    const uniqueOrgs = JSON.stringify([...new Set(orgsCol)].sort());
    
    const html = HtmlService.createTemplateFromFile('9.sidebar');
    html.orgs = uniqueOrgs;

    var colFOptions = getUniqueColumnValues(6); //if you want F dropdown options
    var colGOptions = getMeetingsForFieldMap(); // This is now an object!
    
    html.orgs = JSON.stringify(colFOptions);
    html.colFOptions = JSON.stringify(colFOptions);
    html.colGOptions = JSON.stringify(colGOptions); // OBJECT!
    //SpreadsheetApp.getUi().showSidebar(html.evaluate().setTitle('Contacts Sidebar').setWidth(500));
  }

function apiCreateContact(payloadJSON) {
  const payload = JSON.parse(payloadJSON);
  const marker = payload.marker || "";
  let rowPayload;
  // 1. Use rows[0] if present (move or edit on selection)
  if (payload.rows && payload.rows.length > 0) {
    rowPayload = payload.rows[0];
  } else {
    // 2. Otherwise, use the form values directly from payload
    rowPayload = payload;
  }

  const rowIndex = rowPayload.rowIndex;
  const colF = rowPayload.colF;
  const colG = rowPayload.colG;
  const familyName = rowPayload.familyName;
  const givenName = rowPayload.givenName;

  // Extract text outside parentheses from colG
  const colGExtracted = colG.replace(/\s*\(.*?\)\s*/g, '').trim();
  const colH = `${colF} - ${colGExtracted} (Shared):::TriState Separates (Shared):::myContacts`;

  const contactData = {
    rowIndex,
    colF,
    colG,
    colH,
    familyName,
    givenName,
  };
  
  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  //const { rowIndex, colF, colG, colH, familyName, givenName } = contactData;
  const numCols = sheet.getLastColumn();

  // Prepare the new row data as an array
  // Fill blank values for columns you don't use, except for those you set
  let newRow = new Array(numCols).fill('');
  newRow[5] = colF;           // Col F (6th index, 0-based)
  newRow[6] = colG;           // Col G (7th index, 0-based)
  newRow[7] = colH;           // Col H (8th index)
  newRow[8] = familyName;     // Col I (9th index)
  newRow[9] = givenName;      // Col J (10th index)

  const selectedRow = insertNewSortedContact(contactData);

  // Check if a new Meeting was created
  if (rowPayload.isNewMeeting) {
    new Contact().updateSortItemsInSettings(); // Rebuild the Meetings list
    focusOnNewMeetingOrderCell_simple(colG); // Focus on the new cell
  }
  if (marker === "MOVE_SELECTED") {
    return JSON.stringify({ status: "OK", insertedRowIndices: [selectedRow] });
  } else if (marker === "NEW_MEETING") {
    return JSON.stringify({ status: "NEW_MEETING_ADDED" });
  } else {
    return JSON.stringify({ status: "UNKNOWN" });
  }
}

function insertNewSortedContact(contactData) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Contacts');
  const data = sheet.getDataRange().getValues();
  const { rowIndex, colF, colG, colH, familyName, givenName } = contactData;
  let insertIndex = data.length; // Default to append at end
  let fieldStartIdx = -1;
  let fieldEndIdx = -1;

  // 1. Find the range for the specified field (colF)
  for (let i = 0; i < data.length; i++) {
    if (data[i][5] === colF && fieldStartIdx === -1) {
      fieldStartIdx = i;
    } else if (fieldStartIdx !== -1 && data[i][5] !== colF) {
      fieldEndIdx = i - 1;
      break;
    }
  }
  if (fieldStartIdx !== -1 && fieldEndIdx === -1) fieldEndIdx = data.length - 1;

  if (fieldStartIdx === -1) {
    // New Field entirely, append alphabetically (You might sort fields separately later)
    insertIndex = data.length + 1; // Insert at the end (Sheets is 1-based)
  } else {
    // 2. Within Field, check if meeting exists
    let meetingExists = false;
    let meetingStartIdx = -1;
    let meetingEndIdx = -1;
    for (let i = fieldStartIdx; i <= fieldEndIdx; i++) {
      if (data[i][6] === colG && meetingStartIdx === -1) {
        meetingExists = true;
        meetingStartIdx = i;
      } else if (meetingStartIdx !== -1 && data[i][6] !== colG) {
        meetingEndIdx = i - 1;
        break;
      }
    }
    if (meetingStartIdx !== -1 && meetingEndIdx === -1) meetingEndIdx = fieldEndIdx;

    if (!meetingExists) {
      // Insert new Meeting alphabetically within Field
      insertIndex = fieldStartIdx + 1;
      while (insertIndex - 1 <= fieldEndIdx && data[insertIndex - 1][6].localeCompare(colG) < 0) {
        insertIndex++;
      }
    } else {
      // Meeting exists, insert new row alphabetically by Family Name within Meeting
      insertIndex = meetingStartIdx + 1;
      while (insertIndex - 1 <= meetingEndIdx && data[insertIndex - 1][7].localeCompare(familyName) < 0) {
        insertIndex++;
      }
    }
  }

  // --- SAVE ORIGINAL ROW DATA BEFORE ANY INSERT/DELETE ---
  let originalRow = null;
  if (rowIndex !== undefined && rowIndex !== null) {
    originalRow = sheet.getRange(rowIndex, 1, 1, sheet.getLastColumn()).getValues()[0];
  }

  // 3. Insert new row at determined index
  sheet.insertRowBefore(insertIndex);
  const numCols = sheet.getLastColumn();

  // 4. Fill Cols F, G, H (if needed) and Family/Given Name in new row
  if (colF) sheet.getRange(insertIndex, 6).setValue(colF);
  if (colG) sheet.getRange(insertIndex, 7).setValue(colG);
  if (colH) sheet.getRange(insertIndex, 8).setValue(colH);
  if (familyName) sheet.getRange(insertIndex, 9).setValue(familyName);
  if (givenName)  sheet.getRange(insertIndex, 10).setValue(givenName);
  
  // 5. Only copy/delete if rowIndex is provided (i.e., you are moving an existing row)
  let selectedRow = insertIndex;

  // If moving a selected row, paste the saved data for cols I–AQ (cols 9–43)
  if (originalRow) {
    const valuesToCopy = originalRow.slice(8, 43); // I–AQ
    sheet.getRange(insertIndex, 9, 1, valuesToCopy.length).setValues([valuesToCopy]);

    // Only overwrite Family Name/Given Name if present in form
    if (familyName && familyName.trim() !== "") {
      sheet.getRange(insertIndex, 9).setValue(familyName);
    }
    if (givenName && givenName.trim() !== "") {
      sheet.getRange(insertIndex, 10).setValue(givenName);
    }

    // 6. Delete the original row (make sure not to delete the newly inserted row!)
    batchDeleteSelectedContacts([rowIndex]);
    let rowToDelete = rowIndex;
    if (insertIndex <= rowIndex) rowToDelete = rowIndex + 1;
    sheet.deleteRow(rowToDelete);

    if (insertIndex > rowToDelete) selectedRow = insertIndex - 1;
  }

  // Select and highlight the new row
  sheet.getRange(selectedRow, 1).setValue(true);
  sheet.setActiveRange(sheet.getRange(selectedRow, 1, 1, sheet.getLastColumn()));

  return selectedRow;
}

function apiMoveContacts(payloadJSON) {
  const payload = JSON.parse(payloadJSON);
  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  const numCols = sheet.getLastColumn();
  let data = sheet.getDataRange().getValues();

  const rowsToDelete = [];
  const rowsToInsert = [];

  // Step 1: Identify rows to move
  payload.rows.forEach(rowPayload => {
    let rowIndex = null;
    if (rowPayload.rowIndex !== undefined) {
      rowIndex = rowPayload.rowIndex;
    } else {
      for (let i = 1; i < data.length; i++) {
        if (
          String(data[i][8]).trim().toLowerCase() === rowPayload.familyName.toLowerCase() &&
          String(data[i][9]).trim().toLowerCase() === rowPayload.givenName.toLowerCase()
        ) {
          rowIndex = i + 1;
          break;
        }
      }
    }

    if (rowIndex != null) {
      let rowData = data[rowIndex - 1].slice(); // clone to avoid mutation
      rowData[5] = rowPayload.colF;
      rowData[6] = rowPayload.colG;
      const colGExtracted = rowPayload.colG.replace(/\s*\(.*?\)\s*/g, '').trim();
      rowData[7] = `${rowPayload.colF} - ${colGExtracted} (Shared):::TriState Separates (Shared):::myContacts`;
      rowData[0] = false;

      rowsToDelete.push(rowIndex);
      rowsToInsert.push({ rowData, colG: rowPayload.colG, familyName: rowData[8] });
    }
  });

  rowsToDelete.sort((a,b)=>b-a).forEach(row => sheet.deleteRow(row));

  // Step 3: Reload data after deletes
  data = sheet.getDataRange().getValues();

  // Step 4: Insert each moved contact into its new group (sorted)
  let insertedRowIndices = [];
  rowsToInsert.forEach(({rowData, colG, familyName}) => {
    data = sheet.getRange(2, 1, sheet.getLastRow()-1, numCols).getValues(); // Update after each insert
    const insertedRowIdx = insertSortedContact(rowData, colG, familyName, data);
    console.log("insertedRowIdx =", insertedRowIdx);
    insertedRowIndices.push(insertedRowIdx);
    matchGroupColors(insertedRowIdx, rowData[5], rowData[6]);
    // Update data for the next insertion 
    data = sheet.getDataRange().getValues();
  });
  sortContactSheet();
  return JSON.stringify({ status: "OK", insertedRowIndices });
}

function focusOnNewMeetingOrderCell_simple(meetingName) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var settingsSheet = ss.getSheetByName('Settings');
  var lastRow = settingsSheet.getLastRow();
  var meetingCol = 8; // H (0-based index = 7)
  var orderCol = 9;   // I (1-based, 0-based index = 8)

  var data = settingsSheet.getRange(2, meetingCol, lastRow-1, 1).getValues(); // Col H, skip header
  for (var i = 0; i < data.length; i++) {
    if ((data[i][0] || "").toString().trim() === meetingName.trim()) {
      var rowIdx = i + 2; // +2 because data starts at row 2
      var orderCell = settingsSheet.getRange(rowIdx, orderCol);

      // Check above and below
      var above = rowIdx > 2 ? settingsSheet.getRange(rowIdx-1, orderCol).getValue() : "";
      var below = rowIdx < lastRow ? settingsSheet.getRange(rowIdx+1, orderCol).getValue() : "";
      if (above || below) {
        SpreadsheetApp.getUi().alert(
          "Please assign a sort order for the new meeting.\nNearby meetings have order numbers." +
          "\n\nThen go back to Contacts tab to finish new row to create Contact."
        );
        ss.setActiveSheet(settingsSheet);
        settingsSheet.setActiveRange(orderCell);
        SpreadsheetApp.flush();
      } else {
      }
      break;
    }
  }
}

/**
 * Searches Contacts sheet for matches and returns array of row numbers (1-based).
 */
function searchContacts(payload) {
  payload = JSON.parse(payload);
  const { familyName, givenName } = payload;
  if (!familyName && !givenName) {
    SpreadsheetApp.getUi().alert('Enter at least a Family Name.');
    return;
  }
  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  if (!sheet) throw new Error('Contacts sheet not found');
  const data = sheet.getDataRange().getValues(); // includes headers

  // Precompute search terms for speed
  const searchFamily = familyName ? familyName.trim().toLowerCase() : null;
  const searchGiven = givenName ? givenName.trim().toLowerCase() : null;
  const matches = [];

  for (let i = 1; i < data.length; i++) { // skip header
    const row = data[i];
    // Cache the lower-case/trim for this row once
    const rowFamily = String(row[8] || '').trim().toLowerCase();
    const rowGiven = String(row[9] || '').trim().toLowerCase();

    if (searchFamily && searchGiven) {
      if (rowFamily.includes(searchFamily) && rowGiven.includes(searchGiven)) matches.push(i + 1);
    } else if (searchFamily) {
      if (rowFamily.includes(searchFamily)) matches.push(i + 1);
    } else if (searchGiven) {
      if (rowGiven.includes(searchGiven)) matches.push(i + 1);
    }
  }
  if (matches.length === 0) {
    SpreadsheetApp.getUi().alert("0 contacts found");
    return "NO_MATCH";
  }
  return matches;
}

/**
 * Centers/focuses/highlights a specific row in the Contacts sheet.

function focusContactRow(payload) {
  payload = JSON.parse(payload);
  const { row } = payload;
  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  if (!sheet) return;
  const numCols = sheet.getLastColumn();
  const userProps = PropertiesService.getUserProperties();

  // Clear previous highlight and restore original color if stored
  const prevRow = Number(userProps.getProperty('lastHighlightedRow'));
  if (prevRow && prevRow !== row && prevRow > 1 && prevRow <= sheet.getLastRow()) {
    const prevColorsStr = userProps.getProperty(`rowColors_${prevRow}`);
    if (prevColorsStr) {
      const prevColors = JSON.parse(prevColorsStr); // [["#ffffff", ...]]
      sheet.getRange(prevRow, 1, 1, numCols).setBackgrounds(prevColors);
      userProps.deleteProperty(`rowColors_${prevRow}`);
    } else {
      // If not stored, just clear (fallback)
      sheet.getRange(prevRow, 1, 1, numCols).setBackground(null);
    }
  }

  // Store current row's original background colors
  const currRange = sheet.getRange(row, 1, 1, numCols);
  const currColors = currRange.getBackgrounds();
  userProps.setProperty(`rowColors_${row}`, JSON.stringify(currColors));

  // Highlight the new row in hot cyan
  currRange.setBackground('#65FDF8');
  sheet.setActiveRange(currRange);
  SpreadsheetApp.flush();

  // Store current as last highlighted
  userProps.setProperty('lastHighlightedRow', row);
}

function clearAllHighlights() {
  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  if (!sheet) return;
  const userProps = PropertiesService.getUserProperties();
  const lastRow = sheet.getLastRow();
  const numCols = sheet.getLastColumn();

  // Restore color for any previously highlighted row
  const prevRow = Number(userProps.getProperty('lastHighlightedRow'));
  if (prevRow && prevRow > 1 && prevRow <= lastRow) {
    const prevColorsStr = userProps.getProperty(`rowColors_${prevRow}`);
    if (prevColorsStr) {
      const prevColors = JSON.parse(prevColorsStr);
      sheet.getRange(prevRow, 1, 1, numCols).setBackgrounds(prevColors);
      userProps.deleteProperty(`rowColors_${prevRow}`);
    } else {
      sheet.getRange(prevRow, 1, 1, numCols).setBackground(null);
    }
    userProps.deleteProperty('lastHighlightedRow');
  }
}
*/

/**
   * update/create Sheets Photo from Contacts
   */
function updatePhotosForSelectedContacts() {
  var ws = SpreadsheetApp.getActive().getSheetByName('Contacts');
  if (!ws) throw new Error('Contacts sheet not found');

  var data = ws.getDataRange().getValues();
  var headers = data[0];
  var indexOfContactId = headers.indexOf('Contact ID');
  var indexOfPhoto = headers.indexOf('Photo');
  var indexOfSelected = headers.indexOf('Selected');

  if (indexOfContactId === -1 || indexOfPhoto === -1 || indexOfSelected === -1) 
    throw new Error('Required columns not found');

  var count = 0;
  for (var i = 1; i < data.length; i++) {
    var row = data[i];
    if (row[indexOfSelected] === true || row[indexOfSelected] === "TRUE") {
      var id = row[indexOfContactId];
      if (!id) continue;
      var contact = People.People.get(id, { personFields: "photos" });
      var photoUrl = (contact.photos && contact.photos[0] && contact.photos[0].url) || "";
      ws.getRange(i + 1, indexOfPhoto + 1).setValue(photoUrl);
      ws.getRange(i + 1, indexOfSelected + 1).setValue(false);
      count++;
    }
  }
  SpreadsheetApp.getUi().alert(`Photos updated for ${count} contact(s)!`);
  return null;
}

function apiDeleteContacts(payload) {
  payload = JSON.parse(payload);
  const { selectedRows } = payload;

  if (!selectedRows || !selectedRows.length) {
    SpreadsheetApp.getUi().alert('No rows selected for deletion!');
    return;
  }

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const contactsSheet = ss.getSheetByName('Contacts');
  let   deletedSheet  = ss.getSheetByName('Deleted');
  if (!contactsSheet) throw new Error("Contacts sheet not found.");
  if (!deletedSheet)  deletedSheet = ss.insertSheet('Deleted'); // ensure it exists

  // Use your Contact class instance
  const app = new Contact();

  const rowsToDelete = [...selectedRows];

  // Collect resourceNames before deletes (unchanged)
  const resourceNames = [];
  for (const row of selectedRows) {
    const resourceName = contactsSheet.getRange(row, 2).getValue();
    if (resourceName && resourceName.startsWith("people/")) {
      resourceNames.push(resourceName);
    }
  }

  // Confirm
  const ui = SpreadsheetApp.getUi();
  const response = ui.alert(
    'Delete Contacts',
    `Are you sure you want to delete ${rowsToDelete.length} contact(s)?`,
    ui.ButtonSet.YES_NO
  );
  if (response !== ui.Button.YES) {
    rowsToDelete.forEach(rowNum => contactsSheet.getRange(rowNum, 1).setValue(false));
    return 'Deletion cancelled.';
  }

  // Delete in descending order so row indexes don't shift
  rowsToDelete.sort((a, b) => b - a);

  // Delete from Google Contacts
  batchDeleteSelectedContacts(selectedRows);

  const data = contactsSheet.getDataRange().getValues();
  const header = data[0];
  const statusIdx = header.indexOf('Status');

  rowsToDelete.forEach(rowNum => {
    contactsSheet.getRange(rowNum, 1).setValue(false); // uncheck
    const row = data[rowNum - 1];

    // reflect delete in the row we move
    row[0] = false;           // Selected
    row[statusIdx] = "Deleted";
    row[1] = "";              // Contact ID
    row[2] = "";              // Etag

    // Move to Deleted at top
    deletedSheet.insertRows(2, 1);
    deletedSheet.getRange(2, 1, 1, row.length).setValues([row]);
    deletedSheet.getRange(2, 1).insertCheckboxes();
    // Set the timestamp in Col D (Last Updated)
    deletedSheet.getRange(2, 4).setValue(new Date());
    // Delete from Contacts sheet
    contactsSheet.deleteRow(rowNum);
  });

  // Re-apply formats so Col A has checkboxes + yellow-row CF on BOTH sheets
  app.formatSheet(deletedSheet,  app.headers.map(v => v.format));
  app.formatSheet(contactsSheet, app.headers.map(v => v.format));

  app.sortContactSheet({ skipConfirm: true });

  ui.alert(`${rowsToDelete.length} contact(s) have been deleted.`);
  return null;
}

function batchDeleteSelectedContacts(selectedRows) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var contactsSheet = ss.getSheetByName('Contacts');
  if (!contactsSheet) throw new Error("Contacts sheet not found.");
  
  // Collect resourceNames for only selected rows
  var resourceNames = [];
  for (var i = 0; i < selectedRows.length; i++) {
    var row = selectedRows[i];
    var name = contactsSheet.getRange(row, 2).getValue(); // Col B
    if (name && name.startsWith("people/")) {
      resourceNames.push(name);
    }
  }
  if (resourceNames.length === 0) return;
  
  // Batch delete in pages of 500
  var pageSize = 500;
  for (var i = 0; i < resourceNames.length; i += pageSize) {
    var batch = resourceNames.slice(i, i + pageSize);
    People.People.batchDeleteContacts({ resourceNames: batch });
  }
}

function getSelectedContactRows() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Contacts");
  if (!sheet) return [];
  var data = sheet.getDataRange().getValues();
  var selectedRows = [];
  for (var i = 1; i < data.length; i++) { // Skip header row (i=1)
    if (data[i][0] === true || data[i][0] === "TRUE") { // Col A (0-based)
      selectedRows.push(i + 1); // Sheet rows are 1-based
    }
  }
  return selectedRows;
}

function insertSortedContact(newRowData, colG, familyName, cachedData = null) {
  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  const numCols = sheet.getLastColumn();
  const data = cachedData || sheet.getRange(2, 1, sheet.getLastRow()-1, numCols).getValues();

  // Standardize target group and family name for comparison
  const groupKey = String(colG).trim().toLowerCase();
  const targetFamily = String(familyName).trim().toLowerCase();

  let insertIdx = data.length + 2; // default to end
  let firstGroup = -1;
  let lastGroup = -1;

  // 1. Find bounds for the target Meeting group (col G)
  for (let i = 0; i < data.length; i++) {
    const thisGroup = String(data[i][6]).trim().toLowerCase();
    if (thisGroup === groupKey) {
      if (firstGroup === -1) firstGroup = i;
      lastGroup = i;
    } else if (lastGroup !== -1) {
      // Past the end of the group
      break;
    }
  }

  // 2. Within the group, insert by Family Name
  if (firstGroup !== -1) {
    // Default to end of group
    insertIdx = lastGroup + 2 + 1;
    for (let i = firstGroup; i <= lastGroup; i++) {
      const thisFamily = String(data[i][8] || '').trim().toLowerCase();
      if (targetFamily < thisFamily) {
        insertIdx = i + 2;
        break;
      }
    }
  } else {
    // (Should not happen with dropdown logic! But just in case...)
    // Try to insert before the next group, sorted by group name
    for (let i = 0; i < data.length; i++) {
      const thisGroup = String(data[i][6]).trim().toLowerCase();
      if (thisGroup > groupKey) {
        insertIdx = i + 2;
        break;
      }
    }
  }

  // Clamp insertIdx for safety
  insertIdx = Math.min(insertIdx, sheet.getLastRow() + 1);

  sheet.insertRows(insertIdx);
  sheet.getRange(insertIdx, 1, 1, numCols).setValues([newRowData]);
  // Highlight new row
  sheet.getRange(insertIdx, 1).setValue(true);
  sheet.setActiveRange(sheet.getRange(insertIdx, 1, 1, numCols));
  SpreadsheetApp.flush();
  return insertIdx;
}

function highlightContactCells(payload) {
  // Accept payload as an object, or a stringified object
  if (typeof payload === 'string') payload = JSON.parse(payload);
  const row = Number(payload.row); // Ensure it's a number

  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  if (!sheet) throw new Error('Contacts sheet not found');
  const userProps = PropertiesService.getUserProperties();

  // Restore previous highlight if any
  const prevRow = Number(userProps.getProperty('lastCellHighlightRow'));
  if (prevRow && prevRow !== row && prevRow > 1 && prevRow <= sheet.getLastRow()) {
    const prevColorsStr = userProps.getProperty(`cellColors_${prevRow}`);
    if (prevColorsStr) {
      const prevColors = JSON.parse(prevColorsStr); // [["#fff", "#fff"]]
      sheet.getRange(prevRow, 9, 1, 2).setBackgrounds(prevColors);
      userProps.deleteProperty(`cellColors_${prevRow}`);
    } else {
      sheet.getRange(prevRow, 9, 1, 2).setBackground(null);
    }
  }

  // Store the current cells' background colors
  const currRange = sheet.getRange(row, 9, 1, 2);
  const currColors = currRange.getBackgrounds(); // [["#fff", "#fff"]]
  userProps.setProperty(`cellColors_${row}`, JSON.stringify(currColors));

  // Highlight with color (cyan)
  currRange.setBackgrounds([["#65FDF8", "#65FDF8"]]);
  sheet.setActiveRange(currRange);

  // Store which row was highlighted
  userProps.setProperty('lastCellHighlightRow', row);
}

function clearAllCellHighlights() {
  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  if (!sheet) return;
  const userProps = PropertiesService.getUserProperties();
  const lastRow = sheet.getLastRow();

  // Restore previously highlighted cells, if any
  const prevRow = Number(userProps.getProperty('lastCellHighlightRow'));
  if (prevRow && prevRow > 1 && prevRow <= lastRow) {
    const prevColorsStr = userProps.getProperty(`cellColors_${prevRow}`);
    if (prevColorsStr) {
      const prevColors = JSON.parse(prevColorsStr);
      sheet.getRange(prevRow, 9, 1, 2).setBackgrounds(prevColors);
      userProps.deleteProperty(`cellColors_${prevRow}`);
    } else {
      sheet.getRange(prevRow, 9, 1, 2).setBackground(null);
    }
    userProps.deleteProperty('lastCellHighlightRow');
  }
}

function restoreContacts() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const deletedSheet = ss.getSheetByName("Deleted");
  const contactsSheet = ss.getSheetByName("Contacts");
  if (!deletedSheet || !contactsSheet) {
    SpreadsheetApp.getUi().alert("Required 'Contacts' or 'Deleted' sheets not found.");
    return;
  }

  // Only proceed if on Deleted sheet
  if (ss.getActiveSheet().getName() !== "Deleted") {
    SpreadsheetApp.getUi().alert('You must be on the "Deleted" sheet to restore.');
    return;
  }

  const data = deletedSheet.getDataRange().getValues();
  const rowsToRestore = [];
  for (let i = 1; i < data.length; i++) { // skip header
    if (String(data[i][0]).toLowerCase() === "true") {
      rowsToRestore.push(i + 1); // Sheet rows are 1-based (header = 1)
    }
  }

  if (rowsToRestore.length === 0) {
    SpreadsheetApp.getUi().alert("No contacts are selected for restore.");
    return;
  }

  // Compose preview string for confirmation
  let preview = rowsToRestore.slice(0,10).map(row => {
    const fam = deletedSheet.getRange(row, 9).getValue();
    const giv = deletedSheet.getRange(row, 10).getValue();
    return `• ${fam}, ${giv}`;
  }).join("\n");
  if (rowsToRestore.length > 10) preview += `\n...and ${rowsToRestore.length-10} more.`;

  const ui = SpreadsheetApp.getUi();
  const result = ui.alert(
    `Restore Contacts?`,
    `Do you want to restore ${rowsToRestore.length} contact(s) from Deleted to Contacts?\n\n${preview}`,
    ui.ButtonSet.YES_NO
  );
  if (result !== ui.Button.YES) {
    for (const row of rowsToRestore) {
    deletedSheet.getRange(row, 1).setValue(false);
  }
    return;
  }

  // Prepare all data before modifying sheet
  const numCols = deletedSheet.getLastColumn();
  let rowsWithData = rowsToRestore.map(row => {
    let rowData = deletedSheet.getRange(row, 1, 1, numCols).getValues()[0];
    // Update Status and Last Updated
    rowData[3] = new Date();
    rowData[4] = "Restored";
    return { row, rowData };
  });

  // Sort by descending row so deletes don't shift subsequent rows
  rowsWithData.sort((a, b) => b.row - a.row);

  // Move each contact
  const contactsData = contactsSheet.getDataRange().getValues();
  for (const item of rowsWithData) {
    const row = item.row;
    const rowData = item.rowData;

    // Remove from Deleted sheet
    deletedSheet.deleteRow(row);

    // Find insert position in Contacts (sort by Meeting, Family, Given)
    const newMeeting = rowData[6];
    const newFam = rowData[8];
    const newGiven = rowData[9];
    let insertIndex = contactsSheet.getLastRow() + 1;
    for (let i = 1; i < contactsData.length; i++) {
      const m = contactsData[i][6];
      const f = contactsData[i][8];
      const g = contactsData[i][9];
      if (
        (String(m) > String(newMeeting)) ||
        (String(m) === String(newMeeting) && String(f) > String(newFam)) ||
        (String(m) === String(newMeeting) && String(f) === String(newFam) && String(g) > String(newGiven))
      ) {
        insertIndex = i + 1;
        break;
      }
    }
    contactsSheet.insertRowBefore(insertIndex);
    contactsSheet.getRange(insertIndex, 1, 1, numCols).setValues([rowData]);
    // Optional: highlight new row in Contacts
    contactsSheet.getRange(insertIndex, 9, 1, 2).setBackgrounds([["#B9FFB7", "#B9FFB7"]]);
    // ---- Restore group color for I & J ----
    const groupValue = rowData[7]; // Col H
    let foundColor = null;
    for (let i = 1; i < contactsData.length; i++) {
      if (contactsData[i][7] === groupValue && i + 1 !== insertIndex) {
        const colors = contactsSheet.getRange(i + 1, 9, 1, 2).getBackgrounds()[0];
        foundColor = colors;
        break;
      }
    }
    if (foundColor) {
      contactsSheet.getRange(insertIndex, 9, 1, 2).setBackgrounds([foundColor]);
    } else {
      contactsSheet.getRange(insertIndex, 9, 1, 2).setBackgrounds([["#FFFFFF", "#FFFFFF"]]);
    }
  }
  
  ss.setActiveSheet(contactsSheet);
  SpreadsheetApp.flush();
  createContacts();
  
  /** 
  // --- Ask user if they want to create in Google Contacts ---
  //const ui = SpreadsheetApp.getUi();
  const createResult = ui.alert(
    "Create in Google Contacts?",
    "Do you want to create the restored contact(s) in Google Contacts now?",
    ui.ButtonSet.YES_NO
  );

  if (createResult === ui.Button.YES) {
    createContacts();
  } else {
    // Deselect (uncheck) all selected rows in Col A (header in row 1)
    const data = contactsSheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][0]).toLowerCase() === "true") {
        contactsSheet.getRange(i + 1, 1).setValue(false); // Col A, row i+1 (1-based)
      }
    }
  }
  */
}

let contactManager;
function getApp() {
  if (!contactManager) contactManager = new Contact();
  return contactManager;
}

function createContacts() {
  return getApp().createContacts();
}

function logAllContactResourceNames() {
  const response = People.People.Connections.list({
    resourceName: 'people/me',
    pageSize: 2000,
    personFields: 'names,emailAddresses,metadata'
  });
  const connections = response.connections || [];
  for (let person of connections) {
    if (person.resourceName) {
      Logger.log(person.resourceName + ' : ' + (person.names && person.names.length ? person.names[0].displayName : 'No Name'));
    }
  }
}

function selectRows(rowIndicesJSON) {
  const indices = JSON.parse(rowIndicesJSON); // Use a unique name like "indices"
  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  indices.forEach(idx => {
    //sheet.getRange(idx, 2, 1, 2).clearContent(); // Columns B (2) & C (3)
    sheet.getRange(idx, 1).setValue(true); // Set Col A to true
  });
}

function updateSelectedContactsAndSort(selectedRowIndicesJSON) {
  const selectedRowIndices = JSON.parse(selectedRowIndicesJSON);
  selectedRowIndices.sort((a, b) => b - a);

  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];

  // 1. Collect all BEFORE row data
  const beforeRows = selectedRowIndices.map(rowIndex =>
    sheet.getRange(rowIndex, 1, 1, headers.length).getValues()[0]
  );

  // 2. Batch update all selected contacts (your existing optimized method)
  const app = getApp();
  app.updateContacts(); // assumes this runs on all selected

  // 3. Collect all AFTER row data
  const afterRows = selectedRowIndices.map(rowIndex =>
    sheet.getRange(rowIndex, 1, 1, headers.length).getValues()[0]
  );

  // 4. Move/sort rows if group fields changed
  for (let i = 0; i < selectedRowIndices.length; i++) {
    const rowIndex = selectedRowIndices[i];
    const before = beforeRows[i];
    const after = afterRows[i];
    const colF_before = before[5];
    const colG_before = before[6];
    const colF_after = after[5];
    const colG_after = after[6];

    if (colF_before !== colF_after || colG_before !== colG_after) {
      after[0] = false; // deselect
      sheet.deleteRow(rowIndex);
      insertSortedContact(after, colG_after, after[8]);
    }
  }
}

// Global cache for the script run
let CACHED_CONTACT_GROUPS = null;

function loadAllContactGroups() {
  const groups = [];
  let pageToken;
  do {
    const response = People.ContactGroups.list({
      pageSize: 200,
      pageToken: pageToken
    });
    if (response.contactGroups) {
      groups.push(...response.contactGroups);
    }
    pageToken = response.nextPageToken;
  } while (pageToken);
  return groups;
}

function cleanGroupName(name) {
  // Lowercase, strip (Shared), trim spaces
  return name
    .replace(/\(.*?\)/g, '')    // remove (Shared) or any ()
    .replace(/\s+/g, ' ')       // collapse multiple spaces
    .trim()
    .toLowerCase();
}

function getGroupResourceNameByName(groupName) {
  if (!CACHED_CONTACT_GROUPS) {
    CACHED_CONTACT_GROUPS = loadAllContactGroups();
    Logger.log("Loaded contact groups: " + JSON.stringify(CACHED_CONTACT_GROUPS.map(g => g.name)));
  }

  if (!groupName) return null;

  const cleanedTarget = cleanGroupName(groupName);
  Logger.log(`Looking for group: "${groupName}" cleaned: "${cleanedTarget}"`);

  // First try exact (but cleaned) match
  const match = CACHED_CONTACT_GROUPS.find(g =>
    cleanGroupName(g.name) === cleanedTarget
  );

  if (match) {
    Logger.log(`Found group "${groupName}" as "${match.name}" => ${match.resourceName}`);
    return match.resourceName;
  }

  // If still not found, log warning
  Logger.log(`WARNING: No match for group "${groupName}"`);
  return null;
}

/**
 * Quickly update a contact in Google Contacts when only Fields/Meetings/Group have changed.
 * Call this after a move, passing the row index (1-based, including header) or contact id.
 */
function quickUpdateContacts(rowIndices) {
  if (typeof rowIndices === "string") {
    rowIndices = JSON.parse(rowIndices);
  }
  if (!Array.isArray(rowIndices)) {
    throw new Error("rowIndices must be an array");
  }

  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  const numCols = sheet.getLastColumn();
  const headers = sheet.getRange(1, 1, 1, numCols).getValues()[0];

  let updatedCount = 0;
  let missingCount = 0;
  let errors = [];

  rowIndices.forEach(rowIndex => {
    try {
      const row = sheet.getRange(rowIndex, 1, 1, numCols).getValues()[0];

      // Get header indexes
      const idxContactId = headers.indexOf("Contact ID");
      const idxEtag = headers.indexOf("Etag");
      const idxFamily = headers.indexOf("Family Name");
      const idxGiven = headers.indexOf("Given Name");
      const idxFields = headers.indexOf("Fields");
      const idxMeetings = headers.indexOf("Meetings");
      const idxGroupMembership = headers.indexOf("Group Membership");
      const idxStatus = headers.indexOf("Status");
      const idxSelected = headers.indexOf("Selected");
      const idxLastUpdated = headers.indexOf("Last Updated");

      const contactId = row[idxContactId];
      const etag = row[idxEtag];
      const colF = row[idxFields];
      const colG = row[idxMeetings];

      if (!contactId || !etag) {
        missingCount++;
        return;
      }

      // Compute new Group Membership value
      const colGExtracted = colG ? colG.replace(/\s*\(.*?\)\s*/g, '').trim() : "";
      const newGroupMembership = `${colF} - ${colGExtracted} (Shared):::TriState Separates (Shared):::myContacts`;
      row[idxGroupMembership] = newGroupMembership;
      sheet.getRange(rowIndex, idxGroupMembership + 1).setValue(newGroupMembership);

      // Split the newGroupMembership string to get desired groups
      const groupNames = newGroupMembership
        .split(":::")
        .map(name => name.trim())
        .filter(name => name);

      // Map group names to resourceNames using your helper
      const memberships = groupNames
        .map(getGroupResourceNameByName)
        .filter(resourceName => resourceName)
        .map(resourceName => ({
          contactGroupMembership: { contactGroupResourceName: resourceName }
        }));

      // Build the contact object to send
      const contactPerson = {
        resourceName: contactId,
        etag: etag,
        names: [{ familyName: row[idxFamily], givenName: row[idxGiven] }],
        organizations: [{
          title: colF,
          department: colG
        }],
        userDefined: [{ key: "Group Membership", value: newGroupMembership }],
        memberships: memberships
      };

      const updateFields = ["names", "organizations", "userDefined", "memberships"];

      // Call Google People API to update
      const updated = People.People.updateContact(
        contactPerson,
        contactId,
        { updatePersonFields: updateFields.join(",") }
      );

      // Write back updated etag and metadata
      sheet.getRange(rowIndex, idxEtag + 1).setValue(updated.etag);
      if (idxLastUpdated > -1) {
        sheet.getRange(rowIndex, idxLastUpdated + 1).setValue(new Date());
      }
      if (idxStatus > -1) {
        sheet.getRange(rowIndex, idxStatus + 1).setValue("updated");
      }
      if (idxSelected > -1) {
        sheet.getRange(rowIndex, idxSelected + 1).setValue(false);
      }

      updatedCount++;
    } catch (e) {
      if (e && e.message && e.message.indexOf('404') !== -1) {
        // Mark as missing in Google
        if (idxStatus > -1) {
          sheet.getRange(rowIndex, idxStatus + 1).setValue("missing in Google");
        }
        if (idxSelected > -1) {
          sheet.getRange(rowIndex, idxSelected + 1).setValue(false);
        }
        missingCount++;
      } else {
        errors.push({ row: rowIndex, error: e });
      }
    }
  });

  return JSON.stringify({
    updated: updatedCount,
    missing: missingCount,
    errors: errors
  });
}

function matchGroupColors(insertedRowIdx, colF, colG) {
 try {
  Logger.log('matchGroupColors: start, row=%s, colF=%s, colG=%s', insertedRowIdx, colF, colG);
  const sheet = SpreadsheetApp.getActive().getSheetByName('Contacts');
  const data = sheet.getDataRange().getValues();
  const realCols = data[0].length; 
  const lastRow = sheet.getLastRow();
  const numCols = sheet.getLastColumn();
  
  // Find another row in the same group, excluding the newly inserted row
  let matchRowIdx = null;
  for (let i = 2; i <= lastRow; i++) { // start from 2 to skip header
    if (i === insertedRowIdx) continue;
    const row = data[i-1]; // -1 for 0-based array
    const f = row[5];      // Col F (0-based index)
    const g = row[6];     // Col G
    if (f === colF && g === colG) {
      matchRowIdx = i;
      break;
    }
  } 
  Logger.log('matchGroupColors: matchRowIdx=' + matchRowIdx);
  if (matchRowIdx) {
    Logger.log('Getting background colors from matchRowIdx=%s, cols=%s', matchRowIdx, realCols);
    // Copy background colors from group peer row
    const sourceColors = sheet.getRange(matchRowIdx, 1, 1, numCols).getBackgrounds()[0];
    sheet.getRange(insertedRowIdx, 1, 1, numCols).setBackgrounds([sourceColors]);
    Logger.log('Set background colors to inserted row.');
  } else {
    // Optionally, clear colors if this is the first in the group
    const safeCols = 10;
    Logger.log('About to clear backgrounds for row=%s, numCols=%s', insertedRowIdx, numCols);
    Logger.log('No matchRowIdx found; clearing backgrounds for row=%s, cols=%s', insertedRowIdx, safeCols);
    //const numCols = sheet.getLastColumn(); // real number of columns with data
    
    sheet.getRange(insertedRowIdx, 1, 1, safeCols).setBackground(null);
    Logger.log('Cleared backgrounds.');
  }
  Logger.log('matchGroupColors: finished.');
  } catch (e) {
    Logger.log('matchGroupColors ERROR: %s', e.toString());
    throw e;
  }
}

function sortContactSheet(payload) {
    const s = new Spreadsheet();
    return s.sortContactSheet(payload);
}

function getSortOrdersFromSettings() {
  const settingsSheet = SpreadsheetApp.getActive().getSheetByName('Settings');
  const fieldsRange = settingsSheet.getRange('D2:E'); // Field names & Order
  const meetingsRange = settingsSheet.getRange('G2:I'); // Field, Meeting, Order

  const fields = fieldsRange.getValues().filter(r => r[0]);
  const meetings = meetingsRange.getValues().filter(r => r[0] && r[1]);

  const fieldOrder = {};
  const meetingOrder = {};

  fields.forEach(([field, order]) => fieldOrder[String(field).trim().toLowerCase()] = Number(order) || 0);
  meetings.forEach(([field, meeting, order]) => {
    const key = String(field).trim().toLowerCase() + '||' + String(meeting).trim().toLowerCase();
    meetingOrder[key] = Number(order) || 0;
  });

  return { fieldOrder, meetingOrder };
}
