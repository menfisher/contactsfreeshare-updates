/**
 * PDF Imposition (4-up on Letter, 8.5" x 11")
 *
 * Requirements:
 * - Input PDF is the most recent PDF in SETTINGS.FOLDER.PDF_PRINT
 * - Output PDF saved to folder named "Printed Book"
 * - 2x2 portrait, no gaps; left-justified block
 * - User chooses between:
 *   1) Cut 4-up (stacked quarters for cutting)
 *   2) Booklet 4-up (paired for folding)
 */

const IMPOSE = {
  OUTPUT_FOLDER: "Printed Book",
  MODES: {
    CUT: "cut",
    BOOKLET: "booklet"
  }
};

async function imposeLatestAddressBookPdf() {
  _showImposeChoiceDialog_();
}

const IMPOSE_STATUS_KEY = "IMPOSE_PDF_STATUS";

function _showImposeChoiceDialog_(requestId) {
  const requestJson = JSON.stringify(requestId || "");
  const html = HtmlService.createHtmlOutput(`
    <div style="font-family:Arial;font-size:15px;line-height:1.5;">
      <div style="margin-bottom:12px;font-weight:bold;">Choose Book Binding</div>
      <div style="display:flex;gap:10px;margin-bottom:10px;">
        <button id="btn-cut" onclick="choose('cut')" style="padding:8px 16px;background:#1f7a1f;color:#fff;border:0;border-radius:4px;cursor:pointer;">Side Spiral</button>
        <button id="btn-booklet" onclick="choose('booklet')" style="padding:8px 16px;background:#1b4d89;color:#fff;border:0;border-radius:4px;cursor:pointer;">Folding</button>
      </div>
      <div id="status" style="margin-bottom:8px;color:#444;"></div>
    </div>
    <script>
      var REQUEST_ID = ${requestJson};
      function choose(mode){
        document.getElementById('status').textContent = 'Processing…';
        document.getElementById('btn-cut').disabled = true;
        document.getElementById('btn-booklet').disabled = true;
        google.script.run
          .withFailureHandler(function(err){ alert(err && err.message ? err.message : err); })
          .withSuccessHandler(function(){ google.script.host.close(); })
          .runImposeChoice(mode, REQUEST_ID);
      }
    </script>
  `).setWidth(320).setHeight(150);

  SpreadsheetApp.getUi().showModalDialog(html, "Impose PDF");
}

async function runImposeChoice(mode, requestId) {
  const reqId = requestId ? String(requestId) : "";
  _setImposeStatus_({
    state: "running",
    requestId: reqId,
    startedAt: new Date().toISOString()
  });

  try {
    let sourceFile = null;
    const file = await imposeLatestAddressBookPdfWithMode_(mode, sourceFile);
    if (sourceFile) sourceFile.setTrashed(true);
    if (file) _showImposedPdfLink_(file, "Imposed PDF created");

    if (file) {
      _setImposeStatus_({
        state: "done",
        requestId: reqId,
        finishedAt: new Date().toISOString(),
        pdfFileId: file.getId(),
        pdfFileName: file.getName()
      });
    } else {
      _setImposeStatus_({
        state: "error",
        requestId: reqId,
        finishedAt: new Date().toISOString(),
        message: "Imposed PDF file was not created."
      });
    }
  } catch (err) {
    _setImposeStatus_({
      state: "error",
      requestId: reqId,
      finishedAt: new Date().toISOString(),
      message: err && err.message ? err.message : String(err)
    });
    throw err;
  }
}

function getImposedPdfStatusByRequestId(requestId) {
  const status = _getImposeStatus_();
  if (!status || !requestId) return null;
  return status.requestId === String(requestId) ? status : null;
}

function _getImposeStatus_() {
  const props = PropertiesService.getScriptProperties();
  const raw = props.getProperty(IMPOSE_STATUS_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (err) {
    return { state: "error", message: "Invalid impose status payload." };
  }
}

function _setImposeStatus_(status) {
  PropertiesService.getScriptProperties().setProperty(
    IMPOSE_STATUS_KEY,
    JSON.stringify(status || {})
  );
}

async function imposeLatestAddressBookPdfWithMode_(mode, sourceFile) {
  if (!mode) throw new Error("Missing imposition mode.");
  if (mode !== IMPOSE.MODES.CUT && mode !== IMPOSE.MODES.BOOKLET) {
    throw new Error("Unsupported imposition mode: " + mode);
  }

  const ss = _getActiveSpreadsheet_();
  const parent = DriveApp.getFileById(ss.getId()).getParents().next();

  if (!sourceFile) {
    const sourceFolder = _getOrCreateFolderByNameImpose_(
      parent,
      SETTINGS.FOLDER.PDF_PRINT,
      false
    );
    if (!sourceFolder) {
      throw new Error('Source folder "' + SETTINGS.FOLDER.PDF_PRINT + '" not found.');
    }

    sourceFile = _getMostRecentPdf_(sourceFolder);
    if (!sourceFile) {
      throw new Error('No PDF files found in "' + SETTINGS.FOLDER.PDF_PRINT + '".');
    }
  }

  const outputFolder = _getOrCreateFolderByNameImpose_(
    parent,
    IMPOSE.OUTPUT_FOLDER,
    true
  );

  const date = Utilities.formatDate(
    new Date(),
    Session.getScriptTimeZone(),
    "yyyy-MM-dd"
  );
  const bookLabel = mode === IMPOSE.MODES.CUT ? "Side Spiral book" : "Folded book";
  const outputName = _withPdfSuffix_(`${bookLabel} ${date}`);

  return await imposePdfFileToLetter4Up_(
    sourceFile,
    outputFolder,
    { mode: mode, outputName: outputName }
  );
}

async function imposePdfFileToLetter4Up_(sourceFile, outputFolder, options) {
  const opts = options || {};
  const mode = opts.mode || IMPOSE.MODES.CUT;
  const outputName = _withPdfSuffix_(opts.outputName || (sourceFile.getName() + " 4up"));

  const PDFLib = _getPdfLibFallback_();

  const rawBytes = sourceFile.getBlob().getBytes();
  const srcBytes = Uint8Array.from(rawBytes, (b) => (b + 256) % 256);
  const srcDoc = await PDFLib.PDFDocument.load(srcBytes);
  const outDoc = await PDFLib.PDFDocument.create();
  const srcPages = srcDoc.getPages();
  const embeddedCache = new Map();

  const totalPages = srcPages.length;
  if (!totalPages) throw new Error("Source PDF has no pages.");

  const firstPage = srcPages[0];
  const pageWidth = firstPage.getWidth();
  const pageHeight = firstPage.getHeight();

  const LETTER_WIDTH = 8.5 * 72;
  const LETTER_HEIGHT = 11 * 72;

  const positionsFront = _getLetterPositions_(pageWidth, pageHeight, false);
  const positionsBack = _getLetterPositions_(pageWidth, pageHeight, true);

  if (mode === IMPOSE.MODES.CUT) {
    const sheetMaps = _buildCutSheetMaps_(totalPages);
    for (const map of sheetMaps) {
      const front = outDoc.addPage([LETTER_WIDTH, LETTER_HEIGHT]);
      await _drawPagesOnSheet_(
        srcPages,
        outDoc,
        front,
        map.front,
        positionsFront,
        totalPages,
        embeddedCache
      );
      _drawCutMarks_(front, pageHeight, PDFLib, "front");

      const back = outDoc.addPage([LETTER_WIDTH, LETTER_HEIGHT]);
      await _drawPagesOnSheet_(
        srcPages,
        outDoc,
        back,
        map.back,
        positionsBack,
        totalPages,
        embeddedCache
      );
      _drawCutMarks_(back, pageHeight, PDFLib, "back");
    }
  } else {
    const sheetMaps = _buildBookletSheetMapsImpose_(totalPages);
    for (const map of sheetMaps) {
      const front = outDoc.addPage([LETTER_WIDTH, LETTER_HEIGHT]);
      await _drawPagesOnSheet_(
        srcPages,
        outDoc,
        front,
        map.front,
        positionsFront,
        totalPages,
        embeddedCache
      );
      _drawCutMarks_(front, pageHeight, PDFLib, "front");

      const back = outDoc.addPage([LETTER_WIDTH, LETTER_HEIGHT]);
      await _drawPagesOnSheet_(
        srcPages,
        outDoc,
        back,
        map.back,
        positionsBack,
        totalPages,
        embeddedCache
      );
      _drawCutMarks_(back, pageHeight, PDFLib, "back");
    }
  }

  const outBytes = await outDoc.save();
  const outBlob = Utilities.newBlob(outBytes, MimeType.PDF, outputName);
  return outputFolder.createFile(outBlob);
}

function _getLetterPositions_(pageWidth, pageHeight, rightJustify) {
  const LETTER_WIDTH = 8.5 * 72;
  const LETTER_HEIGHT = 11 * 72;
  const blockHeight = pageHeight * 2;
  const blockWidth = pageWidth * 2;
  const offsetX = rightJustify ? Math.max(0, LETTER_WIDTH - blockWidth) : 0;

  const topY = LETTER_HEIGHT - pageHeight;
  const bottomY = LETTER_HEIGHT - blockHeight;

  return [
    { x: offsetX, y: topY },                   // top-left
    { x: offsetX + pageWidth, y: topY },       // top-right
    { x: offsetX, y: bottomY },                // bottom-left
    { x: offsetX + pageWidth, y: bottomY }     // bottom-right
  ];
}

function _drawCutMarks_(sheet, pageHeight, PDFLib, side) {
  const LETTER_HEIGHT = 11 * 72;
  const topY = LETTER_HEIGHT;
  const midY = LETTER_HEIGHT - pageHeight;
  const bottomY = LETTER_HEIGHT - (pageHeight * 2);

  const tick = 4;
  const color = PDFLib.rgb(0, 0, 0);
  const thickness = 0.5;

  const inch = (n) => n * 72;
  const drawPlus = (x, y) => {
    sheet.drawLine({
      start: { x: x - tick, y },
      end: { x: x + tick, y },
      color,
      thickness
    });
    sheet.drawLine({
      start: { x, y: y - tick },
      end: { x, y: y + tick },
      color,
      thickness
    });
  };

  const isFront = side !== "back";

  const topXs = isFront ? [inch(3.5), inch(7)] : [inch(1.5), inch(5)];
  const midXs = isFront ? [inch(0), inch(3.5), inch(7)] : [inch(1.5), inch(5), inch(8.5)];
  const botXs = isFront ? [inch(0), inch(3.5), inch(7)] : [inch(1.5), inch(5), inch(8.5)];

  topXs.forEach((x) => drawPlus(x, topY));
  midXs.forEach((x) => drawPlus(x, midY));
  botXs.forEach((x) => drawPlus(x, bottomY));
}

async function _drawPagesOnSheet_(
  srcPages,
  outDoc,
  sheet,
  indices,
  positions,
  totalPages,
  embeddedCache
) {
  const pageCount = totalPages ?? srcPages.length;
  const entries = [];
  const pending = new Set();
  const pendingIndices = [];
  const pendingPages = [];

  for (let i = 0; i < positions.length; i++) {
    const pageIndex = indices[i];
    if (pageIndex == null || pageIndex < 0 || pageIndex >= pageCount) {
      continue;
    }

    const pos = positions[i];
    entries.push({ pageIndex, x: pos.x, y: pos.y });

    if (!embeddedCache.has(pageIndex) && !pending.has(pageIndex)) {
      pending.add(pageIndex);
      pendingIndices.push(pageIndex);
      pendingPages.push(srcPages[pageIndex]);
    }
  }

  if (!entries.length) return;

  if (pendingPages.length) {
    const embeddedPages = await outDoc.embedPages(pendingPages);
    for (let i = 0; i < embeddedPages.length; i++) {
      embeddedCache.set(pendingIndices[i], embeddedPages[i]);
    }
  }

  for (const entry of entries) {
    const embedded = embeddedCache.get(entry.pageIndex);
    if (!embedded) continue;
    sheet.drawPage(embedded, { x: entry.x, y: entry.y });
  }
}

function _buildBookletSheetMapsImpose_(totalPages) {
  const paddedTotal = Math.ceil(totalPages / 8) * 8;
  const sheets = [];
  const sheetCount = paddedTotal / 8;
  const quarter = paddedTotal / 4;

  const norm = (p) => {
    if (p < 1 || p > totalPages) return -1;
    return p - 1;
  };

  for (let i = 0; i < sheetCount; i++) {
    const L = paddedTotal - (2 * i);
    const R = 1 + (2 * i);

    sheets.push({
      front: [
        norm(L),
        norm(R),
        norm(L - quarter),
        norm(R + quarter)
      ],
      back: [
        norm(R + 1),
        norm(L - 1),
        norm(R + quarter + 1),
        norm(L - quarter - 1)
      ]
    });
  }

  return sheets;
}

function _buildCutSheetMaps_(totalPages) {
  const padded = Math.ceil(totalPages / 8) * 8;
  const quarter = padded / 4;
  const sheets = [];

  for (let s = 0; s < quarter / 2; s++) {
    const frontN = (s * 2) + 1;
    const backN = frontN + 1;

    const front = [
      frontN - 1,
      frontN + quarter - 1,
      frontN + (2 * quarter) - 1,
      frontN + (3 * quarter) - 1
    ];

    const back = [
      backN + quarter - 1,
      backN - 1,
      backN + (3 * quarter) - 1,
      backN + (2 * quarter) - 1
    ];

    sheets.push({
      front: _clampPageIndices_(front, totalPages),
      back: _clampPageIndices_(back, totalPages)
    });
  }

  return sheets;
}

function _clampPageIndices_(indices, totalPages) {
  return indices.map((i) => (i >= 0 && i < totalPages ? i : -1));
}

function _getMostRecentPdf_(folder) {
  const files = folder.getFilesByType(MimeType.PDF);
  let latest = null;
  let latestTime = 0;

  while (files.hasNext()) {
    const file = files.next();
    const t = file.getLastUpdated().getTime();
    if (t > latestTime) {
      latestTime = t;
      latest = file;
    }
  }
  return latest;
}

function _getOrCreateFolderByNameImpose_(parent, name, createIfMissing) {
  const iter = parent.getFoldersByName(name);
  if (iter.hasNext()) return iter.next();
  if (createIfMissing) return parent.createFolder(name);
  return null;
}

function _withPdfSuffix_(name) {
  return /\.pdf$/i.test(name) ? name : (name + ".pdf");
}

function _showImposedPdfLink_(file, title) {
  const url = file.getUrl();

  if (typeof _openLink_ === "function") {
    _openLink_(url, "Imposed PDF has been created.", title || "Imposed PDF");
    return;
  }

  const safeUrl = url.replace(/"/g, "&quot;");
  const html = HtmlService.createHtmlOutput(
    '<div style="font-family:Arial;font-size:12px;">' +
      '<p>Imposed PDF created.</p>' +
      '<p><a href="' + safeUrl + '" target="_blank" rel="noopener">Open PDF</a></p>' +
    "</div>"
  ).setWidth(320).setHeight(140);

  SpreadsheetApp.getUi().showModalDialog(html, title || "Imposed PDF");
}

function _getPdfLibFallback_() {
  if (typeof _getPdfLib_ === "function") return _getPdfLib_();
  if (typeof PDFLib !== "undefined" && PDFLib && PDFLib.PDFDocument) return PDFLib;
  throw new Error(
    "PDFLib not found. Make sure the pdf-lib UMD build is loaded in PdfLib.gs."
  );
}
