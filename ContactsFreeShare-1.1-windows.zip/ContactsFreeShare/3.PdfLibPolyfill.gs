// Polyfills needed by pdf-lib in Apps Script.
if (typeof setTimeout === "undefined") {
  var setTimeout = function (fn, ms) {
    Utilities.sleep(ms || 0);
    fn();
    return null;
  };
}

if (typeof clearTimeout === "undefined") {
  var clearTimeout = function () {};
}
