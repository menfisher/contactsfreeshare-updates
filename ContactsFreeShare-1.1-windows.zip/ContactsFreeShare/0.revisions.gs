const REVISIONS = [
{
    date: new Date("3/Apr/2026"),
    items: [
      "Fixed Address 2 & Address 3 fields.",
      "address types and values now print in PDF"
    ],
  },
{
    date: new Date("28/Mar/2026"),
    items: [
      "Fixed All Fields check box problem",
    ],
  },
 {
    date: new Date("27/Mar/2026"),
    items: [
      "Fixed custom phone type names",
    ],
  },
  {
    date: new Date("26/Jan/2026"),
    items: [
      "Added Cover photo option to sidebar",
    ],
  },
  {
    date: new Date("22/Jan/2026"),
    items: [
      "Can set font size for printed book now",
      "code retries when network error timeout happens",
      "can set font size for tables in Col C on MeetingData tab",
    ],
  },
  {
    date: new Date("21/Jan/2026"),
    items: [
      "Updated Create Field list sidebar",
      "fixed onEdit bug when modifying tables",
    ],
  },
  {
    date: new Date("19/Jan/2026"),
    items: [
      "Create Field List works again",
      "fixed errors with field and mtg sorting while printing",
    ],
  },
  {
    date: new Date("18/Jan/2026"),
    items: [
      "Cover Photo added to PDF for phone",
      "use format code um1 in Col C to keep union mtg tables on same page",
      "newly created 'PDF for phone' file also saves in 'PDF & Addbook files' folder"
    ],
  },
  {
    date: new Date("16/Jan/2026"),
    items: [
      "Program can print PDF for paper book now",
      "Updated Create Address Book Sidebar",
      "Optimized code for faster runtime"
    ],
  },
  {
    date: new Date("9/Jan/2026"),
    items: [
      "Meeting info now kept in tables in MeetingData tab",
      "Updated Create Address Book Sidebar",
      "Optimized code for runtime savings"
    ],
  },
  {
    date: new Date("4/Dec/2025"),
    items: [
      "Fixed issue of blank lines at top of Field list",
      "Updated Create Address Book Sidebar"
    ],
  },
  {
    date: new Date("3/Dec/2025"),
    items: ["Fixed bug concerning comma in Field or Meeting name"],
  },
  {
    date: new Date("22/Nov/2025"),
    items: ["Can choose Fields to print in Address Book creation"],
  },
  {
    date: new Date("18/Nov/2025"),
    items: [
      "no printing for minors created",
    ],
  },
  {
    date: new Date("14/Nov/2025"),
    items: [
      "Phone tag problem resolved",
    ],
  },
  {
    date: new Date("7/Nov/2025"),
    items: [
      "Fixed bug with Notes not updating",
      "Fixed bug with GPS coor appending to old coor in Contacts",
      "Address Book is working now"
    ],
  },
  {
    date: new Date("2/Aug/2025"),
    items: [
      "New Contact Administration Sidebar created",
      "Address List is working now"
    ],
  },
  {
    date: new Date("7/Jul/2025"),
    items: ["Fixed a bug found on MS North org field list"],
  },
  {
    date: new Date("30/Jun/2025"),
    items: ['Fixed a bug on "continued" header for field list'],
  },
  {
    date: new Date("26/Jun/2025"),
    items: ["Create field list with the new method"],
  },
  {
    date: new Date("7/Jun/2025"),
    items: ["relabeled Cols F & G to Fields and Meetings"],
  },
  {
    date: new Date("5/Jun/2025"),
    items: ["mismatched eTags addressed"],
  },
  {
    date: new Date("5/Jun/2025"),
    items: ["Last Updated & Status column data erasure issue resolved"],
  },
  {
    date: new Date("5/Jun/2025"),
    items: ["Photo now imported using updateContacts"],
  },
  {
    date: new Date("26/May/2025"),
    items: ["New feature - bookmark links for table of content"],
  },
  {
    date: new Date("20/May/2025"),
    items: [
      'Rename column "Sort Number" to "Mtg home-1/Elder-2"',
      'Rename headers in settings to "Fields" & "Meetings"',
    ],
  },
  {
    date: new Date("20/Apr/2025"),
    items: ["Add etags check before contacts update"],
  },
  {
    date: new Date("17/Apr/2025"),
    items: [
      "Update organization titles and names in the settings when create/update/get/delete contacts",
    ],
  },
  {
    date: new Date("16/Apr/2025"),
    items: ["Enable custom sorting method for contacts in the settings"],
  },
  {
    date: new Date("17/Apr/2025"),
    items: [
      "Update organization titles and names in the settings when create/update/get/delete contacts",
    ],
  },
  {
    date: new Date("16/Apr/2025"),
    items: ["Enable custom sorting method for contacts in the settings"],
  },
  {
    date: new Date("10/Apr/2025"),
    items: ["Fix a logic error in name letters"],
  },
  {
    date: new Date("9/Apr/2025"),
    items: [
      "Put contact in a separate group if it's not in the family even they have the same address",
    ],
  },
  {
    date: new Date("8/Apr/2025"),
    items: [
      "Bring custom field values back to Contacts Sheet",
      "Add new column 'Sort Number'",
      "Add phone number to the wrapped line of family names",
    ],
  },
  {
    date: new Date("7/Apr/2025"),
    items: ["Wrap family names line when it's too long"],
  },
  {
    date: new Date("6/Apr/2025"),
    items: ["Fix a bug in address coordinates parse from map URLs"],
  },
  {
    date: new Date("5/Apr/2025"),
    items: [
      "Use address type as the label for the address map URL (website)",
      "Stop using custom field 3 for storing the coordinates",
    ],
  },
  {
    date: new Date("4/Apr/2025"),
    items: [
      "Use custom field 1 for the sorting numbers 1, 2, 3 ...",
      "Add address map URLs back to website fields",
    ],
  },
  {
    date: new Date("2/Apr/2025"),
    items: ["Fix a bug on underline formatting"],
  },
  {
    date: new Date("31/Mar/2025"),
    items: ["Fix a bug in the new sorting method with address type 1"],
  },
  {
    date: new Date("27/Mar/2025"),
    items: [
      "Update the contact sorting logic by using Address 1 - Type to replace Custom Field 1 - Value",
    ],
  },
  {
    date: new Date("25/Mar/2025"),
    items: ["Apply underscore style to the address without coordinates"],
  },
  {
    date: new Date("24/Mar/2025"),
    items: [
      "Use custom field 2 for saving address coordinates 1,2,3",
      "Address new fields 'Address 1/2/3 - Coordinates'",
    ],
  },
  {
    date: new Date("19/Mar/2025"),
    items: ["Handle contacts with no phone numbers", "Add map type selection"],
  },
  {
    date: new Date("17/Mar/2025"),
    items: [
      "Fixed a bug in text formatting in meetings",
      "Handle special contact case like Jason Clark",
    ],
  },
  {
    date: new Date("9/Mar/2025"),
    items: [
      "Use column 'Coordinates' for Google & Apple Maps URLs in contact create & update",
      "Fix a bug in name letter logic",
    ],
  },
  {
    date: new Date("5/Mar/2025"),
    items: [
      'Update phone letter logic for phone type "nh" (nursing home)',
      "Update name letter logic for husband & wife with same leading letter",
      "Remove duplicated phone numbers",
    ],
  },
  {
    date: new Date("3/Mar/2025"),
    items: [
      "Apply contacts sort logic in new workaround",
      "Fix a bug in husband & wife name swap",
    ],
  },
  {
    date: new Date("2/Mar/2025"),
    items: ["Update function 'applyColors2'"],
  },
  {
    date: new Date("26/Feb/2025"),
    items: [
      "Get coordinates from map address url to AR column",
      "Move city & state to new line when address is too long",
      "Fix the 'undefined' issue on contact page index",
    ],
  },
  {
    date: new Date("24/Feb/2025"),
    items: ["Add address type 2 & 3 to address line"],
  },
  {
    date: new Date("18/Feb/2025"),
    items: ["Group contact by the address1Formatted instead of family name"],
  },
  {
    date: new Date("28/Jan/2025"),
    items: ["Phone letters & name Letters", "Remove underline style for links"],
  },
  {
    date: new Date("27/Jan/2025"),
    items: ["Fix bugs in meeting & field info lines"],
  },
  {
    date: new Date("26/Jan/2025"),
    items: [
      "Set links to black for better readability",
      "Use address for the map URL when no coordinates",
      "Add contact page index lines for the address book",
      "Add organization overview lines for the address book",
    ],
  },
  {
    date: new Date("26/Sep/2024"),
    items: ["Add title - continued for the next page on address book"],
  },
  {
    date: new Date("24/Sep/2024"),
    items: [
      "Add page number and sort contact index by name in the group for the address book",
      "Sort all contact index in one group from A-Z by using the full name",
      "Fix the full name issue in the contact index",
    ],
  },
  {
    date: new Date("23/Sep/2024"),
    items: ["Add contact index for the address book"],
  },
  {
    date: new Date("11/Sep/2024"),
    items: ['Handle relationship "son" in the address-book'],
  },
  {
    date: new Date("22/Jul/2024"),
    items: ["Update map position when there are multiple emtpy address lines"],
  },
  {
    date: new Date("15/Jul/2024"),
    items: ["Update Google Map Apple Map position when no address"],
  },
  {
    date: new Date("9/Jul/2024"),
    items: ["Add doc template app"],
  },
  {
    date: new Date("8/Jul/2024"),
    items: [
      "Handle splited contact lines in address book",
      "Add specific folders for saving field list and address book",
    ],
  },
  {
    date: new Date("25/Jun/2024"),
    items: [
      "Add line continued logic for meeting, field, and more info",
      "Add a line before meeting, field, and more info by default",
    ],
  },
  {
    date: new Date("17/Jun/2024"),
    items: ["Fix the two-line contact column break for the field list"],
  },
  {
    date: new Date("12/May/2024"),
    items: ["Fix the position of 'countined' for the field list"],
  },
  {
    date: new Date("2/May/2024"),
    items: [
      "Fix sorting logic for meeting home/elder, meeting home, and elder with value in AM(Custom Field 1 - Value)",
    ],
  },
  {
    date: new Date("12/Mar/2024"),
    items: [
      "Remove the continued line for meetings",
      "Remove the extra empty rows in address book",
    ],
  },
  {
    date: new Date("6/Mar/2024"),
    items: [
      "Remove the empty lines in field list for address map links",
      "Add 'continued' for every new column in field list",
    ],
  },
  {
    date: new Date("5/Mar/2024"),
    items: ["Fixed the position of 'continued' section"],
  },
  {
    date: new Date("23/Feb/2024"),
    items: [
      "Handle 'MoreInfo' in the meetings",
      "Fix the margin issue on two columns layout",
    ],
  },
  {
    date: new Date("18/Jan/2024"),
    items: ["Handle two column layout for field list"],
  },
  {
    date: new Date("12/Jan/2024"),
    items: ["Add sidebar for creating field list"],
  },
  {
    date: new Date("3/Jan/2024"),
    items: ["Move meeting & field info in a seperate sheet"],
  },
  {
    date: new Date("11/Dec/2023"),
    items: ["Set all headings to black", "All caps for family name"],
  },
  {
    date: new Date("21/Nov/2023"),
    items: [
      "Table of content - title font size to 15, and all caps",
      "Table of content - center, font size to 15, and 1.5 line space",
      "Capitalize family and keep it bold",
    ],
  },
  {
    date: new Date("13/Nov/2023"),
    items: [
      "Update the contact sort logic by using the given name after family name",
      "Add w after name letter for work phone when there is only one line for the family",
    ],
  },
  {
    date: new Date("10/Nov/2023"),
    items: [
      "Update the contact sort logic by using the family instead of using given name",
    ],
  },
  {
    date: new Date("6/Nov/2023"),
    items: [
      "Change font to Ubuntu Mono",
      "Update sorting logic with meeting home/elder, meeting home, and elder",
    ],
  },
  {
    date: new Date("30/Oct/2023"),
    items: [
      "Update contact sort logic with meeting home",
      "Add hyper link to phone number",
    ],
  },
  {
    date: new Date("16/Oct/2023"),
    items: [
      "Check name capitalization for the 1st word only",
      "Fix family name alignment when no phone number for the content",
      "Update the logic for phone letter when there is only one contact in the family",
      "Update the empty row check logic for meeting info",
      "Move up phone number when there is empty space above",
    ],
  },
  {
    date: new Date("10/Oct/2023"),
    items: [
      "Merge title and subtitle & join them with comma",
      "Sort contacts by given name",
      "Fix the phone letter issue",
    ],
  },
  {
    date: new Date("9/Oct/2023"),
    items: ["Update with minor improvements"],
  },
  {
    date: new Date("23/Sep/2023"),
    items: ["Layout fix for multiple lines"],
  },
  {
    date: new Date("31/Aug/2023"),
    items: ["Remove title section for Meeting Info & Field Info"],
  },
  {
    date: new Date("28/Aug/2023"),
    items: [
      "Update the sort method for family members",
      "Handle multiple children in the family",
    ],
  },
  {
    date: new Date("25/Aug/2023"),
    items: ["Always 2-letter space for name/phone prefix"],
  },
  {
    date: new Date("15/Aug/2023"),
    items: ["Update phone suffix logic"],
  },
  {
    date: new Date("13/Aug/2023"),
    items: [
      "Add 2 spaces after contact prefix",
      "Update phone suffix",
      "Remove extra spaces",
      "Fix map address issue",
    ],
  },
  {
    date: new Date("03/May/2023"),
    items: ["Enable rich text from Sheets to Docs"],
  },
  {
    date: new Date("09/Apr/2023"),
    items: ["Add more contact info to the address book"],
  },
  {
    date: new Date("08/Apr/2023"),
    items: ["Initial release for Address Book App"],
  },
];
