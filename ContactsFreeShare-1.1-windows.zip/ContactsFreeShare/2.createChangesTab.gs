function archiveAndRecreateChangesTab() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const ui = SpreadsheetApp.getUi();
  const response = ui.alert(
    "Archive Changes Tab",
    "Move Changes tab to Drive/Archive and create new Changes tab\n\nProceed?",
    ui.ButtonSet.YES_NO
  );

  if (response !== ui.Button.YES) return;

  const changesSheetName = "Changes";
  const oldSheet = ss.getSheetByName(changesSheetName);

  // 1. Archive existing "Changes" sheet if it exists
  if (oldSheet) {
    const year = Utilities.formatDate(new Date(), ss.getSpreadsheetTimeZone(), "yyyy");
    const archiveName = changesSheetName + year;

    // Create a new spreadsheet for the archive
    const newSS = SpreadsheetApp.create(archiveName);
    const copiedSheet = oldSheet.copyTo(newSS);
    copiedSheet.setName(archiveName);
    copiedSheet.setFrozenRows(1);

    // Remove the default "Sheet1" from the new spreadsheet
    const defaultSheet = newSS.getSheetByName("Sheet1");
    if (defaultSheet) {
      newSS.deleteSheet(defaultSheet);
    }

    // Move the new spreadsheet to the "Archive" folder
    const folderName = "Archive";
    const root = DriveApp.getRootFolder();
    const folders = root.getFoldersByName(folderName);
    const archiveFolder = folders.hasNext() ? folders.next() : root.createFolder(folderName);

    const file = DriveApp.getFileById(newSS.getId());
    file.moveTo(archiveFolder);

    // Delete the old sheet from the current spreadsheet
    ss.deleteSheet(oldSheet);
  }

  // 2. Create a new "Changes" sheet
  let newSheet = ss.getSheetByName(changesSheetName);
  if (newSheet) {
    newSheet.clear();
  } else {
    newSheet = ss.insertSheet(changesSheetName);
  }

  // 3. Set Headers
  const headers = [
    "Updated Sheets",
    "Updated Addbook5",
    "Saved PDF",
    "Automatic Date Entry",
    "Name/Event",
    "Changes",
    
  ];

  newSheet.getRange(1, 1, 1, headers.length)
    .setValues([headers])
    .setBackground("#2fff3e")
    .setFontWeight("bold")
    .setFontFamily("Arial")
    .setFontSize(10);
  newSheet.setFrozenRows(1);
  
  newSheet.setColumnWidth(1, 112);
  newSheet.setColumnWidth(2, 132);
  newSheet.setColumnWidth(3, 115);
  newSheet.setColumnWidth(4, 118);
  newSheet.setColumnWidth(5, 125);
  newSheet.setColumnWidth(6, 740);
}