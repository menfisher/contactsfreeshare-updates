
var sheet = SpreadsheetApp.getActiveSheet();
function sortMtgSht() {
    const range = sheet.getRange(
      3,
      1,
      sheet.getLastRow() - 1,
      sheet.getLastColumn()
    );
    range.sort([
      { column: 1, ascending: true },
      { column: 2, ascending: true },      
    ]);
//    SpreadsheetApp.flush();
//    this.applyColors(sheet);
  }

