"""Incremental owner→recipient contact sync using sync_mappings."""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import Any

from .. import db
from ..google_auth import owner_credentials, recipient_credentials
from ..people_api import get_group_member_ids, get_people_batch, people_service
from ..people_recipient import (
    assignment_shared_group_name,
    create_contact_in_group,
    delete_contact,
    delete_contact_photo,
    ensure_assignment_contact_label,
    ensure_contact_in_group,
    get_person_etags_batch,
    has_custom_contact_photo,
    normalize_person_resource_name,
    remove_contact_from_group,
    remove_stale_assignment_label,
    set_contact_photo,
    update_contact,
)
from .contact_hash import compute_contact_hash, compute_photo_hash
from .recipient_import import contacts_identity_match, _ensure_recipient_group

logger = logging.getLogger(__name__)


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _fetch_etag_or_gone(creds, recipient_person_id: str) -> tuple[str, bool]:
    """(etag, gone). gone is True only when Google answers 404/410.

    A rate limit or network hiccup is neither: the card may still exist, so the
    caller must not clear the mapping and create a second copy.
    """
    rid = normalize_person_resource_name(recipient_person_id)
    if not rid:
        return "", True
    for attempt in range(3):
        try:
            data = (
                people_service(creds)
                .people()
                .get(resourceName=rid, personFields="metadata")
                .execute()
            )
            return str(data.get("etag") or ""), False
        except Exception as exc:  # noqa: BLE001
            status = getattr(getattr(exc, "resp", None), "status", None)
            if status in (404, 410):
                return "", True
            if attempt < 2:
                time.sleep(15.0 * (attempt + 1))
    return "", False


def _normalize_person_ids(person_ids: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in person_ids:
        normalized = normalize_person_resource_name(str(raw or "").strip())
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        out.append(normalized)
    return out


def _membership_group_resource_names(member_data: dict[str, Any] | None) -> set[str]:
    names: set[str] = set()
    for membership in (member_data or {}).get("memberships") or []:
        if not isinstance(membership, dict):
            continue
        group_membership = membership.get("contactGroupMembership") or {}
        resource_name = str(group_membership.get("contactGroupResourceName") or "").strip()
        if resource_name:
            names.add(resource_name)
    return names


def _ensure_membership_group_resource_names(
    owner_creds,
    person_id: str,
    member_data: dict[str, Any],
) -> set[str]:
    """Use batch memberships when present; otherwise fetch them for this contact."""
    names = _membership_group_resource_names(member_data)
    if names:
        return names
    normalized = normalize_person_resource_name(person_id)
    if not normalized or owner_creds is None:
        return set()
    try:
        service = people_service(owner_creds)
        person = (
            service.people()
            .get(resourceName=normalized, personFields="memberships")
            .execute()
        )
    except Exception:
        logger.exception("Failed to load memberships for %s", normalized)
        return set()
    if isinstance(person, dict):
        member_data["memberships"] = person.get("memberships") or []
    return _membership_group_resource_names(member_data)


def _discover_mappings_for_unmapped_contact(
    *,
    owner: str,
    owner_person_id: str,
    member_data: dict[str, Any],
    owner_creds,
) -> list[dict[str, Any]]:
    """Build create mappings for shared groups this new contact belongs to."""
    owner_data = db.get_app_data(owner) or {}
    owner_groups = dict(owner_data.get("groups") or {})
    if not owner_groups:
        return []

    membership_names = _ensure_membership_group_resource_names(
        owner_creds, owner_person_id, member_data
    )
    discovered: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()

    for resource_name, group in owner_groups.items():
        if not isinstance(group, dict):
            continue
        shared_emails = [
            db.normalize_email(email)
            for email in (group.get("shared") or [])
            if str(email or "").strip()
        ]
        if not shared_emails:
            continue

        in_group = resource_name in membership_names
        if not in_group and not membership_names:
            # Fallback when People API omits memberships: check group member list.
            try:
                member_ids = {
                    normalize_person_resource_name(item)
                    for item in get_group_member_ids(owner_creds, resource_name)
                }
            except Exception:
                logger.exception("Failed to list members for %s", resource_name)
                continue
            in_group = owner_person_id in member_ids
        if not in_group:
            continue

        share_id = str(group.get("shareId") or "").strip()
        for recipient_email in shared_emails:
            recipient_data = db.get_app_data(recipient_email) or {}
            target = next(
                (
                    g
                    for g in (recipient_data.get("sharedGroups") or [])
                    if isinstance(g, dict)
                    and g.get("owner") == owner
                    and g.get("resourceName") == resource_name
                ),
                None,
            )
            if not target:
                continue
            resolved_share_id = str(target.get("shareId") or share_id).strip()
            if not resolved_share_id:
                continue
            key = (resolved_share_id, resource_name, recipient_email)
            if key in seen:
                continue
            seen.add(key)
            discovered.append(
                {
                    "id": None,
                    "share_id": resolved_share_id,
                    "owner": owner,
                    "group_resource_name": resource_name,
                    "recipient_email": recipient_email,
                    "owner_person_id": owner_person_id,
                    "recipient_person_id": "",
                    "last_hash": "",
                    "last_photo_hash": "",
                    "owner_etag": "",
                }
            )
    return discovered


def _mapping_key(mapping: dict[str, Any]) -> tuple[str, str, str]:
    return (
        str(mapping.get("share_id") or ""),
        str(mapping.get("group_resource_name") or ""),
        db.normalize_email(str(mapping.get("recipient_email") or "")),
    )


def _contacts_identity_match(left: dict[str, Any] | None, right: dict[str, Any] | None) -> bool:
    """True when two People payloads are the same person (name plus phone/email)."""
    return contacts_identity_match(left, right)


def _unique_identity_staged_id(
    share_id: str, member_data: dict[str, Any], current_owner_person_id: str
) -> str:
    current_id = normalize_person_resource_name(current_owner_person_id)
    matches: list[str] = []
    for staged in db.read_shared_contacts(share_id):
        staged_id = normalize_person_resource_name(str(staged.get("resourceName") or ""))
        if not staged_id or staged_id == current_id:
            continue
        if _contacts_identity_match(member_data, staged):
            matches.append(staged_id)
    if len(matches) != 1:
        return ""
    return matches[0]


def _delete_recipient_person(recipient_email: str, recipient_person_id: str) -> bool:
    rid = normalize_person_resource_name(recipient_person_id)
    if not rid:
        return True
    creds = recipient_credentials(recipient_email)
    if not creds:
        return False
    try:
        deleted = bool(delete_contact(creds, rid))
    except Exception:
        logger.exception(
            "Failed deleting recipient contact %s for %s", rid, recipient_email
        )
        return False
    if deleted:
        _forget_deleted_card(recipient_email, rid)
    return deleted


def _forget_deleted_card(recipient_email: str, recipient_person_id: str) -> int:
    """Drop every mapping row, in any group, that pointed at a card we just deleted.

    One recipient card can be mapped from several groups. Without this, the other
    groups keep pointing at a card that is gone and Share reports it as lost track of.
    """
    removed = db.delete_sync_mappings_for_recipient_card(recipient_email, recipient_person_id)
    if removed:
        logger.info(
            "Dropped %s mapping row(s) for deleted recipient card %s (%s)",
            removed,
            recipient_person_id,
            recipient_email,
        )
    return removed


def _card_still_used_by_another_group(
    recipient_email: str, recipient_person_id: str, share_id: str, group_resource_name: str
) -> bool:
    rid = normalize_person_resource_name(recipient_person_id)
    if not rid:
        return False
    for row in db.find_mappings_for_recipient_card(recipient_email, rid):
        if (
            str(row.get("share_id") or "") == share_id
            and str(row.get("group_resource_name") or "") == group_resource_name
        ):
            continue
        return True
    return False


def _recipient_group_id_for(recipient_email: str, share_id: str, group_resource_name: str) -> str:
    """The recipient's own Google label id for one shared group, or ''."""
    from .recipient_import import _contact_group_resource

    data = db.get_app_data(recipient_email) or {}
    for group in data.get("sharedGroups") or []:
        if not isinstance(group, dict):
            continue
        if (
            str(group.get("shareId") or "") == share_id
            and str(group.get("resourceName") or "") == group_resource_name
        ):
            return _contact_group_resource(group.get("created") or group.get("googleGroupId")) or ""
    return ""


def _prune_one_mapping(mapping: dict[str, Any], *, drop_staged: bool = False) -> dict[str, Any]:
    """Delete one recipient card and its mapping when the owner contact left the share."""
    share_id = str(mapping.get("share_id") or "")
    owner = str(mapping.get("owner") or "")
    group_resource_name = str(mapping.get("group_resource_name") or "")
    recipient_email = str(mapping.get("recipient_email") or "")
    owner_person_id = str(mapping.get("owner_person_id") or "")
    rid = str(mapping.get("recipient_person_id") or "")
    if rid and not _delete_recipient_person(recipient_email, rid):
        return {
            "status": "error",
            "reason": "delete_failed",
            "action": "prune",
            "mapping_id": mapping.get("id"),
        }
    if share_id and owner and group_resource_name and recipient_email and owner_person_id:
        db.delete_sync_mapping_rows(
            share_id,
            owner,
            group_resource_name,
            recipient_email,
            owner_person_ids=[owner_person_id],
        )
    if drop_staged and share_id and owner_person_id:
        db.delete_shared_contact_member(share_id, owner_person_id)
    return {
        "status": "pruned",
        "action": "prune",
        "mapping_id": mapping.get("id"),
        "recipient_person_id": rid,
    }


def _relink_identity_mappings(
    *,
    owner: str,
    owner_person_id: str,
    member_data: dict[str, Any],
) -> list[dict[str, Any]]:
    """Point existing recipient cards at a new owner Google ID.

    CFS is the source of truth. When Google recreates a contact, keep the
    recipient card and retarget the mapping. Extra duplicate cards from the
    new ID are removed; the contact itself is not deleted from recipients.
    """
    relinked: list[dict[str, Any]] = []
    for staged in db.list_staged_share_groups_for_owner(owner):
        share_id = str(staged.get("share_id") or "").strip()
        group_resource_name = str(staged.get("group_resource_name") or "").strip()
        if not share_id or not group_resource_name:
            continue
        old_id = _unique_identity_staged_id(share_id, member_data, owner_person_id)
        if not old_id:
            continue
        for mapping in db.find_mappings_for_owner_person(owner, old_id):
            if (
                str(mapping.get("share_id") or "") != share_id
                or str(mapping.get("group_resource_name") or "") != group_resource_name
            ):
                continue
            recipient_email = db.normalize_email(str(mapping.get("recipient_email") or ""))
            new_mappings = [
                item
                for item in db.find_mappings_for_owner_person(owner, owner_person_id)
                if _mapping_key(item) == (share_id, group_resource_name, recipient_email)
            ]
            extra_rid = ""
            if new_mappings:
                extra_rid = normalize_person_resource_name(
                    str(new_mappings[0].get("recipient_person_id") or "")
                )
            kept_rid = normalize_person_resource_name(
                str(mapping.get("recipient_person_id") or "")
            )
            if extra_rid and extra_rid != kept_rid:
                _delete_recipient_person(recipient_email, extra_rid)
            db.retarget_sync_mapping_owner_person(
                share_id=share_id,
                owner=owner,
                group_resource_name=group_resource_name,
                recipient_email=recipient_email,
                old_owner_person_id=old_id,
                new_owner_person_id=owner_person_id,
            )
            db.patch_shared_contact_member(share_id, old_id, member_data)
            mapping["owner_person_id"] = owner_person_id
            mapping["relinked"] = True
            relinked.append(mapping)
    return relinked


def _prune_missing_owner_person(owner: str, owner_person_id: str) -> list[dict[str, Any]]:
    """Remove recipient cards after a CFS permanent delete (owner Google 404)."""
    person_id = normalize_person_resource_name(owner_person_id)
    mappings = db.find_mappings_for_owner_person(owner, person_id) if person_id else []
    if not mappings:
        for staged in db.list_staged_share_groups_for_owner(owner):
            share_id = str(staged.get("share_id") or "").strip()
            if share_id and person_id:
                db.delete_shared_contact_member(share_id, person_id)
        return [{"status": "pruned", "action": "prune", "reason": "owner_missing"}]

    outcomes: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    for mapping in mappings:
        key = _mapping_key(mapping)
        if key in seen:
            continue
        seen.add(key)
        outcomes.append(_prune_one_mapping(mapping, drop_staged=True))
    return outcomes


def prune_orphan_recipient_contacts(
    *,
    share_id: str,
    owner: str,
    group_resource_name: str,
    recipient_email: str,
    current_owner_person_ids: set[str] | list[str],
) -> dict[str, Any]:
    """Delete recipient Google contacts whose owner person is no longer in the shared group.

    When an owner contact is permanently deleted or recreated with a new Google ID, Sync
    used to create a replacement without removing the old recipient copy. This prunes those
    leftovers using sync_mappings that point at owner IDs no longer in the current set.
    """
    current_ids = {
        normalize_person_resource_name(str(item or "").strip())
        for item in current_owner_person_ids
        if str(item or "").strip()
    }
    current_ids.discard("")
    by_owner, _ = db.load_sync_mappings(
        share_id, owner, group_resource_name, recipient_email
    )
    orphans = [
        mapping
        for owner_person_id, mapping in by_owner.items()
        if normalize_person_resource_name(owner_person_id) not in current_ids
        and str(mapping.get("recipient_person_id") or "").strip()
    ]
    if not orphans:
        return {"checked": len(by_owner), "orphans": 0, "deleted": 0, "failed": 0}

    creds = recipient_credentials(recipient_email)
    if not creds:
        return {
            "checked": len(by_owner),
            "orphans": len(orphans),
            "deleted": 0,
            "failed": len(orphans),
            "reason": "not_connected",
        }

    deleted = 0
    failed = 0
    deleted_owner_ids: list[str] = []
    for mapping in orphans:
        owner_person_id = str(mapping.get("owner_person_id") or "").strip()
        rid = normalize_person_resource_name(str(mapping.get("recipient_person_id") or ""))
        shared_elsewhere = _card_still_used_by_another_group(
            recipient_email, rid, share_id, group_resource_name
        )
        try:
            if shared_elsewhere:
                # Another group still maps this card, so deleting it would leave that
                # group pointing at nothing. Only take it out of this group.
                group_id = _recipient_group_id_for(recipient_email, share_id, group_resource_name)
                ok = bool(group_id) and bool(remove_contact_from_group(creds, rid, group_id))
            else:
                ok = delete_contact(creds, rid) if rid else True
                if ok and rid:
                    _forget_deleted_card(recipient_email, rid)
        except Exception:
            logger.exception(
                "Failed deleting orphan recipient contact %s for owner %s",
                rid,
                owner_person_id,
            )
            ok = False
        if ok:
            deleted += 1
            if owner_person_id:
                deleted_owner_ids.append(owner_person_id)
        else:
            failed += 1

    if deleted_owner_ids:
        db.delete_sync_mapping_rows(
            share_id,
            owner,
            group_resource_name,
            recipient_email,
            owner_person_ids=deleted_owner_ids,
        )
    return {
        "checked": len(by_owner),
        "orphans": len(orphans),
        "deleted": deleted,
        "failed": failed,
    }


def _load_recipient_person(creds, recipient_person_id: str) -> dict[str, Any]:
    rid = normalize_person_resource_name(recipient_person_id)
    if not rid or creds is None:
        return {}
    try:
        person = (
            people_service(creds)
            .people()
            .get(resourceName=rid, personFields="metadata,photos")
            .execute()
        )
    except Exception:
        logger.exception("Failed to load recipient person %s", rid)
        return {}
    return person if isinstance(person, dict) else {}


def _apply_recipient_photo(
    creds,
    recipient_person_id: str,
    member_data: dict[str, Any],
    *,
    photo_hash: str,
    owner_token: str | None,
) -> bool:
    """Push or clear a recipient photo. Returns False when the photo step failed."""
    if photo_hash == "no-photo":
        return bool(delete_contact_photo(creds, recipient_person_id))
    return bool(
        set_contact_photo(
            creds,
            recipient_person_id,
            member_data,
            owner_token=owner_token,
        )
    )


def _propagate_to_siblings(
    *,
    owner: str,
    recipient_email: str,
    owner_person_id: str,
    member_data: dict[str, Any],
    contact_hash: str,
    photo_hash: str,
    owner_etag: str,
    photo_changed: bool,
    exclude_mapping_id: int | None,
    owner_token: str | None = None,
) -> int:
    creds = recipient_credentials(recipient_email)
    if not creds:
        return 0
    siblings = db.find_sibling_mappings(
        owner, recipient_email, owner_person_id, exclude_id=exclude_mapping_id
    )
    if not siblings:
        return 0
    recipient_ids = [
        normalize_person_resource_name(s.get("recipient_person_id") or "")
        for s in siblings
    ]
    recipient_ids = [rid for rid in recipient_ids if rid]
    etags = get_person_etags_batch(creds, recipient_ids)
    updated = 0
    for sibling in siblings:
        rid = normalize_person_resource_name(sibling.get("recipient_person_id") or "")
        etag = etags.get(rid)
        if not rid or not etag:
            continue
        try:
            if update_contact(creds, rid, member_data, etag):
                new_assignment_label = assignment_shared_group_name(member_data)
                old_assignment_label = str(sibling.get("last_assignment_label") or "")
                ensure_assignment_contact_label(creds, rid, member_data)
                remove_stale_assignment_label(
                    creds, rid, old_assignment_label, new_assignment_label
                )
                stored_photo_hash = str(sibling.get("last_photo_hash") or "")
                if photo_changed:
                    if _apply_recipient_photo(
                        creds,
                        rid,
                        member_data,
                        photo_hash=photo_hash,
                        owner_token=owner_token,
                    ):
                        stored_photo_hash = photo_hash
                    # Keep the previous hash on failure so the next sync retries.
                else:
                    stored_photo_hash = photo_hash
                db.upsert_sync_mapping(
                    share_id=str(sibling.get("share_id") or ""),
                    owner=owner,
                    group_resource_name=str(sibling.get("group_resource_name") or ""),
                    recipient_email=recipient_email,
                    owner_person_id=owner_person_id,
                    recipient_person_id=rid,
                    last_hash=contact_hash,
                    last_photo_hash=stored_photo_hash,
                    owner_etag=owner_etag,
                    last_assignment_label=new_assignment_label,
                )
                updated += 1
        except Exception:
            logger.exception("sibling propagate failed for %s", rid)
    return updated


def _apply_mapping_update(
    *,
    owner: str,
    mapping: dict[str, Any],
    member_data: dict[str, Any],
    owner_etag: str,
    owner_token: str | None = None,
) -> dict[str, Any]:
    recipient_email = str(mapping.get("recipient_email") or "")
    creds = recipient_credentials(recipient_email)
    if not creds:
        return {"status": "skipped", "reason": "not_connected", "mapping_id": mapping.get("id")}

    owner_person_id = str(mapping.get("owner_person_id") or "")
    contact_hash = compute_contact_hash(member_data)
    photo_hash = compute_photo_hash(member_data)
    prev_hash = str(mapping.get("last_hash") or "")
    prev_photo = str(mapping.get("last_photo_hash") or "")
    prev_etag = str(mapping.get("owner_etag") or "")
    recipient_person_id = str(mapping.get("recipient_person_id") or "")

    hash_changed = contact_hash != prev_hash
    photo_changed = photo_hash != prev_photo
    etag_changed = owner_etag != prev_etag

    if recipient_person_id:
        rid = normalize_person_resource_name(recipient_person_id)
        recipient_person: dict[str, Any] = {}
        if photo_hash != "no-photo":
            recipient_person = _load_recipient_person(creds, rid)
            if recipient_person and not has_custom_contact_photo(recipient_person):
                photo_changed = True
        if not hash_changed and not photo_changed and not etag_changed:
            live_etag = str(recipient_person.get("etag") or "")
            if not live_etag:
                live_etag = get_person_etags_batch(creds, [rid]).get(rid) or ""
            if not live_etag:
                live_etag, card_gone = _fetch_etag_or_gone(creds, rid)
                if not live_etag and not card_gone:
                    return {"status": "error", "reason": "etag_unavailable", "mapping_id": mapping.get("id")}
            if live_etag:
                return {"status": "skipped", "reason": "unchanged", "mapping_id": mapping.get("id")}
            # Mapped card is gone. Fall through and create it again.

        etag = str(recipient_person.get("etag") or "")
        if not etag:
            etag = get_person_etags_batch(creds, [rid]).get(rid)
        if not etag:
            etag, card_gone = _fetch_etag_or_gone(creds, rid)
            if not etag and not card_gone:
                # Rate limited or offline. Do not clear the mapping and create a copy.
                return {"status": "error", "reason": "etag_unavailable", "mapping_id": mapping.get("id")}
        if not etag:
            share_id = str(mapping.get("share_id") or "")
            group_resource_name = str(mapping.get("group_resource_name") or "")
            prev_assignment_label = str(mapping.get("last_assignment_label") or "")
            db.upsert_sync_mapping(
                share_id=share_id,
                owner=owner,
                group_resource_name=group_resource_name,
                recipient_email=recipient_email,
                owner_person_id=owner_person_id,
                recipient_person_id="",
                last_hash=prev_hash,
                last_photo_hash=prev_photo,
                owner_etag=prev_etag,
                last_assignment_label=prev_assignment_label,
            )
            recipient_person_id = ""
        else:
            new_assignment_label = assignment_shared_group_name(member_data)
            old_assignment_label = str(mapping.get("last_assignment_label") or "")
            if (
                old_assignment_label.strip()
                and new_assignment_label.strip()
                and old_assignment_label != new_assignment_label
            ):
                from .card_repair import queue_person_for_label_repair

                queue_person_for_label_repair(owner_person_id)
            if hash_changed or etag_changed:
                if not update_contact(creds, rid, member_data, etag):
                    return {"status": "error", "reason": "update_failed", "mapping_id": mapping.get("id")}
                ensure_assignment_contact_label(creds, rid, member_data)
                remove_stale_assignment_label(
                    creds, rid, old_assignment_label, new_assignment_label
                )
            stored_photo_hash = prev_photo
            photo_failed = False
            if photo_changed:
                if _apply_recipient_photo(
                    creds,
                    rid,
                    member_data,
                    photo_hash=photo_hash,
                    owner_token=owner_token,
                ):
                    stored_photo_hash = photo_hash
                else:
                    photo_failed = True
                    logger.warning(
                        "Recipient photo sync failed for %s -> %s; will retry next sync",
                        owner_person_id,
                        rid,
                    )

            share_id = str(mapping.get("share_id") or "")
            group_resource_name = str(mapping.get("group_resource_name") or "")
            db.upsert_sync_mapping(
                share_id=share_id,
                owner=owner,
                group_resource_name=group_resource_name,
                recipient_email=recipient_email,
                owner_person_id=owner_person_id,
                recipient_person_id=rid,
                last_hash=contact_hash,
                last_photo_hash=stored_photo_hash,
                owner_etag=owner_etag,
                last_assignment_label=new_assignment_label,
            )
            siblings = _propagate_to_siblings(
                owner=owner,
                recipient_email=recipient_email,
                owner_person_id=owner_person_id,
                member_data=member_data,
                contact_hash=contact_hash,
                photo_hash=photo_hash,
                owner_etag=owner_etag,
                photo_changed=photo_changed,
                exclude_mapping_id=int(mapping.get("id") or 0) or None,
                owner_token=owner_token,
            )
            result = {
                "status": "updated",
                "mapping_id": mapping.get("id"),
                "siblings": siblings,
            }
            if photo_failed:
                result["photo_failed"] = True
                result["reason"] = "photo_failed"
            return result

    if not recipient_person_id:
        recipient_data = db.get_app_data(recipient_email) or {}
        shared_groups = list(recipient_data.get("sharedGroups") or [])
        target = next(
            (
                g
                for g in shared_groups
                if g.get("owner") == owner
                and g.get("resourceName") == mapping.get("group_resource_name")
                and str(g.get("shareId") or "") == str(mapping.get("share_id") or "")
            ),
            None,
        )
        if not target:
            return {"status": "error", "reason": "group_not_found", "mapping_id": mapping.get("id")}

        group_name = str(target.get("name") or "Shared Group")
        group_id = _ensure_recipient_group(creds, target, group_name)
        if not group_id:
            return {"status": "error", "reason": "group_create_failed", "mapping_id": mapping.get("id")}

        rid = create_contact_in_group(creds, member_data, group_id, skip_photo=True)
        if not rid:
            return {"status": "error", "reason": "create_failed", "mapping_id": mapping.get("id")}

        stored_photo_hash = "no-photo"
        photo_failed = False
        if photo_hash != "no-photo":
            if _apply_recipient_photo(
                creds,
                rid,
                member_data,
                photo_hash=photo_hash,
                owner_token=owner_token,
            ):
                stored_photo_hash = photo_hash
            else:
                # Leave blank so the next incremental sync retries the photo.
                stored_photo_hash = ""
                photo_failed = True
                logger.warning(
                    "Recipient photo create failed for %s -> %s; will retry next sync",
                    owner_person_id,
                    rid,
                )
        else:
            stored_photo_hash = photo_hash

        new_assignment_label = assignment_shared_group_name(member_data)
        db.upsert_sync_mapping(
            share_id=str(mapping.get("share_id") or ""),
            owner=owner,
            group_resource_name=str(mapping.get("group_resource_name") or ""),
            recipient_email=recipient_email,
            owner_person_id=owner_person_id,
            recipient_person_id=rid,
            last_hash=contact_hash,
            last_photo_hash=stored_photo_hash,
            owner_etag=owner_etag,
            last_assignment_label=new_assignment_label,
        )
        ensure_contact_in_group(creds, rid, group_id)
        ensure_assignment_contact_label(creds, rid, member_data)
        result = {"status": "created", "mapping_id": mapping.get("id"), "recipient_person_id": rid}
        if photo_failed:
            result["photo_failed"] = True
            result["reason"] = "photo_failed"
        return result

    return {"status": "error", "reason": "unexpected_state", "mapping_id": mapping.get("id")}


def _record_mapping_outcome(
    summary: dict[str, Any], person_id: str, outcome: dict[str, Any]
) -> None:
    summary["results"].append({"person_id": person_id, **outcome})
    status = outcome.get("status")
    if status == "updated":
        summary["updated"] += 1
    elif status == "created":
        summary["created"] += 1
    elif status == "pruned":
        summary["pruned"] += 1
    elif status == "skipped":
        summary["skipped"] += 1
    elif status == "error":
        summary["errors"] += 1
        summary["error_details"].append(
            f"{person_id} mapping {outcome.get('mapping_id')}: {outcome.get('reason')}"
        )
    if outcome.get("relinked"):
        summary["relinked"] += 1
    if outcome.get("photo_failed"):
        summary["errors"] += 1
        summary["error_details"].append(
            f"{person_id} mapping {outcome.get('mapping_id')}: photo_failed"
        )


def sync_contact_changes(owner_email: str, owner_person_ids: list[str]) -> dict[str, Any]:
    """Push specific owner contacts to all mapped connected recipients."""
    owner = db.normalize_email(owner_email)
    person_ids = _normalize_person_ids(owner_person_ids)
    summary: dict[str, Any] = {
        "requested": len(person_ids),
        "updated": 0,
        "created": 0,
        "relinked": 0,
        "pruned": 0,
        "skipped": 0,
        "errors": 0,
        "pending": 0,
        "error_details": [],
        "results": [],
    }
    if not person_ids:
        return summary

    owner_creds = owner_credentials(owner)
    if not owner_creds:
        summary["errors"] = len(person_ids)
        summary["error_details"].append("Owner not signed in")
        return summary

    members_by_id = get_people_batch(owner_creds, person_ids)
    for person_id in person_ids:
        member_data = members_by_id.get(person_id)
        if not member_data:
            # CFS permanent delete removes the owner Google card first. That is
            # not an error: prune the recipient copies of that same person.
            for outcome in _prune_missing_owner_person(owner, person_id):
                _record_mapping_outcome(summary, person_id, outcome)
            continue

        owner_etag = str(member_data.get("etag") or "")
        _ensure_membership_group_resource_names(owner_creds, person_id, member_data)
        mappings = db.find_mappings_for_owner_person(owner, person_id)
        relinked_mappings = _relink_identity_mappings(
            owner=owner,
            owner_person_id=person_id,
            member_data=member_data,
        )
        if relinked_mappings:
            existing = {_mapping_key(item) for item in mappings}
            for item in relinked_mappings:
                key = _mapping_key(item)
                if key in existing:
                    mappings = [
                        mapping if _mapping_key(mapping) != key else item
                        for mapping in mappings
                    ]
                else:
                    mappings.append(item)
                    existing.add(key)

        # Existing mappings (Charlie, Emmy, ...) are not enough. A later
        # recipient of the same group, or a contact added back to AlMsLa,
        # still needs a create mapping.
        discovered = _discover_mappings_for_unmapped_contact(
            owner=owner,
            owner_person_id=person_id,
            member_data=member_data,
            owner_creds=owner_creds,
        )
        if discovered:
            existing = {_mapping_key(item) for item in mappings}
            for item in discovered:
                key = _mapping_key(item)
                if key not in existing:
                    mappings.append(item)
                    existing.add(key)
        if not mappings:
            from .app_data import patch_staged_shared_contacts_for_owner_person

            staged = patch_staged_shared_contacts_for_owner_person(owner, person_id, member_data)
            summary["skipped"] += 1
            summary["results"].append(
                {"person_id": person_id, "status": "no_mappings", "staged_patched": staged}
            )
            continue

        owner_token = str(owner_creds.token or "") or None
        for mapping in mappings:
            outcome = _apply_mapping_update(
                owner=owner,
                mapping=mapping,
                member_data=member_data,
                owner_etag=owner_etag,
                owner_token=owner_token,
            )
            if mapping.get("relinked"):
                outcome = {**outcome, "relinked": True}
            if outcome.get("status") == "skipped" and outcome.get("reason") == "not_connected":
                from .app_data import patch_staged_shared_contacts_for_owner_person

                staged = patch_staged_shared_contacts_for_owner_person(owner, person_id, member_data)
                outcome = {**outcome, "staged_patched": staged}
            _record_mapping_outcome(summary, person_id, outcome)

    return summary
